---
type: example
status: canonical
domain: [kubernetes]
derived_from:
  - "[[helm-deploy]]"
updated: 2026-07-16
---

# Service ingress thin

## When

Exposing a Service; Ingress only when edge routing requires it.

## When not

Public Ingress on every internal worker by default.

```yaml
# Service ClusterIP default; Ingress for declared edge routes only
```

## Related

- [[helm-deploy]] · [[policy-ingress-contract]]
