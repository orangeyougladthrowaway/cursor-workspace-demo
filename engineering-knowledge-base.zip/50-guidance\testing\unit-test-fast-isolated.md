---
type: guidance
status: canonical
id: engineering-knowledge-base-g-unit-fast
concern: testing
description: Practical unit-test craft — AAA, naming, avoid infra, maintainable assertions.
domain: []
aliases: [fast, isolated, aaa]
derived_from:
  - "[[unit-testing-norm]]"
updated: 2026-07-15
---

# Unit test fast isolated

## Applies when

Writing or reviewing unit-level tests (any language; MS examples are .NET-shaped).

## Guidance

From MS unit-testing best practices (D1 #2 primary):

1. Keep unit projects **free of infrastructure packages**; use fakes/stubs for seams.
2. Names should teach: scenario + expectation visible without opening production code.
3. **AAA** sections for readability — Act should be obvious; don’t bury asserts in setup.
4. Avoid testing private implementation; exercise the surface users (and honesty seams) use.
5. Prefer real or fake collaborators over heavy mocks when proving a seam ([[prove-honesty-contracts]]).

SE@Google ch12 adds: test **behaviours** (not methods bloated over time); keep tests complete and concise; DAMP over DRY.

## Related

- [[unit-testing-norm]] · [[tott-culture]] · [[delivery-gates]] · [[pytest-practices]]
