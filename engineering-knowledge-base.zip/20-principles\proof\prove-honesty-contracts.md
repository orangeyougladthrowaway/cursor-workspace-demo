---
type: principle
status: canonical
description: Prove the contracts that keep architecture and trust honest — not only happy-path functions.
id: engineering-knowledge-base-p-008
category: "[[proof]]"
derived_from:
  - "[[proof]]"
  - "[[ownership]]"
updated: 2026-07-17
---

# Prove honesty contracts

## Statement

Tests and delivery gates should protect the seams that preserve ownership, envelopes/contracts, and threat-model properties. A green suite that never touches those seams is weak evidence of health. Soft checks, skipped contract tests, and ghost suites that fail to collect are **not** proof — label them ([[delivery-gates]]).

## Rationale

Architecture and security bugs hide in “obvious” integration assumptions. Proving honesty contracts catches silent regression where READMEs lie.

## Encourages

- Contract tests for I/O shapes, deploy/secret paths, manifests, adapter boundaries
- Hard gates on behavioural proof that matters
- Naming skipped/soft gates next to any quality claim
- Prefer asserting **observable outcomes** (state) at honesty seams over brittle interaction/mocks of internals
- Prefer real implementations or fakes over heavy mocks when proving a seam; mocks only when the real dependency is slow, nondeterministic, or unsafe
- Own regression risk: if you liked a behaviour, put a test on it before unrelated infra/refactors are expected to catch it
- Treat well-named tests as **executable documentation** of behaviour — still not a substitute for colocated authority notes
- Review tests as code: they do not test themselves; reject brittle or vacuous assertions ([[code-review-norm]])
- Depending on unpublished observable behaviour across versions without a contract ([[published-contract-stability]])

## Prevents

- Docs-say / scripts-leak divergence
- Treating unenforced aspirational coverage, soft lint, or uncollected tests as the quality story
- “Theatre knobs” and unwired algos sold as live controls ([[hydra-config]], [[train-loop-ppo]])
- Green suites that only exercise happy-path units while privilege/contract/threat seams stay unproven
- Depending on unpublished observable behaviour across versions (**Hyrum’s Law**) without a contract
- Brittle change-detector / interaction-only tests mistaken for behaviour proof ([[tott-culture]])

## Evidence (thin)

Strongest where deploy/env and envelope contracts are tested; weaker where only compile gates or soft style gates exist — those gaps motivate this principle rather than redefine it.

## Related

- Category: [[proof]]
- [[fail-at-the-gate]] · [[threat-model-matched-controls]] · [[delivery-gates]]
- [[required-happy-path]] · [[happy-path-only]] · [[prove-honesty-contracts-in-delivery]]
- [[fail-at-the-gate]] · [[threat-model-matched-controls]] · [[delivery-gates]]
