---
type: example
status: canonical
domain: [docker]
derived_from:
  - "[[docker-containers]]"
updated: 2026-07-16
---

# Dockerignore layers thin

## When

Keeping build context small and cache-friendly.

## When not

Sending `.venv`/`node_modules` into every build context.

```text
# .dockerignore
.venv
.git
**/__pycache__
```

## Related

- [[docker-containers]]
