---
type: foundation
status: canonical
description: Principles that govern this knowledge bible itself.
updated: 2026-07-14
---

# Repository principles

These govern the **vault**, not application code. Change rarely.

## P1 — Single source of truth

One authoritative note per concept; link, don’t duplicate.

## P2 — Explicit justification

Non-trivial norms carry short rationale **in the note**. Preference without rationale isn’t doctrine.

## P3 — Abstraction before implementation

How-to derives from higher reasoning. Don’t invent stack-shaped “principles.”

## P4 — Separation of knowledge kinds

Philosophy, category, principle, standard, pattern, guidance stay distinct ([[knowledge-model]]).

## P5 — Minimal cognitive load

Short notes; one question each; sparse metadata.

## P6 — Knowledge over documentation theatre

Preserve judgement; link out for vendor facts. No encyclopaedia for its own sake.

## P7 — Evolve the living note

Update current doctrine when you learn. Don’t grow parallel histories inside the vault — Git is enough.

## P8 — AI-first navigation

Altitude × concern paths, typed frontmatter (`id`, `concern`, `domain`, `aliases`), unique catalogs/maps — see [[navigation]]. Structure beats guessing.

## P9 — Enter low, elevate carefully

New ideas start as guidance/pattern/draft until they earn a higher seat. Don’t crown a one-off as philosophy.

## P10 — Stable above changing

Isolate worldview from SDKs and tool churn.

## P11 — Category before leaf

Principles live under a category spine. New categories are rare and deliberate.

See [[layout]] and [[changing-this-bible]].
