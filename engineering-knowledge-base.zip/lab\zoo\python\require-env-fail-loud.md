---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[config-fail-at-load]]"
updated: 2026-07-17
---

# Require env fail loud

## When

Missing/invalid config should stop the process at startup.

## When not

Defaulting secrets/paths silently so the service “comes up broken.”

```python
import os

def require_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise SystemExit(f"missing required env: {name}")
    return value
```

## Related

- [[config-fail-at-load]] · [[fail-at-the-gate]] · [[required-happy-path]] · [[silent-fallback-anti]]
