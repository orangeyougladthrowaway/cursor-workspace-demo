---
type: example
status: canonical
domain: [github-actions]
derived_from:
  - "[[delivery-ci]]"
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Continue on error anti

## When

Naming soft theatre that paints green while quality fails.

## When not

Marketing CI green with `|| true` / `continue-on-error` as Done.

```yaml
# ANTI
- run: mypy . || true
  continue-on-error: true
```

## Related

- [[delivery-ci]] · [[delivery-gates]] · [[soft-mypy-anti]]
