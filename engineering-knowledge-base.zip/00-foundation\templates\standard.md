---
type: template
status: canonical
description: Starter template for standard notes.
updated: 2026-07-14
---

# Template — Standard

```markdown
---
type: standard
status: draft
id: engineering-knowledge-base-s-NNN
concern: delivery
description: ""
domain: []
aliases: []
derived_from: []
updated: YYYY-MM-DD
---

# Standard name

## Requirement

## Derived from

## Rationale

## Exceptions

## Related
```

Path: `30-standards/{concept}/{slug}.md`. See [[navigation]].
