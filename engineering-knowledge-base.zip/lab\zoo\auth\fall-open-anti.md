---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[gateway-auth]]"
  - "[[threat-model-declaration]]"
updated: 2026-07-15
---

# Fall open anti

## When

AuthZ must fail closed by default.

## When not

Fall-open Authorizer marketed as “secured.”

```text
ANTI: except: return allow
Prefer: deny + explicit threat-model lab exceptions only ([[threat-model-declaration]])
```

## Related

- [[gateway-auth]] · [[threat-model-matched-controls]] · [[owasp-top10-mapping]]
