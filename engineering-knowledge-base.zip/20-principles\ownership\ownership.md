---
type: category
status: canonical
description: Spine for ownership — where trust, secrets, and side effects may live.
id: engineering-knowledge-base-cat-ownership
derived_from:
  - "[[accountable-meaning-under-change]]"
updated: 2026-07-13
---

# Ownership

## Theme

Privileged capabilities and durable responsibility have **clear owners**. Feature work rides those rails.

## Belongs here

Principles about capability ownership, I/O walls, domain isolation from transport/vendors, and similar boundary constraints.

## Does not belong here

Domain isolation walls ([[boundaries]]); threat-model specifics ([[trust]]); proof of seams ([[proof]]).

## Leaves

- [[privileged-capability-ownership]]
