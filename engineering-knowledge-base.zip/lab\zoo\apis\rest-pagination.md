---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[rest-resource-design]]"
  - "[[rest-resource-design-norm]]"
updated: 2026-07-15
---

# Rest pagination

## When

Listing collections with documented page/cursor honesty.

## When not

Unbounded list endpoints as the default public API.

```text
Prefer documented pagination/filtering in the Spec ([[rest-resource-design]])
```

## Related

- [[rest-resource-design]] · [[rest-resource-design-norm]] · [[openapi-specification]]
