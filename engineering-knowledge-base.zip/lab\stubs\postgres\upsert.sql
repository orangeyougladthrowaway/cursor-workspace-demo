-- Postgres upsert stub — not production-ready.
-- Canons: [[postgres-sql-craft]] · [[postgres-core-concepts]]
-- Zoo: [[on-conflict-upsert]]

-- Requires a UNIQUE/PK on (id). Adjust columns to your model.

INSERT INTO example_item (id, name, updated_at)
VALUES ($1, $2, now())
ON CONFLICT (id) DO UPDATE
SET name = EXCLUDED.name,
    updated_at = now()
RETURNING id, name, updated_at;
