---
type: guidance
status: canonical
id: engineering-knowledge-base-g-rest
concern: apis
description: REST resource design — nouns, HTTP verbs, pagination, versioning, PUT idempotency.
domain: []
aliases: [rest, http, resource]
derived_from:
  - "[[boundaries]]"
  - "[[honesty]]"
  - "[[rest-resource-design-norm]]"
  - "[[published-contract-stability]]"
updated: 2026-07-16
---

# REST resource design

Primary (D1 #4 + D2 #7): [Azure REST API design best practices](https://learn.microsoft.com/en-us/azure/architecture/best-practices/api-design) — resource model + pagination/filtering + versioning (+ idempotency note).

## Applies when

Designing partner-facing HTTP — not internal Envelope RPC.

## Does not apply when

Internal Envelope `/call` peers — do not force REST pagination/versioning dialects onto RPC ([[public-http-vs-internal-envelope]]).

## House defaults

| Concern | House default (public HTTP) |
| --- | --- |
| Pagination | `limit`/`offset`; default **25** / **0**; **max limit 100** |
| Filtering | allow-listed query fields only; reject unknown/`fields` that escape the contract |
| Versioning | prefer **URI** `/v1/...` for partner APIs unless a lived product already chose another |
| Idempotency | **PUT** idempotent; POST creates; document any idempotency-key header if retries matter |
| Errors | stable problem shape (status + code/message); no stack traces to partners |

## Guidance

### Resource model (D1)

1. Organize around **resources** (nouns) with URIs; HTTP verbs carry the action.
2. Prefer **stateless** requests; collections and items have distinct URIs; keep relationships simple.
3. Do **not** mirror DB tables as resources; avoid chatty tiny-resource APIs.
4. Document status codes and representations; typical exchange format JSON over HTTP.

### Idempotency / pagination / versioning

5. **PUT** must be idempotent. POST/PATCH are not guaranteed idempotent.
6. Paginate large collections; impose a **max limit** (DoS / abuse).
7. Validate filter/sort/`fields` so clients cannot access hidden columns; sort params affect cache keys.
8. Publish an explicit version strategy; breaking schema changes need a version story.

## Collision

Envelope `service:method` is **RPC-shaped** internally — fine; do not dress it as REST without OpenAPI resource model. Envelope need not copy REST pagination/versioning dialects.

## Untapped

HATEOAS modelling standards · Range/partial GET deep · async request-reply patterns · full media-type versioning recipes.

## Related

- [[openapi-specification]] · [[public-http-vs-internal-envelope]] · [[published-contract-stability]] · [[apis-atlas]]
