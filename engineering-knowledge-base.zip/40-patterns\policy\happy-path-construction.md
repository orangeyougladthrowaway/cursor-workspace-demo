---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-012
concern: policy
description: Build one required construction path for config and control authority; fail closed — do not soft-recover into a second truth.
domain: []
aliases: [single-construction-path]
derived_from:
  - "[[required-happy-path]]"
  - "[[happy-path-only]]"
  - "[[fail-at-the-gate]]"
updated: 2026-07-17
---

# Happy path construction

Portable cousin of lived [[config-fail-at-load]]. Stack recipes stay there; this note is the abstract shape.

## Context

Services and tools need configuration, policy, and control authority before they can honestly serve. Agents and operators will treat “process up” as “configured correctly” unless construction fails closed.

## Problem

Missing required inputs tempt soft defaults, dual loaders, empty-policy allow, and immortal compat branches — systems that stay “up” while inventing truth.

## Forces

- Desire to be resilient and user-friendly
- Need for one reviewable authority artefact
- Migration pressure (old path still works)
- Lab/demo reduced controls vs production posture

## Solution

1. **Name the required inputs** for the control path (env, manifest, compiled artefact, trust root).
2. **Load once** on a single construction path at boot, compile, or explicit first-use cache — same artefact CI and runtime trust when compile is used.
3. **Hard-fail** invalid or missing required inputs; surface a structured error.
4. **Forbid** silent substitutes: no inventing secrets, no empty AuthZ ⇒ allow, no second unofficial loader taught as equal.
5. **Name** any soft path (extension skip, lab fall-open, migration dual path) in docs and threat model; bound migrations.

```text
required inputs → one loader/compile → valid artefact
                      ↓ invalid/missing
                 fail at gate (no soft continue)
```

## Consequences

**Easier:** Operators see real misconfiguration; agents cannot “fix” by adding a fallback; honesty seams are testable ([[prove-honesty-contracts]]).

**Harder:** Migrations need explicit dual-path hygiene; labs must declare reduced controls; fewer “helpful” conveniences.

**Watch:** Soft default chains; dual SoT; empty-policy allow; legacy compat that never dies — [[silent-fallback-anti]].

## Pattern statement

1. One happy-path construction for required authority.
2. Missing/invalid required inputs fail at the gate.
3. Soft paths are named exceptions — or they do not ship.

## Related

- [[required-happy-path]] · [[happy-path-only]] · [[config-fail-at-load]]
- [[policy-as-artefact]] · [[single-lived-source-of-truth]] · [[threat-model-declaration]]
- [[policy-ingress-contract]] · [[delivery-gates]] · [[silent-fallback-anti]]
