---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-langsec-secrets]]"
updated: 2026-07-15
---

# Compare digest

## When

Comparing secrets/tokens in constant-ish time.

## When not

`==` on secrets in hot auth paths.

```python
import secrets

def token_ok(provided: str, expected: str) -> bool:
    return secrets.compare_digest(provided, expected)
```

## Related

- [[python-langsec-secrets]] · [[secrets-token-urlsafe]]
