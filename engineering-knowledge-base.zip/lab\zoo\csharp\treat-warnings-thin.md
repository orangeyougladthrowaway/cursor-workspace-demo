---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-project-toolchain]]"
  - "[[delivery-gates]]"
updated: 2026-07-16
---

# Treat warnings thin

## When

Keeping analyzer warnings visible in CI.

## When not

Mass `#pragma warning disable` as the house style.

```xml
<TreatWarningsAsErrors>true</TreatWarningsAsErrors>
<!-- or explicit WarningsAsErrors list -->
```

## Related

- [[csharp-project-toolchain]] · [[delivery-gates]]
