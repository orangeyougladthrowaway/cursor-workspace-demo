---
type: principle
status: canonical
description: Prefer deterministic rules before constrained probabilistic steps; never let free-form model output drive control silently.
id: engineering-knowledge-base-p-011
category: "[[honesty]]"
derived_from:
  - "[[honesty]]"
  - "[[restraint]]"
updated: 2026-07-13
---

# Deterministic before probabilistic

## Statement

Use cheap deterministic logic first. Introduce probabilistic components (including LLMs) as constrained specialists behind schemas, thresholds, and explicit failure behaviour — not as ambient intelligence inside the control path.

## Rationale

Unbounded model output is an untrusted medium. Deterministic rails keep cost, latency, and correctness accountable.

## Encourages

- Regex/rule gates before inference; schema-bound I/O; temperature/policy as explicit config

## Prevents

- Narrative model text flowing into business decisions without validation
- “AI as architecture”

## Evidence (thin)

Clear regex-then-structured-inference design in service platforms. Product-domain prompt layouts are guidance later; coding-agent policy is still thin in source projects and belongs in future engineering-knowledge-base workflows.

**ReAct spine (wide):** interleaved **reason + act** (LLM thoughts + tool/env actions) is product-LLM pressure — still requires schema-bound I/O, explicit failure, and deterministic rails before free-form traces drive control ([[coding-agent-projection]]).

## Related

- Category: [[honesty]]
- [[fail-loud-on-control-paths]]
- [[policy-as-explicit-artefact]]
