---
type: example
status: canonical
domain: [github-actions]
derived_from:
  - "[[code-review-norm]]"
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Small cl tests

## When

Behaviour change and covering tests ship in the same change.

## When not

“Tests later” on logic changes.

```text
PR includes code + related tests together
```

## Related

- [[code-review-norm]] · [[unit-testing-norm]] · [[delivery-gates]]
