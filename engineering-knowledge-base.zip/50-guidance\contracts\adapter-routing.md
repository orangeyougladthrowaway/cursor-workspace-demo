---
type: guidance
status: canonical
id: engineering-knowledge-base-g-adapter
concern: contracts
description: Accumulated UniversalAdapter + metadata routing knowledge.
domain: [pytorch, python]
aliases: [universaladapter, game_type]
derived_from:
  - "[[adapter-metadata-routing]]"
updated: 2026-07-15
---

# Adapter routing

Atlas: [[trainer-atlas]]. Pattern: [[adapter-metadata-routing]]. Config: [[hydra-config]].

## Interface (`universal_trainer/adapters/adapter.py`)

Subclass must set `metadata` **before** `super().__init__()`.

Required metadata: `game_type` ∈ {pvp,pve,self_play,team}, `num_agents`, `supports_symbolic_state`, `action_space_type`, `observation_space_type`.

Required methods: `reset`, `step`, `get_observation_space_info`, `get_action_space_info`.

Duck-typed: `info["action_mask"]`, `get_action_mask`, `set_opponent_policy`, checkpoint slug metadata.

## Load

`load_adapter_from_cfg`: `class_path` OR `file_path`(+`class_name`/scan) OR assert. Validate metadata + space info dicts.

## Route

```text
game_type in {pvp, self_play, selfplay, multiagent, versus, …} → train_pvp
else → train_pve
```

**Conflict:** assert allows `team`; route aliases omit `team` → trains as PvE.

## Masking gap

Batched collect/eval masking practiced; default **PvP** `collect_rollout` path often **unmasked**.

## Add a game

Implement UniversalAdapter → metadata → file_path/class_path → optional GUI entry → prove reset smoke. Product demo games stay quarantine (not engineering law).

## Ghost tests

Tests importing missing adapters undercut “hard pytest” claims ([[trainer-packaging]]).

## Related

- [[adapter-metadata-routing]] · [[hydra-config]] · [[train-loop-ppo]] · [[trainer-atlas]]
