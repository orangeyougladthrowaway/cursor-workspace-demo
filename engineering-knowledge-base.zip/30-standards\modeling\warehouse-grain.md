---
type: standard
status: canonical
id: engineering-knowledge-base-s-018
concern: modeling
description: Warehouse grain declaration and column laws for facts, bridges, and dims.
domain: [warehouse, sql-server]
derived_from:
  - "[[declare-the-grain]]"
  - "[[atomic-grain-first]]"
updated: 2026-07-20
---

# Warehouse grain

## Normally require

For every serving fact or association table:

| Field | Test |
| --- | --- |
| Grain sentence | One row = … (business event / membership) |
| Grain key | Minimal uniqueness set; adding an independent id that changes cardinality ⇒ different grain |
| Cardinality outcomes | 1:N → child grain; M:N → association grain ([[grain-cardinality]]) |
| Columns true to grain | Each FK and measure single-valued at grain |
| One table per grain | No mixed grains |

## Column laws (binding)

1. **L1 Declare before design** — no Ready DDL without grain sentence.  
2. **L2 One table, one grain.**  
3. **L3 Columns true to grain** — if a column forces row duplication for the same event, it is wrong grain or belongs on a bridge.  
4. **L4 Grain key completeness** — documented uniqueness matches business grain.  
5. **L5 Atomic preference** ([[atomic-grain-first]]).  
6. **L6 Cardinality law** — M:N ⇒ new grain; 1:N ⇒ child absorbs parent.  
7. **L7 Measures law** — measures only if true (and additivity noted) at this grain.  
8. **L8 Multivalued law** — no repeating columns; use bridge (+ weights if allocating).  
9. **L9 SCD2 key law** — facts needing history use dim **surrogate**; current-serving loads document policy ([[snapshot-fact-shape]], [[scd2-dimension-envelope]]).  
10. **L10 No silent grain denormalisation** of measures.  
11. **L11 No second merge SoT** — ODS owns Type-2 **write**/merge. DWH dims may **mirror** SCD2 columns for joins; they must not run a parallel historisation engine ([[historisation-layers]], [[scd2-dimension-envelope]]).  
12. **L12 Ready bar** — grain, key, cardinality, measures, SCD2 join policy all stated.

## Refuse

- Adjective grain (“sales data”)
- Fact FK to natural key only across Type-2 history
- M:N exploded into fact rows that redefine the measurement

## Related

- [[design-warehouse-tables]] · [[dimensional-modeling-kimball]] · [[scd2-dimension-envelope]] · [[snapshot-fact-shape]]
