---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[adapter-routing]]"
updated: 2026-07-16
---

# Adapter routing zoo

## When

Routing through declared adapters at an edge.

## When not

Ad-hoc if/else vendor branching in domain code.

```text
Domain → adapter port → capability bridge ([[adapter-routing]])
```

## Related

- [[adapter-routing]] · [[adapter-metadata-routing]]
