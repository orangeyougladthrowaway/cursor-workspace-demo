---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-project-toolchain]]"
updated: 2026-07-15
---

# Bang operator sparingly

## When

Narrow boundary where the compiler cannot see an invariant you have proven.

## When not

`!` as the house “make mypy/.NET quiet” habit.

```csharp
// Prefer: annotations + checks
ArgumentNullException.ThrowIfNull(customer);
Process(customer);

// ANTI: Process(customer!); // silence without proof
```

## Related

- [[csharp-project-toolchain]] · [[csharp-style-conventions]]
