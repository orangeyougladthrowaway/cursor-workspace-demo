---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-project-toolchain]]"
updated: 2026-07-15
---

# Nullable enable

## When

Turning on nullable reference types so nullability is part of the public contract.

## When not

Sprinkling `!` everywhere instead of fixing annotations.

```csharp
string required = "ok";
string? optional = null;
if (optional is not null)
{
    _ = optional.Length;
}
```

## Related

- [[csharp-project-toolchain]] · [[csharp-style-conventions]]
