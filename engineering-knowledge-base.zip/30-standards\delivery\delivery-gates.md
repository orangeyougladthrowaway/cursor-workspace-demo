---
type: standard
status: canonical
id: engineering-knowledge-base-s-007
concern: delivery
description: "Distinguish hard delivery gates from soft/theatre checks; ban quality claims without matching hard gates."
domain: []
aliases:
  - ci-gates
  - hard-soft-gates
derived_from:
  - "[[prove-honesty-contracts]]"
  - "[[prove-honesty-contracts-in-delivery]]"
  - "[[fail-at-the-gate]]"
updated: 2026-07-17
---

# Delivery gates

## Requirement

1. Every active system lists which checks **fail the change** (hard) vs **report only / skipped / `|| true`** (soft).
2. Claims such as “strict types”, “≥90% coverage”, “auth matrices enforced”, or “production-ready quality” are **forbidden** unless the matching check is hard-gated (or the claim is removed).
3. Honesty-seam proofs (envelope/wrapper tests, config compile, schema/Helm generate) prefer **hard** gates when those seams are load-bearing.
4. Soft gates may exist for migration; they must be labelled soft in docs and PR checks — never as the primary quality story.
5. Conflicting workflows (one hard ruff, one soft ruff) must be resolved or documented so “green CI” is unambiguous.
6. Agent or human **“done”** claims require evidence matching this standard: tests that fail without the change and pass with it when behaviour changes; soft/theatre checks must not be cited as proof ([[prove-honesty-contracts]]). Bug fixes: reproduce with a failing test before the fix when practical.
7. Behaviour/logic changes ship with **related tests in the same change**. Independent coverage of pre-existing code may land first; do not land behavioural changes with a “tests later” story. Prefer **small, self-contained changes** and durable CL descriptions ([[code-review-norm]]).
8. Do not “fix” a red gate by skipping the check, deleting the test, or converting hard→soft without updating this honesty map. Prefer shift-left: cheaper checks fail earlier.
9. **Coverage % is not the quality story.** Soft/absent coverage thresholds (see platform snapshot) must not be marketed as “≥N% covered quality.” Prefer hard gates on honesty seams over vanity line coverage. (.NET guidance agrees: high coverage ≠ high quality.)
10. Prefer unit tests that are **fast, isolated, repeatable, self-checking** (Microsoft unit-testing spine). Honesty-seam and integration proofs stay hard where load-bearing — units alone are not enough ([[prove-honesty-contracts-in-delivery]]).
11. **Delivery throughput pressure (DORA spine):** five software-delivery metrics (change lead time, deployment frequency, failed-deployment recovery time, change fail rate, deployment rework rate) orient improvement. Speed and stability correlate for high performers — metrics are guidance, **not** Goodhart goals. They do **not** license silencing hard gates or rewriting soft checks as quality.
12. **CI feedback timing (SE@Google ch23, D2 #16):** catch failures as early as cheap/reliable tests allow. Presubmit runs **fast, reliable** suites (typically small/unit scoped to the changed project). Slow, flaky, or environment-heavy suites move to **post-submit**, release-candidate, or staging — do not bloated-block every change with exhaustive E2E on every PR.
13. Distinguish **true head** (latest commit) from **green head** (latest commit verified by continuous build). Prefer cutting release candidates from green when the pipeline supports it; emergency cuts from true head require an explicit minimal confidence suite.
14. CI feedback must be **accessible and actionable** (clear per-test signal, logs findable, flake classification when possible) — a red blob with undecipherable logs is soft theatre with worse UX.
15. Temporarily disabling/suppressing failing tests to keep a suite usable requires **tracked ownership** (bug/hotlist) and cleanup — silent `# skip` or soft-gate conversion without updating this honesty map is forbidden (aligns with §8).
16. **Silent runtime fallbacks** that conceal missing required config or broken control contracts are **forbidden** as a delivery quality story — same honesty bar as soft gates ([[required-happy-path]], [[happy-path-only]]).

Primary for §12–15: [*Software Engineering at Google* — Continuous Integration](https://abseil.io/resources/swe-book/html/ch23.html).

## Platform snapshot

| Seam | Compose dual-plane | Compose single-plane | K8s gateway family |
| --- | --- | --- | --- |
| Ruff | Hard (`ruff check . --line-length 99`) | Hard (scoped paths: `lib services domain tests deploy scripts`) | Hard in `build-multi-path.yml`; **soft** in `test.yml` (`\|\| true` + `continue-on-error: true`) |
| Unit tests | Hard (+ Postgres 15 CI service) | Hard | Hard |
| Mypy | Hard process, soft config (`strict=false`, `ignore_missing_imports=true`, tests excluded) | **Absent** in CI (configured for `domain.<product>.*` strict; never run) | Soft (`\|\| true` / `head -20 \|\| true`) despite `strict=true` in `pyproject.toml` |
| Black | Absent in CI (dep only) | Absent in CI (dep only) | Never in CI |
| Coverage threshold | Soft/absent — collected, no `--cov-fail-under` | Soft/absent — no `--cov` at all | Soft/absent — Codecov upload with `fail_ci_if_error: false` |
| Envelope/wrapper/gateway-layer units | Hard | Hard | Hard |
| Product config compile | **Hard** — `domain.<product>.build_config` in CI, Docker image, and deploy | N/A (no compile step exists) | **Hard** — Helm `generate-manifests.sh` + `tests/test_manifests.py` |
| Deploy/Docker contract tests (string/file asserts, not live boot) | Hard — `test_deploy_env_contract.py`, `test_caddy_edge.py`, `test_db_driver_contract.py` | Hard — `test_deploy_contract.py` | N/A (helm/manifest tests cover this role instead) |
| Auth.yaml / AuthZ enforcement | Theatre | Theatre | Theatre |
| Import-layer / domain purity | Ungated (no import-linter in any of the three) | Ungated | Ungated |
| Integration / full compose | Absent (no job, no `tests/integration/` tree) | Absent (marker exists, excluded by default, no tests present) | Partial — hard in `test.yml` only; `build-multi-path.yml` has no integration job |
| Pre-commit | Absent (no `.pre-commit-config.yaml`) | Absent | Absent |
| Image build gating | Hard on `main` push only; PR builds no images | Hard on `main` push only | Hard on `main` push only; PR builds no images |
| Smoke / E2E demo proof in CI | Absent from CI (manual post-deploy script only) | Absent from CI | Absent from CI |

Job-resolution header tests are **skipped** in the K8s repo (`test_app_gateway_job_resolution.py`) — a contract hole under CI that a "hard unit tests" claim should not paper over.

## Derived from

- [[prove-honesty-contracts-in-delivery]]
- [[fail-at-the-gate]]

## Exceptions

Throwaway spikes under an explicit lab threat model may run soft-only — named in [[threat-model-declaration]]. Demo token (dual-plane `verify_demo_token`) and edge basic auth (dual-plane Caddy `/home/*`) are genuinely **hard, narrow** application-level gates; their existence does not license treating the broader `auth.yaml`/Authorizer RBAC claim as enforced — a real gate on one path is not proof of a real gate on all paths.

## Warehouse / SSDT

SQL Server warehouse builds add a seam not covered by the platform snapshot above: schema-compile CI is easy to make hard-gated, but it proves compile only.

| Seam | Status | Notes |
| --- | --- | --- |
| DACPAC compile (PR + release workflows) | Hard | Fails on restore/build error or zero `.dacpac` output |
| SqlPackage publish (data-loss guards, ordering) | Ungated | Not run in CI at all; destructive-publish defaults are never checked |
| SCD2 / merge-proc correctness | Absent | No SQL unit tests (tSQLt or equivalent); no assertions on tombstone/dual-current invariants |
| Fact/dim DDL ↔ load-proc column contract | Absent | Drift between a table's DDL and its load proc's INSERT list is not caught by CI |
| Release checksum integrity | Produced, not verified | Checksums are written into the release bundle by CI; nothing in the activation path checks them |

"CI is green" for a warehouse repo means the schema compiles — treat it as a distinct claim from "the release is safe to publish" or "the merge/load procs are correct." Detail: [[warehouse-historisation]], [[dacpac-publish]], [[host-activation]], [[tsql-set-based-merge]].

## Related

- [[prove-honesty-contracts]] · [[config-fail-at-load]] · [[single-lived-source-of-truth]]
- [[required-happy-path]] · [[happy-path-only]]
- [[delivery-ci]] · [[envelope-call]] · [[dora-metrics]] · [[unit-testing-norm]]
- [[platform-atlas]] · [[warehouse-atlas]] · [[trainer-atlas]] · [[delivery-atlas]]
