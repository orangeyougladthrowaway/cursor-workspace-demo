---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-007
concern: policy
description: "Schema-as-code compiles to versioned DACPACs; ordered multi-DB publish; one activation SoT."
domain:
  - sql-server
  - ssdt
aliases:
  - dacpac
  - sqlpackage
  - schema-as-code
derived_from:
  - "[[policy-as-artefact]]"
  - "[[fail-at-the-gate]]"
  - "[[config-fail-at-load]]"
updated: 2026-07-15
---

# Compiled schema release

Stack detail: [[dacpac-publish]] · [[host-activation]]. Atlas: [[warehouse-atlas]]. Cousin of [[config-fail-at-load]]. Which **git tip** to build for an env is [[sql-env-release-assembly]] · [[sql-server-env-branches]]; which **schema model** (state vs additive) is [[schema-change-models]].

## Context

Multiple SQL Server databases (landing, history, marts, control) must ship together without hand-editing live schemas.

## Problem

Click-ops schema drift; unordered publishes break cross-DB refs; competing “current” activation stories confuse operators.

## Forces

- Reviewable schema-as-code
- Compile proveable in CI
- Ordered publish across DBs
- Lab may allow destructive publish; history stores must not silently inherit that forever
- One activation authority (clone vs release zip — pick one)

## Solution

1. Each database is a **sqlproj** (Microsoft.Build.Sql, DSP `Sql170`/SQL Server 2025) — schema is the artefact source; files auto-included, not hand-listed ([[ssdt-sqlproj]]).
2. **CI compiles** Release builds and asserts `.dacpac` outputs; versioned bundle (+ checksums) on main.
3. **Publish** with SqlPackage in **fixed order** (landing → history → marts → reports → control last with SQLCMD vars) using named **publish profiles** ([[ssdt-publish-scripts]], [[dacpac-publish]]).
4. Optional **version marker** skip if already deployed (`db-last-deployed.txt` style).
5. **PreDeploy / PostDeploy** — one entry script each; fragments via `:r`; excluded from model build; restrained on history tiers ([[ssdt-publish-scripts]]).
6. Pick **one** activation authority and document it as the only one; do not let a second path linger "just in case" (see Watch — this repo has not done this yet).

### CI compile gate (lived shape)

| Workflow | Trigger | Steps | Hard fail on |
| --- | --- | --- | --- |
| PR build | `pull_request` → main | checkout → setup-dotnet → NuGet cache → `dotnet restore <solution>` → `dotnet build -c Release` per sqlproj | restore/build error; zero `.dacpac` produced under the databases folder |
| Release on main | `push` → main | same Release build → package dacpacs + `manifest.json` + `checksums.sha256` into a versioned zip (plus service/host bundles) → upload as release assets | packaging/upload failure |

Compile-gate honesty: a green compile build proves the schema builds, **not** that SqlPackage publish succeeds, that data-loss guards are on, or that downstream load procs match the DDL they read from. Treat "CI is green" and "release is correct" as two separate claims — see [[delivery-gates]].

### SqlPackage publish properties (name the defaults)

| Property | Lab-convenient default | Effect | Safe-for-history setting |
| --- | --- | --- | --- |
| `CREATE_NEW_DATABASE` / `CreateNewDatabase` | `True` | Drops and recreates the target DB before publish — **erases all history** in a Type-2 database | `False` once a durable tier holds real history |
| `BLOCK_ON_DATA_LOSS` / `BlockOnPossibleDataLoss` | `False` | Allows destructive column/type changes to apply silently | `True` for any DB that must not lose data |
| `DROP_OBJECTS_NOT_IN_SOURCE` | `True` | Drops target objects absent from source | Scope narrowly or turn off for shared/manual objects |
| `ALLOW_TABLE_RECREATION` | `True` | Permits full table recreation for otherwise-blocked changes | Off once recreation would imply data loss |

These are lab-only defaults. Copying them into a "release profile" for a warehouse whose durable tier is supposed to survive redeploys is the anti-pattern — comments acknowledging the danger are not the same as fixing the default.

### Version marker / skip-redeploy

1. Derive a version fingerprint: prefer `manifest.json` `"version"`, fall back to a hash of `checksums.sha256`, fall back to a hash of the dacpac file list.
2. Compare against a state file (e.g. `db-last-deployed.txt`) from a prior run.
3. Equal → skip publish, exit 0.
4. After a successful publish loop, write the new fingerprint to the state file.

This only protects against redundant publishes of an *identical* bundle — it is not a data-safety control and does not substitute for `BlockOnPossibleDataLoss`.

### Debug vs Release build split

Container/host build tooling commonly builds `Debug` configuration into a local bundle directory (fast local loop), while CI builds `Release` for the versioned artefact. Same schema sources, different output folders and potentially different MSBuild-conditional items. Without an equality/parity check between the two, "it built locally" and "the release bundle is identical" are separate, unverified claims.

## Consequences

**Easier:** Same compile CI and runtime trust; ordered multi-DB; rollback via prior artefact.

**Harder:** Windows agents; SqlPackage profile honesty; Debug local vs Release CI drift.

**Watch (do not elevate as virtue):**

- `BlockOnPossibleDataLoss=False` / `CreateNewDatabase=True` / drop-not-in-source against a durable history DB.
- **Dual activation SoT that both remain "practiced."** It is not enough to observe that a clone/pull path and a release-zip/symlink path both have working scripts — if neither has been decommissioned, the system has two competing sources of truth for "what is live," and an operator can activate one while the other's state file / symlink says something else. Document which one is canonical and mechanically retire (not just out-document) the other.
- Soft `|| true` wrapped around a deploy or service-restart step in an activation script — a "successful" refresh can mask a failed publish or a failed restart.
- Checksums **produced** by CI (`checksums.sha256` in the release bundle) but never **verified** on the consuming side — packaging integrity theatre.
- No publish dry-run / plan review step in CI before a destructive-capable publish reaches a real environment.
- Hollow reporting projects (an empty sqlproj still in the publish order, or a UI that queries placeholder SQL) sold as "the reporting layer."

## Pattern statement

1. Schema-as-code → compiled artefacts → ordered publish.
2. Control/orchestrator DB publishes last, with SQLCMD variables wired to the other databases' names.
3. CI hard-gates compile of load-bearing projects; it does not gate publish safety or cross-DB data contracts.
4. Name destructive lab profiles; do not reuse them blindly on history stores.
5. One activation SoT — quarantine dual, undocumented, or merely-coexisting paths; "both have scripts" is not the same as "one is canonical."
6. Cousin of app config compile: same “artefact + gate” idea, different toolchain.

## Related

- [[dacpac-publish]] · [[ssdt-sqlproj]] · [[ssdt-publish-scripts]] · [[host-activation]] · [[warehouse-atlas]]
- [[schema-change-models]] · [[sql-env-release-assembly]] · [[sql-server-env-branches]]
- [[config-fail-at-load]] · [[historisation-layers]] · [[delivery-gates]] · [[single-lived-source-of-truth]] · [[ssis-dtproj-dtsx]]
