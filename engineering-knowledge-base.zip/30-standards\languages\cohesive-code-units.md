---
type: standard
status: canonical
id: engineering-knowledge-base-s-015
concern: languages
description: Source units stay cohesive and easy to scan; split by responsibility, not arbitrary size limits.
domain: []
aliases: [cohesion, source-structure]
derived_from:
  - "[[programming-over-time]]"
  - "[[extend-established-patterns]]"
  - "[[boundaries]]"
  - "[[restraint]]"
updated: 2026-07-16
---

# Cohesive code units

## Requirement

Files, types, functions, methods, and SQL objects must each have a clear primary responsibility and a name that reveals it.

Normally:

1. Keep one **primary abstraction level** inside a callable. Extract lower-level detail when it obscures the operation being described.
2. Group code that changes for the same reason; split code with independent responsibilities or ownership.
3. Put the public contract and normal reading path before private implementation detail where the language permits.
4. Follow established local structure unless it damages clarity or violates higher doctrine ([[extend-established-patterns]]).
5. Do not use line counts, method counts, or “one class per file” as universal correctness rules. Treat size as a prompt to inspect cohesion.
6. Prefer a small explicit unit over a reusable abstraction with only one speculative caller.

## Decision test

Split or extract when at least one is true:

- The unit needs two unrelated names to describe it.
- A block has a stable, meaningful name and can be tested independently.
- Nesting or interleaved side effects hide the main operation.
- Different owners or change rates repeatedly collide in the same unit.
- A type mixes boundary translation, domain decisions, and external I/O.

Keep together when separation would create pass-through indirection, scatter one invariant, or make the normal path harder to read.

## Rationale

Cohesion makes code navigable across time and authors. Arbitrary micro-files and universal size limits can reduce navigability as easily as god units do.

## Exceptions

Generated code, framework-required partial types, migration bundles, and tightly coupled tiny value types may use different physical grouping. Name the reason; do not generalise the exception.

## Related

- [[readable-control-flow]] · [[code-review-norm]] · [[domain-free-of-transport-io]] · [[languages-atlas]]
