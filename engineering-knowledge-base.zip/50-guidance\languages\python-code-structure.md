---
type: guidance
status: canonical
id: engineering-knowledge-base-g-py-structure
concern: languages
description: Python source structure — cohesive modules, explicit public surfaces, typed callables, and deliberate model choices.
domain: [python]
aliases: [module-structure, class-layout, function-shape]
derived_from:
  - "[[cohesive-code-units]]"
  - "[[python-style-pep8]]"
  - "[[python-typing-honesty]]"
  - "[[domain-free-of-transport-io]]"
updated: 2026-07-16
---

# Python code structure

## Applies when

Organising Python modules, classes, functions, and data shapes inside an installable package.

## Does not apply when

Choosing repository/install layout ([[python-packaging-layout]]) or transport-specific boundaries.

## House defaults

### Names and files

| Element | Normally use |
| --- | --- |
| Package/module/file | `snake_case`; leading `_` for intentionally private modules |
| Class/protocol/exception | `PascalCase`; exceptions end in `Error` |
| Function/method/local | `snake_case`; predicates read as questions |
| Constant | `UPPER_SNAKE_CASE` |

One module should own one coherent responsibility. Python does **not** require one class per file: colocate tightly related protocols, small value types, exceptions, and helpers when that improves discovery.

### File shape

Prefer this scan order when present:

1. Useful module docstring
2. Standard-library, third-party, then local imports
3. Constants and type aliases
4. Public protocols/types/functions/classes
5. Private helpers
6. Explicit entrypoint guard

Keep `__init__.py` small: expose a deliberate public surface; do not hide substantial execution or import-cycle work there.

### Functions and classes

1. Prefer a module-level function when no durable state or polymorphic contract is needed.
2. Use a class for owned state, invariants, lifecycle, or interchangeable behaviour—not as a namespace.
3. Within a class: class data → constructor/factories → properties → public methods → private helpers. Keep related dunder methods near the behaviour they support when that reads better.
4. New production callables should normally be fully annotated. Public/package boundaries require annotations; prototypes may remain gradual only when the typed-quality claim stays honest ([[python-typing-honesty]]).
5. Prefer keyword-only parameters when several same-typed options would be ambiguous. Replace growing boolean flags with named operations or policy objects.

## Data-shape choices

| Need | Prefer |
| --- | --- |
| Behaviour-free value carrier | `@dataclass`, often `frozen=True` when immutable |
| Tiny immutable positional record | `NamedTuple` only when tuple behaviour is useful |
| JSON-shaped mapping without runtime validation | `TypedDict` |
| Untrusted wire/config input | Pydantic/runtime validator at the edge |
| Behaviour, identity, invariants, lifecycle | Plain class |
| Structural capability contract | `Protocol` |

Do not duplicate wire, ORM, and domain models automatically. Split them when validation, persistence, or domain invariants genuinely differ ([[python-logging-modeling]]).

## Related

- [[python-flow-choices]] · [[python-packaging-layout]] · [[python-typing-honesty]] · [[python-logging-modeling]] · [[languages-atlas]]
