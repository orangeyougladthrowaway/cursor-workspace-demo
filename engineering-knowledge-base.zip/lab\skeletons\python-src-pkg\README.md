---
description: Minimal Python src-layout package skeleton — cites packaging/pytest canons.
updated: 2026-07-15
---

# python-src-pkg

## Purpose

Copy-out starter for a small installable Python package using **src layout** + editable install + pytest importlib mode.

## Required canons

- [[python-packaging-layout]]
- [[pytest-practices]]
- [[python-typing-honesty]] (optional hard mypy — only if gated)
- [[delivery-gates]]

## Copy steps

1. Copy this folder into a new repo root (or merge files).
2. Rename `mypkg` / project name in `pyproject.toml`.
3. `python -m venv .venv` → activate → `pip install -e ".[dev]"`.
4. `pytest`.

## Honesty

- Unit pytest should be a **hard** gate if you claim quality.
- Do **not** ship `mypy … || true` while claiming typed ([[delivery-ci]] anti-pattern).
- Dual Poetry+pip without a lock is quarantine ([[trainer-packaging]]) — this skeleton uses pip + pyproject only.
