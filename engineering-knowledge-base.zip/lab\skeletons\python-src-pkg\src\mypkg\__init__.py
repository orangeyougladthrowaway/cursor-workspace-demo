"""Minimal package marker."""

__version__ = "0.1.0"


def hello(name: str) -> str:
    return f"Hello {name}"
