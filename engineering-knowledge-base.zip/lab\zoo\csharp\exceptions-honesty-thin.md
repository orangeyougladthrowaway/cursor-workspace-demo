---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-async-di]]"
updated: 2026-07-16
---

# Exceptions honesty thin

## When

Failing closed on unexpected errors at boundaries.

## When not

Catch-all that returns success defaults.

```csharp
try { await WorkAsync(ct); }
catch (OperationCanceledException) { throw; }
// ANTI: catch (Exception) { return Ok(); }
```

## Related

- [[csharp-async-di]] · [[fail-loud-on-control-paths]]
