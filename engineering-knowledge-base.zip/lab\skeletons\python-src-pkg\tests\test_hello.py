from mypkg import hello


def test_hello() -> None:
    assert hello("engineering-knowledge-base") == "Hello engineering-knowledge-base"
