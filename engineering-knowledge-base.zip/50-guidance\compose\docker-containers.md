---
type: guidance
status: canonical
id: engineering-knowledge-base-g-docker
concern: compose
description: Container craft — one process, non-root USER, multi-stage, healthcheck, lean layers.
domain: [docker, compose]
derived_from:
  - "[[ownership]]"
  - "[[failure]]"
  - "[[compose-deploy]]"
  - "[[service-packaging]]"
updated: 2026-07-19
---

# Docker containers


Primary (D1 #7): [Docker — What is a container?](https://docs.docker.com/get-started/docker-concepts/the-basics/what-is-a-container/).

## Applies when

Packaging lab/VM/K8s runtimes with Compose or comparing containers vs VMs.

## Does not apply when

- Treating “containerised” as automatic AppSec or least privilege
- Stuffing multiple daemons into one image as the default topology

## House defaults

1. A container is an **isolated process** with its filesystem/deps — not a guest OS. Multiple containers share the **host kernel**.
2. **One primary process / capability per image** — map optional deps via extras ([[service-packaging]]), not fat mega-images.
3. **Local-tool owners** (e.g. OCR bridge): install the OS package set the capability needs **in the Dockerfile** (binary + config-selected language/data packs). Python extras do not replace that layer; durable fix is image rebuild — not one-shot `apt` in a live container ([[service-packaging]], [[credential-owning-bridge]]).
4. Run as **non-root** when the process allows (`USER` numeric UID after chown of needed dirs). Isolation ≠ AppSec ([[owasp-top10-mapping]]).
5. Prefer **multi-stage** builds: build tools in a builder stage; copy artefacts into a slim runtime stage.
6. Declare **HEALTHCHECK** (or rely on orchestrator probes) so restart policy has a signal — do not claim readiness without one.
7. Keep **`.dockerignore`** tight (`.git`, venvs, tests, local secrets) so context/layers stay lean.
8. **Lab/throwaway peer images** (fake upstreams, one-file stubs) may omit multi-stage builds and `HEALTHCHECK` when named as lab-only in Compose/README — still prefer non-root `USER` when practical. Runtime/service images do not inherit that exception.
9. **In-container one-offs match the image package root.** Images set `WORKDIR` / install layout (often `/app` as import root). Running `docker compose exec … python /app/scripts/….py` without that root on `PYTHONPATH` (or without `python -m …` as the service CMD does) yields `ModuleNotFoundError` for `lib` / package names. Prefer the same invocation shape as production; do not invent a second import path for ops scripts ([[python-packaging-layout]], [[service-packaging]]).

```dockerfile
FROM python:3.12-slim AS runtime
WORKDIR /app
COPY --from=builder /app/dist /app
USER 65532:65532
HEALTHCHECK CMD curl -fsS http://127.0.0.1:8000/health || exit 1
```

## Decision rules

| Concern | Prefer |
| --- | --- |
| Deps by role | extras → image ([[service-packaging]]) |
| Local-tool OS deps | Dockerfile apt (or equivalent) for binary + selected lang packs; verify list-langs / missing-traineddata before claiming OCR ready |
| Runtime identity | non-root `USER` |
| Build vs run | multi-stage (runtime images) |
| Readiness signal | `HEALTHCHECK` or orchestrator probes (runtime images) |
| Lab packaging | Compose profiles ([[compose-deploy]]); thin stubs OK if named lab-only |
| One-off scripts in the container | Same package root as image CMD (`PYTHONPATH` or `python -m`); not cwd accidents |

## Untapped

Networking/volumes deep · Docker Deep Dive · CNCF courses · rootless daemon encyclopaedia.

## Related

- [[compose-deploy]] · [[service-packaging]] · [[python-packaging-layout]] · [[credential-owning-bridge]] · [[capability-bridges]] · [[helm-deploy]] · [[infrastructure-atlas]]
