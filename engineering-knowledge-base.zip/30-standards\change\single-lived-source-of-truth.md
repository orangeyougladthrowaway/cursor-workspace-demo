---
type: standard
status: canonical
id: engineering-knowledge-base-s-008
concern: change
description: Each deployable system has one lived source of truth for activation/deploy; dual SoTs are named debt until retired.
domain: []
aliases: [activation-sot, deploy-sot]
derived_from:
  - "[[colocated-authority]]"
  - "[[extend-established-patterns]]"
  - "[[fail-at-the-gate]]"
updated: 2026-07-17
---

# Single lived source of truth

## Requirement

1. For each deployable system (app platform, warehouse host, trainer packaging story), name **one** activation/deploy path as the **lived** source of truth.
2. Competing paths (clone vs zip, bare `helm install` vs regenerate-and-apply, dual package managers sold as both official) must be either **retired** or explicitly labelled **non-authoritative residue** — not left as co-equal “practiced” instructions. Unnamed dual construction is forbidden under [[required-happy-path]].
3. Operator docs and scripts that disagree with the lived SoT are updated or demoted in the **same change** that establishes the SoT ([[colocated-authority]]).
4. CI/release artefacts should match the SoT consumers use (Debug-only local vs Release-only release without parity is a related honesty debt — name it).

## Rationale

Two “working” paths that disagree are worse than one thin path: they teach false completeness and hide which tree is live.

## Lived pressure (illustrative — not the standard body)

| System | Dual SoT pressure | Guidance |
| --- | --- | --- |
| Warehouse host | clone/pull vs zip+symlink both scripted | [[host-activation]] |
| K8s platform | regenerate manifests + apply vs bare helm install | [[helm-deploy]] |
| Trainer install | pip+requirements (+CUDA) vs Poetry without lock | [[trainer-packaging]] |

## Exceptions

Lab spikes may keep a second path briefly while migrating — date it and delete or quarantine by a deadline.

## Related

- [[colocated-authority]] · [[compiled-schema-release]] · [[config-fail-at-load]] · [[delivery-gates]]
- [[required-happy-path]] · [[happy-path-only]] · [[silent-fallback-anti]]
- [[host-activation]] · [[helm-deploy]] · [[platform-atlas]] · [[warehouse-atlas]]
