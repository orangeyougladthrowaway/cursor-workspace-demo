---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-009
concern: boundaries
description: Fowler smart-endpoints / dumb-pipes — compare to central policy ingress.
domain: []
aliases: [microservices, dumb-pipes]
derived_from:
  - "[[microservices-tradeoffs]]"
updated: 2026-07-15
---

# Smart endpoints dumb pipes contrast

## Context

Microservice literature favours domain logic at endpoints with minimal central orchestration.

## Problem

Blind adoption conflicts with deliberate **central policy ingress** ([[policy-ingress-contract]]).

## Solution

Use as **comparison**, not mandate. Document when central ingress wins (uniform auth, audit, envelope) vs true peer services.

## Related

- [[modular-monolith-default]] · [[architecture-atlas]]
