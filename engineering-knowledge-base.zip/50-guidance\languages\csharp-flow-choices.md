---
type: guidance
status: canonical
id: engineering-knowledge-base-g-cs-flow
concern: languages
description: C# flow choices — guards, switch forms, loops, LINQ, lambdas, async, and measured memory craft.
domain: [csharp, dotnet]
aliases: [guards, foreach, switch]
derived_from:
  - "[[readable-control-flow]]"
  - "[[csharp-linq-api]]"
  - "[[csharp-async-di]]"
  - "[[restraint]]"
updated: 2026-07-16
---

# Csharp flow choices

## Applies when

Choosing how a C# method validates, branches, queries, iterates, or introduces asynchronous work.

## House defaults

### Guards and branches

1. Establish argument and state preconditions at the top when an early guard leaves a linear happy path (`ArgumentNullException.ThrowIfNull` where suitable).
2. Use a switch **expression** for pure, exhaustive value mapping; use a switch statement when branches perform effects or need multiple steps.
3. Prefer positive conditions for normal alternatives; use negative guards for rejected/absent cases.
4. Name compound predicates. Do not compress business decisions into nested ternaries.
5. Prefer explicit result/domain types when absence or failure is expected; do not use null or exceptions as an undocumented mode flag.

### LINQ, loops, lambdas

| Need | Prefer |
| --- | --- |
| Pure query/projection with readable operators | LINQ |
| State, effects, logging, retry, early `break`/`continue` | `foreach` / explicit loop |
| Stable snapshot or repeated enumeration | materialise deliberately |
| Tiny local selector/predicate | lambda |
| Reused, multi-step, or separately testable operation | named method |
| Remote provider query | `IQueryable` with translation awareness |

Keep LINQ projections side-effect free. Stop chaining when named intermediate values or a loop reveal the decision better ([[csharp-linq-api]]).

### Async and memory

Use async for I/O and pass `CancellationToken`; do not wrap synchronous work in `Task.Run` merely to expose an async signature. Use `Task.WhenAll` for independent bounded work; avoid unobserved fire-and-forget tasks ([[csharp-async-di]]).

Keep ordinary collection code until profiling shows allocation/copy pressure. Then choose Span/Memory according to lifetime; never Span across an await ([[csharp-span-memory]]).

### Errors and resources

Throw meaningful exceptions at failed boundaries; do not catch only to log and silently continue. Keep `using`/`await using` close to the owned resource. Translate exceptions only where the abstraction meaning changes.

## Exceptions

Provider limitations, framework callbacks, and measured hot paths may require less direct forms. Contain the exception and test its semantics.

## Related

- [[csharp-code-structure]] · [[csharp-linq-api]] · [[csharp-async-di]] · [[csharp-span-memory]] · [[languages-atlas]]
