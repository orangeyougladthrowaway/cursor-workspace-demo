---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-sql-craft]]"
updated: 2026-07-15
---

# Window partition

## When

Per-group ranking/ordering without collapsing rows.

## When not

Putting window functions directly in `WHERE` (filter in outer query/CTE).

```sql
SELECT *,
       row_number() OVER (PARTITION BY dep ORDER BY salary DESC) AS rn
FROM emp;
```

## Related

- [[postgres-sql-craft]]
