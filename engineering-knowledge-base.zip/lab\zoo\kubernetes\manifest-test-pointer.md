---
type: example
status: canonical
domain: [kubernetes]
derived_from:
  - "[[delivery-gates]]"
  - "[[helm-deploy]]"
updated: 2026-07-15
---

# Manifest test pointer

## When

Generated manifests deserve hard tests, not lint-only green.

## When not

“`helm lint` green” as the sole ship proof.

```text
generate-manifests + tests/test_manifests.py → hard gate
```

## Related

- [[delivery-gates]] · [[helm-deploy]] · [[prove-honesty-contracts]]
