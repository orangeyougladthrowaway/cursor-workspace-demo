---
type: example
status: canonical
domain: [argo]
derived_from:
  - "[[argo-workflows]]"
  - "[[historisation-layers]]"
updated: 2026-07-15
---

# Outer stage grain

## When

Argo owns outer workflow/stage grain — not warehouse domain procs.

## When not

Putting all business historisation logic only in workflow YAML.

```text
Platform stages → [[argo-workflows]]
Warehouse ETL   → SQL procs / [[historisation-layers]]
```

## Related

- [[argo-workflows]] · [[historisation-layers]] · [[warehouse-historisation]]
