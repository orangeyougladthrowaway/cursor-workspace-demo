---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[adapter-metadata-routing]]"
updated: 2026-07-16
---

# Adapter metadata zoo

## When

Routing uses adapter metadata contracts.

## When not

Hidden header conventions without a documented contract.

```text
Metadata keys declared → [[adapter-metadata-routing]]
```

## Related

- [[adapter-metadata-routing]] · [[policy-ingress-contract]]
