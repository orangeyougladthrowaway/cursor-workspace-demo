---
type: guidance
status: canonical
id: engineering-knowledge-base-g-owasp-password
concern: auth
description: OWASP Password Storage — slow hash + salt; hash≠encrypt; collide with lived mesh (often no passwords).
domain: []
aliases: [password-storage, argon2, bcrypt]
derived_from:
  - "[[owasp-authentication-pressure]]"
  - "[[gateway-auth]]"
updated: 2026-07-15
---

# OWASP password storage pressure

Primary (D2 #1): [OWASP Password Storage Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html).

## Applies when

Storing or verifying **user/app passwords** (product AuthN, admin UIs, partner portals). Not when the product is service-mesh actors only — still document the absence.

## Guidance (claims elevated)

1. **Never** store plaintext passwords. Prefer **slow, adaptive** hashing — not fast general hashes (SHA-256 alone is unsuitable for password storage).
2. Prefer algorithm order: **Argon2id** → scrypt → bcrypt (legacy) → PBKDF2 when FIPS/NIST constrained.
3. OWASP baseline (tune to host): Argon2id min ~**19 MiB**, **t=2**, **p=1** (or sheet-equivalent CPU/RAM trade-offs); scrypt N≥2^17 when Argon2 unavailable; bcrypt work factor ≥10 and respect **72-byte** input limit; PBKDF2-HMAC-SHA-256 ≥**600,000** iterations when required.
4. Use **unique per-password salt** (modern libs usually manage this). Optional **pepper** (shared secret, stored off-DB) is defense-in-depth — not a substitute for slow hashing.
5. Prefer **hash** over encrypt for passwords; encrypt only for rare “must recover plaintext” bridges — redesign when possible.
6. Keep verification cost **under ~1s** on the server; raise work factors over time on next successful login; plan legacy MD5/SHA-1 upgrades (re-hash on auth or expire).
7. Do not invent home-grown crypto; use vetted library APIs.

## Collision with lived gateway

| Sheet pressure | Lived ([[gateway-auth]]) |
| --- | --- |
| Password hashing SoT | Mesh often has **no password store** (actor / optional JWT) |
| Argon2id / work factors | N/A until a human identity edge exists |
| Pepper + secrets vault | Applies when product AuthN lands — not theatre on empty `auth.yaml` |

**Resolution:** password-storage law binds **human-credential surfaces**. Mesh-only lab continues under named threat model; claiming “OWASP-compliant AuthN” without this sheet’s controls is dishonest.

## Untapped

MFA cheat sheet · Forgot Password · Cryptographic Storage · Secrets Management · bcrypt pre-hash edge cases deep.

## Related

- [[owasp-authentication-pressure]] · [[owasp-top10-mapping]] · [[security-atlas]]
