---
type: example
status: canonical
domain: [helm]
derived_from:
  - "[[helm-deploy]]"
updated: 2026-07-16
---

# Resources limits thin

## When

Setting requests/limits for predictable scheduling.

## When not

Unlimited burstable pods as the silent default in shared clusters.

```yaml
resources:
  requests: { cpu: "100m", memory: "128Mi" }
  limits: { memory: "256Mi" }
```

## Related

- [[helm-deploy]]
