---
type: index
status: canonical
id: engineering-knowledge-base-root
description: Entry point — engineering bible (majority common-case ambition) + subordinate lab praxis.
updated: 2026-07-16
---

# Engineering Knowledge Base (engineering-knowledge-base)

The engineering bible — accumulated craft, standards, and patterns for house work, with coding-agent rails. Not a history archive; not a task centre.

> **New here? Start from the [agent-harness](../agent-harness/README.md) hub.** It is the single entry point for the workspace: it classifies your task, retrieves the right knowledge, and runs one workflow at a time. Use it before editing this vault directly.

**Two planes:** **doctrine** (living law under `00`–`60` + `maps/`) and **praxis** (`lab/` — examples and skeletons that cite the canon).

**Ambition:** cover the majority of common cases for house languages and tools, scored on [[common-case-coverage]] (Axis F). Seeding a facet is not the same as finishing it.

## Organising questions

1. What **altitude** of knowledge?
2. What **responsibility folder**?
3. Which **family atlas**? (`maps/families/…`)
4. Which **stack** facets? (`domain` / `aliases`)
5. How **covered** is this track? → [[common-case-coverage]]
6. Need an **exemplar**? → [[lab-atlas]] after the canon

## Start here

| Note | Role |
| --- | --- |
| [[navigation]] | Navigation constitution |
| [[methodology]] | Note shape, naming, linking |
| [[changing-this-bible]] | Amend / retire / cleanliness |
| [[catalog-maps]] | Family / theme atlases |
| [[common-case-coverage]] | Majority coverage scoreboard (Axis F) |
| [[lab-atlas]] | Praxis index (examples / skeletons) |
| [[purpose]] | Why this exists |
| [[scope]] | In/out (includes praxis + matrices) |
| [[layout]] | Folders |
| [[knowledge-model]] | Types |
| [[dependency-rules]] | Dependency direction |
| [[roadmap]] | Axes W/D/L/P/F |

For platform depth open [[platform-atlas]]. Cross-cutting themes: [[catalog-maps]] → `maps/themes/`.

Agents: [[coding-agent-projection]] · [[plan-engineering-change]] · [[build-engineering-change]] · [[verify-engineering-change]] · [[review-engineering-change]] · [[praxis-ingestion]] · product template [[agents-projection]] · root `AGENTS.md`. Vault health: [[vault-health-checks]] (`pytest tests/ -v` and `pytest tests/lab -v` when lab changes).

## Agents

Follow `.cursor/rules/engineering-knowledge-base-authority.mdc` and root `AGENTS.md`. Prefer atlases + responsibility notes over inventing playbooks. Invoke skills `engineering-knowledge-base-plan` / `engineering-knowledge-base-build` / `engineering-knowledge-base-test` / `engineering-knowledge-base-review` as thin pointers to lifecycle workflows. Open lab only after the canon; never treat zoo as sole law. Full-coverage asks → [[common-case-coverage]], not quiet scope shrink.
