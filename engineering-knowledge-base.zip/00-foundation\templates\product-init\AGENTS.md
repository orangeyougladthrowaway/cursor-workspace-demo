# Agent notes — <product-name>

## Engineering authority

Canonical engineering knowledge lives in the **Engineering Knowledge Base (engineering-knowledge-base)**.

- **engineering-knowledge-base path (edit one):** `.engineering-knowledge-base` (gitignored junction) **or** `../engineering-knowledge-base`
- engineering-knowledge-base is the **primary source** for how this repo is engineered.
- External research is allowed for domain gaps; **engineering-knowledge-base rules win** on house engineering when sources disagree.
- Do **not** invent parallel doctrine here. Do **not** edit/commit engineering-knowledge-base from this workspace.

## Operating law (always)

1. **Retrieve before build** — navigation → atlas → canonical notes → then code.
2. **Lab last** — `lab/maps/lab-atlas.md` only after canons; never sole law.
3. **Cite ids** for load-bearing house choices.
4. **Hard gates** for any quality claim; no `continue-on-error` / `|| true` quality theatre.
5. **No `product-init/` folder** left in this tree after setup.

## Start here (paths relative to engineering-knowledge-base root)

- Family atlas: `maps/families/<platform|warehouse|trainer>/<name>-atlas.md`
- Navigation: `00-foundation/navigation.md`
- Agent protocol: `60-workflows/knowledge/coding-agent-projection.md`
- Coverage: `60-workflows/knowledge/common-case-coverage.md`
- Code craft (when writing modules): `cohesive-code-units`, `readable-control-flow`, plus language structure/flow notes via `languages-atlas`

## Load-bearing ids (replace)

- `engineering-knowledge-base-s-007` — delivery gates honesty
- `engineering-knowledge-base-s-008` — single lived SoT
- `engineering-knowledge-base-s-015` — cohesive code units
- `engineering-knowledge-base-s-016` — readable control flow
- `engineering-knowledge-base-g-py-pkg` — src-layout + pin/lock (if Python)

## This repo’s stack facets

<!-- e.g. python, compose, helm, sql-server, postgres -->

## Quarantine (do not elevate)

Soft CI as quality · fall-open AuthZ · dual deploy/activation SoTs · host-brand cloud as universal law · product lore as architecture · bulk third-party skill packs as a second bible · leftover `product-init/` template folders

## Optional skills

`.cursor/skills/` = invoke-only. Point at engineering-knowledge-base `id`s / workflows. Never paste engineering-knowledge-base note bodies.

Preferred lifecycle skills (when present in the engineering-knowledge-base mount): `engineering-knowledge-base-plan` · `engineering-knowledge-base-build` · `engineering-knowledge-base-test` · `engineering-knowledge-base-review` → workflows `plan-engineering-change`, `build-engineering-change`, `verify-engineering-change`, `review-engineering-change`.
