---
type: guidance
status: canonical
id: engineering-knowledge-base-g-py-pkg
concern: languages
description: Python packaging layout — src vs flat; editable installs; pin or lock app deps; lived extras elsewhere.
domain: [python]
aliases: [src-layout, pyproject, lockfile]
derived_from:
  - "[[honesty]]"
  - "[[proof]]"
  - "[[pytest-practices]]"
  - "[[service-packaging]]"
updated: 2026-07-16
---

# Python packaging layout

Primary (L-py #2): [PyPA — src layout vs flat layout](https://packaging.python.org/en/latest/discussions/src-layout-vs-flat-layout/) (+ [[pytest-practices]] integration practices).

## Applies when

Choosing import-package layout for libraries or service packages (not image-extras matrices — those stay [[service-packaging]]).

## House default

Prefer **`src/` + editable install** for new distributeable packages:

```text
repo/
  pyproject.toml
  src/
    mypkg/
      __init__.py
      __main__.py          # optional CLI
  tests/
```

`pip install -e .` then pytest with `importlib` mode ([[pytest-practices]]) so tests import the installed package, not cwd accidents.

## Guidance

1. **Flat layout** puts import packages at repo root; **src layout** nests them under `src/`. Src forces an install so tests run against the *installed* import path.
2. Flat layout is acceptable for some apps, but cwd-first `sys.path` can silently import the working tree — treat as a known hazard.
3. Declare metadata in **`pyproject.toml`**; invoke tests via pytest / tox, not deprecated setuptools test runners.
4. **Console entrypoints** / `__main__` belong to the packaging story — document the install path operators actually use.
5. Tooling honesty: one install story. Dual Poetry+pip without a lock as “both official” remains quarantine ([[trainer-packaging]]).
6. **App/service dependency honesty:** pin direct runtime deps **or** commit a lockfile (`uv.lock` / `requirements.txt` freeze / equivalent). Open lower-bounds alone (`fastapi>=0.115` with no lock) are not a reproducible install story for house apps. Libraries may keep looser ranges when they are published for reuse — still document the story.

## Collision with lived

[[service-packaging]] answers *extras-by-image*. This note answers *import/layout* (+ app pin/lock). Do not duplicate extras tables here.

## Untapped

Full PyPA packaging flow · uv-as-only-SoT policy · namespace packages deep · wheel/sdist CI publish · private index allowlists.

## Related

- [[pytest-practices]] · [[service-packaging]] · [[trainer-packaging]] · [[python-typing-honesty]] · [[languages-atlas]]
