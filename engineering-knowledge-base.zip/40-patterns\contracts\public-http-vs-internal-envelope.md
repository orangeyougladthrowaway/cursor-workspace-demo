---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-010
concern: contracts
description: Coexist public HTTP/OpenAPI with internal Envelope /call — one published shape per boundary.
domain: []
aliases: [openapi, public-api]
derived_from:
  - "[[boundaries]]"
  - "[[honesty]]"
  - "[[policy-ingress-contract]]"
  - "[[rest-resource-design-norm]]"
updated: 2026-07-16
---

# Public HTTP vs internal envelope

## Context

Products may expose partner REST while platforms use Envelope internally.

## Problem

Dual dialects without a named job become integration debt and honesty gaps ([[published-contract-stability]]).

## Solution

1. **Internal** platform spine: Envelope v1 on `POST /call` ([[envelope-call]]).
2. **External** product edge: OpenAPI-described resource HTTP where that is the product ([[openapi-specification]], [[rest-resource-design]]).
3. Adapters translate at the edge — domain cores stay transport-free ([[domain-io-edge-packaging]], [[domain-free-of-transport-io]]).

## Adapter checklist

| Check | Pass means |
| --- | --- |
| Boundary named | public REST vs internal `/call` are labeled jobs, not one muddled surface |
| One publish shape per consumer class | partners get OAS; mesh peers get Envelope |
| Mapping owned | adapter owns status/error/shape translation; domain does not |
| Version story | public versioning ≠ Envelope method renames by accident |
| Auth posture | gateway/policy ingress applies at the correct edge ([[gateway-auth]]) |

## Consequences

Clear consumer contracts; explicit mapping cost; forbids pretending `/call` is REST.

## Related

- [[rest-resource-design-norm]] · [[apis-atlas]] · [[policy-ingress-contract]] · [[adapter-routing]]
