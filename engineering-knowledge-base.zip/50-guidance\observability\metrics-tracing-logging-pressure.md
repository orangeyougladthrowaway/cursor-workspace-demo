---
type: guidance
status: canonical
id: engineering-knowledge-base-g-otel
concern: observability
description: OTEL traces + metrics signals — spans/context/instruments; cardinality hazards; lived gaps named.
domain: []
aliases: [metrics, tracing, logging, otel]
derived_from:
  - "[[honesty]]"
  - "[[reliability]]"
  - "[[delivery-gates]]"
  - "[[dora-capabilities-index]]"
updated: 2026-07-16
---

# Metrics tracing logging pressure

Primary (D1 #9 primer + D2 #11): [OTEL Observability primer](https://opentelemetry.io/docs/concepts/observability-primer/), [Traces](https://opentelemetry.io/docs/concepts/signals/traces/), [Metrics](https://opentelemetry.io/docs/concepts/signals/metrics/).

## Applies when

Evaluating operability beyond CI gate honesty and JSON-wrapped `/metrics`.

## House wire path (honest)

| Layer | House state |
| --- | --- |
| Metrics text `/metrics` | often practiced (sometimes awkwardly wrapped) |
| Tracing extras in packaging | present ≠ wired ([[service-packaging]]) |
| Full OTEL SDK → Collector | **named debt** until a family wires it end-to-end |
| SLI/SLO program | intentional thin (V06 / [[dora-metrics]]) |

Do not claim observability done because an optional `tracing` extra exists.

## Guidance

### Primer (D1)

1. **Observability** = ask novel questions from outside — needs instrumentation. Signals: traces, metrics, logs. Reliability ≠ uptime alone (SLI→SLO).

### Traces (D2 #11)

2. A **trace** is the end-to-end path of a request; **spans** are units of work with hierarchy via `parent_id` / shared `trace_id`.
3. Pipeline pieces: **TracerProvider** → **Tracer** → spans; **exporters** to Collector/backends; **context propagation** stitches distributed spans.
4. Spans carry attributes, events (point-in-time), optional links (async/causal), and status (`Unset` default success; `Error`; explicit `Ok` rare). Prefer semantic attributes.
5. Span kinds hint assembly: Client/Server/Internal/Producer/Consumer.

### Metrics (D2 #11)

6. **MeterProvider** → **Meter** → instruments: Counter, UpDownCounter, Gauge, Histogram (+ async variants).
7. Metrics are **aggregates** over a window (unlike request-lifecycle traces). **Views** customize aggregation/attributes.
8. **Cardinality limits** (SDK default ~2000 combinations): high-card attributes (user IDs, raw URL paths) cause overflow into `otel.metric.overflow=true` — totals preserved, attribute-filtered queries/alerts can undercount. Prefer resource attributes for constant process identity.

## Collision with lived

Prometheus text awkwardly wrapped; tracing extras unwired ([[envelope-call]], [[service-packaging]]) — **named debt**. DORA monitoring/observability capability pressure: [[dora-capabilities-index]].

## Untapped

Logs signal deep · Collector pipelines · language SDK install recipes · sampling strategies.

## Related

- [[dora-metrics]] · [[dora-capabilities-index]] · [[microservice-prerequisites]] · [[observability-atlas]]
