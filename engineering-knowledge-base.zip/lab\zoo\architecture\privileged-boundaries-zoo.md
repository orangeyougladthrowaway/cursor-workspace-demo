---
type: example
status: canonical
domain: [architecture]
derived_from:
  - "[[privileged-capability-boundaries]]"
updated: 2026-07-16
---

# Privileged boundaries zoo

## When

Keeping privileged capabilities behind clear boundaries.

## When not

Spreading elevated credentials across app tiers.

```text
→ [[privileged-capability-boundaries]] · [[ownership]]
```

## Related

- [[privileged-capability-boundaries]] · [[credential-owning-bridge]]
