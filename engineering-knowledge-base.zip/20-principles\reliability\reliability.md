---
type: category
status: canonical
description: Spine for reliability — expect failure; design for observable recovery.
id: engineering-knowledge-base-cat-008
derived_from:
  - "[[failure]]"
updated: 2026-07-15
---

# Reliability

## Theme

Systems fail partially and asynchronously. Reliability is **honest expectation management** plus **recoverable design** — not uptime theatre.

## Belongs here

Distributed failure, storage durability trade-offs, replication/consistency pressure (remote sources).

## Does not belong here

Delivery throughput metrics ([[delivery-gates]], [[dora-metrics]]); lived WAL detail ([[observer-wal]]).

## Leaves

- [[distributed-systems-expectations]]
- [[durable-storage-tradeoffs]]
