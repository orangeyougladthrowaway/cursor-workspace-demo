---
type: example
status: canonical
domain: [kubernetes]
derived_from:
  - "[[kubernetes-hard-way-pedagogy]]"
updated: 2026-07-15
---

# Hard way not sot

## When

Separating education clusters from lived deploy paths.

## When not

Treating tutorial clusters as house source of truth.

```text
Practiced surfaces → [[helm-deploy]] · [[compose-deploy]]
```

## Related

- [[kubernetes-hard-way-pedagogy]] · [[helm-deploy]]
