---
type: guidance
status: canonical
id: engineering-knowledge-base-g-py-typing
concern: languages
description: Python typing — gradual annotations, mypy honesty; soft CI mypy is not typed quality.
domain: [python]
aliases: [mypy, type-hints]
derived_from:
  - "[[honesty]]"
  - "[[proof]]"
  - "[[delivery-gates]]"
  - "[[python-style-pep8]]"
updated: 2026-07-16
---

# Python typing honesty

Primary (L-py #1): [mypy — Getting started](https://mypy.readthedocs.io/en/stable/getting_started.html) (+ [typing module](https://docs.python.org/3/library/typing.html) as reference surface).

## Applies when

Adopting or claiming static types in Python services/tools ([[delivery-ci]]).

## Guidance

1. **Annotations change what checkers see**, not runtime behaviour (unless you opt into runtime validators). Unannotated functions are treated as dynamically typed — mypy will often report little until hints exist.
2. Adopt **incrementally**: annotate stable public APIs and honesty seams first; prototype may stay dynamic. Escalate with `--disallow-untyped-defs` / `--strict` when the package is ready — not as theatre in `pyproject` alone.
3. Prefer precise ABCs over rigid containers when intent is “iterable of T” (`Iterable[str]` vs only `list[str]`). Use `|` unions (3.10+) and narrowing (`isinstance`) deliberately.
4. Third-party code without types needs **stubs** (`types-*`) or explicit ignore strategy — `ignore_missing_imports` without a plan hides real holes.
5. Protocols / structural typing for duck-typed seams; TypedDict for JSON-shaped dicts when a model class is too heavy. Keep **Pydantic/runtime models** for wire validation — do not pretend mypy alone validates HTTP bodies. At JSON boundaries: `json.loads` → TypedDict/model validate → domain types — never sprinkle `dict[str, Any]` through the core.
6. **Honesty:** `strict = true` in config while CI runs mypy with `|| true` / truncated output is **soft theatre** ([[delivery-gates]], [[delivery-ci]]). Claim “typed codebase” only when the matching check is **hard**.

## Collision with lived

K8s/platform soft mypy vs README/pyproject strict voice — quarantine already named; this note is the language-side law.

## Untapped

PEP 484/544 encyclopaedia · pyright vs mypy house choice · stubgen workflows · pydantic v2 deep typing.

## Related

- [[delivery-gates]] · [[delivery-ci]] · [[python-packaging-layout]] · [[pytest-practices]] · [[languages-atlas]]
