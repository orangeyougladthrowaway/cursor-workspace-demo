---
type: example
status: canonical
domain: [helm]
derived_from:
  - "[[helm-deploy]]"
updated: 2026-07-16
---

# Helm rollback thin

## When

Using Helm history/rollback after a bad release.

## When not

Editing cluster objects by hand as the recovery SoT.

```bash
helm rollback release 1
# Prefer chart+values fix forward when safer
```

## Related

- [[helm-deploy]]
