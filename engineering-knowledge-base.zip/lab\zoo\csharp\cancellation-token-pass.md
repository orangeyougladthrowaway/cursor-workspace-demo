---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-async-di]]"
updated: 2026-07-15
---

# Cancellation token pass

## When

Async I/O or timed work that callers must be able to abort.

## When not

Dropping `CancellationToken` at service boundaries “for simplicity.”

```csharp
public async Task<string> FetchAsync(Uri url, CancellationToken ct)
{
    using var response = await _http.GetAsync(url, ct);
    return await response.Content.ReadAsStringAsync(ct);
}
```

## Related

- [[csharp-async-di]] · [[unit-testing-norm]]
