---
type: category
status: canonical
description: Spine for trust — controls match the declared threat model; no theatre, no ambient privilege.
id: engineering-knowledge-base-cat-005
derived_from:
  - "[[accountable-meaning-under-change]]"
updated: 2026-07-13
---

# Trust

## Theme

Security controls match an **explicit threat model**. Avoid production cosplay in demos and avoid ambient reachability where trust should be enumerated.

## Belongs here

Threat-model fit, allow-lists, exposure posture at principle altitude — not vendor checklists.

## Does not belong here

Where secrets physically live (ownership → [[ownership]]); contract tests for seams ([[proof]]).

## Leaves

- [[threat-model-matched-controls]]
