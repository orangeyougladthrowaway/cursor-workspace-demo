---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-sql-craft]]"
updated: 2026-07-15
---

# On conflict upsert

## When

Atomic insert-or-update on a unique key/constraint.

## When not

Guessing `ON CONFLICT` target without a matching unique index/constraint.

```sql
INSERT INTO t (id, name)
VALUES (1, $1)
ON CONFLICT (id) DO UPDATE
SET name = EXCLUDED.name
RETURNING id;
```

## Related

- [[postgres-sql-craft]] · [[postgres-core-concepts]]
