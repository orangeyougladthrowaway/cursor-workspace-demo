---
type: example
status: canonical
domain: [delivery]
derived_from:
  - "[[coverage-not-quality]]"
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Coverage not quality zoo

## When

Treating coverage % as a diagnostic signal.

## When not

Marketing soft coverage or `--cov-fail-under` theatre as the Done story.

```text
Coverage informs risk — it does not replace behaviour proof
See [[coverage-not-quality]]
```

## Related

- [[coverage-not-quality]] · [[delivery-gates]] · [[unit-testing-norm]]
