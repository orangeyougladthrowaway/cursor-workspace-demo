---
type: guidance
status: canonical
id: engineering-knowledge-base-g-ddd
concern: modeling
description: DDD strategic pressure — ubiquitous language and bounded context for naming, not folder trees.
domain: []
aliases: [ddd, domain-driven-design]
derived_from:
  - "[[bounded-context-language]]"
updated: 2026-07-15
---

# Domain driven design pressure

## Applies when

Naming services, modules, Envelope methods, and ownership boundaries.

## Guidance

1. **Ubiquitous language** and **bounded context** pressure align vocabulary with ownership ([[bounded-context-language]]).
2. Do **not** invent an L1 folder per bounded context — amend [[navigation]] only when a concern truly lacks a home.
3. Pair with [[modular-monolith-default]] and [[microservices-tradeoffs]]: DDD naming is orthogonal to deploy-topology fashion.

## Untapped

Evans · Vernon · event storming · aggregates deep.

## Related

- [[domain-io-edge-packaging]] · [[architecture-atlas]]
