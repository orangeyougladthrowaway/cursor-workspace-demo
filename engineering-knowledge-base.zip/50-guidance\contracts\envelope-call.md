---
type: guidance
status: canonical
id: engineering-knowledge-base-g-envelope
concern: contracts
description: Accumulated Envelope v1 /call contract knowledge from gateway platforms.
domain: [python, fastapi, kubernetes]
aliases: [envelope, /call, wire-contract]
derived_from:
  - "[[policy-ingress-contract]]"
updated: 2026-07-19
---

# Envelope call

Accumulated wire knowledge from K8s gateway family, Compose single-plane, and Compose dual-plane. Portable shape: [[policy-ingress-contract]]. Atlas: [[platform-atlas]].

## Envelope v1

**K8s path:** `framework/platform_core/envelopes.py`  
**Compose path:** `lib/contracts/envelopes.py` (same shape)

### Request fields

| Field | Constraint |
| --- | --- |
| `envelope_version` | `Literal["1.0"]` |
| `kind` | `Literal["request"]` |
| `schema_version` | two-part string e.g. `"1.0"` |
| `trace_id` | 1–256 chars |
| `request_id` | 1–256 chars |
| `actor` | must start with `service:` or `user:` |
| `timestamp` | `datetime` |
| `target` | expects `service`, `method` |
| `payload` | `dict` — gate Validator rejects falsy / `{}` |
| `metadata` / `tags` | default `{}` |

### Response

Same identity fields + `status` ∈ {`success`,`error`} + `payload` XOR `error` (`code`, `message`, `retryable`).

**ErrorCode enum (K8s):** `framework/platform_core/errors.py` — AUTH_*, VALIDATION_*, ROUTING_ERROR, TIMEOUT, etc. with `is_retryable()` / `http_status_code()`.

Wire literals fixed at `"1.0"`; no envelope v2 in tree.

**API honesty spine:** consumer-facing HTTP APIs may use OpenAPI descriptions; this note’s `/call` Envelope is the practiced internal spine. Prefer one published shape per boundary — dual dialects without a named product job are debt ([[policy-ingress-contract]]).

## Ingress layer pipe (gateway)

Typical order (K8s `framework/app.py` → `POST /call`):

1. Job header resolve (`X-Job-Id` / `X-Workflow-Name` via DbApiClient) — fail → thin `{detail,status:"error"}` 502/503 **before** envelope pipeline  
2. Authenticator (JWT Bearer or legacy actor)  
3. Validator (version, target, non-empty payload)  
4. Authorizer (scopes/policies — **fall-open** in all lived trees)  
5. Router (`service:method` registry)  
6. Enricher (stamps received_at / target / actor; does not set job_id)  
7. Observer.record_pending (WAL iff job_id)  
8. Executor.execute (`max_retries=2`; retries on **any** exception)  
9. ResponseHandler  
10. Observer.observe (WAL terminal + metrics + execution_log)

Ops surfaces: `GET /health`, `GET /metrics` (often JSON-wrapped Prometheus text — awkward to scrape).

## Routing

Boot loads manifests (`config/services` or Compose equivalent) → register forward closures into Router. Unknown route → `ROUTING_ERROR` / 404-style. Soft-skipped bad YAML → methods silently missing until 404.

Pod side: `create_service_api` + `@wrapper_method`; unknown method often thin `{status,error}` not full envelope.

## Outbound

| Helper | K8s | Compose |
| --- | --- | --- |
| Practiced client | `framework.platform_core.gateway_db_call.call_via_gateway` | `lib.gateway_client.outbound.call_via_gateway` |
| DB shorthand | `call_db_api` | same idea |
| Fuller client | `GatewayClient` — little production use | similar |

```python
from framework.platform_core.gateway_db_call import call_via_gateway

call_via_gateway(
    target_service="storage_api",
    target_method="get_object",
    payload={"bucket": "...", "key": "..."},  # non-empty at gate
    trace_id=trace_id,
    job_id=job_id,
)
```

Default `GATEWAY_URL` cluster DNS (Helm ConfigMap). Side-doors: gateway→db_api for WAL (intended); leaf SDKs only inside owning bridges.

## Headers / identity

| Header / field | Role |
| --- | --- |
| `actor` | `service:*` / `user:*` (Argo often `service:argo`) |
| `Authorization` | JWT path exists; often unset → legacy actor |
| `X-Job-Id` | Opt-in WAL; Argo `workflow.uid` at edge |
| `X-Workflow-Name` | Ensure-workflow bind |
| `X-Trace-Id` | Required on Compose gateway; looser on K8s middleware |

Compose service pods hitting `/call` directly often require **both** trace and job headers — stricter than gateway.

## Diagnosing multi-hop `/call` failures

Caller logs often show only `POST http://gateway:8000/call` → `200` or `500` without the leaf exception. Do **not** stop at the first 500 line in the orchestrator/peer.

| Step | Must |
| --- | --- |
| 1 | Confirm **leaf** config for the failing concern (`printenv` / secrets ownership — [[compose-deploy]], [[credential-owning-bridge]]) |
| 2 | Confirm caller and gateway `/health` |
| 3 | Tail **gateway and leaf** logs; correlate by `trace_id` / `request_id` / `target.service` / `target.method` (and job id when present) |
| 4 | Classify hop: auth/actor, routing/missing method, leaf validation/missing secret, upstream dependency |

Expect structured logs that carry service, method, and identity fields. Prefer leaf error payload / gateway “request completed” vs exception text over guessing from the caller HTTP status alone. Full OTEL Collector wiring remains named debt ([[metrics-tracing-logging-pressure]]) — practiced diagnosis still uses logs + envelope identity.

## Timeouts / retries

| Knob | Lived |
| --- | --- |
| Forward read | Often unlimited / unset (`GATEWAY_FORWARD_READ_TIMEOUT_SECONDS`) |
| Client read | Helm `"86400"` vs code fallback `120` |
| Executor | `max_retries=2` |
| Argo `retryStrategy` | absent on lived templates |
| Idempotency keys | absent |

## Error shape divergence

Happy path ≈ full `EnvelopeV1Response`. Most gate failures → shorthand `{status, error:{code,message,retryable}}`. Job-resolve pre-pipeline → `{detail, status:"error"}`. Clients may still tolerate legacy `{status,data}`.

## Contract tests (K8s evidence)

Hard unit: envelope, gateway layers, wrapper, manifests, observer WAL. Job-resolution app tests often **skipped**. Compose/Dockerfile routing contract suites weak/absent. Envelope JSON Schema files exist but Validator uses Pydantic — schema files can drift.

## Differs by family

| Facet | K8s | Compose single-plane / dual-plane |
| --- | --- | --- |
| Trace header at gateway | Looser | Required → thin 400 |
| Manifest hard-fail | `_framework.yaml` hard; others soft | Root YAML hard (dual-plane + workflow.yaml) |
| Import path | `framework.platform_core…` | `lib.gateway_client…` |

## Quarantine (describe, do not copy as virtue)

Unlimited forward timeout · gate shorthand treated as full envelope · AuthZ fall-open as “secured” · legacy `{status,data}` tolerance · skipped job-resolution CI · blaming only the caller process for a leaf 500.

## Related

- [[policy-ingress-contract]] · [[gateway-auth]] · [[observer-wal]] · [[helm-deploy]] · [[argo-workflows]] · [[credential-owning-bridge]] · [[compose-deploy]] · [[in-process-orchestration]] · [[metrics-tracing-logging-pressure]] · [[platform-atlas]]
