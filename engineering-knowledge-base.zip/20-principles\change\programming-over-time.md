---
type: principle
status: canonical
id: engineering-knowledge-base-p-014
category: "[[change]]"
description: Software engineering integrates programming over time, scale, and changing teams — not one-shot coding.
derived_from:
  - "[[change]]"
updated: 2026-07-15
---

# Programming over time

## Statement

Engineering decisions must survive **time**, **scale**, and **many authors**. Short-lived “it works today” is insufficient for doctrine. Code health is a **continuous** property — each change should leave the system more maintainable than it found it ([[code-review-norm]]).

## Rationale

SE@Google framing (programming integrated over time) plus Google Eng Practices: reviewers optimize for long-run system health, not perfect one-off CLs. Collides with [[extend-established-patterns]] and [[single-lived-source-of-truth]].

## Encourages

- Small, reviewable steps that leave the tree working
- Explicit trade-offs when expedience would degrade health
- Documentation and contracts that future authors can find ([[colocated-authority]], [[published-contract-stability]])

## Prevents

- Drive-by architecture forks “while here”
- Merging known health decreases without emergency framing
- Treating unfinished / soft checks as “done” for future readers

## Evidence

- D1 Google Eng Practices review standard (approve improvements; refuse worsenings)
- D1 #1b SE@Google ch01 — time, scale, explicit trade-offs; Hyrum’s Law ([[published-contract-stability]])
- Lived SoT / honesty-gate notes across platform and warehouse families

## Untapped

SE@Google remaining chapters (beyond ch01 / review / testing overview+unit).

## Related

- [[code-review-norm]] · [[published-contract-stability]] · [[coding-agent-projection]] · [[engineering-craft-atlas]]
