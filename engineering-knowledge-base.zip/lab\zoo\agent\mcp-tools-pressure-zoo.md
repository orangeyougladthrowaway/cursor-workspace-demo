---
type: example
status: canonical
domain: [agent]
derived_from:
  - "[[coding-agent-projection]]"
updated: 2026-07-16
---

# Mcp tools pressure zoo

## When

Using MCP/tool hosts with agents.

## When not

Treating third-party skill packs as platform law.

```text
Host owns consent; tools untrusted until allowed ([[coding-agent-projection]])
```

## Related

- [[coding-agent-projection]] · [[rag-untrusted]]
