---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[tsql-batch-craft]]"
updated: 2026-07-15
---

# Sp executesql params

## When

Dynamic SQL is unavoidable — keep plan reuse and block injection.

## When not

Concatenating untrusted values into the statement string.

```sql
EXEC sp_executesql
  N'SELECT * FROM dbo.T WHERE Id = @Id',
  N'@Id int',
  @Id = @Id;
```

## Related

- [[tsql-batch-craft]]
