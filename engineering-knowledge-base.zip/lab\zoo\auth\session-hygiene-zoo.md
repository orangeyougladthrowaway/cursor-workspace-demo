---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[owasp-session-pressure]]"
updated: 2026-07-16
---

# Session hygiene zoo

## When

Session fixation/timeout/rotation at the gateway.

## When not

Long-lived tokens without revoke/rotate story.

```text
Session pressure → [[owasp-session-pressure]]
```

## Related

- [[owasp-session-pressure]] · [[session-hygiene-pointer]]
