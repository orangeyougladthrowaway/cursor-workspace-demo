---
type: guidance
status: canonical
id: engineering-knowledge-base-g-trainer-pkg
concern: packaging
description: Accumulated trainer packaging / CI honesty.
domain: [python, poetry, pip]
aliases: [requirements, cuda, poetry]
updated: 2026-07-15
---

# Trainer packaging

Atlas: [[trainer-atlas]].

## Install stories

Practiced demos: launcher venv + `requirements*.txt` + CUDA wheel swap.  
Poetry `pyproject` without lock used in CI theatre — dual official story is quarantine.

## CI / tests

Soft format/mypy (`|| true`). Ghost tests import missing adapters — undercuts hard pytest narrative. Smoke train job often absent.

## Quarantine

Dual Poetry+pip as both official · soft mypy as strict quality · README production-ready ahead of tree.

## Related

- [[hydra-config]] · [[adapter-routing]] · [[delivery-gates]] · [[trainer-atlas]]
