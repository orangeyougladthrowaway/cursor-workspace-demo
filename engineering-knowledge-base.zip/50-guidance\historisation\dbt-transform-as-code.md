---
type: guidance
status: draft
id: engineering-knowledge-base-g-dbt
concern: historisation
description: dbt transform-as-code — pointer vs lived SQL proc orchestration.
domain: [dbt]
aliases: [dbt]
derived_from:
  - "[[warehouse-historisation]]"
updated: 2026-07-15
---

# dbt transform as code

## Applies when

Evaluating modern warehouse transform tooling.

## Guidance

W5 pointer: dbt models = SELECT → warehouse objects + tests + lineage. **Not lived** here — warehouse uses SQL procs + [[host-activation]]. Do not invent dbt L1 folder from interest alone.

## Skipped / deep backlog

dbt project structure · incremental models · dbt Cloud · Fusion engine docs.

## Related

- [[airflow-dag-orchestration]] · [[python-ingest]]
