---
type: standard
status: canonical
aliases: ["honesty-in-delivery"]
domain: []
concern: delivery
id: engineering-knowledge-base-s-002
description: Delivery must hard-gate proofs of ownership, contract, and threat-model seams — not only happy paths or soft lint.
derived_from:
  - "[[prove-honesty-contracts]]"
  - "[[fail-at-the-gate]]"
  - "[[fail-loud-on-control-paths]]"
updated: 2026-07-13
---

# Prove honesty contracts in delivery

## Requirement

1. Every system under active change identifies its **honesty seams** — at least: privileged-capability boundaries, cross-boundary contracts/shapes, and properties claimed by the threat model.
2. Those seams have **automated checks** that fail the delivery gate (CI/CD or equivalent) on regression. Happy-path unit tests alone are not sufficient if seams are untested.
3. Style, formatting, and aspirational static checks may exist, but they must **not** be the primary story of quality when honesty-seam checks are missing or soft-failing.
4. A change that alters a seam updates its checks in the **same change** (pairs with documentation authority when the seam is documented).

## Derived from

- [[prove-honesty-contracts]]
- [[fail-at-the-gate]]
- [[fail-loud-on-control-paths]]
- Category: [[proof]]

## Rationale

Architecture and trust fail quietly when only convenient paths are proven. Honest green builds require green seams.

## Exceptions

- Prototypes/demos may defer seam gates only if the threat model and README authority explicitly say so and the deferral is time-bounded.
- Manual proof is acceptable only where automation is genuinely impossible — record why in the authoritative note.

## What this does not prescribe yet

Specific frameworks, coverage percentages, or folder layouts — those belong in later guidance. This standard only requires that honesty seams exist as identified, tested, and hard-gated.

## Related

- [[single-authority-for-documentation]]
- [[threat-model-declaration]]
- [[privileged-capability-ownership]]
