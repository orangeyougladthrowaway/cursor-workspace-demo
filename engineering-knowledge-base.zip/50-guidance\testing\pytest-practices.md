---
type: guidance
status: canonical
id: engineering-knowledge-base-g-pytest
concern: testing
description: pytest good integration practices — layout, import modes, fixtures, parametrize; collide with lived hard pytest gates.
domain: [python, pytest]
aliases: [pytest]
derived_from:
  - "[[unit-testing-norm]]"
  - "[[delivery-gates]]"
  - "[[prove-honesty-contracts]]"
updated: 2026-07-16
---

# Pytest practices

Primary (D2 #14): [Good Integration Practices](https://docs.pytest.org/en/stable/explanation/goodpractices.html).  
Fixtures (L+): [How to use fixtures](https://docs.pytest.org/en/stable/how-to/fixtures.html).  
Parametrize: [Parametrizing fixtures and test functions](https://docs.pytest.org/en/stable/how-to/parametrize.html).

## Applies when

Choosing Python package layout, discovery, fixtures, parametrize, and how tests are invoked in CI or local tooling.

## Guidance

1. Develop in a **venv**; install the app and pytest via pip. Prefer a root `pyproject.toml` and **editable** install (`pip install -e .`) so tests run against a real install path.
2. Discovery defaults: recurse from `testpaths`/cwd; `test_*.py` / `*_test.py`; `test*` functions/methods; `Test*` classes without `__init__`. Also collects `unittest.TestCase`.
3. Prefer **tests outside** application code (`tests/` sibling of `src/`) for new projects. Recommend **`src` layout** so accidental import of the working tree is harder.
4. Prefer `--import-mode=importlib` for new projects (config `addopts`). Default `prepend` can force unique test module basenames and surprising `sys.path` side effects; `importlib` avoids mutating `sys.path`.
5. Without editable install + `src` layout, set `pythonpath = ["src"]` (or `PYTHONPATH=src`) so local runs match intent — do not pretend the package is installed when it is not.
6. Use **tox** (or equivalent) to run against the **installed** package in clean envs — detects packaging glitches editable-local runs miss.
7. Do **not** run tests via `python setup.py test` / pytest-runner — deprecated; bypasses hash-pinning and security mechanisms. Invoke pytest (or `python -m pytest`) directly.
8. Prefer **strict mode** (`strict = true` in pytest ≥9) when pytest is pinned/locked — enables future strictness options together. Otherwise enable individual `strict_*` options. Lived K8s `pyproject` `strict=true` for **mypy** is a different seam: soft mypy in CI still fails honesty ([[delivery-gates]], [[delivery-ci]]).
9. Optional: flake8-pytest-style for fixture/marker misuse — not official pytest; treat as style tooling.

### Fixtures (L+)

10. Tests **request** fixtures by parameter name; pytest resolves and injects return values. Prefer fixtures over ad-hoc setup duplication.
11. Scope deliberately (`function` default; `module`/`session` for expensive shared resources). Wider scope ⇒ shared mutable state risk — keep fixtures pure or reset.
12. Prefer **explicit fixture deps** over clever autouse except for true cross-cutting harness concerns.
13. Combine with [[unit-test-fast-isolated]]: fixtures that open real DB/network turn units into integration — name the size and gate honesty.

### Parametrize (common cases)

14. Use `@pytest.mark.parametrize` for table-driven cases that share one behaviour assertion — keep cases **data**, not copy-pasted tests.
15. Prefer ids (`ids=` or readable `pytest.param(..., id=...)`) so failures name the case.
16. Do not parametrize away distinct behaviours that deserve separate tests; do not hide integration cost inside “one more param.”

## Collision with lived

Hard **unit pytest** gates remain the honesty bar ([[delivery-ci]]). Soft mypy / absent coverage thresholds are **not** fixed by pytest layout advice. Named size: unit vs integration ([[unit-testing-norm]], [[prove-honesty-contracts]]).

## Untapped

monkeypatch deep · plugins ecosystem · CI Pipeline pytest docs · fixture finalizers encyclopaedia.

## Related

- [[unit-test-fast-isolated]] · [[unit-testing-norm]] · [[python-packaging-layout]] · [[delivery-gates]] · [[delivery-atlas]] · [[proof]]
