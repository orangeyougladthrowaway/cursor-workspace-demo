---
type: guidance
status: canonical
id: engineering-knowledge-base-g-orch
concern: orchestration
description: Accumulated in-process / service orchestrator knowledge (not Argo).
domain: [python]
aliases: [orchestrator, workflow-runner]
updated: 2026-07-19
---

# In-process orchestration

Service/process orchestrators that sit **behind** the gateway and call out via Envelope. Outer K8s stage grain: [[argo-workflows]]. Atlas: [[platform-atlas]]. Ownership: [[credential-owning-bridge]].

## Lived roles

| Family | Orchestrator | Role |
| --- | --- | --- |
| K8s | pipeline workers / entry | Long `run_pipeline` style methods; thread pools + chunk loops in memory |
| Compose single-plane | `<orchestrator>` | Profile orchestrator → `call_via_gateway` |
| Compose dual-plane | `<workflow-runner>` (+ frontend triggers) | Demo orchestration; dual DB product plane |

All are **Envelope clients**, not peer mesh owners.

## Grain

- Stages often configured in product YAML (`product/` — do not elevate taxonomies as platform law)  
- Crash loses in-memory run — **no** Observer resume  
- Nested gateway calls with shared `job_id` create nested WAL rows under one job ([[observer-wal]])  

## Optional third-party hops

Orchestrators may own a **feature flag / routing decision** for an optional integration (product-local name, e.g. enable/disable a CRM push). They must **not** own or fail-closed-validate that integration’s OAuth/API secrets — those stay on the credential-owning bridge ([[credential-owning-bridge]], [[compose-deploy]]).

| Flag state | Must |
| --- | --- |
| Disabled | Complete the pipeline; return HTTP success with a **structured skip** (reason named, e.g. flag false); log skip at info — not a gateway 500 |
| Enabled | `call_via_gateway` to the owning bridge; bridge fail-closes if secrets/config invalid |

Never half-fail across `/call` because a peer process checked secrets it was never injected.

## Timeouts

Orchestrators may override client read timeouts (e.g. frontend 300s). Forward hop may still be unlimited — document triad with Argo/gateway. Multi-hop 500s: diagnose gateway + leaf, not only the orchestrator log line ([[envelope-call]]).

## Quarantine

Product stage taxonomies as reusable architecture · “resume from WAL” claims · treating orchestrator as credential owner for Spaces/DB/SaaS · fail-closed on absent third-party secrets inside the orchestrator when those secrets are mounted only on the bridge.

## Related

- [[argo-workflows]] · [[envelope-call]] · [[observer-wal]] · [[capability-bridges]] · [[credential-owning-bridge]] · [[compose-deploy]] · [[platform-atlas]]
