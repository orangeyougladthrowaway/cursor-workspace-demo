---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-packaging-layout]]"
  - "[[pytest-practices]]"
updated: 2026-07-15
---

# Src layout editable

## When

New distributeable package — avoid accidental cwd imports.

## When not

Treating flat-layout cwd import as “installed” behaviour.

```text
pyproject.toml
src/mypkg/__init__.py
tests/test_app.py
# pip install -e .
# pytest --import-mode=importlib
```

## Related

- [[python-packaging-layout]] · [[pytest-practices]]
