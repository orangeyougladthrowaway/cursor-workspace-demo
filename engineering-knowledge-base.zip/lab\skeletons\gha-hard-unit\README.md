---
description: GitHub Actions hard unit gate skeleton — pytest fails the change.
updated: 2026-07-15
---

# gha-hard-unit

## Purpose

Minimal workflow where unit tests are a **hard** gate (no `continue-on-error`).

## Required canons

- [[delivery-gates]]
- [[delivery-ci]]
- [[unit-testing-norm]]

## Copy steps

1. Copy `.github/workflows/hard-unit.yml` into the target repo.
2. Adjust Python version / install / test path.
3. Keep unit job hard — soft checks belong in separately labeled jobs.

## Honesty

- Soft mypy/`|| true` is not a quality Done story ([[continue-on-error-anti]] · [[soft-mypy-anti]]).
- Behaviour + tests in the same change ([[small-cl-tests]]).
- Coverage % ≠ quality ([[coverage-not-quality-zoo]]).
