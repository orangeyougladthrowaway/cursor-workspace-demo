---
type: philosophy
status: canonical
description: Engineering exists to preserve accountable meaning and trust as systems change — not to maximise local convenience.
id: engineering-knowledge-base-ph-001
updated: 2026-07-13
---

# Accountable meaning under change

## Statement

Engineering is for keeping **meaning, trust, and side effects accountable** as systems evolve. Local convenience that erases that accountability is not progress.

## Context

This is the rare worldview above thematic categories. Categories such as boundaries, honesty, restraint, and knowledge authority specialise it; they are not themselves this philosophy.

## Rationale

Tools, products, and teams change. What must survive is the ability to know what the system means, who owns risk, and when it is lying.

## Implications

- Prefer structures that remain explainable under change.
- Treat hidden coupling, silent failure, and duplicated authority as philosophical defects, not mere style issues.
- Domain and technology guidance must derive downward from this stance via categories and principles — never redefine it.

## Related

- Concept folders under [[catalog-principles]]
- Navigation: [[navigation]]
- [[dependency-rules]]
