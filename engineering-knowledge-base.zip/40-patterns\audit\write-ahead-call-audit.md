---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-005
concern: audit
description: "At policy ingress, record pending then terminal call state correlated by job headers — not a full redo engine."
domain:
  - python
  - postgres
aliases:
  - wal
  - observer
  - task-execution
derived_from:
  - "[[prove-honesty-contracts]]"
  - "[[fail-loud-on-control-paths]]"
updated: 2026-07-15
---

# Write-ahead call audit

Stack detail: [[observer-wal]]. Atlas: [[platform-atlas]]. Outer stage callers: [[argo-workflows]].

## Context

Multi-hop jobs die mid-flight; operators need a uniform trail at the same ingress that already sees identity and target — without every worker holding the audit DB.

## Problem

Post-hoc logs alone lose “started but never finished”; ad-hoc logging differs per service.

## Forces

- Audit should sit on the **policy ingress**
- Not every call needs a durable trail
- Payloads in audit stores are sensitive
- Product data plane may need a different DB than platform audit

## Solution

1. Client opts in with **`X-Job-Id`** (external run uid) plus `X-Trace-Id` / optional `X-Workflow-Name`.
2. Gateway **resolves/creates** an internal job row (`get_or_create_job_by_workflow_uid`) → `context["job_id"]`.
3. **Before** forward: `Observer.record_pending` → `record_task_execution_pending` (inputs snapshot).
4. Forward / execute the envelope.
5. **After:** `Observer.observe` → `update_task_execution` (success|failed) + execution log.
6. Own the store behind a **credential-owning DB API**; peers never mount that Postgres.
7. Optional **dual plane** (dual-plane): platform/WAL DB ≠ product/workflow DB — do not put WAL methods on the product API.
8. Missing job header → **skip WAL**, continue the call (metrics may still run).

## When skipped

| Condition | Effect |
| --- | --- |
| No `X-Job-Id` | No pending/observe DB writes; call still succeeds — WAL is opt-in, not always-on |
| `OBSERVER_DB_ENABLED` ≠ true | Skip DB path (structured logs/metrics still run) |
| No `db_api_client` wired | Skip (unit tests) |
| Resolve fails with header present | Hard fail — thin `{detail, status:"error"}` at 502/503, **before** the envelope pipeline; no soft skip once a header was offered |

## Consequences

**Easier:** Crash forensics; uniform recovery inspection; same hop as policy.

**Harder:** Payload retention risk; header contract must hold on side-door clients (`DbApiClient`).

**Watch:**

| Debt | Fact |
| --- | --- |
| Terminal INSERT fallback with empty inputs | Early failures (e.g. auth) with a resolved `job_id` but no prior `record_pending` can still call `update_task_execution`, which falls back to an INSERT with `inputs={}` — a terminal row without a true write-ahead row |
| Schema `running` status | Theatre / unused in every family — task rows move `pending` → `success`/`failed` directly |
| Job-row terminal update | In the dual-plane family this is largely unused on the hot path (`uneven`) — **task** terminals are practiced, but the parent `jobs` row terminal state often isn't reliably closed out; don't assume job status reflects task status |
| Full payload JSONB | No redaction anywhere — treat every WAL store as sensitive |
| Naming traps around "WAL" | K8s: `framework/core/tracer.py` uses `trace_wal`-adjacent naming for a **crash-trace/correlation** helper, plus a dead `@write_audit_log` decorator (invents a job UUID if missing, zero call sites — theatre if ever revived). Compose single-plane: `lib/observability/trace_wal.py` is a **real, used** stdout-print-before-fn decorator on some domain sites (`orchestrator_port`, `finalize_continuity_diff`) — it exists and runs, but it is not Postgres durable. Compose dual-plane: **no `@trace_wal` decorator exists at all** — WAL there is Observer-only. Do not assume any of these three behave the same from the name alone. |
| Recovery treating `jobs.id` as `workflow_uid` | Spurious job create (K8s family) |
| Empty headers on some `forward_envelope` hops | Conflicts with service `/call` header middleware (single-plane/dual-plane require both `X-Trace-Id` and `X-Job-Id` at the pod) |
| `item_id` accepted but not bound as a column | Nested into `inputs` JSONB instead (dual-plane) — a theatre parameter that looks structured but isn't |
| Dual plane only in one family | Dual-plane alone has a genuine second Postgres plane (`db_api_workflow` / `workflow.sql`) with **no WAL API of its own** — K8s and Compose single-plane both keep a single plane; don't design as if dual-plane is the default shape |
| Recovery tooling gap | K8s and Compose single-plane's `recovery_cli` needs `tabulate`, which is **not declared** as a dependency — install footgun on first use. Dual-plane instead exposes a frontend "gateway-log" UI (`apps/web/views/gateway_log_view.py`, `frontend_gateway_runs_list`/`frontend_gateway_run_detail` on `db_api`) as the primary operator surface, with `recovery_cli` as an advisory-only secondary path |

## Pattern statement

1. Opt-in hop audit: external uid → internal job → pending before side effects → terminal after.
2. Missing header = intentional no-WAL.
3. WAL behind owner bridge only.
4. Dual audit/product DB is optional and must stay split.
5. Treat stored payloads as sensitive.
6. Do not elevate until sidecar clients satisfy the same header contract as peer forwards.
7. Do not confuse stdout “WAL” helpers with durable Observer audit.
8. **Audit ≠ redo** — re-run means a new external uid / new job row; outer engines ([[argo-workflows]], UI triggers) are callers, not resume-from-WAL engines.

## Related

- [[observer-wal]] · [[argo-workflows]] · [[platform-atlas]]
- [[policy-ingress-contract]] · [[credential-owning-bridge]]
- [[fail-loud-on-control-paths]] · [[prove-honesty-contracts]]
