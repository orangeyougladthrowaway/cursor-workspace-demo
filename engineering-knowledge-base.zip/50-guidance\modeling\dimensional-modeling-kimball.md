---
type: guidance
status: canonical
id: engineering-knowledge-base-g-dim-model
concern: modeling
description: Kimball dimensional modeling — grain, dims, facts; lived SQL-first stack.
domain: [warehouse]
aliases: [kimball, dimensional]
derived_from:
  - "[[declare-the-grain]]"
  - "[[kimball-type2-scd]]"
updated: 2026-07-20
---

# Dimensional modeling Kimball

## Applies when

Designing warehouse marts, conformed dimensions, or renaming SCD/history layers.

## Guidance

1. Dimensional vocabulary (facts, dimensions, conformed bus) **names** warehouse concerns — it does not require a second tooling stack.
2. **Declare the grain** before dims/measures ([[declare-the-grain]] · [[warehouse-grain]]). Prefer atomic ([[atomic-grain-first]]); apply cardinality ([[grain-cardinality]]).
3. Lived path remains SQL/SSDT/SqlPackage ([[warehouse-historisation]], [[dacpac-publish]]).
4. House dim shape: SCD2 envelope ([[scd2-dimension-envelope]]). House fact shape: snapshot + `created_at` + surrogate FK ([[snapshot-fact-shape]] · [[scd2-dim-snapshot-fact]]).
5. Type 2 technique page: [[kimball-type2-scd]]. Design sequence: [[design-warehouse-tables]].

## Further detail

- [Grain](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/grain/)
- [Declaring the Grain](https://www.kimballgroup.com/2003/03/declaring-the-grain/)
- [Keep to the Grain](https://www.kimballgroup.com/2007/07/keep-to-the-grain-in-dimensional-modeling/)
- [Multivalued / bridge](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/multivalued-dimension-bridge-table/)

## Untapped

Full Toolkit bus matrix worksheets · snowflake debates as house law.

## Related

- [[warehouse-table-design]] · [[kimball-scd-vocabulary]] · [[data-atlas]] · [[warehouse-atlas]]
