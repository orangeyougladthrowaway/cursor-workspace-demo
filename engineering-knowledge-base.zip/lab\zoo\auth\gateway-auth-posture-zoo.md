---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[gateway-auth]]"
updated: 2026-07-16
---

# Gateway auth posture zoo

## When

Gateway owns authentication/authorization decisions at the edge.

## When not

Domain services re-implementing ad hoc auth inconsistently.

```text
Gateway auth posture → [[gateway-auth]] · fail closed
```

## Related

- [[gateway-auth]] · [[threat-model-declaration]]
