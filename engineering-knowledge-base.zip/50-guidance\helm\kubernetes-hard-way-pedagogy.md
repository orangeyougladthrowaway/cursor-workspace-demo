---
type: guidance
status: canonical
id: engineering-knowledge-base-g-kthw
concern: helm
description: Kubernetes The Hard Way — bootstrap pedagogy, not this family's deploy SoT.
domain: [kubernetes]
aliases: [hard-way, bootstrap]
derived_from:
  - "[[helm-deploy]]"
updated: 2026-07-15
---

# Kubernetes hard way pedagogy

## Applies when

Learning control-plane mechanics — **not** when shipping the gateway family.

## Guidance

1. Manual CA/etcd/control-plane/worker bootstrap is **education**.
2. Lived deploy SoT: [[host-opentofu]] + manifest compile + apply ([[helm-deploy]]).
3. Do not elevate Hard Way labs into production procedure without a named ops job.

## Untapped

Hard Way labs 01–13 · CKA/CKAD · production k8s ops books (D*).

## Related

- [[docker-containers]] · [[infrastructure-atlas]]
