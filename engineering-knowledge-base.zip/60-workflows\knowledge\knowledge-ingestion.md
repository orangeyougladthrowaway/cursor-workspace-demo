---
type: workflow
status: canonical
aliases: ["ingestion"]
domain: []
concern: knowledge
id: engineering-knowledge-base-wf-001
description: Lived harvest and remote research enter via claims → collide → amend-first; ledger outside doctrine.
derived_from:
  - "[[navigation]]"
  - "[[changing-this-bible]]"
  - "[[methodology]]"
  - "[[scope]]"
  - "[[colocated-authority]]"
updated: 2026-07-15
---

# Knowledge ingestion

How knowledge enters this bible. Sources are pressure; **claims** are the unit of work; **living notes** remain doctrine. Placement: [[navigation]]. Naming / retirement: [[methodology]], [[changing-this-bible]]. Rollout progress: [[roadmap]].

## Paths (two branches, one vault)

```text
Lived:  repo / temp harvest → distill claims → collide → amend (practice is evidence)
Remote: book / docs / course / OSS / paper → admit → claims → collide → amend
                                              └ pointer | defer | reject (often)
```

| Branch | Default altitude | Remote may overwrite lived canonical? |
| --- | --- | --- |
| Lived | guidance → pattern when portable | N/A |
| Remote | draft guidance / pressure on higher notes | **No** — see conflict protocol |

## Pipeline

```text
Admit → Claim cards → Locate/collide → Conflict resolve → Elevate → Cleanliness gate
```

### Stage A — Admit (before deep reading)

| Admit | Meaning | May emit claims? |
| --- | --- | --- |
| `pressure` | Challenges doctrine you care about, or on [[scope]] watchlist | Yes |
| `specialise` | On watchlist **and** maps to an existing concern | Yes |
| `pointer` | Research aid only (Awesome lists, sample apps, blogs by default) | **No** |
| `defer` | Good source, wrong season | No (re-admit later) |
| `reject` | Out of [[scope]] or noise | No |

**Ledger** lives outside doctrine (chat / spreadsheet / issue / [[ingest-coverage]]). Do not build a 25-domain curriculum tree in the vault. Praxis zoo is **not** a curriculum — [[praxis-ingestion]].

External **agent-skill packs** (third-party workflow libraries): default `pressure` or `pointer`. Wholesale absorption into the vault = `reject` (curriculum mirror). Prefer amending [[coding-agent-projection]] over cloning skill trees.

### Stage B — Claim cards

Extract **claims**, not chapter mirrors. Cap: **≤20 claims per source** first pass; prefer claims that would change a decision.

```text
claim_id
statement           # one actionable sentence
altitude_guess      # philosophy|principle|standard|pattern|guidance|workflow|reject
concern_guess       # navigation enum (or propose new — requires navigation amend first)
domain_facets       # stack tags or []
confidence          # high|med|low
practiced_here      # yes|no|unknown
conflicts_with      # note stems / ids if known
evidence_span       # chapter/section/url anchor — provenance, not a quote dump
source_ref
branch              # lived|remote
```

**Ban as claims:** glossary of widely known terms, API laundry lists, tutorial step dumps, vendor CLI encyclopaedia.

### Stage C — Locate and collide

1. Search by concern, atlas links, `id`, stem — not free curriculum browse.
2. Open candidate living notes (`canonical` preferred; `draft` = non-law).
3. Classify each claim:

| Outcome | Action |
| --- | --- |
| **Reinforce** | Optional strengthen rationale — do not duplicate |
| **Specialise** | Amend guidance under existing concern + `domain:` |
| **Gap** | New **draft** only after naming failed merge targets |
| **Tension** | Partial overlap — rewrite one note or split *questions* (never two answers to one question) |
| **Contradiction** | Do **not** merge — Stage D |
| **Reject** | Noise / out of scope / quarantine theatre |

**Amend-first law:** default is amend one existing note. New note requires explicit “no merge target” check.

### Stage D — Conflict protocol

**Authority stack (highest wins for our doctrine):**

1. User explicit override (then update the living note)
2. Canonical engineering-knowledge-base note already decided
3. Lived practice in our families (when remote is generic)
4. Invariant principles (ownership, boundaries, honesty, restraint, proof, authority, …)
5. Stronger remote sources (e.g. SE@Google, official eng practices, DDIA, OWASP) over tutorials
6. Drafts and blogs — advisory only

**Practiced asymmetry:** if remote contradicts **canonical lived** pattern/guidance, allowed outcomes only: reject remote · aspirational `draft` (non-law) · tradeoff note with **default = lived**. Cite the winning local note.

| Resolution | Vault shape |
| --- | --- |
| Choose & justify | One norm + short why-we-reject-the-other |
| Contextual split | Two notes, **different questions** |
| Tradeoff | Decision factors; marked default; non-default explicit |
| Hold as draft | `Open tension:` naming both sides — agents must not prefer this as law |
| Quarantine | In-note watch / do not elevate |

**Banned:** silent synthesis (“industry balances X and Y”); two canonical answers to one question; quote stacks as doctrine.

### Stage E — Elevate

| Become | Required |
| --- | --- |
| `draft` | Pass Stage C; one concern; one question; upward links |
| `canonical` | Human promotion (or explicit user command); no open contradiction; short rationale in note |
| Higher altitude | Multiple independent pressures + fit; never “book said so” alone |
| New concern folder | Amend [[navigation]] **first** |

**Session budget (default / wide elevate):** ≤30 claim cards · ≤3 note amends · ≤1 new draft. Prefer `amends ≫ new notes`.

**Scaffold mode (explicit):** invent thin `draft` homes + amend [[navigation]] / theme atlases when expanding topic coverage. Claim cards optional. **Freeze admits afterward** (stop creating empty notes). Promote only via elevate / deep.

**Deep-dive session (explicitly invoked only):** after a source is chosen for full harvest, budget may rise (e.g. ≤60 claims · ≤8 amends · ≤2 drafts) but amend-first on collide, conflict freeze, and cleanliness still bind. Prefer existing theme atlas homes. On promote to `canonical`, thin twin spine paragraphs so one question has one living answer. Record depth `deep` on [[ingest-coverage]].

### Coverage axes (wide → deep → praxis capacity → majority)

| Axis | Goal | Depth target | Structure rule |
| --- | --- | --- | --- |
| **W — Wide spine** | Basic coverage of **every** portfolio theme + named subtopics | `skim`/`section` per subtopic; leave untapped explicit | Map concerns; use **scaffold mode** for orphan themes; index under `maps/themes/` |
| **D1 — One deep** | Theme-ordered deep harvest (primary / tight cluster per theme) — **done**; playbook [[d1-deep-harvest-playbook]] | `deep` on harvested claims | Prefer existing theme homes; scaffold freeze on |
| **D2+ — Residual deep** | One leftover primary per numbered wave ([[roadmap]]) — playbook [[d1-deep-harvest-playbook]]; then [[post-capture-review]] | `deep` on harvested claims only | Prefer cells that unblock [[common-case-coverage]]; no curriculum trees |
| **P — Praxis capacity** | Dual-plane `lab/` — **done** (P0–P4) | example counts — never doctrine `deep` | [[praxis-ingestion]] |
| **F — Majority common cases** | ≥~70% G4 per house language/tool track | G1–G4 on [[common-case-coverage]] | Session caps ≠ destination; anti-shrink |

Wide spine intentionally leaves room for deep dives. Do not pretend W = done knowledge. Do not pretend P = majority coverage.

**Stop rule:** If new notes/week ≫ amends/week **outside** an explicit scaffold batch → freeze admits; tighten Stage E. After scaffold: **no further empty homes until a deep pass needs a proven orphan**.

### Stage F — Cleanliness gate

Before calling a batch done, run [[changing-this-bible]] cleanliness accept. Also:

- Catalog / atlas updated if stems added or renamed
- **[[ingest-coverage]]** updated for every source touched this batch (topics tapped, coverage %, depth, untapped)
- **[[common-case-coverage]]** updated when Axis F cells move
- No old basenames or spelling twins in `aliases:`
- Atlases remain indexes — never curriculum playbooks
- Every new wikilink resolves to a vault note stem (never invent links to Cursor rule files — cite `` `.cursor/rules/…` `` paths instead)
- Notes are hand-written — no bulk-generated doctrine floods

**Dry-run / remote batch bar:** search snippets alone do **not** count as fetch. A batch is not “claim-level done” until primary text was read for each extracted source and claim cards were written before elevate. Coverage remainder must be visible on [[ingest-coverage]].

### Stage G — Post-capture review (after knowledge elevate)

Run **after** Stage F when a W / D1 / D2+ batch is declared done. Catches ledger drift and depth inflation that pytest does not. Detail: [[post-capture-review]].

| Check | Fail if |
| --- | --- |
| Depth honesty | Coverage or roadmap says `deep` / “source complete” for claims not actually fetched |
| Ledger sync | Scoreboard, cluster tables, W skipped rows, or atlas backlog contradict each other or still cite retired homes (e.g. flat `portfolio`) |
| Budget log | Deep wave exceeded playbook caps without noting the override on [[roadmap]] / [[ingest-coverage]] |
| Canonical bar | Note promoted with only thin pressure and no primary cite + Untapped — keep `draft` or label honesty gap |
| Twin scan | Two canonical notes answer the same question; projection dumps reintroduced |
| Health | `pytest tests/` green ([[vault-health-checks]]) |

Do not skip Stage G to “save time” after a theme sweep — that is how D1 minor gaps accumulate.

## Refuse modes (agents)

- `pointer-only` — no claims, no vault writes from this source
- `contradiction — needs human` — stop; present both sides + candidate local winner
- `out of scope` — stop; offer [[scope]] amend if user insists
- `defer` — record on ledger; do not elevate
- `merge targets missing` — do not create a new note

Propose diffs; **do not** silent-canonicalise.

## Batch cadence

| Cadence | Rule |
| --- | --- |
| Session | One source cluster (e.g. agent eng **or** testing — not both) |
| Before next high-conflict cluster | Resolve or park open tensions |
| Stop rule | If new notes/week ≫ amends/week outside scaffold → freeze admits; tighten Stage E |

## Forbidden

- Course mirrors, bookmark dumps, vendor encyclopaedias, evidence warehouses
- Second taxonomy for sources (domain × textbook trees)
- Treating ledger, claim cards, or `temp/` as doctrine
- Fat skills that restate this note ([[coding-agent-projection]])

## Related

- [[roadmap]] (rollout progress) · [[coding-agent-projection]] · [[praxis-ingestion]] · [[common-case-coverage]] · [[post-capture-review]] · [[scope]] · [[catalog-maps]] · [[single-authority-for-documentation]]