---
type: catalog
status: canonical
id: engineering-knowledge-base-cat-standards
description: Standards inventory by concept folder.
updated: 2026-07-20
---

# Catalog — Standards

| Concept | Notes |
| --- | --- |
| ownership | [[privileged-capability-boundaries]] |
| policy | [[policy-as-artefact]], [[required-happy-path]] |
| delivery | [[prove-honesty-contracts-in-delivery]], [[delivery-gates]], [[code-review-norm]], [[unit-testing-norm]], [[dora-metrics]] |
| trust | [[threat-model-declaration]], [[owasp-top10-mapping]], [[asvs-authentication-mapping]] |
| authority | [[single-authority-for-documentation]] |
| change | [[extend-by-established-patterns]], [[single-lived-source-of-truth]] |
| apis | [[rest-resource-design-norm]] |
| languages | [[cohesive-code-units]], [[readable-control-flow]] |
| modeling | [[warehouse-grain]], [[snapshot-fact-shape]] |
| historisation | [[scd2-dimension-envelope]] |

Atlases: [[catalog-maps]].
