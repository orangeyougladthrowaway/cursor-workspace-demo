---
type: example
status: canonical
domain: [opentofu]
derived_from:
  - "[[terraform-modules-composition]]"
  - "[[terraform-state-backends]]"
updated: 2026-07-15
---

# Variable validation thin

## When

Catching invalid inputs before apply.

## When not

Trusting callers to always pass sane values.

```hcl
variable "env" {
  type = string
  validation {
    condition     = contains(["lab", "prod"], var.env)
    error_message = "env must be lab or prod."
  }
}
```

## Related

- [[terraform-modules-composition]] · [[host-opentofu]]
