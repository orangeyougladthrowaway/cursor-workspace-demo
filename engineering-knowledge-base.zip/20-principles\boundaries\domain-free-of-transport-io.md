---
type: principle
status: canonical
description: Keep domain rules free of transport and vendor I/O so meaning can change without dragging infrastructure along.
id: engineering-knowledge-base-p-002
category: "[[boundaries]]"
derived_from:
  - "[[boundaries]]"
  - "[[restraint]]"
updated: 2026-07-13
---

# Domain free of transport and vendor I/O

## Statement

Domain and business rules should not import transport clients, cloud SDKs, or persistence drivers. Side effects live at declared edges; the domain stays replaceable and testable.

## Rationale

When rules and I/O fuse, every vendor change rewrites product meaning. Separating them preserves evolvability and makes tests prove rules, not networks.

## Encourages

- Ports/adapters, staging boundaries, pure domain modules
- Orchestration that calls out through explicit façades

## Prevents

- Rule logic coupled to a particular database, HTTP stack, or cloud API

## Evidence (thin)

Repeated domain/service splits and warehouse rule “ingest stops at staging; transforms owned elsewhere.” Local packing choices are not the principle.

## Related

- Category: [[boundaries]]
- [[privileged-capability-ownership]]
- [[restraint]]
