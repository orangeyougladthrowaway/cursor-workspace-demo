---
type: example
status: canonical
domain: [opentofu]
derived_from:
  - "[[terraform-state-backends]]"
updated: 2026-07-15
---

# S3 backend lockfile

## When

S3 state with native locking (not deprecated DynamoDB-only).

## When not

Skipping versioning on the state bucket.

```hcl
terraform {
  backend "s3" {
    bucket       = "mybucket"
    key          = "path/to/key"
    region       = "eu-west-1"
    use_lockfile = true
  }
}
```

## Related

- [[terraform-state-backends]]
