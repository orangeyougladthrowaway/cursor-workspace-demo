---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[unit-testing-norm]]"
  - "[[prove-honesty-contracts]]"
updated: 2026-07-16
---

# Unit vs integration name

## When

Choosing how to label and gate a test that touches IO.

## When not

Calling network/DB tests “unit” while claiming fast isolation.

```text
Unit: no real network/DB — hard gate in pre-submit
Integration: real dependencies — named size + honest gate ([[unit-test-fast-isolated]])
```

## Related

- [[unit-testing-norm]] · [[unit-test-fast-isolated]] · [[delivery-gates]]
