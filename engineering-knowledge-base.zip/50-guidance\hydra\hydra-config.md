---
type: guidance
status: canonical
id: engineering-knowledge-base-g-hydra
concern: hydra
description: Accumulated Hydra/OmegaConf truth for local RL trainer.
domain: [hydra, pytorch]
aliases: [omegaconf, default.yaml]
updated: 2026-07-15
---

# Hydra config

Atlas: [[trainer-atlas]]. Adapter boundary: [[adapter-routing]]. Algos: [[train-loop-ppo]].

Authority files: `scripts/train.py`, `scripts/train_lib.py`, `configs/default.yaml`.

## Bootstrap

`@hydra.main` on train → `OmegaConf.set_struct(cfg, False)` (typos admit) → seed/metrics → adapter load → route by metadata → `train_pve` / `train_pvp`.

**No ConfigStore / defaults package tree** — single flat `default.yaml`. Docs implying rich composition without files = theatre.

## Wired vs theatre (selected)

| Key | Affects train_step? |
| --- | --- |
| `adapter.*` | env identity — yes |
| `model.name` / dims | architecture — yes |
| `algo.gamma`, clip, entropy, … | yes via PPO getattr |
| `algo.num_steps`, `rollout_length`, intervals | loop control — yes |
| `algo.learning_rate` | **not** passed as `lr=` — theatre |
| `algo.num_epochs` | train_step single pass — theatre |
| `algo.minibatch_size` | unused — theatre |

GUI radio “PPO + Retrieval” sets **`model.name=retrieval` only** — does not construct `RetrievalPPO`.

## Add a wired knob

1. Key in `default.yaml`  
2. Read in `train_lib` / PPO  
3. Optional GUI override append  
4. Log resolved value at start  

## Related

- [[adapter-routing]] · [[train-loop-ppo]] · [[trainer-packaging]] · [[adapter-metadata-routing]] · [[trainer-atlas]]
