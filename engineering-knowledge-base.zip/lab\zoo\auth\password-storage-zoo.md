---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[owasp-password-storage-pressure]]"
updated: 2026-07-16
---

# Password storage zoo

## When

Persisting credentials with a modern KDF.

## When not

Reversible password stores.

```text
Argon2/bcrypt/… — [[owasp-password-storage-pressure]]
```

## Related

- [[owasp-password-storage-pressure]] · [[password-storage-pointer]]
