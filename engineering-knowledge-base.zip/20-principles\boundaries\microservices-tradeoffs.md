---
type: principle
status: canonical
id: engineering-knowledge-base-p-017
category: "[[boundaries]]"
description: Microservices — independently deployable services are optional; central ingress is valid.
derived_from:
  - "[[boundaries]]"
  - "[[restraint]]"
updated: 2026-07-15
---

# Microservices tradeoffs

## Statement

Independently deployable services organized around business capability, with smart endpoints and dumb pipes, are **one** style. Central policy ingress ([[policy-ingress-contract]]) is a deliberate alternative, not a failure to “do microservices.”

## Rationale

Primary (D1 #5): [Fowler — Microservices](https://martinfowler.com/articles/microservices.html). Characteristics include independent deploy, capability boundaries, decentralized data — each has cost (distributed failure, contract churn). Collides with lived gateway-central AuthZ/audit. **D2 #8:** do not adopt before [[microservice-prerequisites]]; weigh microservice premium ([[modular-monolith-default]]).

## Encourages

- Choosing decomposition for a **named job** (scale, team, failure isolation)
- Honest contrast notes ([[smart-endpoints-dumb-pipes-contrast]], [[modular-monolith-default]], [[microservice-prerequisites]])

## Prevents

- Microservices-as-default fashion
- Calling central pipes “wrong” without trade-off analysis

## Related

- [[architecture-atlas]] · [[thin-primitives-over-platform-weight]]
