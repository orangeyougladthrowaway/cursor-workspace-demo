---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-async-di]]"
updated: 2026-07-15
---

# Scoped in singleton anti

## When

Naming the captive-dependency hazard in review.

## When not

Injecting a scoped `DbContext` (or similar) into a singleton as “normal.”

```csharp
// ANTI: singleton HostedService(IScopedDep d) — captive dependency
// Prefer: IServiceScopeFactory + create scope per work unit
```

## Related

- [[csharp-async-di]]
