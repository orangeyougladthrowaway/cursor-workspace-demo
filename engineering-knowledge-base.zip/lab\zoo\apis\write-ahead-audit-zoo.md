---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[write-ahead-call-audit]]"
updated: 2026-07-16
---

# Write ahead audit zoo

## When

Auditing external calls with write-ahead records.

## When not

Best-effort logs after the call as the only audit trail.

```text
Write-ahead audit then call ([[write-ahead-call-audit]])
```

## Related

- [[write-ahead-call-audit]] · [[observer-wal]]
