---
type: catalog
status: canonical
id: engineering-knowledge-base-cat-guidance
description: Guidance inventory by responsibility folder.
updated: 2026-07-20
---

# Catalog — Guidance

| Responsibility | Notes |
| --- | --- |
| contracts | [[envelope-call]], [[adapter-routing]] |
| auth | [[gateway-auth]], [[owasp-authentication-pressure]], [[owasp-session-pressure]], [[owasp-password-storage-pressure]], [[owasp-multifactor-authentication-pressure]], [[owasp-forgot-password-pressure]] |
| bridges | [[capability-bridges]], [[s3-compatible-client-endpoint]] |
| compose | [[compose-deploy]], [[docker-containers]] |
| helm | [[helm-deploy]], [[kubernetes-hard-way-pedagogy]] |
| opentofu | [[host-opentofu]], [[terraform-state-backends]], [[terraform-modules-composition]] |
| argo | [[argo-workflows]] |
| orchestration | [[in-process-orchestration]], [[airflow-dag-orchestration]] |
| audit | [[observer-wal]] |
| packaging | [[service-packaging]], [[trainer-packaging]] |
| delivery | [[delivery-ci]], [[sql-server-env-branches]] |
| historisation | [[warehouse-historisation]], [[kimball-type2-scd]], [[kimball-scd-vocabulary]], [[dbt-transform-as-code]], [[tsql-set-based-merge]], [[tsql-batch-craft]] |
| ingest | [[python-ingest]] |
| policy | [[dacpac-publish]], [[ssdt-sqlproj]], [[ssdt-publish-scripts]], [[schema-change-models]] |
| activation | [[host-activation]] |
| hydra | [[hydra-config]] |
| algorithms | [[train-loop-ppo]] |
| datastores | [[postgres-core-concepts]], [[postgres-wal-concurrency]], [[postgres-sql-craft]], [[postgres-jsonb-craft]], [[ddia-reliability-themes]], [[sql-server-craft-map]], [[sql-index-plan-craft]], [[sql-constraints-craft]], [[sql-programmability-craft]], [[sql-concurrency-craft]], [[sql-agent-jobs-craft]], [[sql-maintenance-craft]] |
| apis | [[openapi-specification]], [[rest-resource-design]] |
| languages | [[python-code-structure]], [[python-flow-choices]], [[python-style-pep8]], [[python-typing-honesty]], [[python-packaging-layout]], [[python-errors-resources]], [[python-concurrency-async]], [[python-logging-modeling]], [[python-langsec-secrets]], [[csharp-code-structure]], [[csharp-flow-choices]], [[csharp-style-conventions]], [[csharp-project-toolchain]], [[csharp-async-di]], [[csharp-linq-api]], [[csharp-span-memory]], [[csharp-system-text-json]], [[sql-code-structure]], [[sql-flow-choices]] |
| testing | [[pytest-practices]], [[tott-culture]], [[unit-test-fast-isolated]] |
| observability | [[dora-capabilities-index]], [[metrics-tracing-logging-pressure]] |
| modeling | [[domain-driven-design-pressure]], [[dimensional-modeling-kimball]], [[warehouse-table-design]] |
| ssis | [[ssis-dtproj-dtsx]] |

Atlases: [[catalog-maps]].
