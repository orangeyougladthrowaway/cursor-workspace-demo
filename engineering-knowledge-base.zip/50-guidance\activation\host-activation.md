---
type: guidance
status: canonical
id: engineering-knowledge-base-g-activation
concern: activation
description: Accumulated warehouse host activation SoTs (clone vs zip).
domain: [bash, docker-compose]
aliases: [drop-zone, symlink, /opt/dw]
updated: 2026-07-15
---

# Host activation

Atlas: [[warehouse-atlas]]. DACPAC: [[dacpac-publish]].

## Layout (`/opt/dw`)

| Path | Role |
| --- | --- |
| `repo` | Git working tree (clone SoT) |
| `secrets` | secrets.env, github_pat |
| `state` | e.g. db-last-deployed.txt |
| `current/db` | Active dacpac bundle |
| `current/services` | Active services target (zip path) |
| `releases/…` | Staged unzipped releases |

Compose: `mssql`, `ingest`, `db-deployer` (runtime overlays).

## Dual SoT — both practiced

**Path A — clone/pull:** `pull_only.sh` → build/deploy dacpacs from repo → ingest/etl. Docs often say “no release zips.”

**Path B — zip + symlink:** `refresh_all.sh`, `pull_and_stage_zip.sh`, `activate_current.sh` (`ln -sfn`) — scripts **present** (obsolete “scripts missing” claim). Soft `\|\| true` on some compose steps.

Unresolved which path is authoritative for a given host — document both; do not elevate dual SoT.

## Quarantine

Checksum verify theatre if ungated · soft `|| true` on deploy steps · zip-vs-clone conflict left undocumented.

## Related

- [[dacpac-publish]] · [[python-ingest]] · [[warehouse-atlas]]
