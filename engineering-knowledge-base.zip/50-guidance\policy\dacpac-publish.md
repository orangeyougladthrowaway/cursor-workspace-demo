---
type: guidance
status: canonical
id: engineering-knowledge-base-g-dacpac
concern: policy
description: Accumulated SSDT DACPAC / SqlPackage publish knowledge.
domain: [sql-server, ssdt]
aliases: [dacpac, sqlpackage, ssdt]
derived_from:
  - "[[compiled-schema-release]]"
updated: 2026-07-15
---

# DACPAC publish

Atlas: [[warehouse-atlas]]. Pattern: [[compiled-schema-release]]. Projects: [[ssdt-sqlproj]]. Scripts/profiles: [[ssdt-publish-scripts]]. Activation: [[host-activation]].

## Build

Microsoft.Build.Sql **sqlproj** per DB: Staging → ODS → DWH → Reports → ETL (SQLCMD variables). See [[ssdt-sqlproj]].  
Debug vs Release: container/host scripts often **Debug**; CI release zips **Release** — drift risk.

Publish profiles and PreDeploy/PostDeploy: [[ssdt-publish-scripts]].

## Publish defaults (lab — quarantine as virtue)

| Property | Lived lab | SqlPackage docs default (publish) |
| --- | --- | --- |
| `CreateNewDatabase` | True | **False** (update existing DB) |
| `BlockOnPossibleDataLoss` | False | **True** (abort if schema change may lose data) |
| `DropObjectsNotInSource` | True | **False** |
| `AllowTableRecreation` | True | (lab-specific) |

Lived lab values are **intentionally destructive** for reset loops. They are **not** production doctrine. Promoting them without a named threat-model exception fails [[threat-model-declaration]] / [[delivery-gates]] honesty. Every SQLCMD variable required by the DACPAC must be supplied (`/Variables:…`) or publish fails.

Order: Staging → ODS → DWH → Reports → ETL with `/Variables:…`.

## Skip redeploy

Fingerprint from `manifest.json` version or checksums → compare `db-last-deployed.txt` under state dir; skip publish if equal.

## Quarantine

Destructive publish defaults as prod law · Debug/Release dual without awareness · hollow Reports as “BI shipped.”

**Prod amplify (L collision):** lived lab `CreateNewDatabase`/`BlockOnPossibleDataLoss=false`/`DropObjectsNotInSource` are reset-loop settings — production publish must invert toward SqlPackage defaults (protect data, update-in-place) unless a named threat-model exception exists. MERGE/SCD correctness remains a separate ungated seam ([[tsql-set-based-merge]], [[delivery-gates]]).

## Related

- [[compiled-schema-release]] · [[ssdt-sqlproj]] · [[ssdt-publish-scripts]] · [[host-activation]] · [[warehouse-historisation]] · [[tsql-set-based-merge]] · [[warehouse-atlas]]
