---
type: example
status: canonical
domain: [sql-server, ssdt]
derived_from:
  - "[[ssdt-sqlproj]]"
  - "[[ssdt-publish-scripts]]"
  - "[[compiled-schema-release]]"
updated: 2026-07-20
---

# Ssdt publish scripts outline

## When

Wiring PreDeploy/PostDeploy and remembering plan-vs-script order.

## When not

Putting CREATE TABLE only in PostDeploy.

```text
Build dacpac → SqlPackage plan → PreDeploy → apply plan → PostDeploy
Entry: Scripts/Script.PreDeployment.sql + Script.PostDeployment.sql (:r fragments)
Profile: lab vs durable BlockOnPossibleDataLoss / CreateNewDatabase
```

Stub: `lab/stubs/sql-server/ssdt-publish-scripts-outline.sql` · `ssdt-sqlproj-outline.xml`

## Related

- [[ssdt-publish-scripts]] · [[dacpac-publish]] · [[sqlpackage-lab-vs-prod]]
