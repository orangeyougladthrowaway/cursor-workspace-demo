---
type: example
status: canonical
domain: [observability]
derived_from:
  - "[[python-langsec-secrets]]"
  - "[[metrics-tracing-logging-pressure]]"
updated: 2026-07-16
---

# Log pii redaction

## When

Logging near auth/PII fields.

## When not

Raw tokens/emails/PAN in logs “for debug.”

```text
Redact secrets/PII at the logger boundary
```

## Related

- [[python-langsec-secrets]] · [[metrics-tracing-logging-pressure]]
