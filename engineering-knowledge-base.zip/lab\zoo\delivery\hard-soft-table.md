---
type: example
status: canonical
domain: [delivery]
derived_from:
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Hard soft table

## When

Listing hard vs soft checks explicitly so green means something.

## When not

Ambiguous greens across conflicting workflows.

```text
| Check  | Hard/Soft |
| pytest | Hard      |
| mypy   | Soft*     |

* Soft only if declared — never market soft as quality Done
```

## Related

- [[delivery-gates]] · [[delivery-ci]] · [[prove-honesty-contracts]]
