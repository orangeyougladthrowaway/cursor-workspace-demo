---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[kimball-type2-scd]]"
  - "[[warehouse-historisation]]"
updated: 2026-07-15
---

# Dual current scd anti

## When

Naming the dual-current Type-2 hazard in review.

## When not

Two rows with `is_current = 1` for the same business key.

```sql
-- ANTI: multiple current rows per natural key
-- Prefer: close prior current (end_dt / is_current=0) then insert new current
-- Outline stub: lab/stubs/sql-server/scd2-merge-outline.sql
```

## Related

- [[kimball-type2-scd]] · [[kimball-scd-vocabulary]] · [[tsql-set-based-merge]]
