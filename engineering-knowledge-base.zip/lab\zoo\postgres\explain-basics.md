---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-sql-craft]]"
updated: 2026-07-15
---

# Explain basics

## When

Reading planner choice before tuning queries/indexes.

## When not

Casual `EXPLAIN ANALYZE` on production write paths.

```sql
EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM t WHERE id = 1;
```

## Related

- [[postgres-sql-craft]] · [[postgres-wal-concurrency]]
