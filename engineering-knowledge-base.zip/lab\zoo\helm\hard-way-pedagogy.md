---
type: example
status: canonical
domain: [helm]
derived_from:
  - "[[kubernetes-hard-way-pedagogy]]"
  - "[[helm-deploy]]"
updated: 2026-07-15
---

# Hard way pedagogy

## When

Using Hard Way to learn cluster guts.

## When not

Copying Hard Way as production platform law / house SoT.

```text
Pedagogy only → [[kubernetes-hard-way-pedagogy]]
Lived SoT    → [[helm-deploy]] / host notes
```

## Related

- [[kubernetes-hard-way-pedagogy]] · [[helm-deploy]]
