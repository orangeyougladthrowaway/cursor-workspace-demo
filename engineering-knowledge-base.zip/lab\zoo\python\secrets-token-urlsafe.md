---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-langsec-secrets]]"
  - "[[owasp-forgot-password-pressure]]"
updated: 2026-07-15
---

# Secrets token urlsafe

## When

Reset links / hard-to-guess URL tokens.

## When not

Using `random` for security tokens.

```python
import secrets

token = secrets.token_urlsafe(32)
ok = secrets.compare_digest(token, provided)
```

## Related

- [[python-langsec-secrets]] · [[owasp-password-storage-pressure]]
