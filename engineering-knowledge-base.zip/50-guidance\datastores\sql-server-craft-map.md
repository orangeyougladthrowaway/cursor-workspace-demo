---
type: guidance
status: canonical
id: engineering-knowledge-base-g-sql-craft-map
concern: datastores
description: Map systems-KB SQL Server concepts to engineering craft homes — build/maintain depth.
domain: [sql-server]
aliases: [sql-engineering-map, systems-sql-projection]
derived_from:
  - "[[warehouse-atlas]]"
  - "[[compiled-schema-release]]"
  - "[[sql-code-structure]]"
updated: 2026-07-20
---

# Sql server craft map

Systems-knowledge-base owns **product/SoR behaviour**. This vault owns **how to build and maintain**. Use this map when elevating or reviewing SQL work.

## Suite / tooling

| Systems note (pressure) | Engineering craft home |
| --- | --- |
| Engine / object model | [[sql-code-structure]] · [[ssdt-sqlproj]] · [[warehouse-historisation]] |
| SSMS | Operator surface — eng uses [[dacpac-publish]] / sqlproj as SoT, not click-ops |
| SSIS product / catalog / deploy model | [[ssis-dtproj-dtsx]] |
| SSRS | Untapped eng craft (report projects) — Gap until lived |
| Azure SQL differences | Publish target honesty in [[ssdt-publish-scripts]] · [[dacpac-publish]] |

## Engine capabilities → craft

| Systems concept | Build / maintain here |
| --- | --- |
| Tables / constraints | [[sql-constraints-craft]] · [[sql-code-structure]] · grain [[warehouse-grain]] |
| Indexes / statistics | [[sql-index-plan-craft]] |
| Programmability (view/proc/fn/trigger) | [[sql-programmability-craft]] · [[sql-flow-choices]] |
| Concurrency / locking / isolation | [[sql-concurrency-craft]] · [[tsql-set-based-merge]] |
| Transaction log / recovery / backup | Ops posture — eng: deploy must not imply backup SoT; see systems processes |
| Tempdb | [[tsql-batch-craft]] (temp vs table var) · plan craft |
| Memory / pages / extents / collation / files | Prefer systems behaviour; eng only when a house default is forced |
| Agent | [[sql-agent-jobs-craft]] |
| Maintenance (CheckDB / index jobs) | [[sql-maintenance-craft]] |
| Principals / securables | PostDeploy / modeled permissions [[ssdt-publish-scripts]]; threat [[threat-model-declaration]] |

## Warehouse stack (lived)

| Concern | Home |
| --- | --- |
| Layers / SCD2 / facts | [[historisation-layers]] · [[scd2-dim-snapshot-fact]] |
| Schema release | [[compiled-schema-release]] · [[schema-change-models]] · [[ssdt-sqlproj]] · [[ssdt-publish-scripts]] · [[dacpac-publish]] · [[host-activation]] |
| Env branches / release assembly | [[sql-env-release-assembly]] · [[sql-server-env-branches]] |
| Ingest edge | [[python-ingest]] |

## Done test for “SQL coverage”

A systems capability cell is **eng-covered** only when this map points at a canonical craft note (or an explicit Untapped Gap). Product encyclopaedia in eng-KB is refuse.

## Related

- [[warehouse-atlas]] · [[languages-atlas]] · [[data-atlas]] · systems-KB `sql-server-atlas` (read-only)
