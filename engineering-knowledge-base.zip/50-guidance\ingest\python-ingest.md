---
type: guidance
status: canonical
id: engineering-knowledge-base-g-ingest
concern: ingest
description: Accumulated Python→Staging ingest / provider knowledge.
domain: [python, sql-server]
aliases: [staging-writer, providers]
derived_from:
  - "[[honesty]]"
  - "[[failure]]"
  - "[[warehouse-historisation]]"
updated: 2026-07-16
---

# Python ingest

Atlas: [[warehouse-atlas]]. Layers: [[warehouse-historisation]].

## Package

`Services/<provider-ingest>/` — entry `python -m src.jobs.stage.run_stage` after pip target install.

| Module | Role |
| --- | --- |
| `run_stage.py` | Orchestrates fetches + writes |
| `providers/<provider>/*` | OAuth + client (soft-skip on ReportableError) |
| `providers/<public-api>/*` | Public API + throttle; **bare `except: pass` in stage loops** |
| `core_api/retry.py` | 3× backoff on 429/5xx |
| `staging/loaders.py` | `StagingWriter`, `row_hash_for` |

`product/` provider domains — structure only; do not elevate product lore as warehouse law.

## Writer contract

```text
TRUNCATE table → insert_many batches (500)
row_hash_for(parts) = sha256("|".join(...))[:32]
```

Failure after truncate ⇒ empty/partial staging visible to SCD2. Hash must cover historised attributes.

## Soft ingest catalogue

| Site | Behaviour |
| --- | --- |
| OAuth provider batch details | print + continue on ReportableError |
| Public-API full loops | silent `except Exception: pass` |
| Exit code | often 0 despite partial data |

Do not elevate soft ingest + absence-delete as a gate.

## Add a provider (recipe outline)

1. Client + throttle/retry  
2. Table writers under `staging/tables`  
3. Wire into `run_stage` sequence  
4. Staging SSDT tables + hash parts  
5. ODS merge proc + DWH load if serving  

## Related

- [[warehouse-historisation]] · [[tsql-set-based-merge]] · [[python-errors-resources]] · [[host-activation]] · [[delivery-gates]] · [[warehouse-atlas]]
