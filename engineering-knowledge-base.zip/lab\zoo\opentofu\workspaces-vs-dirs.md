---
type: example
status: canonical
domain: [opentofu]
derived_from:
  - "[[host-opentofu]]"
updated: 2026-07-16
---

# Workspaces vs dirs

## When

Separating environments with directories (preferred) or workspaces (explicit).

## When not

Silent workspace hopping that shares state ambiguously.

```text
Prefer env dirs + separate state keys over casual workspace switching
```

## Related

- [[host-opentofu]] · [[terraform-state-backends]]
