---
type: example
status: canonical
domain: [bash]
derived_from:
  - "[[delivery-ci]]"
  - "[[tooling-proficiency]]"
updated: 2026-07-16
---

# Ci glue idempotent

## When

CI shell steps that may re-run.

## When not

Scripts that fail on second run due to create-without-exists checks.

```bash
set -euo pipefail
mkdir -p "$OUT"
# prefer idempotent mkdir/cp patterns
```

## Related

- [[delivery-ci]] · [[strict-shell-mode]]
