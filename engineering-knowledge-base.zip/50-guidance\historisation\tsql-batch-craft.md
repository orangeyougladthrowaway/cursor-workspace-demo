---
type: guidance
status: canonical
id: engineering-knowledge-base-g-tsql-batch
concern: historisation
description: T-SQL batch craft — TVPs, TRY/CATCH, parameterized dynamic SQL; collide inject honesty.
domain: [sql-server, t-sql]
aliases: [tvp, try-catch, sp-executesql]
derived_from:
  - "[[tsql-set-based-merge]]"
  - "[[python-ingest]]"
updated: 2026-07-15
---

# Tsql batch craft

Primaries (L+): [TRY…CATCH](https://learn.microsoft.com/en-us/sql/t-sql/language-elements/try-catch-transact-sql); [Table-valued parameters](https://learn.microsoft.com/en-us/sql/relational-databases/tables/use-table-valued-parameters-database-engine); [sp_executesql](https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-executesql-transact-sql).

## Applies when

Staging/hist procs need batch inputs, error handling, or unavoidable dynamic SQL — beside MERGE ([[tsql-set-based-merge]]).

## Guidance

### Table-valued parameters

1. Prefer **TVPs** (user-defined table types) to pass multi-row batches into procs — set-based, strongly typed, fewer round-trips than scalar params or ad-hoc temp tables for client→server lists.
2. TVPs are **READONLY** in the routine — no DML on the parameter itself; `INSERT…SELECT` from `@tvp` into real tables.
3. No statistics on TVP columns — plan quality may differ from permanent tables. Rough guide: TVPs often fine under ~1k rows vs bulk startup cost; profile when larger.
4. Collide ingest: Python truncate+batch insert ([[python-ingest]]) is a different edge; TVPs shine when a single proc call must receive a typed rowset.

### TRY…CATCH

5. Use `TRY…CATCH` for severity >10 errors that do not kill the connection. Catch does **not** auto-return errors to the client — `RAISERROR`/`THROW` (or resultsets) if the app must see them.
6. Check **`XACT_STATE()`** in CATCH: `-1` ⇒ uncommittable ⇒ `ROLLBACK`; do not `COMMIT` doomed work.
7. Compile / name-resolution errors at the same batch level may bypass CATCH; nested procs can change catch behavior — test the real call shape.
8. Not valid in UDFs.

### Dynamic SQL

9. Prefer static SQL. When dynamic is required, use **`sp_executesql` with parameters** — never concatenate untrusted values into the statement string (injection). Docs caution explicitly.
10. Parameterization enables plan reuse vs unique `EXECUTE('…'+@val)` strings. Still fully qualify object names in the statement text.

## Untapped

Temp tables vs table variables deep · `#temp` indexing · QUOTENAME object-name hygiene recipes · THROW vs RAISERROR era detail.

## Related

- [[tsql-set-based-merge]] · [[warehouse-historisation]] · [[delivery-gates]] · [[warehouse-atlas]]
