---
type: catalog
status: canonical
id: engineering-knowledge-base-cat-principles
description: Principles — open a concept folder, then the leaf.
updated: 2026-07-20
---

# Catalog — Principles

Drill: `20-principles/{concept}/` → spine → leaf.

| Concept | Spine | Leaves |
| --- | --- | --- |
| ownership | [[ownership]] | [[privileged-capability-ownership]] |
| boundaries | [[boundaries]] | [[domain-free-of-transport-io]], [[microservices-tradeoffs]], [[bounded-context-language]] |
| failure | [[failure]] | [[fail-at-the-gate]], [[fail-loud-on-control-paths]], [[happy-path-only]] |
| honesty | [[honesty]] | [[deterministic-before-probabilistic]], [[react-reason-act-pressure]], [[rag-retrieval-pressure]] |
| restraint | [[restraint]] | [[thin-primitives-over-platform-weight]], [[modular-monolith-default]] |
| change | [[change]] | [[policy-as-explicit-artefact]], [[extend-established-patterns]], [[programming-over-time]] |
| trust | [[trust]] | [[threat-model-matched-controls]] |
| authority | [[authority]] | [[colocated-authority]] |
| proof | [[proof]] | [[prove-honesty-contracts]], [[published-contract-stability]], [[coverage-not-quality]] |
| reliability | [[reliability]] | [[distributed-systems-expectations]], [[durable-storage-tradeoffs]] |
| modeling | [[modeling]] | [[declare-the-grain]], [[atomic-grain-first]] |

[[navigation]]
