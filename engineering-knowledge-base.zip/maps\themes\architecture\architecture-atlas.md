---
type: map
status: canonical
id: engineering-knowledge-base-map-architecture
concern: architecture
description: Theme atlas — boundaries, microservices tradeoffs, DDD pressure, distributed expectations.
domain: []
aliases: [microservices, ddd, boundaries]
updated: 2026-07-17
---

# Atlas — Architecture

Decomposition, DDD vocabulary pressure, and distributed-systems expectations. Index only.

## Canonical (D1 #5 + D2 #8)

- [[microservices-tradeoffs]] · [[microservice-prerequisites]] · [[smart-endpoints-dumb-pipes-contrast]] · [[modular-monolith-default]]
- [[bounded-context-language]] · [[domain-driven-design-pressure]] · [[distributed-systems-expectations]]
- Lived: [[domain-io-edge-packaging]] · [[policy-ingress-contract]] · [[thin-primitives-over-platform-weight]] · [[capability-bridges]]
- Failure craft: [[happy-path-only]] · [[required-happy-path]] · [[happy-path-construction]]

## Praxis

- Zoo facet `architecture` (allowlisted) — start: [[microservice-prereqs-checklist]] · densify via Axis F ([[common-case-coverage]])

## Deep backlog (D2+)

Fowler Hard Parts book · Evans/Vernon · networking courses · GoF claim-level · owned DDIA chapters.

## Related

- [[catalog-maps]] · [[apis-atlas]] · [[platform-atlas]] · [[data-atlas]] · [[lab-atlas]] · [[common-case-coverage]]
