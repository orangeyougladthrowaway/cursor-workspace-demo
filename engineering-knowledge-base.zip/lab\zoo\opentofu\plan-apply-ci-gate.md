---
type: example
status: canonical
domain: [opentofu]
derived_from:
  - "[[host-opentofu]]"
  - "[[delivery-gates]]"
updated: 2026-07-16
---

# Plan apply ci gate

## When

Requiring `plan` (and gated `apply`) in the delivery path.

## When not

Manual apply-only as the sole proof after “CI green.”

```bash
tofu plan -out=tfplan
# apply only with review / protected env
```

## Related

- [[host-opentofu]] · [[delivery-gates]]
