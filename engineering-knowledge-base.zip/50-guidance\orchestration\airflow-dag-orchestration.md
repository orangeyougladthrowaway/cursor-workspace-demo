---
type: guidance
status: draft
id: engineering-knowledge-base-g-airflow
concern: orchestration
description: Apache Airflow batch DAGs-as-code — pointer vs lived Argo/SQL orchestration.
domain: [airflow, python]
aliases: [airflow, dag]
derived_from:
  - "[[argo-workflows]]"
updated: 2026-07-15
---

# Airflow DAG orchestration

## Applies when

Comparing batch workflow engines.

## Guidance

W5 pointer: Airflow = Python-defined DAGs, schedules, operators. Platform family uses [[argo-workflows]]; warehouse uses SQL job chains — **both** are lived; Airflow is research pressure only.

## Skipped / deep backlog

Operators · scheduling · Astronomer docs · production Airflow patterns.

## Related

- [[dbt-transform-as-code]] · [[in-process-orchestration]]
