---
type: standard
status: canonical
id: engineering-knowledge-base-s-020
concern: modeling
description: Snapshot fact shape — create datetime plus surrogate FK to dim at the same grain.
domain: [warehouse, sql-server]
derived_from:
  - "[[declare-the-grain]]"
  - "[[atomic-grain-first]]"
  - "[[scd2-dimension-envelope]]"
updated: 2026-07-20
---

# Snapshot fact shape

## Normally require

House **facts** are **snapshots of measures at load/event time**, not SCD2 history tables:

| Column class | Requirement |
| --- | --- |
| Grain key / degenerate keys | Identify the measurement event (true to [[warehouse-grain]]) |
| Dim surrogate FKs | Point to dim version **at the same grain** (and as-of policy) |
| `created_at` / `create_dts` (datetime) | When this fact snapshot row was recorded |
| Measures | Numeric/countable; true to grain; additivity noted |

Optional: batch/run id for lineage. **Do not** put `effective_from` / `effective_to` / `is_current` / `row_hash` on facts as a second Type-2 store. Dim history for as-was joins lives on dims (mirrored from ODS merge SoT), not on the fact.

## Join policy

| Policy | When | FK target |
| --- | --- | --- |
| **Current serving** | Mart rebuilt from ODS current | Dim row where `is_current` and not `is_deleted` |
| **As-was** | Need attributes true at event time | Dim surrogate valid at event/`created_at` |

Document which policy each fact uses. Same grain: fact grain must match the business grain of the dim it keys (e.g. goods-line fact → goods dim version, not agreement-only dim as sole grain).

## Refuse

- Fact table that is secretly SCD2 (history SoT in DWH)  
- Natural-key-only FK across Type-2 dims  
- Measures that belong to a parent grain without allocation

## Related

- [[scd2-dimension-envelope]] · [[scd2-dim-snapshot-fact]] · [[historisation-layers]] · lab [[dim-scd2-fact-snapshot-outline]]
