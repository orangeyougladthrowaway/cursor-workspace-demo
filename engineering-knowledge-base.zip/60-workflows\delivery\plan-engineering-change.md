---
type: workflow
status: draft
id: engineering-knowledge-base-wf-009
concern: delivery
description: Plan a scoped engineering change from acceptance through verification before implementation.
domain: ["cursor"]
derived_from:
  - "[[coding-agent-projection]]"
  - "[[delivery-gates]]"
  - "[[cohesive-code-units]]"
  - "[[readable-control-flow]]"
updated: 2026-07-17
---

# Plan engineering change

Use for non-trivial product engineering work before editing code.

For engineering-knowledge-base knowledge changes, use [[knowledge-ingestion]] instead.

## Preconditions

- A stated problem or requested outcome
- The target repository and permitted scope
- No unresolved authority conflict

If acceptance cannot be established, stop and ask.

## Retrieve

1. Read the product's `AGENTS.md` and [[coding-agent-projection]].
2. Open the relevant family or theme atlas ([[catalog-maps]]).
3. Follow links to applicable canonical principles, standards, patterns, and guidance.
4. Open praxis ([[lab-atlas]]) only after identifying the binding doctrine.
5. Research domain or vendor details only where engineering-knowledge-base is silent.
6. If claiming coverage / “bible done,” open [[common-case-coverage]].

## Steps

1. Restate the outcome as observable acceptance conditions.
2. Identify assumptions, unknowns, risks, and authority conflicts.
3. Inspect only directly related code, configuration, callers, and tests.
4. Name the engineering-knowledge-base ids that constrain the change.
5. Divide work into the smallest dependency-ordered vertical slices.
6. Define verification for each slice ([[delivery-gates]]).
7. Identify human or external approvals.
8. Stop if the plan depends on invented facts or weakened gates.

## Output

- Outcome and acceptance conditions
- Scope: in, out, later
- Binding engineering-knowledge-base ids
- Assumptions and open questions
- Ordered implementation slices
- Verification plan
- Risks and approval gates

## Handoff

Pass the accepted plan to [[build-engineering-change]].

## Forbidden

- Editing before material unknowns are resolved
- Treating research as authority over engineering-knowledge-base
- Planning drive-by refactors
- Claiming completeness without [[common-case-coverage]]

## Related

- [[coding-agent-projection]] · [[verify-engineering-change]] · [[review-engineering-change]]
