---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-span-memory]]"
updated: 2026-07-16
---

# Span slice thin

## When

Slicing a buffer without allocating a new array in a sync local method.

## When not

Returning `Span` from async methods — use `Memory` or copy.

```csharp
ReadOnlySpan<char> slice = input.AsSpan(0, Math.Min(3, input.Length));
```

## Related

- [[csharp-span-memory]]
