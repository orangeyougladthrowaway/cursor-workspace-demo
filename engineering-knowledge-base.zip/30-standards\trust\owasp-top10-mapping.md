---
type: standard
status: canonical
id: engineering-knowledge-base-s-012
concern: trust
description: Map threat models to OWASP Top 10:2021 — A01/A07 deep; lab fall-open stays named.
domain: []
aliases: [owasp, top10, a01, a07]
derived_from:
  - "[[threat-model-declaration]]"
  - "[[threat-model-matched-controls]]"
updated: 2026-07-15
---

# OWASP Top 10 mapping

Primary (D1 #3): [A01:2021 Broken Access Control](https://owasp.org/Top10/2021/A01_2021-Broken_Access_Control/), [A07:2021 Identification and Authentication Failures](https://owasp.org/Top10/2021/A07_2021-Identification_and_Authentication_Failures/), plus cheat-sheet elevates ([[owasp-authentication-pressure]], [[owasp-session-pressure]]).

## Requirement

1. Declared threat models **name** relevant Top 10 categories as mapping pressure — at minimum **A01** (access control) and **A07** (identification/authentication) for gateway families.
2. **A01 pressures:** deny-by-default; server-side enforcement; least privilege; no missing controls on mutating methods; functional AuthZ tests; short-lived tokens / invalidate sessions.
3. **A07 pressures:** MFA where relevant; no default/weak credentials; harden recovery; rate-limit + log stuffing; secure session manager; invalidate on logout/idle.
4. Lab fall-open AuthZ + unused `auth.yaml` are **A01 theatre** unless the threat model explicitly scopes them as lab-only ([[gateway-auth]], [[threat-model-declaration]]).
5. Cheat sheets inform gaps; they do **not** auto-elevate maximal public-web controls onto private mesh without a model change. Password storage for human credentials: [[owasp-password-storage-pressure]].

## Lived mapping (gateway)

| Theme | Lived fact | Label |
| --- | --- | --- |
| A01 deny-by-default | Authorizer empty policies → allow | Lab fall-open / debt |
| A01 reuse mechanism | AuthZ not loading `auth.yaml` | Theatre |
| A07 missing AuthN | No Bearer → actor path | Named mesh trust |
| A07 session | Not used on `/call` | N/A internal; edge backlog |

## Untapped

Other Top 10:2021 category pages · Top 10:2025 · Authorization cheat sheet. ASVS AuthN mapping → [[asvs-authentication-mapping]] (D2 #9).

## Related

- [[owasp-authentication-pressure]] · [[owasp-session-pressure]] · [[asvs-authentication-mapping]] · [[security-atlas]] · [[prove-honesty-contracts]]
