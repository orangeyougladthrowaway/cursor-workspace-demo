---
type: example
status: canonical
domain: [docker]
derived_from:
  - "[[docker-containers]]"
updated: 2026-07-16
---

# Multistage build thin

## When

Keeping build tools out of the runtime image.

## When not

Shipping compilers/SDKs in every prod image by default.

```dockerfile
FROM python:3.12 AS build
WORKDIR /src
COPY . .
RUN pip install --prefix=/install .

FROM python:3.12-slim
COPY --from=build /install /usr/local
USER nobody
```

## Related

- [[docker-containers]] · [[service-packaging]]
