---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-async-di]]"
updated: 2026-07-16
---

# Httpclient factory thin

## When

Outbound HTTP via `IHttpClientFactory` with timeout + cancellation.

## When not

`new HttpClient()` per call without lifetime/disposal discipline.

```csharp
services.AddHttpClient("api", c => c.Timeout = TimeSpan.FromSeconds(5));
// call site: await client.GetAsync(uri, cancellationToken);
```

## Related

- [[csharp-async-di]] · [[csharp-system-text-json]]
