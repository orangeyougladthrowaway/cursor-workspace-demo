---
type: example
status: canonical
domain: []
derived_from:
  - "[[public-http-vs-internal-envelope]]"
updated: 2026-07-16
---

# Envelope vs public

## When

Naming the job: partner REST vs internal Envelope `/call`.

## When not

One muddled surface pretending `/call` is REST.

```text
public  → OpenAPI resource HTTP
internal → Envelope POST /call
adapter → owns translation at the edge
```

## Related

- [[public-http-vs-internal-envelope]] · [[envelope-call]] · [[adapter-routing]]
