---
type: principle
status: canonical
id: engineering-knowledge-base-p-013
category: "[[reliability]]"
description: Durability, replication, and consistency are explicit trade-offs — not implied by "we use Postgres."
derived_from:
  - "[[reliability]]"
  - "[[honesty]]"
updated: 2026-07-15
---

# Durable storage tradeoffs

## Statement

Choosing a database does not choose durability semantics. Engine WAL, sync/async commit, replication, backup, and application write-ahead audit must be **named** as separate layers with explicit trade-offs ([[observer-wal]], [[postgres-wal-concurrency]], [[ddia-reliability-themes]]).

## Rationale

D2 #4–#5: Postgres docs prove engine WAL ≠ “we stored a row.” Kleppmann/DDIA public pressure: reliability/scalability/maintainability require comparing designs and accepting limitations — append-only logs and derived views are one pattern, not ambient law for every family.

## Untapped

DDIA owned-copy chapters · replication topology deep · CMU storage engines.

## Related

- [[postgres-core-concepts]] · [[ddia-reliability-themes]] · [[distributed-systems-expectations]] · [[single-lived-source-of-truth]]
