---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[owasp-multifactor-authentication-pressure]]"
updated: 2026-07-16
---

# Mfa hygiene zoo

## When

MFA factors and recovery paths.

## When not

SMS-only MFA as “fully strong” without threat-model caveats.

```text
→ [[owasp-multifactor-authentication-pressure]]
```

## Related

- [[owasp-multifactor-authentication-pressure]] · [[mfa-factor-hygiene]]
