---
type: map
status: canonical
id: engineering-knowledge-base-map-platform
concern: platform
description: Atlas of accumulated gateway/platform knowledge — not a build playbook.
aliases: [gateway, microservices, k8s, helm, compose]
updated: 2026-07-19
---

# Atlas — Platform

Index of **accumulated knowledge** from the gateway-first Python platforms (K8s gateway family, Compose single-plane, Compose dual-plane). Use folders/notes below; do not treat this file as a task checklist.

## Contracts and policy

- [[envelope-call]] · [[policy-ingress-contract]]
- [[gateway-auth]] · [[config-fail-at-load]] · [[happy-path-construction]] · [[required-happy-path]]

## Ownership and edges

- [[capability-bridges]] · [[credential-owning-bridge]] · [[domain-io-edge-packaging]] · [[service-packaging]]
- [[s3-compatible-client-endpoint]]

## Deploy and host

- [[helm-deploy]] · [[compose-deploy]] · [[host-opentofu]]

## Orchestration and audit

- [[argo-workflows]] · [[in-process-orchestration]] · [[observer-wal]] · [[write-ahead-call-audit]]

## Delivery honesty

- [[delivery-ci]] · [[delivery-gates]] · [[threat-model-declaration]] · [[single-lived-source-of-truth]]

## Law (skim)

[[privileged-capability-ownership]] · [[domain-free-of-transport-io]] · [[prove-honesty-contracts]] · [[fail-at-the-gate]] · [[happy-path-only]] · [[required-happy-path]]

## Related

- [[catalog-maps]] · [[navigation]] · [[warehouse-atlas]] · [[trainer-atlas]] · [[security-atlas]] · [[delivery-atlas]]
