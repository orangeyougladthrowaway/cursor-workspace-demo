---
type: guidance
status: canonical
id: engineering-knowledge-base-g-pep8
concern: languages
description: Python PEP 8 — project consistency first; encode dialect via linters, not textbook dumps.
domain: [python]
aliases: [pep8, style]
derived_from:
  - "[[honesty]]"
  - "[[proof]]"
  - "[[delivery-ci]]"
updated: 2026-07-16
---

# Python style PEP 8

Primary (D1 #8): [PEP 8 — Style Guide for Python Code](https://peps.python.org/pep-0008/).

## Applies when

Setting Python format/lint gates ([[delivery-ci]]).

## House dialect (encode in tooling)

| Gate | Prefer |
| --- | --- |
| Format/lint | **ruff** (format + lint) as the single dialect encoder |
| Types | **mypy** as a hard or soft gate per [[python-typing-honesty]] / [[delivery-gates]] — do not invent a second style war |
| Editor | editorconfig aligned to ruff; no per-dev Black-vs-ruff forks |

## Guidance

1. Consistency hierarchy: guide < project < module/function (PEP 8’s “foolish consistency”).
2. Encode dialect in **CI tooling**, not chat folklore or vault textbook dumps.
3. Do **not** mirror Fluent/Effective Python into the vault — elevate claim-level collisions only.

## Untapped

Fluent Python · Effective Python (claim-collision only) — craft now in [[python-typing-honesty]], [[python-packaging-layout]], siblings.

## Related

- [[csharp-style-conventions]] · [[python-typing-honesty]] · [[delivery-gates]] · [[languages-atlas]]
