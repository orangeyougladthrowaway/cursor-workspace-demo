---
type: standard
status: canonical
id: engineering-knowledge-base-s-017
concern: policy
description: Required config and control paths fail loud on one happy path; silent fallbacks forbidden except named bounded exceptions.
domain: []
aliases: [no-silent-fallback, happy-path-field-tests]
derived_from:
  - "[[happy-path-only]]"
  - "[[fail-loud-on-control-paths]]"
  - "[[fail-at-the-gate]]"
  - "[[policy-as-explicit-artefact]]"
updated: 2026-07-17
---

# Required happy path

## Requirement

1. **Fail at load for required config.** Missing or invalid secrets, manifests, env, and other load-bearing inputs **stop** startup, build, or the owning control path. Do not boot or continue on invented substitutes ([[fail-at-the-gate]], [[config-fail-at-load]]).
2. **One construction path.** Each required authority (config set, policy compile, deploy activation) has **one** lived construction or load path. A second path ships only as an **explicit, time-bounded migration** with an owner and retirement — otherwise it is dual-SoT debt ([[single-lived-source-of-truth]]).
3. **No catch-all continue.** Broad `except` / empty `catch` / `continue-on-error` / `|| true` that swallows control-path failure is **forbidden** on load-bearing seams. Soft CI or lab skips must be labelled soft — never the quality story ([[delivery-gates]]).
4. **No invented load-bearing defaults.** Do not silently default secrets, trust roots, timeouts that change contract meaning, AuthZ matrices, or route tables. Optional values may default only when the optionality is **named in the contract**.
5. **Named exceptions only.** Soft recovery, fall-open controls, reduced lab posture, transport retries, and test doubles ship only when **explicitly named**, scoped, and (where temporary) bounded — see Exceptions. Unnamed soft recovery does **not** ship.

## Field tests (observable)

| Test | Pass | Fail |
| --- | --- | --- |
| Required env / secret absent | Process/gate exits with a clear error at load | Service “comes up” on empty/`None`/placeholder |
| Invalid core manifest / policy | Boot or compile hard-fails | Warn + skip critical routes |
| Two construction paths for one authority | Docs/code name one lived SoT; other retired or labelled residue | Both taught as official |
| Control-path exception | Typed failure surfaces; caller sees error | Bare catch + continue / empty success |
| Load-bearing default | Absent from code, or optional and documented | Secret/timeout/AuthZ invented in a fallback branch |
| Exception present | Threat model, migration note, or test seam names it | “Helpful” soft path with no declaration |

## Derived from

- [[happy-path-only]]
- [[fail-loud-on-control-paths]] · [[fail-at-the-gate]]
- [[policy-as-explicit-artefact]]

## Rationale

Resilience is recovery from **declared** failure modes — not concealment of missing authority. Silent workarounds train agents and humans to treat green as proof.

## Exceptions

| Exception | Rule |
| --- | --- |
| Declared lab / reduced controls | Written in [[threat-model-declaration]]; not copied into production doctrine by silence |
| Transport-only retries | Idempotent transport/transient I/O only; never retry as a substitute for missing config or AuthZ |
| Test doubles / fakes | Named in tests; not production fallbacks for absent dependencies |
| Soft extension manifests | Named soft; never documented as “locked core” ([[config-fail-at-load]]) |
| Time-bounded migration dual path | Owner + deadline; delete or quarantine by the deadline ([[single-lived-source-of-truth]]) |
| Untrusted media soft-parse | Contained at the media boundary only ([[fail-loud-on-control-paths]], [[deterministic-before-probabilistic]]) |

## Related

- [[happy-path-construction]] · [[config-fail-at-load]] · [[policy-as-artefact]]
- [[delivery-gates]] · [[prove-honesty-contracts]] · [[coding-agent-projection]]
- [[threat-model-matched-controls]] · [[silent-fallback-anti]]
