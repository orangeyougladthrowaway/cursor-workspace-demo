---
type: principle
status: canonical
description: Invalid configuration and broken load-time contracts fail at the gate — not halfway through a run.
id: engineering-knowledge-base-p-003
category: "[[failure]]"
derived_from:
  - "[[failure]]"
updated: 2026-07-17
---

# Fail at the gate

## Statement

Missing secrets, invalid manifests, unloadable contracts, and broken build artefacts should stop startup, build, or deploy immediately. Do not boot into a half-routed or half-configured world. Inventing defaults so the process “comes up” is a silent fallback — forbidden under [[happy-path-only]] / [[required-happy-path]].

## Rationale

Late discovery of broken config turns operations into archaeology. Gate failure is cheaper than partial success.

## Encourages

- Startup validation, compile/build verification, fail-closed shell/CI gates

## Prevents

- “It started” systems that cannot honestly serve requests
- Tribal knowledge as the only deploy contract

## Evidence (thin)

Shared fail-closed posture on config/build/deploy across warehouse and service platforms. Soft CI on style is a separate concern — see honesty-contracts principle.

## Related

- Category: [[failure]]
- [[fail-loud-on-control-paths]] · [[happy-path-only]] · [[required-happy-path]]
- [[config-fail-at-load]] · [[happy-path-construction]]
