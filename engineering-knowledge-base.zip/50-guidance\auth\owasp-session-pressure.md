---
type: guidance
status: canonical
id: engineering-knowledge-base-g-owasp-session
concern: auth
description: OWASP Session Management Cheat Sheet — cookies, entropy, TLS, fixation; maps to product edge.
domain: []
aliases: [session, cookies, fixation]
derived_from:
  - "[[gateway-auth]]"
  - "[[owasp-authentication-pressure]]"
updated: 2026-07-15
---

# OWASP session pressure

Primary (D1 #3): [OWASP Session Management Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html).

## Applies when

Browser / partner sessions, SSO cookies, or any long-lived session ID — **not** when the product is only service-mesh Envelope actors (still document the absence).

## Guidance (claims elevated)

1. Session IDs: high **entropy** (≥64 bits), unpredictable; avoid fingerprintable default names.
2. Prefer **cookies** over URL session IDs (logs, Referer, fixation).
3. Entire session on **HTTPS**; `Secure` (+ `HttpOnly`, careful `SameSite`); prefer `__Host-` where applicable.
4. Do not accept session IDs from alternate exchange mechanisms (anti-fixation).
5. Regenerate session ID on privilege change / login; invalidate on logout, idle, and absolute timeout.
6. TLS alone does not stop prediction/fixation — cookie flags + regenerate still required.

## Collision with lived gateway

Internal `POST /call` uses Envelope actors / optional JWT — **no classic browser session**. Session cheat sheet pressures **frontend/edge** if/when added. Do not pretend actor strings are session management.

## Untapped

Framework-specific configs · logout cascade recipes · full cookie flag matrix deep.

## Related

- [[owasp-authentication-pressure]] · [[threat-model-declaration]] · [[security-atlas]]
