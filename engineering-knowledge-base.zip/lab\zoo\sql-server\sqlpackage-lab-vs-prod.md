---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[dacpac-publish]]"
  - "[[delivery-gates]]"
  - "[[threat-model-declaration]]"
updated: 2026-07-15
---

# Sqlpackage lab vs prod

## When

Naming lab reset defaults vs production publish honesty.

## When not

Promoting destructive lab props as prod law.

```text
Lab (reset loops): CreateNewDatabase=true; BlockOnPossibleDataLoss=false
Prod (default posture): CreateNewDatabase=false; BlockOnPossibleDataLoss=true
```

## Related

- [[dacpac-publish]] · [[threat-model-declaration]]
