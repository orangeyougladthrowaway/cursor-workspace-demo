---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-011
concern: boundaries
description: Fowler microservice prerequisites — provisioning, monitoring, rapid deploy before service sprawl.
domain: []
aliases: [microservice-prerequisites, microservice-premium]
derived_from:
  - "[[microservices-tradeoffs]]"
  - "[[modular-monolith-default]]"
updated: 2026-07-15
---

# Microservice prerequisites

## Context

Teams want microservices for modularity/team autonomy before operations can run an ecosystem of small services.

## Problem

Without baseline competencies, service sprawl raises operational failure modes that a monolith would not.

## Solution

Primary (D2 #8): [Fowler — Microservice Prerequisites](https://martinfowler.com/bliki/MicroservicePrerequisites.html) + trade-offs essay themes ([Microservice Trade-Offs](https://martinfowler.com/articles/microservice-trade-offs.html)).

Before (or as you put) microservices in production, have:

1. **Rapid provisioning** — new server/capacity in hours via growing automation.
2. **Basic monitoring** — technical (errors/availability) and preferably business signals; ability to rollback fast.
3. **Rapid application deployment** — pipeline to test/prod in hours, trending to full automation.
4. **DevOps collaboration** — shared incident response and root-cause, not ticket walls.

Start with a **handful** of services; learn production health before ramping count. Beyond a handful: continuous delivery, cross-service tracing, multi-repo/tooling support.

Also weigh the **microservice premium**: distributed complexity cost is only repaid when the problem is complex enough ([[modular-monolith-default]]). Coordinated multi-service releases that cannot deploy independently are **not** microservices by definition.

## Collision with lived

Central Envelope ingress ([[policy-ingress-contract]]) + Compose/Helm deploy is a valid **non-microservices** posture. Prerequisites still pressure **ops maturity** for whatever deploy shape you claim.

## Related

- [[microservices-tradeoffs]] · [[delivery-gates]] · [[metrics-tracing-logging-pressure]] · [[architecture-atlas]]
