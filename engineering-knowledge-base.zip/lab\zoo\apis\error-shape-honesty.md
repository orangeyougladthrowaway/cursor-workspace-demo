---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[rest-resource-design]]"
  - "[[envelope-call]]"
updated: 2026-07-16
---

# Error shape honesty

## When

Returning error bodies on public HTTP.

## When not

Leaking stack traces or internal Envelope codes raw.

```text
Stable public error shape ≠ internal exception dumps
```

## Related

- [[rest-resource-design]] · [[public-http-vs-internal-envelope]]
