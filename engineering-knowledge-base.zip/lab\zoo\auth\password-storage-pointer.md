---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[owasp-password-storage-pressure]]"
updated: 2026-07-15
---

# Password storage pointer

## When

Storing credentials with modern KDFs (Argon2/bcrypt/…).

## When not

Reversible / recoverable password stores.

```text
Hash with a modern KDF — see [[owasp-password-storage-pressure]]
```

## Related

- [[owasp-password-storage-pressure]] · [[owasp-authentication-pressure]]
