---
type: guidance
status: canonical
id: engineering-knowledge-base-g-cs-toolchain
concern: languages
description: C# SDK-style projects, NuGet-shaped csproj, nullable references, dotnet test — tooling-first.
domain: [csharp, dotnet]
aliases: [csproj, nullable, nuget]
derived_from:
  - "[[csharp-style-conventions]]"
  - "[[unit-testing-norm]]"
updated: 2026-07-15
---

# Csharp project toolchain

Primaries (L-cs #1): [.NET project SDKs](https://learn.microsoft.com/en-us/dotnet/core/project-sdk/overview); [Nullable reference types](https://learn.microsoft.com/en-us/dotnet/csharp/nullable-references).

## Applies when

Authoring or gatekeeping .NET tooling / SSDT-adjacent C# (scope: tooling-first — not claiming lived service parity yet).

## Guidance

1. Prefer **SDK-style** projects (`<Project Sdk="Microsoft.NET.Sdk">`) — implicit compile globs, smaller csproj, `dotnet build/test/pack`.
2. Do not duplicate default `Compile` includes (NETSDK1022). Customize with `Remove`/`Update` or disable defaults deliberately.
3. Enable **`<Nullable>enable</Nullable>`**. Annotations (`string` vs `string?`) are compile-time intent; runtime types unchanged.
4. Treat null-state warnings as design feedback. Use `!` (null-forgiving) **sparingly** — prefer fixes/annotations. Watch pitfalls: `default` structs and arrays of non-nullable refs can still hold null without warnings.
5. Drive CI with `dotnet test` (and analyzers/editorconfig) as **hard** gates when quality is claimed — same honesty as Python ([[delivery-gates]], [[unit-testing-norm]]).
6. PackageReference / central versions — keep restore reproducible; no floating unpinned chaos in release branches.
7. SSDT / SqlPackage adjacency remains [[dacpac-publish]] — this note does not replace schema publish law.

## Untapped

Central Package Management deep · multi-targeting · Source Link · full Analyzer pack policy · Framework Design Guidelines chapters.

## Related

- [[csharp-style-conventions]] · [[csharp-async-di]] · [[dacpac-publish]] · [[unit-testing-norm]] · [[languages-atlas]]
