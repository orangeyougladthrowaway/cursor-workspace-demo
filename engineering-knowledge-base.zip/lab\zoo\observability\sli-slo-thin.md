---
type: example
status: canonical
domain: [observability]
derived_from:
  - "[[dora-metrics]]"
updated: 2026-07-16
---

# Sli slo thin

## When

Naming thin SLI/SLO signals for a service.

## When not

Inventing SLO dashboards without user journeys.

```text
SLI → objective → error budget conversation ([[dora-metrics]] adjacent)
```

## Related

- [[dora-metrics]] · [[reliability]]
