---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[owasp-multifactor-authentication-pressure]]"
updated: 2026-07-15
---

# Mfa factor hygiene

## When

Treating MFA factors as distinct trust factors with recovery honesty.

## When not

SMS-only MFA as “fully strong” without threat-model caveats.

```text
Factor hygiene + recovery paths → [[owasp-multifactor-authentication-pressure]]
```

## Related

- [[owasp-multifactor-authentication-pressure]] · [[owasp-session-pressure]] · [[asvs-authentication-mapping]]
