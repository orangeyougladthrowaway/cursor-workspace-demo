---
type: map
status: canonical
id: engineering-knowledge-base-map-trainer
concern: trainer
description: Atlas of accumulated local RL trainer knowledge — not a train playbook.
aliases: [hydra, pytorch, adapter, ppo]
updated: 2026-07-15
---

# Atlas — Trainer

Accumulated knowledge from local RL trainer work. Indexes notes; not a task journey. **No gateway assumptions.**

## Config and contracts

- [[hydra-config]] · [[adapter-routing]] · [[adapter-metadata-routing]]

## Algorithms

- [[train-loop-ppo]]

## Packaging / CI

- [[trainer-packaging]] · [[delivery-gates]] · [[single-lived-source-of-truth]]

## Related

- [[catalog-maps]] · [[platform-atlas]] · [[warehouse-atlas]] · [[agent-engineering-atlas]]
