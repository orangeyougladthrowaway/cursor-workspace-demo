---
type: foundation
status: canonical
description: How to learn from projects — distill then edit living notes; no evidence deposits.
updated: 2026-07-14
---

# Project analysis

Projects are **inputs**, not authorities.

## Pipeline

```text
Pick project + question (which note are we pressure-testing?)
        ↓
Lightweight look at structure / seams / gates
        ↓
Distill in chat (philosophy? category? principle? standard? pattern? reject?)
        ↓
Amend the living vault note(s)
```

## Rules

- Stay inside [[scope]].
- Prefer fewer stronger claims.
- Quarantine product/vendor/demo accidents — don’t universalise them.
- Do not file raw extracts into the vault.

## Anti-patterns

Copying project wikis here · one repo → one principle overnight · treating unfinished experiments as doctrine.
