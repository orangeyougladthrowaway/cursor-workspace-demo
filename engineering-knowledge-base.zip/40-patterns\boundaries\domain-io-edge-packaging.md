---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-004
concern: boundaries
description: "Domain transforms stay free of transport/vendor I/O; Docker extras + COPY are the real fences."
domain:
  - python
aliases:
  - domain-purity
  - packaging
  - extras
derived_from:
  - "[[domain-free-of-transport-io]]"
  - "[[restraint]]"
updated: 2026-07-15
---

# Domain I/O edge packaging

## Context

Business/domain rules must stay testable while HTTP, DB, and cloud SDKs churn across many images from one monorepo.

## Problem

Rules that import boto/HTTP/SQL become untestable and vendor-locked; “one package” installs invite accidental leakage.

## Forces

- Pure transforms for fast unit tests
- Real I/O must live somewhere
- Single setuptools tree vs many Docker images
- No import-linter in lived CI (convention + COPY only)

## Solution

1. **Domain / rule modules** hold transforms; **do not** import FastAPI, SQLAlchemy, boto3, or sibling services.
2. **Edges** own I/O: gateway layers, `create_service_api`, bridges (`db_api`, `storage_api`, inference/SaaS), orchestrator calling `call_via_gateway`.
3. **`@wrapper_method` + `ServiceRequest`/`ServiceResponse`** adapt domain/service methods onto the envelope — transport mapping at the edge.
4. **Role extras + Dockerfile COPY** are the real fences (`[db]`, `[gateway]`, `[storage]`, …); not separate publishable packages.
5. Document intentional exceptions (e.g. dual-plane `domain/<product>/inference.py` httpx, single-plane `domain/<product>/metadata_json.py` → `gateway_client.storage.get_bytes`) as **debt**, not style.
6. Prefer injecting ports (gateway classifier, `CompletionPort` / `GatewayCompletionPort`) over domain defaulting to vendor HTTP.

## Layer sketch (Compose family — single-plane and dual-plane share this shape)

```
domain/          # pure-ish transforms (exceptions documented)
lib/contracts/   # envelopes — no FastAPI
lib/runtime/     # FastAPI /call adapter (create_service_api, wrapper_method)
lib/gateway_client/   # call_via_gateway, storage helpers
services/gateway/
services/bridges/ + audit_db/ (+ workflow_db/ in dual-plane)
services/orchestrator/  # or <orchestrator> / <workflow-runner> — domain + call_via_gateway
apps/web/        # frontend (dual-plane only) — no domain COPY, UI doesn't share the transform tree
```

K8s family uses `framework/` layout (`framework/db_api`, `framework/storage_api`, `framework/services/custom/…`, `framework/core`) with the **same rules**, softer "domain purity" naming (rules live inside `services/custom/*` rather than a top-level `domain/`).

### Named leaks (do not elevate as an alternative style)

| Repo | File | Leak |
| --- | --- | --- |
| Compose dual-plane | `domain/<product>/inference.py` | Direct httpx call to DO Inference (`call_do_inference`) — the `inference_api` bridge exists and duplicates this; the orchestrator's default triage path uses the domain function unless a gateway-backed classifier is explicitly injected |
| Compose single-plane | `domain/<product>/metadata_json.py` | Calls `lib.gateway_client.storage.get_bytes` — domain reaching for gateway HTTP instead of the orchestrator/adapter doing it and passing bytes in |
| Compose single-plane | `domain/<product>/ocr_engine.py` | Orphaned duplicate of `services/ocr/engine.py` — zero importers; dead code masquerading as a domain OCR path |

Both leaks are real, named, and small enough to fix later — describe them as debt in reviews, not as evidence the pattern doesn't hold.

## Consequences

**Easier:** Fast domain tests; vendor swaps at bridges; thin worker images when COPY is strict.

**Harder:** Monorepo still installs base FastAPI/httpx everywhere (every extra combination pulls the base dependency set); fat workflow images that pip-install `[db,storage,inference,…]` "just in case" undermine fences even when the happy-path code never imports those SDKs.

**Watch:** Domain inference HTTP; orchestrator/domain → `gateway_client` imports that belong at adapters; absent import-guard CI (no import-linter, no `compileall`-based boundary test, in any of the three repos — the fence is Docker COPY discipline plus code review, not a gate).

### Packaging extras across the three repos (same shape, different names)

| Role | K8s gateway family | Compose single-plane | Compose dual-plane |
| --- | --- | --- | --- |
| Gateway | `[gateway]` — pyjwt, cryptography, bcrypt, kubernetes | `[gateway]` | `[gateway]` |
| DB owner | `[db]` | `[db]` | `[db]` |
| Storage owner | `[storage]` | `[storage]` | `[storage]` |
| Inference/vision | product extras (pillow, pytesseract, reportlab) | `[inference]` / `[ocr]` split | `[storage]`-adjacent, no dedicated extra beyond base |
| Fat worker debt | product extra installs broadly for pipeline workers | `Dockerfile.<orchestrator>` installs `[db,storage,inference,…]` extras it doesn't SDK-call | `Dockerfile.<workflow-runner>` copies all of `domain/<product>` (including the inference leak) and installs base only, but still gets inference env via `env_file` sprawl |
| Dev/CI | `[dev]` | `[dev]` | `[dev]` |
| Unwired extra | `[tracing]` (OTEL) — installed nowhere meaningful | — | `[edge]` (bcrypt) — used only by the host-side Caddy hash CLI, not a service image |

## Pattern statement

1. Transforms in domain; SDKs and frameworks at edges.
2. Cross-service I/O only via gateway client helpers.
3. Image extras + COPY enforce role stronger than package layout alone.
4. No import-linter today → review + known-debt list is mandatory honesty.
5. Wrapper/adapter owns envelope mapping, not domain cores.

**DDD / GoF spine (wide):** keep ubiquitous language and bounded context as *pressure* for naming ownership folders and atlas concerns — not a licence to spawn parallel domain-curriculum trees. GoF catalogues are pointers; elevate only when a lived seam matches.

## Related

- [[capability-bridges]] · [[service-packaging]] · [[platform-atlas]]
- [[domain-free-of-transport-io]] · [[credential-owning-bridge]] · [[policy-ingress-contract]]
