---
type: guidance
status: canonical
id: engineering-knowledge-base-g-sql-index-plan
concern: datastores
description: How to design, review, and maintain indexes and read plans for house SQL workloads.
domain: [sql-server, t-sql]
aliases: [indexing, execution-plan, statistics-craft]
derived_from:
  - "[[sql-flow-choices]]"
  - "[[declare-the-grain]]"
  - "[[fail-at-the-gate]]"
updated: 2026-07-20
---

# Sql index plan craft

Systems behaviour: indexes/stats as engine structures (systems-KB indexes-statistics). This note is **when/how we build and keep them**.

## Applies when

Choosing clustered/nonclustered keys, covering indexes, or diagnosing slow set-based loads (MERGE, mart rebuilds).

## Build

1. **Start from grain and predicates** — index the access path the query actually uses ([[warehouse-grain]], [[sql-flow-choices]]).
2. Prefer **one useful clustered key** per table (often business key or surrogate used in joins); heaps only with a named reason.
3. Add nonclustered indexes for proven seek/filter/join patterns — not speculative “index every FK” theatre.
4. Include columns only when covering removes repeated key lookups on hot paths; measure with **actual** plans.
5. Name indexes/constraints so operators can target them in maintenance ([[sql-code-structure]]).

## Maintain

| Signal | Action |
| --- | --- |
| Bad estimates / spills | Update statistics; check parameter sniffing; revisit predicates |
| Duplicate / unused indexes | Remove after evidence (writes and rebuild cost matter on ODS) |
| Fragmentation | Follow [[sql-maintenance-craft]] — rebuild/reorg is ops craft, not a substitute for wrong keys |
| MERGE/SCD hot tables | Index join keys + `is_current` filters used by load procs; verify plans after schema publish |

## Refuse

- Indexing before the query exists
- Copying vendor “best practice” index packs without workload evidence
- Ignoring write amplification on Type-2 tables

## Untapped

Indexed views as house default · columnstore mart standards · automatic tuning as SoT.

## Related

- [[sql-concurrency-craft]] · [[tsql-set-based-merge]] · [[sql-maintenance-craft]] · [[sql-server-craft-map]]
