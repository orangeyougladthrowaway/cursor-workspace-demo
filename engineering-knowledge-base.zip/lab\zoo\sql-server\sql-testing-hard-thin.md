---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[delivery-gates]]"
updated: 2026-07-16
---

# Sql testing hard thin

## When

Proving SQL/proc behaviour in CI.

## When not

“Manual SSMS check” as the only gate while claiming quality.

```text
Prefer automated SQL/publish checks as hard where claimed ([[delivery-gates]])
```

## Related

- [[delivery-gates]] · [[dacpac-publish]]
