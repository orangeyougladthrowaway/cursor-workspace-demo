---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-errors-resources]]"
updated: 2026-07-15
---

# Exitstack resources

## When

Managing multiple context managers dynamically.

## When not

Nested `with` trees that obscure cleanup order.

```python
from contextlib import ExitStack

with ExitStack() as stack:
    a = stack.enter_context(open(path_a))
    b = stack.enter_context(open(path_b))
    process(a, b)
```

## Related

- [[python-errors-resources]]
