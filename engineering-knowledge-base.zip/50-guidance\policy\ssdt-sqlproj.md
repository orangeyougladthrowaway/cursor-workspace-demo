---
type: guidance
status: canonical
id: engineering-knowledge-base-g-ssdt-sqlproj
concern: policy
description: SSDT / Microsoft.Build.Sql database projects — sqlproj layout, build, references, SQLCMD variables.
domain: [sql-server, ssdt]
aliases: [sqlproj, microsoft-build-sql, database-project]
derived_from:
  - "[[compiled-schema-release]]"
  - "[[dacpac-publish]]"
  - "[[policy-as-artefact]]"
updated: 2026-07-20
---

# Ssdt sqlproj

## Applies when

Authoring, reviewing, or CI-building SQL Server **database projects** (`.sqlproj`) that compile to `.dacpac`.

## Artefact roles

| Artefact | Role |
| --- | --- |
| `.sqlproj` | Project file — SDK, DSP target, includes, refs, SQLCMD vars, Pre/PostDeploy items |
| `.sql` object files | Declarative model (tables, procs, …) — compiled into the dacpac model |
| `.dacpac` | Build output — model + embedded deploy scripts |
| `.publish.xml` | Publish profile — connection + SqlPackage property bag ([[ssdt-publish-scripts]]) |

Product SoR for “what is a database” stays systems-knowledge-base (`sql-server-object-model` — read-only pressure). This note owns **how to build and maintain** the project.

## House layout

1. **One sqlproj per database** in the warehouse stack (Staging / ODS / DWH / Reports / ETL control) — [[compiled-schema-release]].
2. Prefer **Microsoft.Build.Sql** SDK-style projects (files auto-included) over hand-listed legacy SSDT item lists.
3. Set **DSP** (target platform) explicitly (lived: `Sql170` / SQL Server 2025 class) — build validates features against DSP.
4. Folder by schema/object kind for humans; schemas remain ownership boundaries ([[sql-code-structure]]).
5. **Database references** for cross-DB three-part names — compile-time validation; publish still needs ordered SqlPackage ([[dacpac-publish]]).
6. Declare **SQLCMD variables** in the project for environment/DB names; supply every required `/Variables:` at publish or fail loud.

## Build

```text
dotnet restore <solution>
dotnet build <path-to.sqlproj> -c Release
→ bin/.../<Name>.dacpac
```

CI hard-gates Release dacpac presence ([[delivery-gates]]). Debug local vs Release CI must not silently diverge ([[compiled-schema-release]]).

## Maintain

| Change | Do |
| --- | --- |
| New object | Add `.sql` under schema folder; rebuild; review publish plan |
| Rename/drop | Prefer intentional model edit + data-loss-safe publish props |
| Cross-DB call | Add/update database reference; keep publish order honest |
| Env-specific value | SQLCMD variable — not hardcoded server names in model objects |

## Refuse

- Click-ops schema as SoT while sqlproj exists
- Hollow empty sqlproj in publish order sold as a layer
- Mixing Pre/PostDeploy script bodies into the **Build** model (use PreDeploy/PostDeploy items — [[ssdt-publish-scripts]])

## Further detail

- [SQL database projects](https://learn.microsoft.com/en-us/sql/tools/sql-database-projects/sql-database-projects)
- [Microsoft.Build.Sql functionality](https://github.com/microsoft/DacFx/blob/main/src/Microsoft.Build.Sql/docs/Functionality.md)

## Related

- [[ssdt-publish-scripts]] · [[compiled-schema-release]] · [[dacpac-publish]] · [[ssis-dtproj-dtsx]] · [[warehouse-atlas]] · [[sql-server-craft-map]]
