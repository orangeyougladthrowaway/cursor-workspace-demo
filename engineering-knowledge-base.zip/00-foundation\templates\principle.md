---
type: template
status: canonical
description: Starter template for principle notes.
updated: 2026-07-14
---

# Template — Principle

```markdown
---
type: principle
status: draft
id: engineering-knowledge-base-p-NNN
category: "[[ownership]]"   # concept spine in 20-principles/{concept}/
description: ""
derived_from: []
updated: YYYY-MM-DD
---

# Principle name

## Statement

## Rationale

## Implications

## Related
```

Path: `20-principles/{concept}/{slug}.md`. See [[catalog-principles]] · [[navigation]].
