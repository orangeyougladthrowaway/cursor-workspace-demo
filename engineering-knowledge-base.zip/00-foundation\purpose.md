---
type: foundation
status: canonical
description: Why engineering-knowledge-base exists — engineering bible with majority common-case coverage, rooted in principle and primary sources, plus subordinate praxis.
updated: 2026-07-16
---

# Purpose

## Why this repository exists

Engineering decisions become tribal memory. This vault makes the **current** reasoning explicit so humans and agents share the same grounds.

External docs and project code are inputs. This repository holds the distilled **doctrine** — not a history of how every sentence got here — and a controlled **praxis** plane (`lab/`) so law can be applied as exemplars.

## What it is

- A long-lived **current-state** **engineering bible** (doctrine: `00`–`60` + `maps/`)
- Abstract → concrete layering (philosophy → … → guidance), placed by **concern**
- Coverage ambition: the **majority of common cases** for house languages and tools ([[scope]] watchlist), each rooted in **principle** and **trusted primary sources** ([[common-case-coverage]], [[knowledge-ingestion]])
- A subordinate **praxis plane** (`lab/`) — zoo / skeletons / stubs that **cite** canons, densify to that bar, and never redefine law
- Optimised for small notes, unique catalogs/maps, and AI navigation ([[navigation]])

## What it is not

- A proposal/ADR/evidence archive
- A dump of courses, bookmarks, or vendor manuals **as doctrine**
- Per-application product documentation
- A **curriculum path** / lesson sequence that replaces living canons (depth and majority coverage ≠ tutorial chapters)
- A place that ships published application libraries

## Success

Success is **not** “few notes” or “facets seeded.” Success is:

1. New work cites living notes; agents find the right altitude.
2. House languages/tools have **majority common-case** law (G1–G3 on [[common-case-coverage]]) backed by principles and fetched sources.
3. Matching **praxis** usually exists (G4) without treating exemplars as law.
4. Stack churn does not rewrite worldview; Untapped and Gaps stay honest.
5. Session budgets stay tight; **program** ambition stays wide ([[roadmap]] Axis F) — agents must not quietly shrink the destination bar.
