---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-ingest]]"
  - "[[fail-loud-on-control-paths]]"
updated: 2026-07-16
---

# Ingest fail surface

## When

Landing jobs that can partially skip rows.

## When not

Silent continue with zero exit as “success.”

```text
Surface failure: non-zero exit and/or metrics/logs for skipped/failed batches
See [[python-ingest]] — soft skip without signal is quarantine
```

## Related

- [[python-ingest]] · [[python-errors-resources]] · [[failure]]
