---
type: example
status: canonical
domain: [kubernetes]
derived_from:
  - "[[helm-deploy]]"
  - "[[trust]]"
updated: 2026-07-16
---

# Secret mount honesty

## When

Mounting secrets/config into workloads.

## When not

Baking secrets into images or logging mounted files.

```yaml
# Prefer Secret/ConfigMap mounts; never commit raw prod secrets in values
```

## Related

- [[helm-deploy]] · [[threat-model-declaration]]
