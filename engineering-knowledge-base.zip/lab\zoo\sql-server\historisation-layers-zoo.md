---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[historisation-layers]]"
  - "[[warehouse-historisation]]"
updated: 2026-07-16
---

# Historisation layers zoo

## When

Placing SCD2/history responsibility in the correct layer.

## When not

Reimplementing historisation ad hoc in every consumer.

```text
Staging → ODS/DWH layers own history contracts ([[historisation-layers]])
```

## Related

- [[historisation-layers]] · [[kimball-type2-scd]] · [[warehouse-historisation]] · [[scd2-dim-snapshot-fact]] · [[declare-the-grain]]
