---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[tsql-set-based-merge]]"
updated: 2026-07-16
---

# Tx isolation thin

## When

Choosing isolation for set-based warehouse merges.

## When not

Defaulting Serializable everywhere “for safety” without measuring blocking.

```sql
-- Prefer documented isolation for the batch; HOLDLOCK on MERGE target when required
-- See [[tsql-set-based-merge]] concurrency notes
```

## Related

- [[tsql-set-based-merge]] · [[tsql-batch-craft]]
