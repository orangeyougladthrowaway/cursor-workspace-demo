---
type: example
status: canonical
domain: [compose]
derived_from:
  - "[[compose-deploy]]"
updated: 2026-07-15
---

# Profiles honesty

## When

Separating lab stacks with Compose profiles.

## When not

Claiming prod-parity from a lab profile silently.

```yaml
services:
  api:
    profiles: ["lab"]
```

## Related

- [[compose-deploy]]
