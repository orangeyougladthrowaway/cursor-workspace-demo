---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-006
concern: ownership
description: "Volatile landing layer vs durable Type-2 history vs rebuildable serving marts; Python edge, SQL history."
domain:
  - sql-server
aliases:
  - staging
  - ods
  - scd2
  - warehouse-layers
derived_from:
  - "[[ownership]]"
  - "[[deterministic-before-probabilistic]]"
updated: 2026-07-20
---

# Historisation layers

Stack detail: [[warehouse-historisation]] · [[python-ingest]]. Atlas: [[warehouse-atlas]]. Grain/dim/fact shapes: [[declare-the-grain]] · [[scd2-dim-snapshot-fact]].

## Context

External APIs feed a multi-database warehouse. Landing must be cheap to reload; history must survive; serving models must stay queryable without becoming a second historisation engine.

## Problem

One database doing “current + history + marts” blurs ownership; Python SCD2 and SQL SCD2 double-write; silent incomplete extracts poison deletes-as-absence.

## Forces

- Reloadable snapshots vs slowly changing truth
- Clear owner per concern (ingest language vs transform language)
- Completeness before “not in batch ⇒ deleted”
- Facts want simple snapshot rows; dims need version surrogates for current and as-was joins
- Serving must **not** run a second SCD2 merge engine (ODS owns Type-2 write)

## Solution

| Layer | Role | Retention | Owner |
| --- | --- | --- | --- |
| **Landing / Staging** | Snapshot of source extract | Truncate + reload | Python staging writer (hash columns) |
| **Durable / ODS** | Source-aligned history | SCD2 | SQL merge procs |
| **Serving / DWH** | Dim/fact marts | Dims keep SCD2; facts snapshot from current | SQL load procs |
| **Control** | Orchestrate Stage→ODS→DWH | Proc + run control | SQL control project |

1. **Python owns** auth, clients, throttle/retry, explode→tables, row hash, truncate+insert. **No SCD2 in landing.**
2. **SQL owns** historisation and mart rebuilds.
3. **Entity grain:** landing ≈ ODS business key with SCD2 columns (`effective_from/to`, `is_current`, `is_deleted`, `row_hash`). Declare measurement grain separately ([[declare-the-grain]] · [[warehouse-grain]]).
4. Merge changed hashes / insert new rows for durable history. **ODS is the Type-2 merge SoT.** Serving **dims** sync/mirror the SCD2 envelope for joins ([[scd2-dimension-envelope]]); serving **facts** truncate+rebuild as snapshots with `created_at` + surrogate FKs ([[snapshot-fact-shape]] · [[scd2-dim-snapshot-fact]]). Default fact load uses current non-deleted dims; as-was uses dim version valid at event time.
5. Gate historisation behind a **successful ingest exit** (host orchestrator) — and treat incompleteness honestly (see Watch).
6. **Idempotent re-ingest is success.** Re-running the same business key when landing hash and durable current already match may yield **no** durable ODS mutation (noop / zero insert-update-delete). That is success when staging and serving remain consistent — agents must **not** treat a noop count as pipeline failure. Only unexpected empty staging, merge defects, or serving drift are failures.

### Layer diagram (lived shape)

```text
[API providers]
    → Python stage job (truncate Staging + row_hash)
    → EXEC [Control].[usp_Run_All] on control DB
         → [StageToODS].[usp_StageToODS_All]        (SCD2 merge per table)
         → [ODSToDWH].[usp_LoadAll_*]                (truncate + rebuild marts)
```

Landing owns unique business keys only (no version column). Durable tier adds the SCD2 envelope on the **same entity grain**: version surrogate PK, `effective_from`, `effective_to` (null while open), `is_current`, `is_deleted` (tombstone flag), `row_hash` (null on tombstone), unique index typically `(business_key, effective_from)` — note this does **not** enforce single-current (see Watch). **Serving dims** mirror that envelope for surrogate joins (current and as-was) — they are **not** a second merge SoT. **Serving facts** are snapshots (`created_at` + surrogate FK at measurement grain) — [[snapshot-fact-shape]] · [[scd2-dim-snapshot-fact]].

### Merge recipe (Stage → ODS)

Canonical three-phase merge run once per business-key table, per ETL cycle:

```text
@now = SYSUTCDATETIME()

A. UPDATE current durable rows joined to staging on business key
   WHERE row_hash != staging.row_hash
   SET effective_to = @now, is_current = 0

B. INSERT new current from staging
   WHERE NOT EXISTS (current durable row with same key AND same row_hash)
   -- covers brand-new keys + keys just expired by A

C. INSERT tombstone from durable currents whose key NOT IN staging
   is_current = 1, is_deleted = 1, row_hash = NULL, payload columns NULL
```

Phases A–B are sound hash-driven Type-2 **when staging is a complete snapshot**. Phase C is where the pattern breaks in practice — see Watch.

## Consequences

**Easier:** Landing disposable; history reviewable in SQL; marts simple.

**Harder:** Cross-DB publish order; tombstone/absence semantics must be correct or history lies.

**Watch (do not elevate as virtue):**

- **Tombstone Phase C without closing prior current.** If Phase C inserts the tombstone row without first `UPDATE`-expiring the existing current (like A does), the business key ends up with **two** `is_current = 1` rows — the last real payload and the tombstone. The `(key, effective_from)` unique index does not catch this because the tombstone's `effective_from` differs. A generic reusable merge proc that declares `@BusinessKeyCols`/`@joinCondition`/dynamic SQL but never populates them is scaffolding, not a working fallback — don't document it as a real merge path.
- **Re-run amplification.** With the Phase C bug present, every subsequent cycle where the key is still absent inserts *another* tombstone version — history spam and growing dual-current sets, not a stable deleted state.
- Soft ingest (`except: pass` around per-record enrichment loops) paired with absence≡delete: a caught-and-swallowed exception makes a key "missing from staging" indistinguishable from "genuinely removed at source." Fail closed (propagate / abort the stage job) before treating absence as delete, or don't wire absence-delete at all until ingest is provably complete.
- No transaction wrapping the A–B–C phases (or across the per-table dispatcher): a mid-run failure can leave rows expired without their replacement inserted, or leave later tables in a batch un-merged while earlier ones already committed.
- Marts filtering `is_current = 1` but omitting `is_deleted = 0` — a tombstone still flows into a dimension/fact join unless explicitly excluded.
- DDL/load drift: a fact or dim table carries the full SCD2 envelope in its DDL but its load proc's `INSERT` column list doesn't match (missing or renamed columns) — this is schema theatre, not a Type-2 fact; treat any such drift as a build/test gap, not a pattern to copy.
- Destructive SqlPackage defaults (`CREATE_NEW_DATABASE=True`, `BlockOnPossibleDataLoss=False`) run against the durable tier — see [[compiled-schema-release]]. A "successful" redeploy can silently erase all SCD2 history.

## Pattern statement

1. Volatile landing ≠ durable history ≠ rebuildable serving.
2. Edge language loads landing; historisation language owns Type-2.
3. Hash-aware truncate/reload on landing; SCD2 only on durable tier.
4. Serving is not a second Type-2 **merge** tier (ODS owns write); DWH dims may mirror SCD2 columns for joins.
5. Completeness gate before delete-by-absence.
6. Name lab destructiveness separately from the layering pattern.
7. Unchanged key/hash → durable noop on re-ingest is success, not a red signal.
8. Serving facts follow [[snapshot-fact-shape]]; dims follow [[scd2-dimension-envelope]].

## Related

- [[warehouse-historisation]] · [[python-ingest]] · [[dacpac-publish]] · [[warehouse-atlas]]
- [[compiled-schema-release]] · [[ownership]] · [[single-lived-source-of-truth]]
- [[scd2-dim-snapshot-fact]] · [[warehouse-grain]] · [[design-warehouse-tables]]
