---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[policy-ingress-contract]]"
  - "[[adapter-metadata-routing]]"
updated: 2026-07-15
---

# Ingress contract pointer

## When

Policy/ingress metadata must match declared routing contracts.

## When not

Ad-hoc header routing without a documented contract.

```text
Ingress/policy surface → [[policy-ingress-contract]]
Adapter metadata       → [[adapter-metadata-routing]]
```

## Related

- [[policy-ingress-contract]] · [[adapter-routing]] · [[adapter-metadata-routing]]
