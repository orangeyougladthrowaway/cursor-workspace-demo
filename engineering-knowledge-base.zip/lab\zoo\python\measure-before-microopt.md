---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[restraint]]"
updated: 2026-07-16
---

# Measure before microopt

## When

Tempted to micro-optimise hot paths without evidence.

## When not

Skipping algorithm/IO fixes while tuning constants.

```text
Measure (profiler / timer) → change → re-measure
See [[restraint]] — optimisation without a signal is theatre
```

## Related

- [[restraint]] · [[thin-primitives-over-platform-weight]]
