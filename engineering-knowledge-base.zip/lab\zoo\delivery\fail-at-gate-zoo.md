---
type: example
status: canonical
domain: [delivery]
derived_from:
  - "[[fail-at-the-gate]]"
updated: 2026-07-16
---

# Fail at gate zoo

## When

Preferring early hard failure over soft downstream recovery theatre.

## When not

“We’ll catch it in monitoring” as the primary quality plan.

```text
Fail loud at the gate → [[fail-at-the-gate]]
```

## Related

- [[fail-at-the-gate]] · [[delivery-gates]] · [[tott-culture]]
