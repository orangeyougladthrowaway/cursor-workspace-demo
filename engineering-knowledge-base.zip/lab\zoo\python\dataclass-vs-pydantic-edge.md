---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-logging-modeling]]"
updated: 2026-07-15
---

# Dataclass vs pydantic edge

## When

dataclasses for internal structs; Pydantic (or similar) at validated edges.

## When not

Pydantic everywhere “because validation” with no edge/core split.

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class Money:
    amount: int
    currency: str
# Validate at IO edge; keep core models simple
```

## Related

- [[python-logging-modeling]] · [[python-typing-honesty]]
