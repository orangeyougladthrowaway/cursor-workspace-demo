---
type: guidance
status: canonical
id: engineering-knowledge-base-g-sql-structure
concern: languages
description: SQL source structure — discoverable objects/files, explicit query shape, cohesive routines, and owned schemas.
domain: [sql-server, t-sql, postgres]
aliases: [sql-style, routine-layout, object-naming]
derived_from:
  - "[[cohesive-code-units]]"
  - "[[compiled-schema-release]]"
  - "[[boundaries]]"
  - "[[honesty]]"
updated: 2026-07-16
---

# SQL code structure

## Applies when

Organising SQL files, schemas, deployable objects, queries, procedures, and functions across SQL Server/Postgres projects.

## House defaults

### Names, files, objects

1. Follow the established database identifier convention; do not mix `snake_case`, `PascalCase`, abbreviations, and pluralisation inside one schema.
2. For a new schema, prefer descriptive unquoted identifiers and reserve words only when the platform convention requires otherwise.
3. Normally keep one deployable schema object per matching file where DACPAC/migration tooling supports it. Migration files may intentionally contain one ordered change.
4. Use schemas as ownership/capability boundaries—not as arbitrary folders.
5. Name constraints and indexes when operators or migrations must reference them; names should expose table and key purpose.

Cross-dialect casing is deliberately not universalised: established SQL Server and Postgres schemas may own different conventions. Consistency within the live schema wins.

### Query shape

1. Name columns explicitly in persisted/API-facing queries; avoid `SELECT *`.
2. Put major clauses on separate lines; qualify ambiguous columns and use short, meaningful aliases.
3. Keep predicates beside the relation/operation they constrain without hiding join semantics in unrelated conditions.
4. Use a CTE to name a meaningful intermediate set; do not turn every trivial subquery into ceremony.
5. A query or routine should answer one named data question or mutation responsibility.

### Routine shape

Prefer this reading order when the dialect supports it:

1. Parameters and declared outputs
2. Session/routine settings required by the platform
3. Preconditions and no-op guards
4. Transaction ownership
5. Main set-based query/DML
6. Explicit result/audit output
7. Error propagation and cleanup

Keep transaction ownership at one layer. A called routine must not silently commit work its caller expects to own.

### Object responsibility

| Need | Normally use |
| --- | --- |
| Durable relational state/invariant | table + constraints |
| Stable reusable read projection | view |
| Expensive persisted read projection | materialised/indexed view only with refresh/ownership plan |
| Set-returning reusable calculation | function when side-effect rules permit |
| Command/batch boundary | procedure |
| Cross-system orchestration | application/workflow layer, not a hidden trigger chain |

## Related

- [[sql-flow-choices]] · [[sql-programmability-craft]] · [[tsql-batch-craft]] · [[postgres-sql-craft]] · [[ssdt-sqlproj]] · [[compiled-schema-release]] · [[languages-atlas]] · [[sql-server-craft-map]]
