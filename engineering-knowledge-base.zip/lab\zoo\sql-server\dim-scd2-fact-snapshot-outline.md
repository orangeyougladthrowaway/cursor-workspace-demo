---
type: example
status: canonical
id: engineering-knowledge-base-ex-dim-fact-snap
concern: modeling
description: Zoo outline — SCD2 dim envelope + snapshot fact at same grain (SQL sketch).
domain: [warehouse, sql-server]
derived_from:
  - "[[scd2-dimension-envelope]]"
  - "[[snapshot-fact-shape]]"
  - "[[scd2-dim-snapshot-fact]]"
  - "[[warehouse-grain]]"
updated: 2026-07-20
---

# Dim scd2 fact snapshot outline

Fictional **goods** grain (1:N under agreement). Not production DDL. Canons cited above.

## Grain

- **Dim:** one current/historical version row per goods business key.  
- **Fact:** one snapshot row per goods measurement event (e.g. daily balance), FK to goods dim surrogate.

## Sketch

See stub: `lab/stubs/sql-server/dim-scd2-fact-snapshot-outline.sql`.

## Teaching points

- Dim carries `effective_from` / `effective_to` / `is_current` / `is_deleted` / `row_hash`.  
- Fact carries `created_at` + `goods_sk` — **not** a second Type-2 envelope.  
- Agreement appears as attribute or role dim key on goods — not a separate fact grain (1:N).  
- Account–customer M:N would need a **bridge** grain ([[grain-cardinality]]).

## Related

- [[design-warehouse-tables]] · [[historisation-layers]] · stub `scd2-merge-outline.sql`
