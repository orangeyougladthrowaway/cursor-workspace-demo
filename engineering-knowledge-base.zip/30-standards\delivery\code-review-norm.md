---
type: standard
status: canonical
id: engineering-knowledge-base-s-009
concern: delivery
description: Code review improves codebase health over time — standard, size, description, and looking-for norms from Google Eng Practices.
domain: []
aliases: [code-review, cl, lgtm]
derived_from:
  - "[[programming-over-time]]"
  - "[[delivery-gates]]"
  - "[[prove-honesty-contracts]]"
updated: 2026-07-15
---

# Code review norm

Primary source (D1): [Google Eng Practices — Code Review](https://google.github.io/eng-practices/review/) (reviewer standard, looking-for, comments; author small CLs, CL descriptions, handling comments). Pressure only — this note is engineering-knowledge-base doctrine.

## Requirement

### Reviewer standard

1. Primary goal: **overall code health improves over time**.
2. Favor **approve** when a CL **definitely improves** health — even if imperfect. Prefer continuous improvement over perfection theatre.
3. **Never** approve a CL that **definitely worsens** health (emergency-only exception — rare, explicit).
4. Technical **facts and data** overrule opinions. Style guide wins style disputes; design is almost never “mere preference.”
5. If several designs are equally valid on principles/data, accept the **author’s** preference; else apply established design principles. Else ask consistency with existing code **unless** that would worsen health.
6. Mentoring comments are encouraged; if not mandatory, label **Nit:** / **Optional** / **FYI**.
7. Conflicts: seek consensus from these norms; prefer talk/video then **escalate** — do not leave CLs stalled.

### What reviewers look for

| Lens | Ask |
| --- | --- |
| Design | Belongs here? Integrates? Right time? |
| Functionality | Does what was intended — and is that good for users **and** future developers? |
| Complexity | Too hard to understand quickly? Over-engineering / speculative generality (**solve the known problem now**) |
| Tests | Appropriate tests **in the same CL**; tests actually fail when broken; tests are maintainable |
| Naming / comments | Names communicate; comments mostly **why**, not **what** |
| Style | Follow house/style guide; personal prefs are Nits — don’t block on them |
| Docs | Update docs when build/test/interact/release behaviour changes; delete stale docs with deletions |
| Context | Read enough surrounding code; refuse CLs that degrade system health in the small |

Review **every line** assigned (exceptions: generated/data — scan carefully). If you don’t understand it, the next reader won’t — ask for clarification or a more qualified reviewer (security, concurrency, …). Praise good work explicitly.

### Author: small CLs

1. One **self-contained** change — usually part of a feature, not the whole feature.
2. Include **related tests in the same CL**. Behaviour/logic changes ship with tests; pure refactors should be covered (add tests first if missing). Independent test-only CLs may precede refactors.
3. Prefer ~100 lines as a practical scale; ~1000 usually too large — reviewer judgment wins. Many files inflate “size.”
4. Split: stack dependent CLs; split by owner/files; horizontal (layers) / vertical (features); **separate large refactorings** from feature/bug CLs. Local tiny renames OK inside a feature CL.
5. Don’t break the build between stacked submissions. If it “must” be large — almost always wrong; ask for split. Advance consent only if truly unavoidable.

### Author: CL descriptions

1. First line: short imperative summary that **stands alone** in history.
2. Body: **what** and **why** (context, trade-offs, links with enough inline context for future readers).
3. Bad: “Fix bug”, “Phase 1”, “Moving code”. Good: problem + approach + limitations.
4. Re-check the description before final submit — review often drifts the meaning.

### Authors handling comments

1. Don’t take it personally; never reply in anger.
2. Prefer **fix the code** (or a durable code comment) over explaining only in the review tool.
3. Disagree collaboratively — trade-offs and facts, not “No.” Escalate per standard above.

### Reviewer comment craft

1. Be kind; comment on **code**, not the person.
2. Explain **why**.
3. Balance “point at the problem” vs prescribe a fix — learning vs getting the best CL.
4. Label severity: **Nit** / **Optional|Consider** / **FYI**.

## Collisions with lived engineering-knowledge-base

- Soft gates / theatre ([[delivery-gates]]) — review that only checks style while honesty seams are soft **worsens** health; reject that theatre.
- Agent “done” without review evidence — violates this standard ([[coding-agent-projection]]).
- Lab fall-open AuthZ — not fixed by review theatre; still named debt ([[gateway-auth]]).

## Untapped (same source)

Speed-of-review page (fetch retry) · pushback-handling page · full navigation-of-CL page. SE@Google book remains separate deep ([[engineering-craft-atlas]] order #1b).

## Related

- [[delivery-gates]] · [[prove-honesty-contracts-in-delivery]] · [[programming-over-time]] · [[coding-agent-projection]] · [[engineering-craft-atlas]]
