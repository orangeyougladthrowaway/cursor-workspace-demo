---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[rest-resource-design]]"
updated: 2026-07-16
---

# Rest pagination zoo

## When

Listing collections with documented page/cursor honesty.

## When not

Unbounded lists as the default public API.

```text
Document pagination/filtering in the Spec ([[rest-resource-design]])
```

## Related

- [[rest-resource-design]] · [[openapi-specification]]
