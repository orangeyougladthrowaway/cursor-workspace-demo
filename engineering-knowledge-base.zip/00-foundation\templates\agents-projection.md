---
type: template
status: canonical
id: engineering-knowledge-base-tpl-agents
description: Product AGENTS.md — thin pointer; engineering-knowledge-base primary; research fills gaps; house rules win.
updated: 2026-07-16
---

# Template — product `AGENTS.md`

**Prefer the copy-pack:** [[product-init]].

Copy into root, fill brackets, **delete** any leftover `product-init/` folder. Do not paste engineering-knowledge-base note bodies.

Product agents: **retrieve engineering-knowledge-base before build**; external research allowed for domain gaps; **engineering-knowledge-base wins** on house engineering.

Full protocol: [[coding-agent-projection]].

## Related

- [[product-init]] · [[coding-agent-projection]] · [[knowledge-ingestion]] · [[navigation]] · [[catalog-maps]]
