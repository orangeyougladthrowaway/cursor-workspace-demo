---
type: foundation
status: canonical
description: Allowed dependency directions — depend upward, specialise downward.
updated: 2026-07-15
---

# Dependency rules

## Core law

> **Depend upward, specialise downward.**

```text
foundation / philosophy
        ↑
     category
        ↑
    principle
        ↑
    standard
        ↑
     pattern
        ↑
    guidance / workflow / example
```

## Hard rules

1. Philosophy/category/principle must not depend on a concrete language, framework, or cloud product as authority.
2. Every principle declares exactly one `category`.
3. Every standard `derived_from` at least one principle.
4. Guidance specialises; it does not redefine higher notes. If practice conflicts, update the higher note.
5. Examples are non-normative (including `lab/zoo/` entries).
6. Same-tier links are narrow and non-cyclic.
7. **Praxis may depend on doctrine** (`derived_from` / Related → altitude notes). **Doctrine must not treat lab stems as authority** — if an exemplar encodes new law, elevate into guidance/pattern first, then point the zoo entry at the canon.

## Placement

Standards, patterns, guidance, and workflows also sit in a **concern** folder from the closed enum in [[navigation]]. Concern is placement metadata — not a new dependency tier.

## Agent checklist

- [ ] Correct `type` and altitude
- [ ] Correct `concern` folder + frontmatter (where applicable; maps use family folder)
- [ ] Principles have `category`
- [ ] Dependencies only upward / same-tier non-cyclic
- [ ] No stack-as-philosophy; no org-unit L1 folders
- [ ] `status` is `draft` | `canonical` | `deprecated` (deprecated = brief migration only)
- [ ] Naming / cleanliness pass if structure changed ([[methodology]], [[changing-this-bible]])
