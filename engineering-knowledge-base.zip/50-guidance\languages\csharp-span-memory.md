---
type: guidance
status: canonical
id: engineering-knowledge-base-g-cs-span
concern: languages
description: C# Span/Memory common subset — local slices; Memory across awaits; measure before rewrite.
domain: [csharp]
derived_from:
  - "[[restraint]]"
  - "[[reliability]]"
  - "[[csharp-project-toolchain]]"
  - "[[csharp-linq-api]]"
updated: 2026-07-16
---

# Csharp span memory

Primary: [Memory\<T\> and Span\<T\>](https://learn.microsoft.com/dotnet/standard/memory-and-spans/).

## Applies when

Slicing buffers/strings without extra allocations at hot, local boundaries.

## Does not apply when

- Rewriting readable LINQ without a measured allocation/perf problem ([[restraint]])
- Async APIs that would need to return `Span<T>` (illegal / footgun)

## House defaults

1. Prefer `Span<T>` / `ReadOnlySpan<T>` for **stack or local** slices that do not escape the method.
2. Use `Memory<T>` / `ReadOnlyMemory<T>` when the buffer must **live across an await** or be stored on a field.
3. Do **not** expose `Span` on async interfaces — return `Memory`, copy, or keep the slice below the await.

```csharp
// Local slice — OK
ReadOnlySpan<char> head = input.AsSpan(0, Math.Min(3, input.Length));

// Across await — use Memory (or copy), never Span
async Task UseAsync(ReadOnlyMemory<byte> buffer, CancellationToken ct)
{
    await Task.Yield();
    _ = buffer.Span.Length; // Span only after resume, still local
}
```

4. Measure before replacing LINQ pipelines with span rewrites — clarity beats micro-alloc theatre until proven.

## Decision rules

| Need | Prefer |
| --- | --- |
| Parse/slice in one method | `ReadOnlySpan<T>` |
| Buffer handed to async I/O | `ReadOnlyMemory<T>` |
| Hot path unproven | leave LINQ; profile first |

## Untapped

Pipeline API deep · MemoryPool patterns · unsafe interop.

## Related

- [[csharp-project-toolchain]] · [[csharp-linq-api]] · [[languages-atlas]]
