---
type: map
status: canonical
id: engineering-knowledge-base-map-agent-eng
concern: agent-engineering
description: Theme atlas — coding-agent projection, MCP, ReAct/RAG product-LLM pressure.
domain: []
aliases: [agents, mcp, react, rag]
updated: 2026-07-17
---

# Atlas — Agent engineering

AI-assisted coding rails and product-LLM pressure. Index only.

## Workflow / law

- [[coding-agent-projection]] · [[plan-engineering-change]] · [[build-engineering-change]] · [[verify-engineering-change]] · [[review-engineering-change]]
- [[knowledge-ingestion]] · [[d1-deep-harvest-playbook]] · [[post-capture-review]] · [[vault-health-checks]] · [[ingest-coverage]]

## Canonical (D1 #10 + D2 #13)

- [[react-reason-act-pressure]] · [[rag-retrieval-pressure]] · [[deterministic-before-probabilistic]]

## Deep backlog (D2+)

Osmani skills remainder · MCP protocol deep · ReAct full methods · RAG successors · SDK frameworks.

## Related

- [[catalog-maps]] · [[engineering-craft-atlas]] · [[delivery-atlas]]
