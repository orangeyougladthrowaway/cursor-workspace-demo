---
type: guidance
status: canonical
id: engineering-knowledge-base-g-cs-structure
concern: languages
description: C# source structure — discoverable files/types, nullable contracts, cohesive classes, and deliberate data types.
domain: [csharp, dotnet]
aliases: [type-layout, class-layout, records]
derived_from:
  - "[[cohesive-code-units]]"
  - "[[csharp-style-conventions]]"
  - "[[csharp-project-toolchain]]"
  - "[[domain-free-of-transport-io]]"
updated: 2026-07-16
---

# Csharp code structure

## Applies when

Organising C# files, namespaces, types, constructors, members, and data models.

## House defaults

### Names and files

| Element | Normally use |
| --- | --- |
| Namespace/type/public member | `PascalCase` |
| Interface | `I` + `PascalCase` |
| Parameter/local | `camelCase` |
| Private instance field | `_camelCase` |
| Async method | `Async` suffix unless framework convention forbids |

Prefer one primary public type per matching file. Colocate tightly coupled private/nested types and tiny supporting enums/records when splitting would hurt discovery. Partial/generated/framework-required types are named exceptions—not a default decomposition strategy.

Use file-scoped namespaces for new files when consistent with the project. Organise namespaces by owned capability, not merely by technical nouns such as `Helpers`.

### Type and class shape

Prefer this scan order when present:

1. Constants/static fields
2. Instance fields
3. Constructor/factories
4. Properties/events
5. Public methods
6. Protected/private helpers
7. Nested types

Keep one clear injectable constructor ([[csharp-async-di]]). Establish invariants at construction; do not scatter partially valid state across later setup calls.

Methods should do one named job at one abstraction level. Extract when a block has an independent name/invariant or hides the main operation—not to satisfy an arbitrary line limit.

### Data-shape choices

| Need | Prefer |
| --- | --- |
| Identity, mutable lifecycle, behaviour, DI service | `class` |
| Immutable value/data semantics | `record` |
| Tiny value with copy semantics and measured benefit | `readonly record struct` / `readonly struct` |
| HTTP/file/message boundary | explicit DTO, mapped inward |
| Closed alternatives with distinct data | small type hierarchy or discriminated-style records |

Avoid mutable public fields. Enable nullable references; model optionality with `?` only when absence is meaningful. Prefer empty collections over null collections. Use `!` only when an invariant is true but the analyser cannot see it ([[csharp-project-toolchain]]).

## Does not apply when

Generated code owns layout, or a framework requires partial classes/member ordering. Keep generated and hand-written responsibilities visibly separate.

## Related

- [[csharp-flow-choices]] · [[csharp-async-di]] · [[csharp-system-text-json]] · [[csharp-project-toolchain]] · [[languages-atlas]]
