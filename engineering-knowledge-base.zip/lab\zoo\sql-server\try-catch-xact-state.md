---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[tsql-batch-craft]]"
updated: 2026-07-15
---

# Try catch xact state

## When

Trapping severity>10 errors; deciding commit vs rollback.

## When not

Assuming CATCH auto-returns the error to the client.

```sql
BEGIN TRY
  BEGIN TRAN;
  -- work
  COMMIT;
END TRY
BEGIN CATCH
  IF XACT_STATE() = -1 ROLLBACK;
  THROW;
END CATCH;
```

## Related

- [[tsql-batch-craft]]
