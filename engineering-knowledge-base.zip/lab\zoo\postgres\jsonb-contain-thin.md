---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-jsonb-craft]]"
updated: 2026-07-16
---

# Jsonb contain thin

## When

Querying containment on a jsonb attribute bag beside relational keys.

## When not

Storing primary keys / join keys only in jsonb.

```sql
SELECT id FROM widget
WHERE tenant_id = $1
  AND attrs @> '{"tier":"gold"}'::jsonb;
-- pair with GIN (jsonb_path_ops) when measured
```

## Related

- [[postgres-jsonb-craft]] · [[postgres-sql-craft]]
