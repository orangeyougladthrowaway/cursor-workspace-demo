---
type: category
status: canonical
description: Spine for restraint — tools serve owned architecture; refuse platform weight without a job.
id: engineering-knowledge-base-cat-003
derived_from:
  - "[[accountable-meaning-under-change]]"
updated: 2026-07-13
---

# Restraint

## Theme

Frameworks and platforms are **tools**. Owned contracts and thin primitives are the architecture. Accumulate weight only for a maintainable ownership or honesty job.

## Belongs here

Anti-sprawl, thin kernels, tool-subordinate-to-architecture constraints.

## Does not belong here

How policy artefacts evolve (see [[change]]); where privileged I/O lives (see [[ownership]]).

## Leaves

- [[thin-primitives-over-platform-weight]]
