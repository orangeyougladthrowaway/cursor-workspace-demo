---
type: example
status: canonical
domain: [agent]
derived_from:
  - "[[coding-agent-projection]]"
updated: 2026-07-16
---

# Canon first projection

## When

Agents retrieve engineering-knowledge-base before acting.

## When not

Inventing task journeys that bypass atlases/canons.

```text
Atlas → canon → lab second ([[coding-agent-projection]])
```

## Related

- [[coding-agent-projection]] · [[common-case-coverage]]
