---
type: example
status: canonical
domain: [opentofu]
derived_from:
  - "[[terraform-state-backends]]"
updated: 2026-07-15
---

# Azurerm backend minimal

## When

Azure Blob remote state (lived preferred path).

## When not

Committing access keys in the backend block.

```hcl
terraform {
  backend "azurerm" {
    storage_account_name = "tfstateacct"
    container_name       = "tfstate"
    key                  = "env/app.tfstate"
  }
}
```

## Related

- [[terraform-state-backends]]
