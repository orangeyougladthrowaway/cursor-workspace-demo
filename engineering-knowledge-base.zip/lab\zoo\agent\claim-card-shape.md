---
type: example
status: canonical
domain: [agent]
derived_from:
  - "[[knowledge-ingestion]]"
updated: 2026-07-15
---

# Claim card shape

## When

Remote harvest lands as claim cards, not chapter dumps.

## When not

“Paste the book chapter” as doctrine.

```text
claim_id / statement / concern_guess / evidence_span / source_ref
→ [[knowledge-ingestion]] · [[praxis-ingestion]]
```

## Related

- [[knowledge-ingestion]] · [[praxis-ingestion]] · [[post-capture-review]]
