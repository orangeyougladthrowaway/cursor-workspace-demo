---
type: guidance
status: canonical
id: engineering-knowledge-base-g-py-async
concern: languages
description: Python concurrency — async for I/O; TaskGroup; HTTP timeout+cancel together; no sync-over-async.
domain: [python]
aliases: [asyncio, concurrency]
derived_from:
  - "[[reliability]]"
  - "[[honesty]]"
  - "[[failure]]"
  - "[[python-errors-resources]]"
updated: 2026-07-16
---

# Python concurrency async

Primary (L-py #4): [asyncio — Coroutines and Tasks](https://docs.python.org/3/library/asyncio-task.html).  
HTTP timeouts/cancel: client library docs (httpx/asyncio) — both at the edge.

## Applies when

Choosing threads vs processes vs asyncio for I/O-bound service/worker code.

## Does not apply when

- CPU-bound work expected to “go faster” via async alone
- Nesting `asyncio.run` inside hot sync library paths

## House defaults

1. **Async is for concurrent I/O**, not CPU speedup. CPU-bound → processes (or native), not more `await`.
2. Prefer **structured** task APIs (`asyncio.TaskGroup`) over fire-and-forget `ensure_future` piles.
3. Always set **timeouts** and respect **cancellation** at boundaries (`asyncio.timeout` / `wait_for`).
4. Do not call blocking stdlib I/O inside coroutines without an executor — you stall the loop.
5. Sync-over-async is a smell; pick one model per entrypoint.
6. **Threading** for blocking non-async libraries; isolate shared mutable state.
7. Outbound HTTP: **timeout alone is not done.** Set client timeouts **and** pass cancel where the stack supports it (e.g. FastAPI `Request.is_disconnected` / shared `asyncio.CancelledError` path, or an explicit `CancellationToken`-style event into the client call). Unbounded waits are not “simple.”

```python
# Structured timeout around concurrent work
async with asyncio.TaskGroup() as tg:
    async with asyncio.timeout(5):
        tg.create_task(fetch_a())
        tg.create_task(fetch_b())

# httpx — timeout at the client edge; cancel must still be wired by the caller
client = httpx.AsyncClient(timeout=httpx.Timeout(5.0, connect=2.0))
# Prefer: await client.get(url) inside a cancellable task / request-scoped shutdown,
# not fire-and-forget with only a Timeout config.
```

### Done test (HTTP)

| Check | Pass means |
| --- | --- |
| Timeout configured | `Timeout` / connect bound on the client or call |
| Cancel path exists | request abort, task cancel, or explicit cancel signal can stop the wait |
| Errors fail loud | timeout/cancel surface as typed failures — not silent hang |

## Decision rules

| Workload | Prefer |
| --- | --- |
| Many sockets / HTTP | asyncio + timeouts **+** cancel |
| Blocking SDK | thread pool / threads |
| Pure-Python CPU fan-out | processes |

## Untapped

trio/anyio · full streaming · uvloop · FastAPI lifespan deep recipes · httpx transport cancel encyclopaedia.

## Related

- [[python-errors-resources]] · [[python-flow-choices]] · [[service-packaging]] · [[languages-atlas]] · [[fail-loud-on-control-paths]]
