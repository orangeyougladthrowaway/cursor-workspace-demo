---
type: principle
status: canonical
description: Put privileged capabilities behind the smallest owning boundary; do not share secrets or privileged I/O by convenience.
id: engineering-knowledge-base-p-001
category: "[[ownership]]"
derived_from:
  - "[[ownership]]"
updated: 2026-07-13
---

# Privileged capability ownership

## Statement

Secrets, privileged persistence, and dangerous external I/O belong to the smallest owning boundary that needs them. Other components request capability through explicit contracts — they do not inherit credentials by proximity.

## Rationale

Credential and privilege sprawl is the real architecture. Ownership walls limit blast radius and make trust reviewable.

## Encourages

- Capability-scoped runtimes and configs
- Bridges/services/modules that *own* a privilege surface

## Prevents

- “Every component has everything”
- Silent side-channels around the declared trust model

## Evidence (thin)

Recurring in gateway platforms (storage/DB/edge owners) and warehouse secret injection. Product names and vendors omitted by design.

## Related

- Category: [[ownership]]
- [[domain-free-of-transport-io]]
