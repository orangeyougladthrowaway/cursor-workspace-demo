---
type: category
status: canonical
description: Spine for boundaries — where side effects and transport may not leak.
id: engineering-knowledge-base-cat-boundaries
derived_from:
  - "[[accountable-meaning-under-change]]"
updated: 2026-07-14
---

# Boundaries

## Theme

Domain and rule logic stay inside clear walls. Transport, vendors, and privileged I/O do not dissolve those walls for convenience.

## Belongs here

Principles about isolation of domain from transport/vendors and similar boundary constraints.

## Does not belong here

Who owns a credential ([[ownership]]); threat-model specifics ([[trust]]); proof of seams ([[proof]]).

## Leaves

- [[domain-free-of-transport-io]]
