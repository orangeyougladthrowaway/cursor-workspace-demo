---
type: principle
status: canonical
description: On control paths, explicit failure is required; soft-fail only where untrusted media are declared.
id: engineering-knowledge-base-p-004
category: "[[failure]]"
derived_from:
  - "[[failure]]"
updated: 2026-07-17
---

# Fail loud on control paths

## Statement

Decision, persistence, and orchestration control paths **must** raise or surface structured failure when preconditions break. Soft-fail or empty-success is allowed only for explicitly untrusted inputs (e.g. some model outputs), and that exception must be named and contained. Silent recovery that conceals a broken control contract is **forbidden** — see [[happy-path-only]].

## Rationale

Quiet continuation on the control path invents false history. Contained soft-fail on untrusted media can be rational — smuggling it into control flow is not.

## Encourages

- Typed domain errors; explicit precondition checks; clear boundary where recovery is allowed

## Prevents

- Poisoned pipelines and “success” that means guesswork
- Catch-all continue on control seams sold as resilience

## Evidence (thin)

Strong raise-on-missing doctrine in service platforms; known tension with LLM JSON soft-parses — that tension is a candidate for later guidance, not a dilution of this principle.

## Related

- Category: [[failure]]
- [[fail-at-the-gate]] · [[happy-path-only]] · [[required-happy-path]]
- [[deterministic-before-probabilistic]]
