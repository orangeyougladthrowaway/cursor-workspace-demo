---
type: example
status: canonical
domain: [opentofu]
derived_from:
  - "[[host-opentofu]]"
updated: 2026-07-16
---

# Provider lock pin

## When

Pinning providers for reproducible plans.

## When not

Floating provider versions across machines.

```hcl
terraform {
  required_providers {
    azurerm = { source = "hashicorp/azurerm", version = "~> 3.0" }
  }
}
# commit .terraform.lock.hcl
```

## Related

- [[host-opentofu]] · [[terraform-modules-composition]]
