---
type: catalog
status: canonical
id: engineering-knowledge-base-cat-foundation
description: Foundation notes for how this bible works.
updated: 2026-07-14
---

# Catalog — Foundation

| Note | Role |
| --- | --- |
| [[purpose]] | Why engineering-knowledge-base exists |
| [[scope]] | In / out |
| [[navigation]] | **How to navigate** (constitution) |
| [[layout]] | Folder contracts |
| [[knowledge-model]] | Types |
| [[dependency-rules]] | Depend upward |
| [[methodology]] | Note conventions |
| [[changing-this-bible]] | How to edit |
| [[starting-landscape]] | Direction map (not doctrine) |
| [[roadmap]] | What’s next |
| [[glossary]] | Terms |
| [[principles]] | Meta writing principles |
| [[project-analysis]] | How we analyse projects |
| [[design-influences]] | Influences |
| [[catalog-templates]] | Templates |

Entry: [[README]] · Jobs: [[catalog-maps]].
