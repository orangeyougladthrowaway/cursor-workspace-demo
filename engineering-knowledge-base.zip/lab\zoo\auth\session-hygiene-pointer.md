---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[owasp-session-pressure]]"
  - "[[gateway-auth]]"
updated: 2026-07-15
---

# Session hygiene pointer

## When

Session fixation / timeout / rotation pressure at the gateway.

## When not

Long-lived tokens without documented rotation/revoke story.

```text
Session pressure → [[owasp-session-pressure]]
Gateway surface  → [[gateway-auth]]
```

## Related

- [[owasp-session-pressure]] · [[gateway-auth]] · [[owasp-authentication-pressure]]
