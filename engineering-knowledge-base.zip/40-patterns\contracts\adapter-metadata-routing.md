---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-008
concern: contracts
description: "Thin env adapter + metadata tags route training loops without forking the trainer core."
domain:
  - pytorch
  - python
aliases:
  - adapter
  - game_type
  - universal-adapter
derived_from:
  - "[[domain-free-of-transport-io]]"
  - "[[extend-established-patterns]]"
  - "[[deterministic-before-probabilistic]]"
updated: 2026-07-14
---

# Adapter metadata routing

Config: [[hydra-config]] · [[adapter-routing]]. Atlas: [[trainer-atlas]].

## Context

One trainer core must drive many environments/demos without a plugin registry or per-game trainer forks.

## Problem

Hardcoded game branches and mythical `BaseAdapter` docs diverge from the thin duck-typed adapter that actually trains.

## Forces

- Stable train loop (PvE/PvP) vs varying obs/action rules
- Metadata must be enough to route and size networks
- Research features (retrieval, continual) tempt README ahead of wiring
- Path/class load is enough for local research — no mesh/gateway

## Solution

1. **Adapter contract:** required metadata keys (`game_type`, `num_agents`, `supports_symbolic_state`, `action_space_type`, `observation_space_type`) + methods `reset`, `step`, `get_observation_space_info`, `get_action_space_info`.
2. Happy path: discrete actions; obs shaped as `{"vector": …}`; standard reset/step tuples.
3. **Load without fork:** Hydra `adapter.class_path` or `adapter.file_path` (+ optional class name / duck-scan).
4. **Route by tag:** `metadata["game_type"]` aliases choose `train_pvp` vs `train_pve` — document alias set.
5. Infer dims from adapter spaces — no game hardcoding in the core.
6. Prefer `info["action_mask"]` (or `get_action_mask`) for legality; emit `phase_id` when situation bins matter.
7. Keep game rules in demo libs; adapter stays thin.

### Contract detail (single SoT class)

**Class:** `UniversalAdapter` in `universal_trainer/adapters/adapter.py` is the **only** class the adapters package exports (`__init__` re-exports just `["UniversalAdapter"]`). Docs citing `BaseAdapter` / `GameAdapter` describe a class that does not exist in this codebase.

**Constructor invariant:** the subclass must set `self.metadata` **before** calling `super().__init__()`, so the base can assert on it. Setting metadata after the `super()` call, or skipping it, produces a hard `AssertionError` instead of a silent bad state — this is the honest, non-fallback behaviour to keep, not a bug to work around.

| Metadata key | Constraint |
| --- | --- |
| `game_type` | one of a small closed enum, e.g. `pvp`, `pve`, `self_play`, `team` |
| `num_agents` | positive int |
| `supports_symbolic_state` | bool, presence required (even if `False`) |
| `action_space_type` | `discrete` \| `continuous` |
| `observation_space_type` | `vector` \| `image` \| `symbolic` |

**Required methods:** `reset() -> (obs, info)`, `step(action) -> (obs, reward, done, info)`, `get_observation_space_info() -> dict` (`{"type", "shape"}`), `get_action_space_info() -> dict` (`{"type", "n"}`). Happy-path obs is `{"vector": float32[D]}`.

**Optional on the base** (raise "not implemented" until a subclass overrides): symbolic-state accessor, agent-id accessor, episode-summary accessor, render.

**Duck-typed, not on the base, but practiced via runtime attribute checks in the trainer:**

| Hook | Shape | Used for |
| --- | --- | --- |
| `info["action_mask"]` | bool sequence, length = action count | legality mask extraction |
| `get_action_mask(pid)` | bool / ndarray | fallback mask when `info` has none |
| `set_opponent_policy(fn)` | callable `ndarray → int`, or `None` | injecting a frozen opponent policy (PvP) |
| `metadata["id"]` / `metadata["save_prefix"]` | str | checkpoint directory slug |
| `info["metadata"]["phase_id"]` | int | situation-bin key for metrics/retrieval |
| `info["metadata"]["winner"]` | str | PvP win heuristic in the local eval loop |

This is a real dual source of truth: the documented contract is metadata + four methods; the *actual* trainer capability surface also depends on these undocumented duck-typed hooks. Treat both as the contract when writing a new adapter.

### Loading (no plugin registry)

`train_lib.load_adapter_from_cfg(cfg, logger)` tries, in order:

1. `cfg.adapter.class_path` set → `rpartition` into module + class name, import, instantiate `cls(**kwargs)`.
2. Else `cfg.adapter.file_path` set → `_load_module_from_path` registers the module in `sys.modules` **before** `exec_module` (so dataclasses defined in that file resolve correctly), then resolves the class via `cfg.adapter.class_name` or by scanning the module for a type that owns all four required method names.
3. Else → `AssertionError` telling the operator to supply `class_path` or `file_path`. No silent default adapter — this is the correct fail-at-load behaviour, not a gap.

`train_lib.validate_adapter` then asserts the metadata dict and both space-info dicts are shaped correctly and returns `(metadata, obs_info, action_info)`. The GUI launcher (`scripts/launcher.py`, `_diagnose_adapter_module`) runs an additional preflight: it lists candidate classes in a picked file, prefers one that `issubclass(..., UniversalAdapter)`, and smoke-runs `reset()` before starting the training subprocess.

**Trust boundary, stated plainly:** `adapter.file_path` executes arbitrary Python at load time. That is acceptable for a local single-operator research tool and is **not** something to paper over with sandboxing claims that don't exist in the code — no such sandbox is present.

### Metadata routing (coarse, alias-based)

`scripts/train.py` reads `metadata.get("game_type", "pve")`, lower-cases it, and checks membership in a fixed `pvp_aliases` set (`pvp`, `self_play`, `selfplay`, `multiagent`, `versus`, `competitive`, `vs`, `head_to_head`) to choose `train_pvp`; anything else falls through to `train_pve`.

**Documented invariant conflict, worth keeping honest in the note:** the constructor assertion's enum allows `team`, but the alias set used for routing does **not** include `team` — a `team` adapter silently routes as PvE. Conversely the alias set contains strings (`versus`, `competitive`, …) that are **not** in the constructor's allowed enum, so they can only ever appear if an adapter bypasses the assertion (custom code that skips `super().__init__()`, or a future loosening of the assert). Do not "fix" this by inventing a reconciled enum in the note — describe the mismatch as it stands, since it is evidence of drift, not a design choice to emulate.

Demo mapping observed in the reference adapters: two board/social self-play games route as PvP via the `self_play` alias, and one real-time shooter routes as PvP via the literal `pvp` value.

### Action masking — where it actually applies

- Reference PvE-heavy adapters attach `info["action_mask"]` derived from legal-move logic.
- The trainer applies masks during **batched** collect/eval paths (illegal logits pushed to a large negative value; an all-illegal row is treated as all-legal to avoid degenerate distributions).
- The **single-environment** rollout collector used by the default PvP training loop applies **no mask**. This means "automatic legal masking" is only true on the batched PvE path, not universally — a claim that needs the qualifier every time it's repeated.

### How to add a game/adapter (operator recipe)

1. Subclass the base in a new file; keep game logic in a separate lib module — the adapter itself stays thin (glue only).
2. Set metadata (including the `game_type` choice, aware of the alias-mismatch above) **before** calling the base constructor.
3. Implement `reset`/`step`/both space-info methods; emit `{"vector": ...}`; attach `action_mask` in `info` if any actions can be illegal.
4. Optionally implement `set_opponent_policy` for ego-vs-frozen-bot PvP.
5. Point the GUI or CLI at the file: `adapter.file_path=... adapter.class_name=YourAdapter`.
6. Train once with a tiny step budget to confirm inferred obs/action dims are sane before a real run.
7. Non-discrete action spaces are a hard stop: both training loops raise "not implemented" the first time they hit a continuous action — do not claim continuous-action support until that changes.

### Ghost tests (contract implied by tests, not by code)

Several unit tests and a smoke script import adapter helper classes/modules that do not exist in the adapters package (a "dummy adapter" fixture, a generic game-adapter/game-config family, an opponent-diversity helper, a gridworld navigator). These imports fail at collection time. Do not treat their names as part of the real contract, and do not describe the test suite as exercising them — they are evidence of drift between docs/tests and the shipped adapter surface, tracked as a quality gap, not a pattern to extend.

### Quarantine — demo game lore (brief, façade only)

Reference demos exist for a chess-like board game, a real-time capture-the-flag shooter, and a social deduction game, each behind a thin adapter with its rules kept in a sibling library module. Their internal rules, reward shaping, and narrative/IP content are out of scope for this pattern — the only reusable substance is the adapter shape (metadata, `game_type` value, mask source, whether an opponent hook is used). Duplicate/forked demo folders and ad hoc "Copy" variants are packaging debt, not additional patterns.

## Practiced vs not

| Practiced | Aspirational / quarantine |
| --- | --- |
| `UniversalAdapter` + demos | Docs’ `BaseAdapter` / `GameAdapter` (absent) |
| Live `PPO` + GAE + `ActorCritic` | `RetrievalPPO` / continual EMA/EWC **not** on default train path |
| Discrete vector obs | Continuous/image metadata → `NotImplementedError` on train |
| Path/class load | Plugin registry |
| PvE mask/parallel tooling richer | PvP parity / `OpponentPool` on default path |

## Consequences

**Easier:** New env = new adapter module + metadata; trainer untouched.

**Harder:** Duck typing drifts; GUI “retrieval” flags ≠ RetrievalPPO wiring; batched collect key fragility.

**Falsifiers:** Abstract base ship as real API; `train_pvp` gains pool+batched parity by default; RetrievalPPO wired in `train_lib` with shared batch keys.

## Pattern statement

1. Metadata gate + four methods = contract; rest is duck typing.
2. One tag chooses loop family — document aliases **and** assert/route mismatches (e.g. `team` allowed in assert but routed as PvE).
3. Path/class load replaces registries for local research.
4. Elevate the adapter/routing spine — not demo game lore.
5. Live algorithm in the pattern is **PPO**; mark retrieval/continual until wired ([[train-loop-ppo]]).
6. Prefer masks in `info`; keep rules out of the trainer core — and do not claim universal masking when default PvP collect is unmasked.
7. Config keys that never reach `train_step` are theatre ([[hydra-config]]) — name them; do not sell them as controls.

## Related

- [[adapter-routing]] · [[hydra-config]] · [[train-loop-ppo]] · [[trainer-atlas]]
- [[deterministic-before-probabilistic]] · [[extend-established-patterns]] · [[prove-honesty-contracts]]
