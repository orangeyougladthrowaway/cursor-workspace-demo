---
type: map
status: canonical
id: engineering-knowledge-base-map-lab
description: Praxis atlas — index of zoo, skeletons, stubs. Not a curriculum.
updated: 2026-07-17
---

# Atlas — Lab

Index only. Normative answers live in doctrine atlases ([[catalog-maps]]). Coverage bar: [[common-case-coverage]] (**Axis F threshold met**).

## Start

- Plane: [[praxis-plane]] · inventory [[catalog-lab]] · workflow [[praxis-ingestion]]

## Zoo — python

- [[gradual-typing-annotation]] · [[src-layout-editable]] · [[bare-except-anti]] · [[secrets-token-urlsafe]] · [[soft-mypy-anti]]
- [[protocol-boundary]] · [[typeddict-boundary]] · [[console-scripts]] · [[raise-from-chain]] · [[exitstack-resources]]
- [[taskgroup-timeout]] · [[no-sync-over-async-py]] · [[getlogger-module]] · [[dataclass-vs-pydantic-edge]] · [[compare-digest]]
- [[fixture-scope]] · [[request-fixture]]
- [[parametrize-table]] · [[threads-when-blocking]] · [[http-client-timeout]] · [[pathlib-open]] · [[json-loads-typeddict]]
- [[argparse-fail-loud]] · [[unit-vs-integration-name]] · [[require-env-fail-loud]] · [[style-lint-honesty]] · [[ingest-fail-surface]] · [[measure-before-microopt]]

## Zoo — csharp

- [[sdk-style-csproj]] · [[nullable-enable]] · [[bang-operator-sparingly]] · [[cancellation-token-pass]] · [[no-sync-over-async]]
- [[di-lifetimes]] · [[scoped-in-singleton-anti]] · [[linq-deferred]] · [[tolist-when-needed]] · [[fdg-naming-thin]]

## Zoo — sql-server

- [[merge-output-holdlock]] · [[tvp-readonly-batch]] · [[try-catch-xact-state]] · [[sp-executesql-params]] · [[sqlpackage-lab-vs-prod]]
- [[dual-current-scd-anti]] · [[dim-scd2-fact-snapshot-outline]] · [[ssdt-publish-scripts-outline]] · [[ssis-dtproj-outline]]

## Zoo — postgres

- [[on-conflict-upsert]] · [[cte-returning]] · [[window-partition]] · [[explain-basics]] · [[wal-vs-app-audit]]

## Zoo — opentofu

- [[remote-state-required]] · [[azurerm-backend-minimal]] · [[s3-backend-lockfile]] · [[no-plaintext-state]] · [[module-structure-sketch]]
- [[variable-validation-thin]]

## Zoo — docker / compose / packaging

- [[one-process-container]] · [[non-root-user]] · [[image-extras-not-fat]]
- [[profiles-honesty]] · [[service-slice]]
- [[extras-by-role]] · [[dual-poetry-anti]] · [[edge-packaging-slice]]

## Zoo — helm / kubernetes

- [[helm-template-compile]] · [[values-honesty]] · [[hard-way-pedagogy]]
- [[hard-way-not-sot]] · [[manifest-test-pointer]]

## Zoo — delivery / github-actions

- [[hard-soft-table]] · [[coverage-not-quality-zoo]] · [[fail-at-gate-pointer]] · [[dora-metrics-pointer]]
- [[hard-unit-gate]] · [[continue-on-error-anti]] · [[small-cl-tests]] · [[pre-post-submit-pointer]]

## Zoo — apis / auth

- [[openapi-paths]] · [[rest-pagination]] · [[envelope-vs-public]] · [[ingress-contract-pointer]]
- [[forgot-password-anti-enum]] · [[password-storage-pointer]] · [[fall-open-anti]] · [[mfa-factor-hygiene]] · [[session-hygiene-pointer]]

## Zoo — observability / agent / argo / bash

- [[otel-cardinality]] · [[span-kind-basics]] · [[monitoring-vs-observability]]
- [[rag-untrusted]] · [[claim-card-shape]] · [[reason-act-pointer]]
- [[outer-stage-grain]] · [[workflow-params-honesty]]
- [[strict-shell-mode]] · [[quote-expansions]]

## Skeletons

- `lab/skeletons/python-src-pkg/` — [[python-packaging-layout]], [[pytest-practices]]
- `lab/skeletons/csharp-sdk-tool/` — [[csharp-project-toolchain]], [[csharp-async-di]]
- `lab/skeletons/opentofu-stack/` — [[terraform-state-backends]], [[terraform-modules-composition]]
- `lab/skeletons/helm-chart-thin/` — [[helm-deploy]], [[delivery-gates]]
- `lab/skeletons/compose-service-slice/` — [[compose-deploy]], [[service-packaging]]
- `lab/skeletons/gha-hard-unit/` — [[delivery-gates]], [[delivery-ci]]

## Stubs

- `lab/stubs/sql-server/scd2-merge-outline.sql` — [[kimball-type2-scd]], [[tsql-set-based-merge]]
- `lab/stubs/sql-server/dim-scd2-fact-snapshot-outline.sql` — [[scd2-dimension-envelope]], [[snapshot-fact-shape]]
- `lab/stubs/sql-server/ssdt-publish-scripts-outline.sql` · `ssdt-sqlproj-outline.xml` — [[ssdt-publish-scripts]], [[ssdt-sqlproj]]
- `lab/stubs/postgres/upsert.sql` — [[postgres-sql-craft]]

## Zoo — architecture

- [[microservice-prereqs-checklist]] · [[smart-endpoints-zoo]] · [[modular-monolith-default-zoo]] · [[distributed-expectations-zoo]] · [[thin-primitives-zoo]] · [[ddd-pressure-zoo]] · [[privileged-boundaries-zoo]] · [[silent-fallback-anti]]

## Deferred facet themes

- Further architecture densify under Axis F Track 14 as needed — allowlist already open

## Related doctrine

- [[languages-atlas]] · [[infrastructure-atlas]] · [[delivery-atlas]] · [[warehouse-atlas]] · [[data-atlas]] · [[architecture-atlas]] · [[common-case-coverage]]
