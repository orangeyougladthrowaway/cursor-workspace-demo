---
type: guidance
status: canonical
id: engineering-knowledge-base-g-ssdt-publish-scripts
concern: policy
description: Publish profiles, PreDeploy/PostDeploy scripts, and SqlPackage plan honesty for SSDT dacpacs.
domain: [sql-server, ssdt]
aliases: [predeploy, postdeploy, publish-xml, sqlpackage-profile]
derived_from:
  - "[[ssdt-sqlproj]]"
  - "[[dacpac-publish]]"
  - "[[compiled-schema-release]]"
  - "[[fail-at-the-gate]]"
updated: 2026-07-20
---

# Ssdt publish scripts

## Applies when

Configuring how a `.dacpac` is applied: publish profiles, PreDeploy/PostDeploy scripts, SQLCMD-driven seed/migrate steps.

## Execution order (binding)

```text
1. SqlPackage computes deployment plan from model delta (before PreDeploy runs)
2. PreDeploy script executes
3. Deployment plan applies (DDL/DML in plan)
4. PostDeploy script executes
```

Pre/post scripts are **in the dacpac** but **not** validated as part of the object model. Plan is calculated **before** PreDeploy — do not assume PreDeploy mutations are visible to plan generation ([Learn — Pre/Post deployment](https://learn.microsoft.com/en-us/sql/tools/sql-database-projects/concepts/pre-post-deployment-scripts)).

## sqlproj wiring

```xml
<ItemGroup>
  <PreDeploy Include="Scripts\Script.PreDeployment.sql" />
  <PostDeploy Include="Scripts\Script.PostDeployment.sql" />
</ItemGroup>
```

- Only **one** PreDeploy and **one** PostDeploy entry point per project (SDK combines `:r` includes into a single script in the dacpac).
- Extra script fragments: set Build Action **Remove** / exclude from model; include via `:r` from the entry script.
- Verify after build: rename `.dacpac` → `.zip` and inspect embedded pre/post `.sql`.

## Publish profiles (`.publish.xml`)

Store connection target + SqlPackage property bag per environment. For persistent **DEV / UAT / PROD** product instances, keep **one profile per env** aligned to [[sql-server-env-branches]] (deploy only the PR-merged tip for that env).

| Concern | Lab / DEV sandbox | UAT | PROD / durable history |
| --- | --- | --- | --- |
| `CreateNewDatabase` | may be True (reset) | **False** | **False** |
| `BlockOnPossibleDataLoss` | often False (lab) | **True** | **True** |
| `DropObjectsNotInSource` | lab convenience | Narrow or False | Narrow or False |
| SQLCMD variables | profile or `/Variables:` | Every required var supplied | Every required var supplied |

Lived lab destructiveness is quarantine, not release law ([[dacpac-publish]]).

## PreDeploy — house uses

- Guardrails that must run before plan apply (e.g. abort if wrong DB name via SQLCMD)
- Rare, explicit prep that cannot be modeled (document why)
- **Not** casual `DROP ALL` theatre on ODS/history

## PostDeploy — house uses

- Reference/seed data that is **idempotent** (`MERGE` / guarded inserts)
- Permissions / role memberships when not modeled as objects
- Smoke asserts (`IF NOT EXISTS` fail-loud checks)
- **Not** a second schema SoT (tables/procs belong in the model)

## Maintain

1. Keep entry scripts thin; `:r` ordered fragments.
2. Branch environment behaviour with SQLCMD variables — not duplicated entire profiles of divergent DDL.
3. Treat Pre/Post as **deploy gates**: failures fail the publish.
4. Review plan/dry-run before first apply of a profile that can drop or recreate ([[delivery-gates]]).

## Refuse

- Schema objects only in PostDeploy
- PreDeploy that “fixes” the model so plan looks clean while SoT drifts
- Copying lab publish XML onto Type-2 ODS

## Related

- [[ssdt-sqlproj]] · [[dacpac-publish]] · [[compiled-schema-release]] · [[host-activation]] · [[sql-server-env-branches]] · [[schema-change-models]] · zoo [[ssdt-publish-scripts-outline]]
