---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[threat-model-declaration]]"
updated: 2026-07-16
---

# Threat model declare zoo

## When

Declaring the threat model for a surface before claiming secured.

## When not

Security adjectives without a declared model.

```text
Declare model → matched controls ([[threat-model-declaration]])
```

## Related

- [[threat-model-declaration]] · [[threat-model-matched-controls]]
