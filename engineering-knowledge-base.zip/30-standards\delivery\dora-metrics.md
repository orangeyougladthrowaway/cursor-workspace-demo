---
type: standard
status: canonical
id: engineering-knowledge-base-s-011
concern: delivery
description: DORA five metrics orient improvement — not Goodhart goals; do not silence hard gates.
domain: []
aliases: [dora, lead-time, deployment-frequency]
derived_from:
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# DORA metrics

## Requirement

1. Track throughput (change lead time, deployment frequency, failed deployment recovery time) and instability (change fail rate, deployment rework rate) **per application context**.
2. Metrics **guide** improvement; they are **not** merge gates by default ([[delivery-gates]]).
3. Do not trade hard honesty gates for metric green.
4. Pair with signal quality elsewhere: SLI/SLO thinking from observability pressure ([[metrics-tracing-logging-pressure]]) — uptime alone is insufficient.

## Untapped

Accelerate book · individual DORA capability articles beyond monitoring/observability · DevOps handbooks.

## Related

- [[dora-capabilities-index]] · [[delivery-gates]] · [[observability-atlas]]
