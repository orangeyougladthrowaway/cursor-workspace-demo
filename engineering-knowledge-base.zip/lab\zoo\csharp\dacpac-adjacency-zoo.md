---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[dacpac-publish]]"
updated: 2026-07-16
---

# Dacpac adjacency zoo

## When

.NET tooling publishes schema via DACPAC adjacent to app code.

## When not

Treating SSDT as optional folklore beside a second hand-DDL SoT.

```text
dotnet build → DACPAC → SqlPackage ([[dacpac-publish]])
```

## Related

- [[dacpac-publish]] · [[csharp-project-toolchain]]
