---
type: example
status: canonical
domain: [argo]
derived_from:
  - "[[argo-workflows]]"
  - "[[host-activation]]"
updated: 2026-07-15
---

# Workflow params honesty

## When

Workflow parameters are explicit and versioned with the workflow.

## When not

Hidden globals that differ per host without declaration.

```yaml
arguments:
  parameters:
    - name: env
      value: lab
```

## Related

- [[argo-workflows]] · [[host-activation]]
