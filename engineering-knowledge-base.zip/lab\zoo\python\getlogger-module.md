---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-logging-modeling]]"
updated: 2026-07-15
---

# Getlogger module

## When

Module-level logger named after `__name__`.

## When not

`print` / root-only logging as the service story.

```python
import logging

log = logging.getLogger(__name__)

def work() -> None:
    log.info("work started")
```

## Related

- [[python-logging-modeling]] · [[metrics-tracing-logging-pressure]]
