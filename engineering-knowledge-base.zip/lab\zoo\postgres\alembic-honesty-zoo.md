---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-sql-craft]]"
updated: 2026-07-16
---

# Alembic honesty zoo

## When

Schema migrations via Alembic (or cousin) as the lived path.

## When not

Dual hand-SQL + Alembic both “official” without a lock.

```text
One migration SoT · upgrade/downgrade tested · no silent drift
```

## Related

- [[postgres-sql-craft]] · [[compiled-schema-release]]
