---
type: workflow
status: canonical
id: engineering-knowledge-base-wf-007
concern: knowledge
description: Praxis ingestion — densify lab to common-case matrices; cite doctrine; never redefine law.
domain: []
aliases: [lab-ingest, zoo]
derived_from:
  - "[[knowledge-ingestion]]"
  - "[[dependency-rules]]"
  - "[[navigation]]"
  - "[[common-case-coverage]]"
updated: 2026-07-16
---

# Praxis ingestion

Use for `lab/` artifacts. Doctrine remote harvest stays [[knowledge-ingestion]]. Majority bar: [[common-case-coverage]] (Axis F).

## Plane

| Doctrine | Praxis |
| --- | --- |
| `00`–`60` + `maps/` | `lab/zoo` · `lab/skeletons` · `lab/stubs` |
| Sets house law | Illustrates law |
| `deep` on [[ingest-coverage]] | Ledger as `example` / matrix G4 — never doctrine `deep` |

## Admit bar

Add a zoo entry only if it **changes a choice** or **prevents a known bug**, and a **canonical** (or clear draft-to-promote) note already answers the normative question — ideally a **matrix cell** on [[common-case-coverage]].

Reject: uncited tutorials, curriculum sequences, product lore, soft-theatre as virtue.

**Seed ≠ done:** a non-empty facet or P2 seed count does **not** mean the track meets the majority bar. Densify until matrix % (or justified Gap).

## Steps

1. **Canon first** — open the living note; confirm question / matrix cell.
2. **Draft** `lab/zoo/{facet}/{slug}.md` with `type: example`, `derived_from` / Related → doctrine stems, When/When-not, ≤15 loc.
3. **Collide** lived quarantine — label anti-patterns explicitly.
4. **Index** — [[lab-atlas]] + [[catalog-lab]] in the same change.
5. **Ledger** — praxis counts on [[ingest-coverage]]; cell G4 on [[common-case-coverage]].
6. **Health** — `pytest tests/lab -v` (and doctrine suite).
7. **Stage G+** — [[post-capture-review]]: orphan lab? missing canon cite? matrix honesty?

## Skeletons / stubs

- Skeleton = directory under `lab/skeletons/{name}/` + README (purpose · required canons · copy steps · honesty).
- Not `00-foundation/templates/` (those are **note** templates).
- **Session** budgets: ≤10 zoo entries / session · ≤1 skeleton / session unless override noted on [[roadmap]].
- **Program** budgets: continue across sessions until track threshold ([[common-case-coverage]]).

## Manual writes

Hand-write zoo/guidance notes. Do **not** bulk-script vault body generation for coverage waves.

## Elevate feedback

If an exemplar encodes **new** house law → Stages C–E into guidance/pattern → shrink zoo to a pointer. Snippet never wins a fight with a canon ([[dependency-rules]]).

## Related

- [[lab-atlas]] · [[coding-agent-projection]] · [[vault-health-checks]] · [[layout]] · [[scope]] · [[common-case-coverage]]
