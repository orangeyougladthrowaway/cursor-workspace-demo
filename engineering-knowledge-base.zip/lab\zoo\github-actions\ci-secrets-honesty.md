---
type: example
status: canonical
domain: [github-actions]
derived_from:
  - "[[delivery-ci]]"
  - "[[threat-model-declaration]]"
updated: 2026-07-16
---

# Ci secrets honesty

## When

Injecting secrets into CI jobs.

## When not

Logging secrets, checking secrets into the repo, or over-scoping org secrets.

```yaml
# Prefer environment secrets + least privilege
# ANTI: echo "$SECRET" / commit .env with tokens
```

## Related

- [[delivery-ci]] · [[trust]] · [[python-langsec-secrets]]
