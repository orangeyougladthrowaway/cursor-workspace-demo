---
type: template
status: canonical
description: Starter template for pattern notes.
updated: 2026-07-14
---

# Template — Pattern

```markdown
---
type: pattern
status: draft
id: engineering-knowledge-base-pat-NNN
concern: ownership          # single concept; must match folder
description: ""
domain: []
aliases: []
derived_from: []
updated: YYYY-MM-DD
---

# Pattern name

## Context

## Problem

## Forces

## Solution

## Consequences

## Related
```

Path: `40-patterns/{concept}/{slug}.md`. No `and` in concept/slug. See [[navigation]].
