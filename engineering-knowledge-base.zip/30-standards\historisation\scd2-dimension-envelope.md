---
type: standard
status: canonical
id: engineering-knowledge-base-s-019
concern: historisation
description: SCD2 dimension column envelope — effective dating, current, deleted, hash, surrogate.
domain: [warehouse, sql-server]
derived_from:
  - "[[declare-the-grain]]"
  - "[[kimball-type2-scd]]"
  - "[[historisation-layers]]"
updated: 2026-07-20
---

# Scd2 dimension envelope

## Normally require

Serving **dimensions** (and durable ODS entities that feed them) carry Type-2 history with:

| Column | Role |
| --- | --- |
| Surrogate PK | Version id — fact FK target |
| Business / natural key | Member identity (not unique alone across versions) |
| Attribute columns | True to the **entity grain** of the dimension |
| `effective_from` | Version open timestamp |
| `effective_to` | Version close (null while open, or sentinel) |
| `is_current` | Exactly one current non-tombstone per business key (merge must enforce) |
| `is_deleted` | Tombstone / soft-delete current when source absence is complete |
| `row_hash` | Hash of historised attributes (null on tombstone) |

House ODS merge and dim loads follow [[historisation-layers]] / [[warehouse-historisation]]. **SoT:** ODS runs the Type-2 merge; DWH dims may mirror these columns for joins without a second merge engine.

## Laws

- Type 2 **adds a row**; do not overwrite history in place (Type 1).  
- Facts at event time join **surrogate**, not natural key alone.  
- Current-serving facts may load against `is_current = 1 AND is_deleted = 0` after rebuild ([[snapshot-fact-shape]]).  
- Hash covers historised attributes only; key excluded from hash.  
- **Bridges (M:N association grain):** may be Type-2 dated for membership; they are not snapshot facts. Prefer the same envelope columns when membership is historised; document whether bridge FKs point at member business keys or dim version surrogates ([[grain-cardinality]]).

## Refuse

- Dim without effective dating when claiming SCD2  
- Dual `is_current = 1` for one business key  
- Copying full SCD2 envelope onto a fact as if the fact were Type-2 history SoT

## Related

- [[kimball-type2-scd]] · [[scd2-dim-snapshot-fact]] · lab [[dim-scd2-fact-snapshot-outline]]
