---
type: catalog
status: canonical
id: engineering-knowledge-base-cat-lab
description: Inventory of praxis lab artifacts — zoo, skeletons, stubs.
updated: 2026-07-20
---

# Catalog — Lab

Praxis only. Doctrine catalogs: [[catalog-maps]] · [[catalog-guidance]]. Coverage: [[common-case-coverage]].

## Indexes

| Artifact | Note |
| --- | --- |
| Atlas | [[lab-atlas]] |
| Plane contract | [[praxis-plane]] |

## Zoo facets

| Facet | Count | Notes |
| --- | --- | --- |
| python | 28 | Track 1 complete |
| csharp | 20 | Track 5 complete (+ Span/STJ) |
| sql-server | 17 | Track 3 + SSDT/SSIS outlines |
| postgres | 13 | Track 4 complete (+ JSONB) |
| opentofu | 10 | complete |
| docker | 6 | |
| compose | 3 | |
| packaging | 6 | + trainer thin |
| helm | 6 | |
| kubernetes | 6 | |
| github-actions | 6 | |
| delivery | 9 | Track 2 complete |
| apis | 14 | Track 9 complete |
| auth | 13 | Track 10 complete |
| observability | 7 | |
| agent | 7 | |
| argo | 5 | |
| bash | 3 | |
| architecture | 8 | Track 14 + silent-fallback anti |
| **Total** | **187** | Axis F densify |

## Skeletons

| Name | Path |
| --- | --- |
| python-src-pkg | `lab/skeletons/python-src-pkg/` |
| csharp-sdk-tool | `lab/skeletons/csharp-sdk-tool/` |
| opentofu-stack | `lab/skeletons/opentofu-stack/` |
| helm-chart-thin | `lab/skeletons/helm-chart-thin/` |
| compose-service-slice | `lab/skeletons/compose-service-slice/` |
| gha-hard-unit | `lab/skeletons/gha-hard-unit/` |

## Stubs

| Facet | Path |
| --- | --- |
| sql-server | `lab/stubs/sql-server/scd2-merge-outline.sql` · `dim-scd2-fact-snapshot-outline.sql` · `ssdt-publish-scripts-outline.sql` · `ssdt-sqlproj-outline.xml` |
| postgres | `lab/stubs/postgres/upsert.sql` |

Workflow: [[praxis-ingestion]].
