---
type: principle
status: canonical
description: Extend by cloning established local patterns; do not drive-by redesign architecture in passing changes.
id: engineering-knowledge-base-p-006
category: "[[change]]"
derived_from:
  - "[[change]]"
  - "[[restraint]]"
updated: 2026-07-13
---

# Extend established patterns

## Statement

New behaviour should extend the patterns the system already owns. Passing changes — especially AI-assisted ones — do not get to introduce a parallel architecture, error style, or I/O habit without an explicit decision.

## Rationale

Unjustified branches and style forks destroy navigability. Pattern continuity is how a small team (and agents) stay coherent.

## Encourages

- Surgical change; ADRs for intentional forks; “follow existing seams”

## Prevents

- Compatibility shims “just in case”
- Quiet architecture forks across modules

## Evidence (thin)

Explicit “branch justification / follow patterns” norms in multiple projects. Not an excuse to ossify bad patterns — change them deliberately.

## Related

- Category: [[change]]
- [[fail-loud-on-control-paths]]
