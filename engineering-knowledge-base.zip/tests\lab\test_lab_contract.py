"""Praxis (lab/) contract tests — structural; not per-snippet unit tests."""

from __future__ import annotations

from pathlib import Path

from tests.vault import (
    ROOT,
    all_linkable_stems,
    extract_wikilinks,
    iter_lab_notes,
    iter_notes,
    parse_frontmatter,
    read_text,
    rel_posix,
)

FACET_ALLOWLIST = {
    "python",
    "csharp",
    "sql-server",
    "postgres",
    "opentofu",
    "docker",
    "compose",
    "helm",
    "kubernetes",
    "github-actions",
    "apis",
    "auth",
    "observability",
    "packaging",
    "delivery",
    "argo",
    "agent",
    "bash",
    "architecture",
}

LAB_INDEX_STEMS = {"lab-atlas", "catalog-lab", "praxis-plane", "praxis-ingestion"}


def _zoo_files() -> list[Path]:
    zoo = ROOT / "lab" / "zoo"
    if not zoo.is_dir():
        return []
    return sorted(p for p in zoo.rglob("*.md") if p.is_file())


def test_lab_plane_index_files_exist() -> None:
    required = [
        ROOT / "lab" / "praxis-plane.md",
        ROOT / "lab" / "catalog-lab.md",
        ROOT / "lab" / "maps" / "lab-atlas.md",
    ]
    missing = [rel_posix(p) for p in required if not p.is_file()]
    assert not missing, f"Missing lab indexes: {missing}"


def test_zoo_entries_are_examples_with_doctrine_cites() -> None:
    stems = all_linkable_stems()
    doctrine = {p.stem for p in iter_notes()}
    offenders: list[str] = []
    for path in _zoo_files():
        fm, body = parse_frontmatter(read_text(path))
        rel = rel_posix(path)
        if fm.get("type") != "example":
            offenders.append(f"{rel}: type must be example")
        facet = path.parent.name
        if path.parent.parent.name == "zoo" and facet not in FACET_ALLOWLIST:
            offenders.append(f"{rel}: facet {facet!r} not allowlisted")
        derived = fm.get("derived_from") or []
        if not isinstance(derived, list):
            derived = [derived]
        targets = []
        for item in derived:
            if isinstance(item, str):
                targets.extend(extract_wikilinks(item))
        body_links = extract_wikilinks(body)
        cites = set(targets) | set(body_links)
        doctrine_cites = cites & doctrine
        if not doctrine_cites:
            offenders.append(f"{rel}: need derived_from or Related doctrine stem")
        for t in cites:
            if t not in stems:
                offenders.append(f"{rel}: broken [[{t}]]")
    assert not offenders, "\n".join(offenders[:40])


def test_doctrine_derived_from_not_zoo_authority() -> None:
    zoo_stems = {p.stem for p in _zoo_files()}
    offenders: list[str] = []
    for path in iter_notes():
        fm, _ = parse_frontmatter(read_text(path))
        derived = fm.get("derived_from") or []
        if not isinstance(derived, list):
            derived = [derived]
        for item in derived:
            if not isinstance(item, str):
                continue
            for stem in extract_wikilinks(item):
                if stem in zoo_stems and stem not in LAB_INDEX_STEMS:
                    offenders.append(f"{rel_posix(path)} derived_from zoo [[{stem}]]")
    assert not offenders, "\n".join(offenders)


REQUIRED_SKELETONS = {
    "python-src-pkg",
    "csharp-sdk-tool",
    "opentofu-stack",
    "helm-chart-thin",
    "compose-service-slice",
    "gha-hard-unit",
}

REQUIRED_STUBS = {
    Path("lab/stubs/sql-server/scd2-merge-outline.sql"),
    Path("lab/stubs/sql-server/dim-scd2-fact-snapshot-outline.sql"),
    Path("lab/stubs/sql-server/ssdt-publish-scripts-outline.sql"),
    Path("lab/stubs/sql-server/ssdt-sqlproj-outline.xml"),
    Path("lab/stubs/postgres/upsert.sql"),
}

# Soft body size — zoo illustrates; it does not become a second bible chapter.
ZOO_MAX_BODY_LINES = 40


def test_lab_index_wikilinks_resolve() -> None:
    stems = all_linkable_stems()
    broken: list[str] = []
    for path in iter_lab_notes():
        if "zoo" in path.parts:
            continue  # covered in zoo test
        for target in extract_wikilinks(read_text(path)):
            if target not in stems:
                broken.append(f"{rel_posix(path)} -> missing [[{target}]]")
    assert not broken, "\n".join(broken[:40])


def test_skeleton_readme_contract() -> None:
    root = ROOT / "lab" / "skeletons"
    assert root.is_dir(), "lab/skeletons missing"
    required = ("Purpose", "Required canons", "Copy", "Honesty")
    offenders: list[str] = []
    found = {child.name for child in root.iterdir() if child.is_dir()}
    missing = sorted(REQUIRED_SKELETONS - found)
    if missing:
        offenders.append(f"missing skeletons: {missing}")
    for child in sorted(root.iterdir()):
        if not child.is_dir():
            continue
        readme = child / "README.md"
        if not readme.is_file():
            offenders.append(f"{child.name}: missing README.md")
            continue
        text = read_text(readme)
        for needle in required:
            if needle.lower() not in text.lower():
                offenders.append(f"{child.name}: README missing {needle!r}")
    assert not offenders, "\n".join(offenders)


def test_required_stubs_exist() -> None:
    missing = [p.as_posix() for p in REQUIRED_STUBS if not (ROOT / p).is_file()]
    assert not missing, f"Missing stubs: {missing}"


def test_allowlisted_facets_have_at_least_one_zoo() -> None:
    zoo = ROOT / "lab" / "zoo"
    present = {
        p.name
        for p in zoo.iterdir()
        if p.is_dir() and any(p.glob("*.md"))
    } if zoo.is_dir() else set()
    missing = sorted(FACET_ALLOWLIST - present)
    assert not missing, f"Allowlisted facets with no zoo entries: {missing}"


def test_zoo_bodies_stay_thin() -> None:
    offenders: list[str] = []
    for path in _zoo_files():
        _, body = parse_frontmatter(read_text(path))
        lines = [ln for ln in body.splitlines() if ln.strip()]
        if len(lines) > ZOO_MAX_BODY_LINES:
            offenders.append(f"{rel_posix(path)}: {len(lines)} non-empty lines > {ZOO_MAX_BODY_LINES}")
    assert not offenders, "\n".join(offenders[:20])


def test_python_src_pkg_claims_runnable_unit() -> None:
    """Only this skeleton claims executable behaviour — unit test must exist."""
    test_path = ROOT / "lab" / "skeletons" / "python-src-pkg" / "tests" / "test_hello.py"
    assert test_path.is_file(), "python-src-pkg must ship tests/test_hello.py"
    text = read_text(test_path)
    assert "def test_" in text, "python-src-pkg unit file must define a test_"
