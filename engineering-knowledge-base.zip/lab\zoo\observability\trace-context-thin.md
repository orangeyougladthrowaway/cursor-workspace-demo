---
type: example
status: canonical
domain: [observability]
derived_from:
  - "[[metrics-tracing-logging-pressure]]"
updated: 2026-07-16
---

# Trace context thin

## When

Propagating trace context across service boundaries.

## When not

Orphan spans with no parent/correlation.

```text
Propagate W3C/traceparent (or house equivalent) on outbound calls
```

## Related

- [[metrics-tracing-logging-pressure]] · [[span-kind-basics]]
