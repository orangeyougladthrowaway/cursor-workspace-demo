---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-typing-honesty]]"
  - "[[delivery-ci]]"
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Soft mypy anti

## When

Naming CI theatre so “green” is unambiguous.

## When not

Marketing `strict = true` in pyproject while the job is soft.

```yaml
# ANTI — soft theatre ([[delivery-ci]])
- run: mypy . || true
# Prefer hard gate OR remove the typed claim
- run: mypy .
```

## Related

- [[delivery-gates]] · [[python-typing-honesty]]
