---
type: guidance
status: canonical
id: engineering-knowledge-base-g-csharp
concern: languages
description: C# coding conventions — readability + tooling enforcement; not a language textbook.
domain: [csharp, dotnet]
aliases: [csharp, dotnet]
derived_from:
  - "[[honesty]]"
  - "[[proof]]"
  - "[[delivery-ci]]"
  - "[[csharp-project-toolchain]]"
updated: 2026-07-16
---

# CSharp style conventions

Primary (D1 #8): [Microsoft — Common C# code conventions](https://learn.microsoft.com/en-us/dotnet/csharp/fundamentals/coding-style/coding-conventions).

## Applies when

.NET tooling or SqlPackage/SSDT-adjacent C#.

## House dialect (encode in tooling)

| Gate | Prefer |
| --- | --- |
| Style | **editorconfig** + SDK analyzers ([[csharp-project-toolchain]]) |
| Warnings | treat warnings as errors in CI when the project already does — do not soft-green ([[delivery-gates]]) |
| Public APIs | XML docs on shipped public surface |

## Guidance

1. Enforce via **editorconfig / analyzers**, not chat folklore.
2. Docs/sample conventions are an **example dialect**, not the only law.
3. Keep inline comments brief; put long rationale in notes.
4. Not a C# textbook mirror — claim-elevate idioms only when they collide with delivery honesty.

## Untapped

C# in Depth · Framework Design Guidelines deep (beyond [[csharp-project-toolchain]] / [[csharp-async-di]]) · rich LINQ/Span.

## Related

- [[python-style-pep8]] · [[csharp-project-toolchain]] · [[dacpac-publish]] · [[languages-atlas]]
