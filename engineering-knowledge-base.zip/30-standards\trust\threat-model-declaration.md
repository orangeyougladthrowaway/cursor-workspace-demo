---
type: standard
status: canonical
aliases: ["threat-model"]
domain: []
concern: trust
id: engineering-knowledge-base-s-003
description: Every deployment class has an explicit threat model; controls must match it; no theatre and no ambient privilege.
derived_from:
  - "[[threat-model-matched-controls]]"
  - "[[privileged-capability-ownership]]"
updated: 2026-07-17
---

# Threat model declaration

## Requirement

1. Each distinct deployment class (e.g. local, demo, production) has a **written threat model** stating: assets, adversaries/assumptions, trust boundaries, and what is intentionally out of scope.
2. Security controls in use (authn/authz, exposure, secret placement, network defaults) must be **justifiable against that model** — neither weaker than claimed nor inflated with unused theatre.
3. Trust is **enumerated** where the model requires it (who/what may call whom). “Authenticated” does not imply “authorized” unless the model says so.
4. Demo or reduced controls are allowed only when the model **explicitly** declares demo/non-production scope; those choices must not be copied into production doctrine by silence.
5. Changes that widen exposure, move secrets, or alter trust paths update the threat-model authority and related honesty checks in the **same change**.
6. **Lived lab pattern (declare it):** fall-open HTTP AuthZ (empty policies / `service:*` wildcards) plus NetworkPolicy or unpublished mesh ports is a **valid lab model only if named as such**. Do not describe unused `auth.yaml` matrices or JWT-off meshes as “secured.” Detail: [[gateway-auth]]. Unnamed fall-open is forbidden soft recovery under [[required-happy-path]].
7. **Awareness check (OWASP Top 10:2021 spine):** when writing or amending a model, explicitly place or reject at least **A01 Broken Access Control** and **A07 Identification & Authentication Failures** relative to your declared controls (lab fall-open is an intentional A01 tradeoff only if named). Do not claim “we follow OWASP” without this mapping. Full Top 10 programme work is out of scope for this standard body.

## Derived from

- [[threat-model-matched-controls]]
- [[privileged-capability-ownership]]
- Category: [[trust]]

## Rationale

Theatre creates false confidence; ambient privilege creates real risk. Honest scope is part of security. External catalogues (OWASP) are **pressure** to name risks — they do not replace the written model.

## Exceptions

- Personal throwaway spikes need not carry a full model if they never share credentials or network exposure beyond the machine — promote a model before any shared or hosted deploy.
- Inheritance: a service may adopt a platform-level threat model by reference if the authoritative pointer is clear.

## What this does not prescribe yet

Specific TLS vendors, IdP products, or policy languages — only the obligation to declare, match, and keep current.

## Related

- [[gateway-auth]] · [[platform-atlas]]
- [[prove-honesty-contracts-in-delivery]] · [[single-authority-for-documentation]] · [[ownership]]
- [[required-happy-path]] · [[happy-path-only]] · [[threat-model-matched-controls]]
