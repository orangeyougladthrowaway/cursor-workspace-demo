---
type: guidance
status: canonical
id: engineering-knowledge-base-g-tsql-merge
concern: historisation
description: T-SQL set-based MERGE craft — concurrency, JOIN honesty, when discrete DML beats MERGE; SCD collide.
domain: [sql-server, t-sql]
aliases: [merge, upsert, set-based]
derived_from:
  - "[[warehouse-historisation]]"
  - "[[kimball-type2-scd]]"
updated: 2026-07-15
---

# Tsql set based merge

Primary (L-sql #1): [MERGE (Transact-SQL)](https://learn.microsoft.com/en-us/sql/t-sql/statements/merge-transact-sql).

## Applies when

Writing warehouse hist/upsert procs (SCD2, staging→ODS/DWH) rather than row-by-row cursors.

## Guidance

1. Prefer **set-based** DML over cursors for historisation batches. MERGE joins a source to a target and applies INSERT/UPDATE/DELETE in one statement — powerful and easy to get wrong.
2. **`;` terminator required** — MERGE without semicolon errors.
3. At most two `WHEN MATCHED` clauses (one UPDATE, one DELETE path). A target row must not match multiple source rows for UPDATE — cardinality errors.
4. Put **match keys in `ON`**; do not “filter the target” in `ON` to skip rows (incorrect results). Filter with `AND` on `WHEN` clauses instead.
5. Prefer **`OUTPUT` / `$action`** to observe and count effects — do not trust silent merges.
6. **Concurrency:** MERGE locking differs from discrete INSERT/UPDATE/DELETE. At scale, discrete statements can block less. Where keys are both inserted and updated concurrently, **`HOLDLOCK` (SERIALIZABLE)** is often needed to avoid unique-key races — test under concurrency before prod.
7. Large ETL MERGE: prefer low-concurrency windows; batch with care (`TOP` + conditions so batches do not re-insert/re-update wrongly).
8. SCD2 procs ([[kimball-type2-scd]], [[warehouse-historisation]]) must encode expire+insert semantics explicitly — MERGE is a tool, not a historisation design.
9. SQL correctness remains **ungated** in lived warehouse CI ([[delivery-gates]]) — treat tests of merge/SCD invariants as the missing hard seam.

## Untapped

Full isolation-level matrix · indexed-view interactions · Synapse/Fabric MERGE deltas · tSQLt patterns.

## Related

- [[warehouse-historisation]] · [[dacpac-publish]] · [[delivery-gates]] · [[python-ingest]] · [[warehouse-atlas]] · [[languages-atlas]]
