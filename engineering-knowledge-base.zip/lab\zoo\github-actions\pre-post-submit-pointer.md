---
type: example
status: canonical
domain: [github-actions]
derived_from:
  - "[[delivery-gates]]"
  - "[[prove-honesty-contracts-in-delivery]]"
updated: 2026-07-15
---

# Pre post submit pointer

## When

Separating fast pre-submit honesty from heavier post-submit proof.

## When not

Claiming “fully proven” when only lint/pre-submit ran.

```text
Pre-submit: unit + manifest compile (hard)
Post-submit: slower integration / soak — still honest labels
See [[prove-honesty-contracts-in-delivery]]
```

## Related

- [[delivery-gates]] · [[prove-honesty-contracts]] · [[prove-honesty-contracts-in-delivery]]
