---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-packaging-layout]]"
updated: 2026-07-16
---

# Argparse fail loud

## When

Thin stdlib CLI at a package entrypoint.

## When not

Silent wrong-args continue; or scripting forever without an installable entrypoint.

```python
import argparse

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="mytool")
    parser.add_argument("path")
    args = parser.parse_args(argv)
    print(args.path)
    return 0
```

## Related

- [[python-packaging-layout]] · [[console-scripts]]
