---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[owasp-top10-mapping]]"
updated: 2026-07-16
---

# Owasp top10 zoo

## When

Mapping risks to OWASP Top 10 as a pressure index.

## When not

Checklist theatre without living controls.

```text
Top 10 is a map — controls live in notes ([[owasp-top10-mapping]])
```

## Related

- [[owasp-top10-mapping]] · [[asvs-authentication-mapping]]
