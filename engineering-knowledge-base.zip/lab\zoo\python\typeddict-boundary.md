---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-typing-honesty]]"
updated: 2026-07-15
---

# Typeddict boundary

## When

TypedDict for JSON-ish dict shapes at edges.

## When not

TypedDict as a substitute for a real domain model everywhere.

```python
from typing import TypedDict

class ItemIn(TypedDict):
    id: str
    name: str

def accept(item: ItemIn) -> str:
    return item["name"]
```

## Related

- [[python-typing-honesty]] · [[python-logging-modeling]]
