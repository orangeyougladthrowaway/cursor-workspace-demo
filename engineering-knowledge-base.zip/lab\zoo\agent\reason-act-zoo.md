---
type: example
status: canonical
domain: [agent]
derived_from:
  - "[[react-reason-act-pressure]]"
updated: 2026-07-16
---

# Reason act zoo

## When

Bounding agent reason→act loops.

## When not

Unbounded tool spam without observations.

```text
Reason → Act → Observe → bound steps ([[react-reason-act-pressure]])
```

## Related

- [[react-reason-act-pressure]] · [[reason-act-pointer]]
