---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-project-toolchain]]"
updated: 2026-07-16
---

# Options pattern thin

## When

Binding typed options from configuration.

## When not

Sprinkling magic strings for every setting read.

```csharp
services.Configure<WorkerOptions>(config.GetSection("Worker"));
```

## Related

- [[csharp-project-toolchain]] · [[csharp-async-di]]
