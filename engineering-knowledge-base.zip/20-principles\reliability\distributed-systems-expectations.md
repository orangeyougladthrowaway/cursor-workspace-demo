---
type: principle
status: canonical
id: engineering-knowledge-base-p-012
category: "[[reliability]]"
description: Partitions, timeouts, and partial failure are normal — design contracts and bridges accordingly.
derived_from:
  - "[[reliability]]"
  - "[[failure]]"
updated: 2026-07-15
---

# Distributed systems expectations

## Statement

Treat network partitions, timeouts, and partial failure as **expected**, not exceptional. Control paths fail loud; data paths declare consistency and recovery honestly.

## Rationale

D1 #5/#6 pressure: Fowler microservices and Kimball/data themes assume remote failure. Lived gateway stacks already show timeout/retry and bridge debt ([[policy-ingress-contract]], [[capability-bridges]]). Silent “eventually fine” is theatre.

## Untapped

DDIA replication/consensus chapters · networking courses · CMU 15-445 (D*).

## Related

- [[fail-loud-on-control-paths]] · [[microservices-tradeoffs]] · [[ddia-reliability-themes]]
