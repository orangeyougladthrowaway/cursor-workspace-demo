---
type: guidance
status: canonical
id: engineering-knowledge-base-g-cs-linq-api
concern: languages
description: C# LINQ deferred execution + Framework Design Guidelines pressure — tooling/library API craft.
domain: [csharp, dotnet]
aliases: [linq, fdg]
derived_from:
  - "[[restraint]]"
  - "[[honesty]]"
  - "[[csharp-project-toolchain]]"
  - "[[csharp-style-conventions]]"
updated: 2026-07-16
---

# Csharp linq api

Primaries (L+): [LINQ](https://learn.microsoft.com/en-us/dotnet/csharp/linq/); [Framework design guidelines](https://learn.microsoft.com/en-us/dotnet/standard/design-guidelines/) (overview / Do–Avoid pressure — not the full book).

## Applies when

Querying in-memory sequences or shaping public .NET library/tool APIs (still tooling-first).

## House Do / Avoid

| Do | Avoid |
| --- | --- |
| Materialize once when you enumerate twice | Re-running expensive `IQueryable` by accident |
| Keep projections pure inside queries | Side effects inside `Select` |
| Know `IEnumerable` vs `IQueryable` | Assuming every operator translates to SQL |
| Measure before Span-rewriting LINQ ([[csharp-span-memory]]) | Premature alloc micro-opts |

## Guidance

### LINQ

1. Query syntax and method syntax are equivalent after compile — pick readability.
2. **Deferred execution:** defining a query does not run it; iteration/materializers do.
3. Prefer side-effect-free projections; push side effects outside the query.
4. `IEnumerable` → local delegates; `IQueryable` → expression trees (provider may translate). Do not assume every operator round-trips to a remote store.
5. Force materialization (`ToList`/`ToArray`) only for stable snapshots or multiple enumerations.

### API design (FDG pressure)

6. Treat public surface as a product: naming, type choice, and exception behavior follow **Do / Consider / Avoid / Do not** — violate only with a named reason.
7. Prefer **consistency** with .NET (naming, dispose, exceptions) over novel house inventiveness for library APIs.
8. These Learn pages are **excerpts**; full FDG book remains Untapped for deep chapter harvest.

## Untapped

EF Core LINQ translation traps · equality/dispose pattern deep · full FDG 3rd ed.

## Related

- [[csharp-project-toolchain]] · [[csharp-async-di]] · [[unit-testing-norm]] · [[languages-atlas]]
