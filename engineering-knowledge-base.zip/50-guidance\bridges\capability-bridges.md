---
type: guidance
status: canonical
id: engineering-knowledge-base-g-bridges
concern: bridges
description: Accumulated credential-owning bridge catalogue and add-bridge recipes.
domain: [python, kubernetes, compose]
aliases: [bridges, db-api, storage-api]
derived_from:
  - "[[credential-owning-bridge]]"
  - "[[domain-io-edge-packaging]]"
updated: 2026-07-19
---

# Capability bridges


Atlas: [[platform-atlas]]. Pattern: [[credential-owning-bridge]]. Packaging: [[service-packaging]].

## Catalogue (K8s family baseline)

| Bridge | Package | Secrets / capability | Callers |
| --- | --- | --- | --- |
| db-api | `framework/db_api/` :8001 | DB password + SQLAlchemy | gateway forward + DbApiClient; `call_db_api` |
| storage-api | `framework/storage_api/` :8013 | Spaces/S3 keys | gateway / gateway_storage helpers — client `endpoint_url` construction: [[s3-compatible-client-endpoint]] |
| gateway | `framework/app.py` | optional JWT (usually off) | Argo, pods, port-forward |
| LLM sidecars / pipeline workers | custom worker images | GGUF / llama URLs — `host/`+`product/` | via gateway |

Compose families add/rename bridges (inference_api, `<crm_bridge>`, `<mail_bridge>`, ocr_api, second db plane in dual-plane). Prefer family atlases + harvest when extending this catalogue — keep **ownership rule** constant: secrets only on owner.

## Ownership wall

**Convention:** workers must not open Postgres/Spaces SDKs — go through gateway helpers.  
**Enforcement:** Docker extras omit sqlalchemy/boto3 on workers; **no import-linter**. Base image still includes FastAPI/httpx — “domain free of HTTP” is not package-enforced.

Observed leaks (Compose): domain modules calling inference HTTP or storage helpers directly — quarantine under honesty, fix toward bridges.

## Add a bridge (checklist)

1. Service package + `@wrapper_method` + `create_service_api`  
2. Optional-extra + Dockerfile installing that extra  
3. **Local-tool bridges** (`ocr_api`, …): Dockerfile also installs OS binary + lang/data packs required by product config — extras ≠ complete OCR runtime; verify list-langs / missing-traineddata ([[service-packaging]], [[docker-containers]], [[credential-owning-bridge]])  
4. Helm Deployment with **secretKeyRef only here** (or Compose env on owner only — fix env_file sprawl if claiming isolation)  
5. Register endpoint in forwarder ConfigMap / `SERVICE_ENDPOINTS`  
6. Register methods in manifests ([[gateway-auth]])  
7. NetworkPolicy: ingress from gateway; egress to upstream only  
8. Callers: `call_via_gateway(...)` only  
9. Rebuild image; regenerate manifests / compose up  

## Add a domain method

1. Method returning `dict`; `@wrapper_method`  
2. Manifest entry; redeploy **gateway + service**  
3. Prefer gateway helpers over owner SDKs  

## Intended side-doors

Gateway → db-api via `DbApiClient` for job/WAL without recursive `/call`. Leaf OpenAI-compatible HTTP inside inference/LLM bridges is OK; peer `/call` DNS is not (NP / unpublished ports).

## Quarantine

Shared `.env` on every Compose service called “secret isolation” · SA that can list all Secrets as least-privilege · product/SaaS demo lore as bridge architecture · OCR bridge claimed ready because the Python extra installed while config-selected tessdata is missing from the image · orchestrator (or any non-owner) fail-closed-validating third-party secrets mounted only on the bridge.

**Network honesty spine:** bridges and unpublished peer ports are part of the isolation story — document them; do not pretend open mesh DNS is the contract when lived trust is path-shaped ([[policy-ingress-contract]]).

## Related

- [[credential-owning-bridge]] · [[s3-compatible-client-endpoint]] · [[domain-io-edge-packaging]] · [[service-packaging]] · [[envelope-call]] · [[observer-wal]] · [[in-process-orchestration]] · [[platform-atlas]]
