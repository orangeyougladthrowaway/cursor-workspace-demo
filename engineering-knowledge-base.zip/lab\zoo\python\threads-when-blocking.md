---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-concurrency-async]]"
updated: 2026-07-16
---

# Threads when blocking

## When

Calling a blocking library that is not async-native from an otherwise sync worker.

## When not

Using threads to “speed up” pure-Python CPU work under the GIL — prefer processes.

```python
# Prefer: document why threads beat async for this library
from concurrent.futures import ThreadPoolExecutor

def call_blocking(n: int) -> int:
    with ThreadPoolExecutor(max_workers=4) as pool:
        return pool.submit(legacy_sdk_call, n).result()
```

## Related

- [[python-concurrency-async]] · [[honesty]]
