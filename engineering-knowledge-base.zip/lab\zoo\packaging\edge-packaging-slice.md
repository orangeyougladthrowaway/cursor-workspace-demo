---
type: example
status: canonical
domain: [packaging]
derived_from:
  - "[[domain-io-edge-packaging]]"
  - "[[service-packaging]]"
updated: 2026-07-15
---

# Edge packaging slice

## When

Keeping domain I/O adapters as optional packaging edges.

## When not

Pulling every adapter into the core runtime as required.

```text
core package ↔ optional extras for IO edges ([[domain-io-edge-packaging]])
```

## Related

- [[domain-io-edge-packaging]] · [[service-packaging]]
