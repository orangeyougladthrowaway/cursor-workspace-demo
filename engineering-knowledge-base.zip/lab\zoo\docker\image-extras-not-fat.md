---
type: example
status: canonical
domain: [docker]
derived_from:
  - "[[service-packaging]]"
  - "[[docker-containers]]"
updated: 2026-07-15
---

# Image extras not fat

## When

Mapping optional dependency groups to image roles.

## When not

Installing sqlalchemy + boto3 + everything on every image.

```text
extras: gateway | db | storage → separate images / install sets
```

## Related

- [[service-packaging]] · [[docker-containers]] · [[domain-io-edge-packaging]]
