---
type: guidance
status: canonical
id: engineering-knowledge-base-g-ddia
concern: datastores
description: DDIA reliability themes via Kleppmann public primary — logs/immutability/trade-offs; book chapters still Untapped.
domain: []
aliases: [ddia, kleppmann, inside-out]
derived_from:
  - "[[durable-storage-tradeoffs]]"
  - "[[postgres-wal-concurrency]]"
updated: 2026-07-15
---

# DDIA reliability themes

## Primary (D2 #5) — fetch honesty

**Not a paywalled DDIA chapter PDF** (O’Reilly body not available to this wave). Elevated from:

1. Author book thesis — [dataintensive.net](https://dataintensive.net/): build applications that are **reliable, scalable, and maintainable**; dig past buzzwords; **compare designs** and name **trade-offs / fundamental limitations**.
2. Full primary essay — [Turning the database inside-out with Apache Samza](https://martin.kleppmann.com/2015/03/04/turning-the-database-inside-out.html) (Kleppmann; same reliability/log worldview as DDIA).

Label this wave **deep on public Kleppmann reliability/log pressure**, not “DDIA book complete.” Owned-copy chapter harvest remains backlog.

## Applies when

Reasoning about data-system durability, derived reads, or replication/log mental models beyond a single Postgres/SQL box.

## Guidance (claims elevated)

1. Data-system design targets **reliability, scalability, maintainability** together — tooling choice must name trade-offs, not slogans (NoSQL/CAP/etc.).
2. Prefer **comparing designs** to memorising one product’s config surface.
3. A durable **append-only log of immutable events** (facts) simplifies writes: sequential I/O, partition for scale, easier to make reliable than concurrent in-place mutation of shared state.
4. **Materialized views / indexes / caches** can be derived from that log and **rebuilt**; separate write path (log) from read path (views).
5. Even traditional DB replication often turns imperative updates into a **logical log of immutable facts** — event structure is not only “event sourcing fashion.”
6. Application-managed cache invalidation tends toward races and operational mud; a principled **log → view** transform is monitorable and reorderable as one stream of writes.
7. Append-only history aids **recovery and audit** (you can reconstruct / undo); overwriting/deleting throws away information value.

## Collision with lived stacks

| Kleppmann / DDIA pressure | Lived |
| --- | --- |
| Log+views platform (Kafka/Samza-shaped) | Gateway Observer is a **narrow app audit log** ([[observer-wal]]), not that architecture |
| Engine WAL as recovery redo | Distinct vocabulary ([[postgres-wal-concurrency]]) |
| Immutability-first analytics | Warehouse SCD2 is **Type 2 history**, not mandatory event-sourcing rewrite ([[kimball-type2-scd]]) |

**Resolution:** adopt log/view ideas only for a **named job**. Do not pretend Observer `task_executions` == Kafka commit log.

## Untapped

DDIA chapters (owned copy) · replication/partitioning/transactions/streams chapters · CMU 15-445 · stream-processing report deep.

## Related

- [[durable-storage-tradeoffs]] · [[distributed-systems-expectations]] · [[postgres-wal-concurrency]] · [[data-atlas]]
