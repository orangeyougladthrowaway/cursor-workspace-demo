---
type: example
status: canonical
domain: [bash]
derived_from:
  - "[[tooling-proficiency]]"
updated: 2026-07-15
---

# Strict shell mode

## When

CI/glue scripts that must fail loud.

## When not

Ignoring pipe failures so green CI hides broken steps.

```bash
set -euo pipefail
```

## Related

- [[tooling-proficiency]] · [[delivery-ci]]
