---
type: template
status: canonical
description: Starter template for workflow notes.
updated: 2026-07-14
---

# Template — Workflow

```markdown
---
type: workflow
status: draft
id: engineering-knowledge-base-wf-NNN
concern: knowledge
description: ""
domain: []
aliases: []
derived_from: []
updated: YYYY-MM-DD
---

# Workflow title

## When to use

## Steps

## Related
```

Path: `60-workflows/{concept}/{slug}.md`. See [[navigation]].
