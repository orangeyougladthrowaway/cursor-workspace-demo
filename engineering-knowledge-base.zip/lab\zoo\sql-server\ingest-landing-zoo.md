---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[python-ingest]]"
updated: 2026-07-16
---

# Ingest landing zoo

## When

Python writers land into staging for warehouse historisation.

## When not

Writing straight into curated history tables from ad hoc scripts.

```text
Ingest → staging contract → historisation ([[python-ingest]])
```

## Related

- [[python-ingest]] · [[historisation-layers]]
