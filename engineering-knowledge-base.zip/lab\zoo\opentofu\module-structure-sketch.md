---
type: example
status: canonical
domain: [opentofu]
derived_from:
  - "[[terraform-modules-composition]]"
updated: 2026-07-15
---

# Module structure sketch

## When

Reusable module layout (standard module structure pressure).

## When not

Copy-paste root modules with no interface boundary.

```text
modules/network/
  main.tf
  variables.tf
  outputs.tf
  README.md
```

## Related

- [[terraform-modules-composition]]
