---
type: principle
status: canonical
description: Change behaviour and its authoritative note together — no dual sources of truth.
id: engineering-knowledge-base-p-010
category: "[[authority]]"
derived_from:
  - "[[authority]]"
updated: 2026-07-15
---

# Colocated authority

## Statement

When behaviour or a public contract changes, update the single authoritative note in the same change. READMEs point; they do not fork the truth. The same law applies to **deploy/activation**: dual lived SoTs without a named winner are authority failures ([[single-lived-source-of-truth]]).

## Rationale

Docs that lag are worse than thin docs — they teach false confidence. Co-updating keeps humans and agents aligned with reality.

## Encourages

- Vault/standard-as-home; same-PR documentation for behavioural change
- One named activation/deploy SoT per system

## Prevents

- Parallel markdown mythologies
- “Production-ready” claims that outrun the tree
- Co-equal clone-vs-zip / helm-vs-regenerate / dual-package stories left unresolved

## Evidence (thin)

Stated vault-first discipline in several projects; also frequent doc/code drift and dual activation scripts — the drift is the failure mode this principle targets.

## Related

- Category: [[authority]]
- [[policy-as-explicit-artefact]] · [[single-lived-source-of-truth]] · [[single-authority-for-documentation]]
