---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[tsql-batch-craft]]"
  - "[[python-ingest]]"
updated: 2026-07-15
---

# Tvp readonly batch

## When

Passing multi-row batches into a proc without scalar spam.

## When not

Mutating `@tvp` inside the proc (READONLY).

```sql
CREATE TYPE dbo.BatchType AS TABLE (bk nvarchar(64), payload nvarchar(max));
GO
CREATE PROC dbo.usp_Load @rows dbo.BatchType READONLY AS
INSERT dbo.Staging (bk, payload) SELECT bk, payload FROM @rows;
```

## Related

- [[tsql-batch-craft]] · [[warehouse-historisation]]
