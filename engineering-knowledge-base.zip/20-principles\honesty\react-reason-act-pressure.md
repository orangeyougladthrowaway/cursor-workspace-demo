---
type: principle
status: canonical
id: engineering-knowledge-base-p-020
category: "[[honesty]]"
description: Interleaved LLM reason+act (ReAct) is product pressure — still subordinate to schema-bound control paths.
derived_from:
  - "[[honesty]]"
  - "[[deterministic-before-probabilistic]]"
updated: 2026-07-15
---

# ReAct reason act pressure

## Statement

Agents that interleave verbal **reasoning traces** with **external actions** need explicit rails: schema-bound I/O, failure behaviour, and human-visible consent — not ambient model control.

## Rationale

Primary (D1 #10): [Yao et al. — ReAct](https://arxiv.org/abs/2210.03629). Interleaving reason+act improves task solving and interpretability vs reason-only or act-only baselines — **and** still hallucinates without tool constraints. Product agents remain subordinate to [[deterministic-before-probabilistic]] and [[coding-agent-projection]].

## Untapped

Full paper methods/ablations · tool-use safety · MCP trust pages · brittle-prompt literature.

## Related

- [[rag-retrieval-pressure]] · [[coding-agent-projection]] · [[agent-engineering-atlas]]
