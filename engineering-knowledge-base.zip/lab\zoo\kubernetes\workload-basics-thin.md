---
type: example
status: canonical
domain: [kubernetes]
derived_from:
  - "[[helm-deploy]]"
updated: 2026-07-16
---

# Workload basics thin

## When

Choosing Deployment vs Job for a chart workload.

## When not

Long-running Jobs for always-on APIs.

```text
API/worker long-run → Deployment
Batch finite → Job/CronJob
```

## Related

- [[helm-deploy]] · [[argo-workflows]]
