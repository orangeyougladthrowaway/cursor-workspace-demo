using System.Threading;
using System.Threading.Tasks;

namespace CSharpSdkTool;

public static class Program
{
    public static async Task<int> Main(string[] args)
    {
        using var cts = new CancellationTokenSource();
        Console.CancelKeyPress += (_, e) =>
        {
            e.Cancel = true;
            cts.Cancel();
        };

        await RunAsync(cts.Token);
        return 0;
    }

    private static async Task RunAsync(CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        await Task.Yield();
        Console.WriteLine("ok");
    }
}
