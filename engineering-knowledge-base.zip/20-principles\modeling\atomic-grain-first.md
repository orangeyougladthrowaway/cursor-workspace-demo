---
type: principle
status: canonical
id: engineering-knowledge-base-p-024
category: modeling
description: Prefer the finest available business grain; roll-ups are derived tables, not the design start.
derived_from:
  - "[[modeling]]"
  - "[[declare-the-grain]]"
updated: 2026-07-20
---

# Atomic grain first

## Statement

Store facts and grain-true dimensions at the **finest available business grain**. Coarser aggregates may exist for performance, but they are **derived** and must not be the only store of that process.

## Rationale

Atomic grain withstands unpredictable queries; summary grain presupposes the question ([Keep to the Grain](https://www.kimballgroup.com/2007/07/keep-to-the-grain-in-dimensional-modeling/)).

## Encourages

- Child grain for 1:N (parent as dim key on child)
- Separate association grain for M:N
- Explicit aggregate fact tables when needed

## Prevents

- Starting design at monthly rollups
- Losing line-level dims because only summary was stored

## Related

- [[declare-the-grain]] · [[grain-cardinality]] · [[snapshot-fact-shape]]
