---
type: guidance
status: canonical
id: engineering-knowledge-base-g-pg-wal
concern: datastores
description: Postgres engine WAL + MVCC — durability/isolation pressure vs application Observer WAL.
domain: [postgres]
aliases: [wal, mvcc, synchronous-commit]
derived_from:
  - "[[observer-wal]]"
  - "[[postgres-core-concepts]]"
updated: 2026-07-15
---

# Postgres WAL concurrency

Primary (D2 #4): [WAL intro](https://www.postgresql.org/docs/current/wal-intro.html), [Asynchronous commit](https://www.postgresql.org/docs/current/wal-async-commit.html), [MVCC intro](https://www.postgresql.org/docs/current/mvcc-intro.html) (PostgreSQL current docs).

## Applies when

Reasoning about Postgres durability/isolation under the Observer audit database, or naming “WAL” honestly across layers.

## Guidance (claims elevated)

1. **Engine WAL:** changes to data files must be logged and flushed **before** those data pages need to be durable after crash — recover by REDO from WAL (roll-forward). Commit can sync the sequential WAL instead of every dirty page.
2. WAL also enables online backup / **PITR** by archiving WAL and replaying to a chosen time.
3. **Synchronous commit (default):** client success only after WAL flush — crash after “committed” still recovers the txn. **Asynchronous commit** returns earlier: risk is **losing recent txns**, not corrupting the DB; do **not** use when the client takes irreversible external action (ATM cash example). Event/logging loads may accept the risk. Controlled by `synchronous_commit`. Differs from `fsync=off` (corruption risk).
4. **MVCC:** each statement sees a snapshot; readers and writers generally do not block each other. Explicit table/row/advisory locks exist when apps manage conflict points; SSI available for stricter isolation.

## Collision with lived Observer

| Engine / doc | Lived ([[observer-wal]], [[write-ahead-call-audit]]) |
| --- | --- |
| Postgres WAL = redo log for heap/indexes | App “WAL” = `jobs` / `task_executions` append/observe path |
| Sync commit durability guarantee | App may skip DB WAL if no `X-Job-Id`; observe-path failure can 500 **after** backend ran |
| Async commit OK for some logs | Label deliberately if audit accepts loss window — do not imply engine sync |

**Resolution:** keep vocabulary split — **engine WAL** ([[postgres-wal-concurrency]]) vs **application write-ahead audit**. Do not claim Observer durability stronger than `synchronous_commit` + successful flush path.

## Untapped

WAL configuration · checkpoints · replication · full isolation levels chapter · vacuum/bloat · PITR operator recipes · CMU buffer lectures.

## Related

- [[postgres-core-concepts]] · [[observer-wal]] · [[durable-storage-tradeoffs]] · [[data-atlas]]
