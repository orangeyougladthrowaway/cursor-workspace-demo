---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[durable-storage-tradeoffs]]"
updated: 2026-07-16
---

# Pooling honesty zoo

## When

Sizing app connection pools against PG `max_connections`.

## When not

Unbounded pools per replica that exhaust the server.

```text
pool_size × replicas < max_connections − admin headroom
```

## Related

- [[durable-storage-tradeoffs]] · [[postgres-wal-concurrency]]
