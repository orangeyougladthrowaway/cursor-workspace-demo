---
type: principle
status: canonical
id: engineering-knowledge-base-p-018
category: "[[boundaries]]"
description: Ubiquitous language and bounded context pressure naming — not curriculum folder trees.
derived_from:
  - "[[boundaries]]"
  - "[[ownership]]"
updated: 2026-07-15
---

# Bounded context language

## Statement

Align vocabulary with ownership boundaries and atlas concerns. DDD bounded contexts inform **naming**, not automatic L1 folders per context ([[navigation]]).

## Related

- [[domain-driven-design-pressure]] · [[architecture-atlas]]
