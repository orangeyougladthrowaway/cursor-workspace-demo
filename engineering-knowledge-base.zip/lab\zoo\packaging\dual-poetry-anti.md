---
type: example
status: canonical
domain: [packaging]
derived_from:
  - "[[trainer-packaging]]"
  - "[[service-packaging]]"
updated: 2026-07-15
---

# Dual poetry anti

## When

Naming dual Poetry+pip install theatre in review.

## When not

Both stories “official” without a single lock/source of install truth.

```text
ANTI: poetry pyproject without lock + requirements.txt both marked official
Prefer: one install story + lock (pip+uv/poetry lock — pick one)
```

## Related

- [[trainer-packaging]] · [[service-packaging]] · [[python-packaging-layout]]
