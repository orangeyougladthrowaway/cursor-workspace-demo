---
type: guidance
status: canonical
id: engineering-knowledge-base-g-py-log-model
concern: languages
description: Python logging + data modeling — stdlib logging once; dataclass inward; validators at edges.
domain: [python]
aliases: [logging, dataclass, pydantic]
derived_from:
  - "[[honesty]]"
  - "[[boundaries]]"
  - "[[python-typing-honesty]]"
  - "[[config-fail-at-load]]"
updated: 2026-07-16
---

# Python logging modeling

Primaries (L-py #5): [Logging HOWTO](https://docs.python.org/3/howto/logging.html); [dataclasses](https://docs.python.org/3/library/dataclasses.html); lived Pydantic wire models.

## Applies when

Choosing how services log and how in-process data is shaped.

## Does not apply when

- Libraries calling `basicConfig` for the whole process
- Triple-modeling the same DTO across wire/domain/ORM without a reason

## House defaults

### Logging

1. Use stdlib **`logging`** with module-level `logging.getLogger(__name__)`.
2. Configure **once** at process entry (dictConfig/fileConfig/host wiring). Libraries should rarely call `basicConfig`.
3. Levels: DEBUG local; INFO lifecycle; WARNING recoverable; ERROR failed operation; CRITICAL impending stop.
4. Prefer structured extras / adapters when the stack supports them; `print` is not an ops channel.
5. Correlation with traces is via OTEL/context when wired ([[metrics-tracing-logging-pressure]]) — do not invent a second ID scheme casually.

### Data modeling

6. **`dataclass` / NamedTuple** — in-process records; no I/O validation.
7. **Runtime validators** (Pydantic, etc.) — wire/config boundaries where untrusted input must fail loud ([[config-fail-at-load]]).
8. One validation edge + plain domain objects inward; typing ([[python-typing-honesty]]) does not replace validators for JSON/HTTP bodies.

## Decision rules

| Layer | Shape |
| --- | --- |
| HTTP/JSON/env | Pydantic (or equivalent) at edge |
| Domain core | dataclass / plain types |
| Ops signal | `logging` + optional OTEL correlation |

## Untapped

structlog deep · OTEL log signal recipes · Pydantic v2 settings encyclopaedia · attrs.

## Related

- [[python-typing-honesty]] · [[config-fail-at-load]] · [[metrics-tracing-logging-pressure]] · [[languages-atlas]]
