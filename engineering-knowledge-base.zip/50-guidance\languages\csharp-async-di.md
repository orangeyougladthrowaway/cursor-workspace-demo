---
type: guidance
status: canonical
id: engineering-knowledge-base-g-cs-async-di
concern: languages
description: C# async + DI — CancellationToken, no sync-over-async; lifetimes; HttpClient; ILogger; dispose.
domain: [csharp, dotnet]
aliases: [async, dependency-injection, ihost]
derived_from:
  - "[[reliability]]"
  - "[[failure]]"
  - "[[honesty]]"
  - "[[csharp-project-toolchain]]"
updated: 2026-07-16
---

# Csharp async di

Primaries: [Async programming scenarios](https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/async-scenarios); [.NET dependency injection](https://learn.microsoft.com/en-us/dotnet/core/extensions/dependency-injection); [IHttpClientFactory](https://learn.microsoft.com/dotnet/core/extensions/httpclient-factory).

## Applies when

Writing async .NET tooling/workers or wiring Generic Host DI.

## Does not apply when

- Sync console one-shots with no I/O waits (keep them sync)
- Injecting scoped services into singletons “for convenience”

## House defaults

### Async

1. Use `async`/`await` for I/O-bound work; pass **`CancellationToken`** through APIs that can stop (hosts, HTTP, DB).
2. Avoid **sync-over-async** (`.Result` / `.Wait()` / `.GetAwaiter().GetResult()` on async) — deadlock and thread-pool hazards.
3. Prefer async all the way to the entrypoint; fire-and-forget is not observability.

### DI / hosting

4. Register abstractions in `IServiceCollection`; resolve via constructor injection — no ambient service locator as default.
5. Know lifetimes: **singleton** vs **scoped** vs **transient**. Do not inject scoped into singleton; use `IServiceScopeFactory` inside long-running hosted services.
6. Prefer Generic Host / Worker patterns for background tooling; dispose scopes correctly.
7. Keep one clear injectable constructor (ambiguous overloads fail at resolve).

### HttpClient

8. Use **`IHttpClientFactory`** (`AddHttpClient`) — set timeouts on the named/typed client; do not `new HttpClient()` per call.
9. Pass `CancellationToken` into `SendAsync` / typed methods; treat timeout + cancel as first-class failure.

### Logging & dispose

10. Inject **`ILogger<T>`** — structured message templates; do not invent a parallel logging façade per service.
11. Prefer `await using` / `using` for `IAsyncDisposable` / `IDisposable`; do not leave HttpResponseMessage / streams undisposed.
12. Exceptions: throw meaningful types at boundaries; do not swallow and return default; let host policies map to exit codes / HTTP status.

## Decision rules

| Hazard | House rule |
| --- | --- |
| Scoped-in-singleton | refuse; redesign with factory/scope |
| Unbounded HTTP | factory client + timeout + CT |
| Silent catch | fail loud on control paths |

## Untapped

Keyed services deep · Options pattern encyclopaedia · EF Core scoping recipes · ASP.NET filters.

## Related

- [[csharp-project-toolchain]] · [[csharp-system-text-json]] · [[unit-testing-norm]] · [[languages-atlas]]
