---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-system-text-json]]"
updated: 2026-07-16
---

# Stj dto edge

## When

Deserializing a request DTO at the host edge with shared options.

## When not

`JsonDocument` / `JsonElement` threaded through domain logic.

```csharp
var dto = JsonSerializer.Deserialize<ItemDto>(json, HostJson.Options)
    ?? throw new InvalidOperationException("bad json");
```

## Related

- [[csharp-system-text-json]] · [[csharp-project-toolchain]]
