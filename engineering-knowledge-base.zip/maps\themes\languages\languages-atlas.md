---
type: map
status: canonical
id: engineering-knowledge-base-map-languages
concern: languages
description: Theme atlas — Python/C# language craft + indexes; SQL craft via data/warehouse homes.
domain: []
aliases: [python, csharp, pep8]
updated: 2026-07-20
---

# Atlas — Languages

Language craft and house dialect, from source-unit structure to stack seams. **Index only** — not a curriculum. Family depth: [[ingest-coverage]] Language deep ledger. Coverage: [[common-case-coverage]].

## Cross-language craft

- Standards: [[cohesive-code-units]] · [[readable-control-flow]]

## Mechanical style

- [[python-style-pep8]] · [[csharp-style-conventions]] — house dialect encoded in tooling, not textbooks

## Python craft (L)

- Source shape: [[python-code-structure]] · [[python-flow-choices]]
- [[python-typing-honesty]] · [[python-packaging-layout]] · [[python-errors-resources]] · [[python-concurrency-async]] · [[python-logging-modeling]] · [[python-langsec-secrets]]
- Tests: [[pytest-practices]] · [[unit-testing-norm]]
- Lived packaging (no twin): [[service-packaging]] · [[trainer-packaging]] · [[delivery-ci]] · [[delivery-gates]]

## C# craft (tooling-first)

- Source shape: [[csharp-code-structure]] · [[csharp-flow-choices]]
- [[csharp-project-toolchain]] · [[csharp-async-di]] · [[csharp-linq-api]] · [[csharp-span-memory]] · [[csharp-system-text-json]]
- Adjacency: [[dacpac-publish]]

## SQL craft (homes elsewhere)

- Cross-dialect source shape: [[sql-code-structure]] · [[sql-flow-choices]]
- Systems→eng map: [[sql-server-craft-map]]
- T-SQL / warehouse: [[tsql-set-based-merge]] · [[tsql-batch-craft]] · [[warehouse-historisation]] · [[warehouse-atlas]]
- SSDT: [[ssdt-sqlproj]] · [[ssdt-publish-scripts]] · [[dacpac-publish]]
- SSIS: [[ssis-dtproj-dtsx]]
- Postgres: [[postgres-sql-craft]] · [[postgres-core-concepts]] · [[postgres-wal-concurrency]] · [[postgres-jsonb-craft]] · [[data-atlas]]

## Related

- [[catalog-maps]] · [[delivery-atlas]] · [[engineering-craft-atlas]] · [[ingest-coverage]] · [[common-case-coverage]]
