---
type: example
status: canonical
domain: [docker]
derived_from:
  - "[[docker-containers]]"
updated: 2026-07-16
---

# Non root user

## When

Dropping root in runtime images when the process allows it.

## When not

Running as root “because it worked in lab.”

```dockerfile
RUN chown -R 65532:65532 /app
USER 65532:65532
```

## Related

- [[docker-containers]]
