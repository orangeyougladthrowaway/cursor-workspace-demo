---
type: guidance
status: canonical
id: engineering-knowledge-base-g-pg-core
concern: datastores
description: PostgreSQL relational core — tables/types; indexes when measured; foundation for WAL/SQL craft.
domain: [postgres]
aliases: [postgres, rdbms]
derived_from:
  - "[[reliability]]"
  - "[[honesty]]"
  - "[[observer-wal]]"
updated: 2026-07-16
---

# Postgres core concepts

Primary: [PostgreSQL documentation — Tutorial / Overview](https://www.postgresql.org/docs/current/tutorial.html).

## Applies when

Reasoning about platform Postgres persistence (Observer WAL tables, app schemas) before diving into dialect craft.

## Does not apply when

- Treating managed Postgres product quirks as portable house law without naming them
- Skipping SQL craft when writing queries ([[postgres-sql-craft]])

## House defaults

1. RDBMS stores relations as **tables/rows/columns** in a database cluster — SQL row order is not guaranteed without `ORDER BY`.
2. Prefer explicit types (`uuid`, `timestamptz`, `text`, `numeric`) over opaque catch-alls; use `jsonb` only as a bag beside relational keys ([[postgres-jsonb-craft]]).
3. Audit tables (`jobs`, `task_executions`, …) are ordinary relations — **not** a separate “audit DB product” ([[observer-wal]]).
4. Add indexes for **measured** predicates (PK/FK first; then hot WHERE/JOIN). Do not sprinkle indexes from folklore.
5. Durability and concurrency of the cluster are engine concerns — elevate via [[postgres-wal-concurrency]].

## Decision rules

| Question | Open |
| --- | --- |
| Upsert / CTE / EXPLAIN | [[postgres-sql-craft]] |
| Isolation / MVCC / WAL vs app audit | [[postgres-wal-concurrency]] |
| Document attributes | [[postgres-jsonb-craft]] |

## Untapped

Vacuum autotune · planner encyclopaedia · managed Postgres product dialect tables.

## Related

- [[postgres-wal-concurrency]] · [[postgres-sql-craft]] · [[postgres-jsonb-craft]] · [[ddia-reliability-themes]] · [[data-atlas]]
