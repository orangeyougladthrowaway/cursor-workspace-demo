---
type: guidance
status: canonical
id: engineering-knowledge-base-g-py-flow
concern: languages
description: Python flow choices — guards, loops, comprehensions, generators, lambdas, vectorisation, and concurrency.
domain: [python]
aliases: [comprehensions, lambda, iteration]
derived_from:
  - "[[readable-control-flow]]"
  - "[[python-concurrency-async]]"
  - "[[python-errors-resources]]"
  - "[[restraint]]"
updated: 2026-07-16
---

# Python flow choices

## Applies when

Choosing how a Python function branches, iterates, transforms data, or introduces concurrency.

## House defaults

### Branches

1. Guard invalid input, unavailable state, and no-op cases early when that leaves one clear happy path.
2. Prefer positive conditions for normal business alternatives; prefer a negative guard when it directly names rejection.
3. Use `match` for a closed, shape-oriented dispatch that is clearer than repeated extraction. Use `if`/`elif` for predicates and ranges.
4. Avoid nested conditional expressions and compound booleans that need commentary; name intermediate predicates.

### Iteration and transformation

| Need | Prefer |
| --- | --- |
| Simple pure mapping/filtering | comprehension |
| Lazy stream | generator expression/function |
| Branching, mutation, logging, retry, early exit | explicit loop |
| Tiny local key/callback | `lambda` |
| Reused, typed, or multi-step callback | named function |
| Functional pipeline already clearer than syntax | `map`/`filter`; otherwise comprehension |
| Membership lookup | set/dict rather than repeated list scan when scale warrants |

Keep comprehensions to one clear expression and at most a simple filter. Do not nest them into a puzzle.

### Vector, async, thread, process

| Work | Choose |
| --- | --- |
| Existing NumPy/Pandas numeric or columnar operation | vectorised library primitive |
| Small ordinary collection | readable Python first |
| Many independent I/O waits | asyncio with structured tasks/timeouts |
| Blocking library inside async system | isolated thread/executor |
| Pure-Python CPU parallel work | processes |

Do not add a vector library or async boundary solely to avoid a readable loop. Measure before hand-vectorising or Span-like micro-optimising ([[restraint]]).

### Errors and resources

Exceptions represent failed operations, not ordinary loop control across broad scopes. Keep `try` blocks narrow; use context managers for ownership and let cancellation propagate unless cleanup requires handling ([[python-errors-resources]]).

## Exceptions

Performance-critical parsing or numerical kernels may prefer specialised constructs after profiling and focused tests. Existing framework callback shapes may dictate lambdas or async signatures; keep their bodies thin.

## Related

- [[python-code-structure]] · [[python-concurrency-async]] · [[python-errors-resources]] · [[readable-control-flow]] · [[languages-atlas]]
