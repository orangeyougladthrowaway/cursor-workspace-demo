---
type: workflow
status: canonical
id: engineering-knowledge-base-wf-013
concern: knowledge
description: Shell, git, editor, packaging literacy — Missing Semester spine; subordinate to engineering-knowledge-base projection.
domain: []
aliases: [missing-semester, tooling]
derived_from:
  - "[[coding-agent-projection]]"
updated: 2026-07-17
---

# Tooling proficiency

Engineering craft assumes fluent **shell, git, editor, and packaging** tooling (Missing Semester). Agentic coding is a workflow topic — not a second bible ([[coding-agent-projection]]).

## Expectations

1. Command-line fluency for repo operations and deploy scripts.
2. Version control as the coordination spine for changes.
3. Editor/IDE proficiency including optional AI tools with known limits.

## W2 spine status

Missing Semester **syllabus only** — lecture notes deep backlog.

## Deep backlog

Missing Semester 2026 lectures · git advanced · nix/containers tooling · shipping workflows.

## Related

- [[coding-agent-projection]] · [[engineering-craft-atlas]]
