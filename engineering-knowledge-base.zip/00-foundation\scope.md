---
type: foundation
status: canonical
description: engineering-knowledge-base scope — domains of travel, stack watchlist, common-case coverage ambition, quarantine.
updated: 2026-07-16
---

# Scope

engineering-knowledge-base is a **current-state** **engineering bible**. The landscape below is the **starting point** from inventories of existing repos — imperfect practice included. It sets direction of travel. It is **not** automatic elevation to principles, standards, or patterns. Promote only by editing living notes at the right altitude ([[changing-this-bible]], [[knowledge-ingestion]]).

Navigation: [[navigation]] · Atlases: [[catalog-maps]]. Companion: [[starting-landscape]]. Coverage instrument: [[common-case-coverage]]. Ambition: [[purpose]] · [[roadmap]] Axis F.

## In scope (active)

| Area | Why (from lived work) |
| --- | --- |
| Core engineering reasoning | Boundaries, change, quality, trust, knowledge authority, restraint |
| Gateway-first service platforms | Repeated across Compose and K8s gateway family variants |
| Batch / warehouse data systems | SQL Server layered warehouse + Python ingest |
| Local ML / RL libraries | Adapter-driven trainer (secondary; selective elevation) |
| Config-as-data & domain purity | Shared across service platforms; Hydra in trainer |
| Docs-as-authority (vault/ADR lite) | Strong in Compose gateway families; weak/absent elsewhere — upskill target |
| Delivery & quality gates | Hard vs soft gates, Compose/K8s/VM packaging — improve without copying theatre |
| Code craft (micro → macro) | Decision guidance for cohesive files/types/callables, readable control flow, and Python/C#/SQL construct choices — not a style textbook |
| AI product constraints | Schema-bound / regex-first / prompt-as-config LLM use |
| AI-assisted coding | Mostly **absent** in repos today — deliberate engineering-knowledge-base upskill |
| Public research | Challenge and elevate living notes (books, MIT/CS, OS) — **structural homes** under guidance/principles, indexed by `maps/themes/` atlases ([[catalog-maps]]) |
| **Common-case matrices** | Majority coverage for house languages/tools on the watchlist — scored on [[common-case-coverage]]; doctrine G1–G3 then praxis G4 |
| **Praxis plane (`lab/`)** | Zoo / skeletons / stubs densified to the common-case bar — subordinate to doctrine; [[layout]], [[praxis-ingestion]] |

## Out of scope

- Tutorial libraries / course mirrors / vendor API encyclopaedias **as doctrine** — **“not a curriculum” does not mean “stay shallow.”** Majority common-case depth is in scope; lesson journeys and bookmark dumps are not
- Universal line/method limits, one-class-per-file dogma, or copied language textbooks as house law — prefer defaults + decision tests + named exceptions
- Per-app product docs (pipeline taxonomies, domain label schemas, provider/demo lore)
- Decision logs, proposal archives, evidence warehouses in this vault
- Treating any single repo’s README “production-ready” voice as law
- Soft CI, fall-open auth, demo TLS, or silent `except` as virtues to encode
- Using `lab/` entries as sole authority when a canonical note exists (or should)
- Declaring a language/tool “covered” because a zoo facet was **seeded** — score [[common-case-coverage]], not entry counts alone
## Stack watchlist (guidance targets — not top-level folders)

Product/cloud names may appear later under `50-guidance/` as specialisations. Philosophy stays tool-free.

| Class | In watchlist |
| --- | --- |
| Languages | Python 3.11–3.13, T-SQL / SQL Server, C# (.NET for tooling), Shell/Bash, PowerShell, HCL (OpenTofu/Terraform), YAML |
| Service runtime | FastAPI, Uvicorn, Pydantic v2, httpx, structlog, Prometheus client surfaces |
| Data | PostgreSQL (jobs/WAL/domain), SQL Server (Staging/ODS/DWH/Control), SQLite (local episodic), S3-compatible object storage |
| Platform shapes | Multi-image Python monorepo; Docker Compose profiles; single-VM lab hosts; Kubernetes/Helm; Argo Workflows |
| Cloud / IaC | DigitalOcean-class deploy (droplet, DOKS, managed DB, registry, Spaces) via OpenTofu/Terraform — as *your* practiced host, not universal cloud law |
| Warehouse / ETL | Microsoft.Build.Sql / SSDT / DACPAC / SqlPackage; SCD2 proc patterns; provider→staging writers; host drop-zone releases |
| ML / local train | PyTorch, Hydra/OmegaConf, adapter contracts, optional FAISS/retrieval, TensorBoard/WandB-soft |
| Quality tooling | pytest, ruff, mypy (enforcement honesty), GitHub Actions matrices, optional pre-commit |
| Edge / demo | Caddy (lab only — never silent prod doctrine) |
| Inference bridges | Hosted OpenAI-compatible inference adapters; optional local llama-server sidecars |

## Elevation posture

| From inventories | Treat as |
| --- | --- |
| Gateway envelope I/O, credential-owning bridges, domain purity, config-as-data, fail-at-load manifests, honest demo threat models, WAL/observer ideas, staging/SCD2 layering, adapter+metadata routing | **Candidates** for patterns/standards — process deliberately |
| Soft mypy/coverage, actor/auth fall-open, dual deploy paths without one SoT, docs≫code, cloud/product demo specifics | **Quarantine** — learn from, do not encode as good |
| Coding-agent rules in repos | **Gap** — build in engineering-knowledge-base / project projections later |

## Changing scope

Edit this note when the landscape truly changes. Don’t sprawl by interest or by pasting another inventory into the vault.
