---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-typing-honesty]]"
updated: 2026-07-16
---

# Json loads typeddict

## When

JSON enters the process and must become a typed edge shape.

## When not

Pushing `dict[str, Any]` through domain code as the typed story.

```python
import json
from typing import TypedDict

class ItemIn(TypedDict):
    id: str
    name: str

def parse_item(raw: str) -> ItemIn:
    data = json.loads(raw)
    return ItemIn(id=data["id"], name=data["name"])
```

## Related

- [[python-typing-honesty]] · [[typeddict-boundary]]
