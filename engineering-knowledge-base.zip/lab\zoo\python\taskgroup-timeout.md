---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-concurrency-async]]"
updated: 2026-07-15
---

# Taskgroup timeout

## When

Bounding concurrent async work with structured concurrency.

## When not

Fire-and-forget tasks without cancellation/timeout.

```python
import asyncio

async with asyncio.timeout(5):
    async with asyncio.TaskGroup() as tg:
        tg.create_task(fetch_a())
        tg.create_task(fetch_b())
```

## Related

- [[python-concurrency-async]] · [[no-sync-over-async]]
