---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-async-di]]"
  - "[[metrics-tracing-logging-pressure]]"
updated: 2026-07-16
---

# Ilogger thin

## When

Logging from DI-managed services.

## When not

`Console.WriteLine` as the service logging story.

```csharp
public sealed class Worker(ILogger<Worker> log)
{
    public void Run() => log.LogInformation("run");
}
```

## Related

- [[csharp-async-di]] · [[metrics-tracing-logging-pressure]]
