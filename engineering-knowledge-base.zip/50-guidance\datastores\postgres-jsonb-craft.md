---
type: guidance
status: canonical
id: engineering-knowledge-base-g-pg-jsonb
concern: datastores
description: Postgres JSONB common subset — relational keys first; jsonb bags; CHECK + GIN when measured.
domain: [postgres]
derived_from:
  - "[[restraint]]"
  - "[[honesty]]"
  - "[[postgres-sql-craft]]"
  - "[[postgres-core-concepts]]"
updated: 2026-07-16
---

# Postgres jsonb craft

Primary: [PostgreSQL JSON Types](https://www.postgresql.org/docs/current/datatype-json.html).

## Applies when

Storing semi-structured payloads beside stable relational keys.

## Does not apply when

- Every domain attribute is known and queried/joined — use columns
- You want a document DB as the house default for all state

## House defaults

1. Prefer **relational columns** for filter/join/FK keys; put variable attributes in `jsonb`.
2. Use **`jsonb`**, not `json` — binary, indexable, duplicate-key normalized.
3. Constrain shape when it matters: `CHECK (jsonb_typeof(attrs) = 'object')` and/or required-key checks.
4. Index containment only when measured: `CREATE INDEX … ON t USING GIN (attrs jsonb_path_ops);` for `@>` workloads.

```sql
-- Relational key + attribute bag
CREATE TABLE widget (
  id          uuid PRIMARY KEY,
  tenant_id   uuid NOT NULL,
  attrs       jsonb NOT NULL DEFAULT '{}'::jsonb,
  CHECK (jsonb_typeof(attrs) = 'object')
);

-- Containment query
SELECT id FROM widget
WHERE tenant_id = $1
  AND attrs @> '{"tier":"gold"}'::jsonb;
```

5. Operators agents should know: `@>` containment, `?` key exists, `->>` text extract, `#>` path. Prefer `@>` + GIN over `attrs->>'x' = …` when filtering many keys.

## Decision rules

| Attribute | Store as |
| --- | --- |
| Join / unique / FK | column |
| Rare optional bag | `jsonb` |
| Frequently filtered key | promote to column when measured |

## Untapped

jsonpath encyclopaedia · generated columns deep · partitioning interplay.

## Related

- [[postgres-sql-craft]] · [[postgres-core-concepts]] · [[data-atlas]]
