---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[threat-model-matched-controls]]"
updated: 2026-07-16
---

# Matched controls zoo

## When

Controls must map to declared threats.

## When not

Controls without threats, or threats without controls.

```text
Threat ↔ control table ([[threat-model-matched-controls]])
```

## Related

- [[threat-model-matched-controls]] · [[threat-model-declaration]]
