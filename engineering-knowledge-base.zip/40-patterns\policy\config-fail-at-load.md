---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-003
concern: policy
description: "Method registries fail at load for core; product policy may compile; auth YAML is often theatre."
domain:
  - python
  - yaml
aliases:
  - manifests
  - fail-at-load
  - config-compile
derived_from:
  - "[[policy-as-artefact]]"
  - "[[fail-at-the-gate]]"
updated: 2026-07-17
---

# Config fail-at-load

Stack detail: [[gateway-auth]] · [[helm-deploy]] (manifest merge). Cousins: [[hydra-config]], [[compiled-schema-release]]. Abstract house law: [[happy-path-construction]] · [[required-happy-path]]. Atlas: [[platform-atlas]].

## Context

Service method registries, product rules, and deploy manifests change faster than code structure and must not fork across call sites.

## Problem

Scattered literals and “YAML everywhere” without a clear hard vs soft gate → half-registered platforms sold as complete.

## Forces

- Reviewable DRY policy artefacts
- Core platform must not boot with corrupt route tables
- Extensions want soft skip (MVP tension)
- Some product config wants merge/compile; some only needs load-at-use

## Solution

### A. Method / route registry

1. Hand-edited YAML under `config/services/` (`services.<name>.service_name` + methods; ports/methods are **not** JSON-Schema validated by the loader — structural checks only: dict + `service_name` present).
2. Gateway boot: `ServiceManifestLoader.load_all_manifests("config/services")` → `_register_forward_handlers` registers one forward closure per `service:method`.
3. **Hard fail** invalid manifests that the family treats as core (ValueError; gateway process re-raises and refuses to start).
4. **Soft** invalid extension manifests — warn + skip (log, continue registering the rest).
5. No hot reload; boot-once (or worker first-use for product/compile-time YAML).

### Differs by deploy shape — which files are "core" (hard) vs "extension" (soft)

| Family | Hard-loaded (boot fails if invalid) | Soft-loaded (warn/skip) | Notable trap |
| --- | --- | --- | --- |
| K8s gateway family | Only `config/services/_framework.yaml` | `core.yaml`, `<product>.yaml`, `examples.yaml`, and any `custom/*.yaml` | Docs call `core.yaml` "locked core" — **false**: it is soft-merged, only `_framework.yaml` is the true hard-fail authority (dual-SoT claim) |
| Compose single-plane | **All** root files: `core.yaml`, `bridges.yaml` (`strict=True`) | Only `config/services/custom/*.yaml` (directory absent in tree — path unexercised) | `_REQUIRED_MANIFEST_FILES = {"core.yaml","bridges.yaml"}` constant exists but is **never referenced** — dead, do not rely on it enforcing presence |
| Compose dual-plane | `core.yaml`, `bridges.yaml`, `workflow.yaml` (`strict=True`); optional `_framework.yaml` if present | `config/services/custom/*.yaml` (also unexercised) | Same dead `_REQUIRED_MANIFEST_FILES` constant present and unreferenced |

The K8s family is the **odd one out**: it hard-fails the *smallest* file and soft-merges the rest, while both Compose families hard-fail *every* root file. Do not assume "root = hard" transfers unmodified between families — check which file the loader calls `strict=True` on.

### B. Compile into one runtime artefact (when merge needed)

| Repo | Compile command | Output | Gated? |
| --- | --- | --- | --- |
| Compose dual-plane | `python -m domain.<product>.build_config` (CI step; also `RUN` in the workflow-runner Dockerfile) | `domain/<product>/generated/config.json` | **Hard** in CI, image build, **and** deploy — same artefact all three trust |
| K8s | Helm render → `infrastructure/scripts/generate-manifests.sh` | `infrastructure/manifests.yaml` (gitignored — regenerated every deploy, not committed) | **Hard** in CI (`tests/test_manifests.py`) and at deploy time |
| Compose single-plane | *(none for app config)* | Hand YAML only | Runtime load hard; no compile job exists |

Prefer compile when many sources merge (prompt YAML + rules YAML + schema → one JSON the runtime loads once). Prefer fail-at-load when one hand-edited file is already the authority. Editing a compile *source* without re-running the compile step leaves the runtime on stale/missing generated JSON — a `ConfigurationError` (or silently stale behaviour) at first use, not at edit time.

### C. Do not claim theatre artefacts

- `config/auth.yaml` — present in every family; `Authorizer`/`ConfigLoader._load_auth_config` exist but are **never called** from the `authorize()` hot path. Editing this file with no redeploy has zero runtime effect — confusing for operators who expect it to gate something.
- `_REQUIRED_MANIFEST_FILES` — dead constant in both Compose families.
- Envelope JSON Schema files (`schemas/*.schema.json`) — copied into the repo, sometimes with a stricter/different shape than the Pydantic models (e.g. actor pattern forbidding `user:`), never loaded by the Validator.
- `@wrapper_method(input_schema_url=..., output_schema_url=...)` — accepted as decorator kwargs, discarded; no gate reads them.

Document all four as non-authoritative until something on the hot path actually loads them — do not remove them silently (they may be aspirational scaffolding), but do not sell them as enforced policy either.

## Consequences

**Easier:** Provenance; testable loaders; gateway route table from data; CI can build the same artefact runtime trusts.

**Harder:** Tiered severity creates false completeness; method presence not proven until request if wrapper/manifest drift.

**Watch:** Soft custom manifests for critical routes; docs calling `auth.yaml`/`core.yaml` "SoT" or "locked" when the loader treats them as soft; schemas unused at runtime; dead `_REQUIRED_MANIFEST_FILES`; compile-source edits without a rebuild step.

## Pattern statement

1. Route policy lives in manifests loaded at gateway boot.
2. Core/invalid manifests **hard-fail** boot; soft paths must be named.
3. Multi-source product policy → **compile** to one artefact with the same gate CI and runtime use.
4. Unused YAML/Schema without a consumer is documentation, not architecture.
5. Prefer once-at-boot or explicit first-use cache; no silent hot reload fiction.

## Related

- [[gateway-auth]] · [[helm-deploy]] · [[platform-atlas]]
- [[policy-as-artefact]] · [[single-lived-source-of-truth]] · [[policy-ingress-contract]]
- [[delivery-gates]] · [[fail-at-the-gate]] · [[happy-path-construction]] · [[required-happy-path]]
