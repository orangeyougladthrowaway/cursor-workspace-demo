# Agent notes — Engineering Knowledge Base

## Authority

| Source | Owns | Write? |
| --- | --- | --- |
| This repo (`engineering-knowledge-base`) | Engineering craft, coding-agent rails, delivery gates | **Yes** |
| External research | Domain/vendor gaps engineering-knowledge-base does not own | Cite; engineering-knowledge-base wins on house engineering |

Follow `.cursor/rules/engineering-knowledge-base-authority.mdc`. Prefer atlases + responsibility notes. Open lab only after the canon.

## Operating law (always)

1. **Retrieve before build** — `README` → [[navigation]] → family/theme atlas → canonical notes → then code or vault amend.
2. Prefer `status: canonical`; treat `draft` as unfinished.
3. Cite `id`s for load-bearing house choices.
4. **Hard gates** for any quality claim; no soft CI theatre.
5. Skills under `.cursor/skills/` are invoke-only pointers at workflows — never a second bible.
6. Full-coverage asks → [[common-case-coverage]]; hand-write doctrine.

## Lifecycle skills (product engineering)

| Skill | Workflow |
| --- | --- |
| `engineering-knowledge-base-plan` | [[plan-engineering-change]] |
| `engineering-knowledge-base-build` | [[build-engineering-change]] |
| `engineering-knowledge-base-test` | [[verify-engineering-change]] |
| `engineering-knowledge-base-review` | [[review-engineering-change]] |

Umbrella: [[coding-agent-projection]]. Vault amend: [[knowledge-ingestion]] · [[praxis-ingestion]].

## Start here

- [[navigation]] · [[catalog-maps]] · [[coding-agent-projection]]
- [[common-case-coverage]] · [[lab-atlas]]
- Product consumers: [[product-init]]
- Branching / PRs: root `CONTRIBUTING.md` (house detail: sibling `agent-harness` → `docs/source-control.md`)

## Quarantine

Fat skills · task playbooks as sole UX · soft gates · silent fallbacks · bulk third-party skill packs · leftover `product-init/` in product trees · citing `temp/` as doctrine
