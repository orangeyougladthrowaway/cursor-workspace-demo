---
type: template
status: canonical
description: Starter template for principle category spine notes.
updated: 2026-07-13
---

# Template — Category

```markdown
---
type: category
status: draft
description: ""
id: engineering-knowledge-base-cat-NNN
derived_from:
  - "[[accountable-meaning-under-change]]"  # or other philosophy
updated: YYYY-MM-DD
---

# Category name

## Theme

One short statement of the theme.

## Belongs here

## Does not belong here

## Leaves

- *(principle leaf wikilink)*
```
