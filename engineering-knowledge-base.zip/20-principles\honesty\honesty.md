---
type: category
status: canonical
description: Spine for honesty — represent uncertainty and probabilistic work truthfully.
id: engineering-knowledge-base-cat-honesty
derived_from:
  - "[[accountable-meaning-under-change]]"
updated: 2026-07-14
---

# Honesty

## Theme

Do not dress uncertain or probabilistic behaviour as deterministic control-plane truth.

## Belongs here

Principles about truthful representation of uncertainty and similar honesty constraints.

## Does not belong here

How control paths fail ([[failure]]); what delivery must prove ([[proof]]).

## Leaves

- [[deterministic-before-probabilistic]]
