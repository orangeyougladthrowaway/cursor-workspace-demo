---
type: example
status: canonical
domain: [agent]
derived_from:
  - "[[deterministic-before-probabilistic]]"
updated: 2026-07-16
---

# Deterministic first zoo

## When

Preferring deterministic checks before LLM/probabilistic steps.

## When not

Model-first for schema/gate work that should be hard.

```text
Deterministic gates before probabilistic ([[deterministic-before-probabilistic]])
```

## Related

- [[deterministic-before-probabilistic]] · [[delivery-gates]]
