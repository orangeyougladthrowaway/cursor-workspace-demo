---
type: standard
status: canonical
id: engineering-knowledge-base-s-013
concern: apis
description: Public REST uses resource nouns and honest HTTP — distinct from internal Envelope.
domain: []
aliases: [rest, http-api]
derived_from:
  - "[[public-http-vs-internal-envelope]]"
updated: 2026-07-15
---

# REST resource design norm

## Requirement

1. Public partner APIs use **resource-oriented** HTTP with documented **versioning**, pagination/filtering where collections can grow, and error contracts ([[rest-resource-design]]).
2. Internal `POST /call` Envelope remains the **platform spine** ([[envelope-call]]).
3. OpenAPI (or equivalent) is the published discovery surface — Paths/components for HTTP edges ([[openapi-specification]]).
4. One published shape per boundary — dual dialects need a named product job ([[public-http-vs-internal-envelope]]).
5. Prefer **idempotent** PUT and stable published shapes under [[published-contract-stability]] (Hyrum pressure).

## Related

- [[published-contract-stability]] · [[apis-atlas]]
