---
type: example
status: canonical
domain: [architecture]
derived_from:
  - "[[distributed-systems-expectations]]"
updated: 2026-07-16
---

# Distributed expectations zoo

## When

Accepting failure/latency/partition realities of distributed systems.

## When not

Assuming reliable networks and exactly-once by default.

```text
→ [[distributed-systems-expectations]]
```

## Related

- [[distributed-systems-expectations]] · [[reliability]]
