---
type: catalog
status: canonical
id: engineering-knowledge-base-cat-maps
description: Knowledge atlases — lived families and cross-cutting themes (indexes only).
updated: 2026-07-15
---

# Catalog — Knowledge atlases

Atlases **index** notes. They are **not** “how to build/ship/train X” playbooks. Law: [[navigation]].

## Lived families

| Family | Atlas | Body |
| --- | --- | --- |
| Platform | [[platform-atlas]] | Gateway Envelope platforms (Compose + K8s) |
| Warehouse | [[warehouse-atlas]] | SQL Server SSDT / grain / SCD2 dims / snapshot facts / activation |
| Trainer | [[trainer-atlas]] | Local RL / Hydra / adapters |

## Themes (cross-cutting / remote)

| Theme | Atlas |
| --- | --- |
| Security | [[security-atlas]] |
| Delivery | [[delivery-atlas]] |
| Infrastructure | [[infrastructure-atlas]] |
| Data | [[data-atlas]] |
| Architecture | [[architecture-atlas]] |
| APIs | [[apis-atlas]] |
| Languages | [[languages-atlas]] |
| Observability | [[observability-atlas]] |
| Agent engineering | [[agent-engineering-atlas]] |
| Engineering craft | [[engineering-craft-atlas]] |

## Praxis (subordinate)

| Plane | Atlas |
| --- | --- |
| Lab (zoo / skeletons / stubs) | [[lab-atlas]] |
| Common-case scoreboard (Axis F) | [[common-case-coverage]] |

Taxonomic browse: [[catalog-guidance]] · [[catalog-patterns]] · [[catalog-principles]]. Praxis inventory: [[catalog-lab]].
