---
type: map
status: canonical
id: engineering-knowledge-base-map-apis
concern: apis
description: Theme atlas — public HTTP/OpenAPI vs internal Envelope.
domain: []
aliases: [openapi, rest, http]
updated: 2026-07-15
---

# Atlas — APIs

Public HTTP surfaces and OpenAPI honesty vs internal Envelope spine. Index only.

## Canonical (D1 #4 + D2 #7)

- [[openapi-specification]] · [[rest-resource-design]] · [[rest-resource-design-norm]] · [[public-http-vs-internal-envelope]]
- Contract honesty: [[published-contract-stability]]
- Lived: [[envelope-call]] · [[policy-ingress-contract]] · [[adapter-metadata-routing]]

## Deep backlog (D2+)

Full Operation/Schema encyclopaedia · HATEOAS deep · async request-reply · codegen.

## Related

- [[catalog-maps]] · [[architecture-atlas]] · [[platform-atlas]]
