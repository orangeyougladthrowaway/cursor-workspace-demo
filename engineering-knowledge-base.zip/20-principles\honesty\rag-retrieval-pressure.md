---
type: principle
status: canonical
id: engineering-knowledge-base-p-021
category: "[[honesty]]"
description: RAG — parametric + non-parametric memory; retrieved passages are untrusted until validated.
derived_from:
  - "[[honesty]]"
  - "[[deterministic-before-probabilistic]]"
updated: 2026-07-15
---

# RAG retrieval pressure

## Statement

Retrieval-augmented generation combines a **parametric** generator with **non-parametric** retrieved memory. Retrieved chunks remain **untrusted input** until validated. Grounding, provenance, and failing loud when context is missing are honesty requirements — not optional UX.

## Rationale

Primary (D2 #13): [Lewis et al., RAG (arXiv:2005.11401)](https://arxiv.org/abs/2005.11401) — NeurIPS 2020.

1. Parametric LMs store knowledge in weights but struggle to access/update/provenance knowledge precisely on knowledge-intensive tasks.
2. RAG couples a seq2seq generator with a **dense retrieval index** (paper: Wikipedia via neural retriever) — hybrid parametric + non-parametric memory.
3. Two formulations: **RAG-Sequence** (same passages for whole generation) vs **RAG-Token** (different passages per token).
4. Benefits claimed: better open-domain QA vs parametric-only; more specific/factual generation; knowledge can be updated by changing the index without full retrain.
5. Product honesty still binds: retrieved text can be wrong, stale, or adversarial — schema rails, citation, and empty-context failure modes ([[deterministic-before-probabilistic]], [[coding-agent-projection]]).

## Untapped

Full paper methods/ablations · successor RAG surveys · vector DB product docs · chunking/eval recipes · Osmani AI skills.

## Related

- [[react-reason-act-pressure]] · [[deterministic-before-probabilistic]] · [[agent-engineering-atlas]]
