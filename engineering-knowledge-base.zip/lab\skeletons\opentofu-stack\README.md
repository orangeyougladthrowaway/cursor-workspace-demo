---
description: Thin OpenTofu stack skeleton with remote-state honesty — cites terraform canons.
updated: 2026-07-15
---

# opentofu-stack

## Purpose

Copy-out starter for a small root module with **remote state required** and a module sketch.

## Required canons

- [[terraform-state-backends]]
- [[terraform-modules-composition]]
- [[host-opentofu]]

## Copy steps

1. Copy this folder; choose **one** backend (`azurerm` or `s3`) and delete the other block comment.
2. Fill backend bucket/resource-group details — never commit plaintext state.
3. `tofu init` → `tofu plan` (apply only with intended credentials).

## Honesty

- Local state is lab-only — remote + lock for shared work ([[remote-state-required]]).
- No secrets in `.tf` committed files ([[no-plaintext-state]]).
- Validate inputs ([[variable-validation-thin]]).
