---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-sql-craft]]"
updated: 2026-07-15
---

# Cte returning

## When

Readable multi-step write that needs observed ids/rows.

## When not

Blind insert without `RETURNING` when callers need keys.

```sql
WITH ins AS (
  INSERT INTO t (name) VALUES ($1)
  RETURNING id
)
SELECT id FROM ins;
```

## Related

- [[postgres-sql-craft]]
