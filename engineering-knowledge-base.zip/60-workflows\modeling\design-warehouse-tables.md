---
type: workflow
status: canonical
id: engineering-knowledge-base-wf-014
concern: modeling
description: Design warehouse table/schema shapes from grain and cardinality; stop on Gaps.
domain: [warehouse, cursor]
derived_from:
  - "[[warehouse-table-design]]"
  - "[[warehouse-grain]]"
  - "[[coding-agent-projection]]"
updated: 2026-07-20
---

# Design warehouse tables

Use when shaping dims, facts, or bridges for a warehouse change.

## Preconditions

- Named business process / entities (or Gaps)  
- Layering known ([[historisation-layers]])  
- No unresolved SoR invention

## Retrieve

1. [[warehouse-atlas]] · [[data-atlas]]  
2. [[declare-the-grain]] · [[atomic-grain-first]] · [[warehouse-grain]]  
3. [[scd2-dimension-envelope]] · [[snapshot-fact-shape]] · [[grain-cardinality]] · [[scd2-dim-snapshot-fact]]  
4. [[warehouse-table-design]] · zoo [[dim-scd2-fact-snapshot-outline]]

## Steps

1. Restate outcome and acceptance for **this** design task.  
2. Inventory entities + relationships; mark warrants/Gaps.  
3. Cardinality matrix → grain list (atomic preferred).  
4. For each grain: dim / fact / bridge; draft column lists per standards.  
5. Name SCD2 join policy per fact (current vs as-was).  
6. Cite binding ids; list open Gaps.  
7. Hand off DDL/load implementation to build lane — this workflow does not invent SoR attributes.

## Output

- Grain sentences + keys  
- Cardinality matrix  
- Column lists (dim envelope / fact snapshot / bridge)  
- Join policy  
- Cited `id`s · Gaps

## Forbidden

- Skipping grain declaration  
- Mixing grains in one fact  
- Fact SCD2 envelope as history SoT  
- Inventing domain keys/attributes
