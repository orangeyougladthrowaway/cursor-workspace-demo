---
type: standard
status: canonical
aliases: ["extend-patterns"]
domain: []
concern: change
id: engineering-knowledge-base-s-006
description: New behaviour extends established patterns; drive-by architecture forks require an explicit decision — including AI-assisted edits.
derived_from:
  - "[[extend-established-patterns]]"
  - "[[colocated-authority]]"
updated: 2026-07-13
---

# Extend by established patterns

## Requirement

1. New behaviour **extends** seams, error styles, and I/O habits already owned by the system unless you deliberately establish a new pattern and document it as authority.
2. Passing changes — especially **AI-assisted** ones — must not introduce a parallel architecture, contract shape, or failure posture “while here.”
3. Intentional forks update the authoritative notes and honesty checks in the **same change**.
4. Review rejects unexplained pattern drift even when tests pass.

## Derived from

- [[extend-established-patterns]]
- [[colocated-authority]]

## Exceptions

Greenfield modules may establish a first pattern deliberately; document it as authority, not as silence.

## Related

- [[prove-honesty-contracts-in-delivery]]
- [[knowledge-ingestion]]
