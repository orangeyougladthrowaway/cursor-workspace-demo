---
type: example
status: canonical
domain: [architecture]
derived_from:
  - "[[required-happy-path]]"
  - "[[happy-path-only]]"
updated: 2026-07-17
---

# Silent fallback anti

## When

Required config or control authority must fail closed on one happy path.

## When not

Marketing soft defaults, dual loaders, or empty-policy allow as “resilience.”

```text
ANTI — soft default chain
  secret = env.get("API_KEY") or "dev-key"

ANTI — dual construction
  load_v2(path) if exists else load_legacy(path)  # both “official”, no migration owner

ANTI — empty-policy allow
  if not policies: return Allow

ANTI — immortal legacy compat
  try: new_contract(x)
  except: return old_guess(x)  # no deadline, no fail-loud

Prefer: require + fail at load; named lab/migration exceptions only
  → [[required-happy-path]] · [[happy-path-construction]]
```

## Related

- [[required-happy-path]] · [[happy-path-construction]] · [[fail-at-the-gate]]
- [[fall-open-anti]] · [[continue-on-error-anti]] · [[single-lived-source-of-truth]]
