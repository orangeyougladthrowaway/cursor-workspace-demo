"""Tests for naming rules ([[methodology]], [[navigation]])."""

from __future__ import annotations

import re

import pytest

from tests.vault import h1_title, iter_notes, norm_slug, parse_frontmatter, read_text, rel_posix


def test_no_and_in_folder_or_stem() -> None:
    offenders: list[str] = []
    for path in iter_notes():
        if re.search(r"\band\b", path.stem):
            offenders.append(f"stem: {rel_posix(path)}")
        if re.search(r"\band\b", path.parent.name):
            offenders.append(f"folder: {rel_posix(path)}")
    assert not offenders, "\n".join(offenders)


LEGACY_STEM_H1 = {"domain-free-of-transport-io"}


def test_stem_matches_h1_for_doctrine_notes() -> None:
    """Stem should match H1 (prose form of basename)."""
    mismatches: list[str] = []
    for path in iter_notes():
        if path.stem in LEGACY_STEM_H1:
            continue
        if path.stem.startswith("catalog-"):
            continue
        if "templates" in path.parts:
            continue
        rel = rel_posix(path)
        if not rel.split("/")[0].startswith(("20-", "30-", "40-", "50-", "60-", "maps/", "10-")):
            continue
        _, body = parse_frontmatter(read_text(path))
        title = h1_title(body)
        if not title:
            mismatches.append(f"{rel}: missing H1")
            continue
        ns, nh = norm_slug(path.stem), norm_slug(title)
        nh_compact = nh.replace("-and-", "-").replace("-and", "").replace("and-", "")
        if ns != nh and ns != nh_compact and not (ns.replace("-", "") == nh.replace("-", "")):
            mismatches.append(f"{rel}: stem={path.stem!r} h1={title!r}")
    assert not mismatches, "\n".join(mismatches[:40])
