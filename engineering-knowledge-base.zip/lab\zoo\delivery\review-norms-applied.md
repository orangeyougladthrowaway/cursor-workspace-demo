---
type: example
status: canonical
domain: [delivery]
derived_from:
  - "[[code-review-norm]]"
updated: 2026-07-16
---

# Review norms applied

## When

Reviewing a change for design, tests, and code health.

## When not

Approve-by-emoji without looking-for lenses.

```text
Looking-for: design · complexity/YAGNI · tests · comments that explain why
Approve improvements; refuse health-decreasing changes ([[code-review-norm]])
```

## Related

- [[code-review-norm]] · [[programming-over-time]]
