---
type: example
status: canonical
domain: [delivery]
derived_from:
  - "[[prove-honesty-contracts-in-delivery]]"
updated: 2026-07-16
---

# Pre post submit zoo

## When

Separating fast pre-submit honesty from heavier post-submit proof.

## When not

Claiming “fully proven” after lint-only pre-submit.

```text
Pre-submit: unit + compile (hard)
Post-submit: slower integration — label honestly
→ [[prove-honesty-contracts-in-delivery]]
```

## Related

- [[prove-honesty-contracts]] · [[delivery-gates]]
