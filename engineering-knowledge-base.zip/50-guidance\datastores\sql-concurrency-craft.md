---
type: guidance
status: canonical
id: engineering-knowledge-base-g-sql-concurrency
concern: datastores
description: How to choose isolation, locking hints, and transaction shape for house T-SQL loads.
domain: [sql-server, t-sql]
aliases: [isolation-craft, locking-craft]
derived_from:
  - "[[tsql-set-based-merge]]"
  - "[[tsql-batch-craft]]"
  - "[[sql-flow-choices]]"
updated: 2026-07-20
---

# Sql concurrency craft

Systems: lock/isolation behaviour. Eng: **defaults for warehouse loads and APIs**.

## Build

1. Prefer short transactions around one set-based unit ([[tsql-batch-craft]]).
2. Default warehouse merge: document isolation; lived MERGE often uses locking hints (`HOLDLOCK`/`UPDLOCK` class) for correctness — see [[tsql-set-based-merge]] and zoo `merge-output-holdlock`.
3. Readers that must not block writers: consider row-versioning isolation **only** when tempdb/version store capacity is owned.
4. Deadlocks: treat as defects in access order or hinting — retry only with bounded policy and metrics, not silent infinite retry.

## Maintain

- After index or predicate changes, re-validate deadlock graphs and duration on StageToODS/ODSToDWH.
- Do not raise isolation “to be safe” without measuring blocking on shared ODS.

## Untapped

Full isolation matrix as house law · RCSI default estate-wide.

## Related

- [[sql-index-plan-craft]] · [[historisation-layers]] · [[sql-server-craft-map]]
