---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[pytest-practices]]"
updated: 2026-07-16
---

# Parametrize table

## When

Several input/expected pairs share one behaviour assertion.

## When not

Hiding unrelated behaviours or paying integration cost inside “one more param.”

```python
import pytest

@pytest.mark.parametrize(
    ("raw", "expected"),
    [("a", 1), ("bb", 2)],
    ids=["short", "longer"],
)
def test_len(raw: str, expected: int) -> None:
    assert len(raw) == expected
```

## Related

- [[pytest-practices]] · [[unit-testing-norm]]
