---
type: guidance
status: canonical
id: engineering-knowledge-base-g-tf-modules
concern: opentofu
description: Module composition — concept-shaped modules; flat lived tree; no single-resource shims.
domain: [opentofu, terraform]
aliases: [modules]
derived_from:
  - "[[restraint]]"
  - "[[boundaries]]"
  - "[[host-opentofu]]"
  - "[[terraform-state-backends]]"
updated: 2026-07-16
---

# Terraform modules composition

Primary (D1 #7): [Terraform — Standard Module Structure](https://developer.hashicorp.com/terraform/language/modules/develop/structure).

## Applies when

Factoring host stacks (`infrastructure/modules/*`) or publishing reusable modules.

## Does not apply when

- Wrapping one resource “for neatness”
- Deep mutual nesting that hides the real dependency graph

## House defaults

1. Root module is the primary entrypoint; prefer `main.tf` / `variables.tf` / `outputs.tf` with descriptions + validation where footguns exist.
2. Nested modules live under `modules/`; keep them **composable by the caller**, not a deep call tree of mutual nesting.
3. Modules describe **architectural concepts** (network, compute, database, kubernetes, registry, storage) — lived shape: `infrastructure/modules/{compute,database,kubernetes,network,registry,storage}/` ([[host-opentofu]]).
4. Examples under `examples/` use the **external** `source` address callers would use.
5. Pin providers / lockfiles at the root; modules should not silently float provider majors ([[host-opentofu]]).
6. Variables: validate enums/ranges that prevent footguns; outputs: export only what callers need (no secret sprawl in outputs).

## Decision rules

| Smell | Fix |
| --- | --- |
| One-resource module | inline at root or fold into concept module |
| Module A ↔ B mutual nest | flatten; root composes both |
| Brand resource names as law | keep capability class; quarantine vendor IDs |

## Untapped

Module testing frameworks · registry publishing · multi-cloud composition encyclopaedia.

## Related

- [[terraform-state-backends]] · [[host-opentofu]] · [[infrastructure-atlas]]
