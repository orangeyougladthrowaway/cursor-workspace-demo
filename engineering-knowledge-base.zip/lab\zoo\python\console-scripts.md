---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-packaging-layout]]"
updated: 2026-07-15
---

# Console scripts

## When

Exposing a CLI entrypoint from an installable package.

## When not

Relying on `python path/to/script.py` as the only install story.

```toml
[project.scripts]
mytool = "mypkg.cli:main"
```

## Related

- [[python-packaging-layout]] · [[src-layout-editable]]
