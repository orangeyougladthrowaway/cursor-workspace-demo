---
type: principle
status: canonical
id: engineering-knowledge-base-p-019
category: "[[restraint]]"
description: Prefer modular monolith with clear seams until split is forced by a named job.
derived_from:
  - "[[restraint]]"
  - "[[boundaries]]"
updated: 2026-07-15
---

# Modular monolith default

## Statement

Default to **one deployable** with explicit internal boundaries ([[domain-io-edge-packaging]]) before service sprawl. Split when the question changes (scale, team, failure isolation) — not because Fowler exists.

## Related

- [[microservices-tradeoffs]] · [[architecture-atlas]]
