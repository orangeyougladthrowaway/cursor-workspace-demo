---
type: map
status: canonical
id: engineering-knowledge-base-map-warehouse
concern: warehouse
description: Atlas of accumulated SQL warehouse knowledge — not a ship playbook.
aliases: [ssdt, dacpac, scd2, grain, sqlproj]
updated: 2026-07-20
---

# Atlas — Warehouse

Accumulated knowledge from the SQL Server layered warehouse. Indexes notes; not a task journey.

## Systems → engineering craft

- [[sql-server-craft-map]] (full capability → build/maintain map)

## Grain and dimensional design

- [[declare-the-grain]] · [[atomic-grain-first]] · [[warehouse-grain]]
- [[grain-cardinality]] · [[warehouse-table-design]] · [[design-warehouse-tables]]
- [[dimensional-modeling-kimball]] · [[scd2-dimension-envelope]] · [[snapshot-fact-shape]] · [[scd2-dim-snapshot-fact]]

## Layers and transforms

- [[warehouse-historisation]] · [[historisation-layers]] · [[tsql-set-based-merge]] · [[tsql-batch-craft]]
- [[kimball-type2-scd]] · [[kimball-scd-vocabulary]]

## Engine craft (build/maintain)

- [[sql-constraints-craft]] · [[sql-index-plan-craft]] · [[sql-programmability-craft]]
- [[sql-concurrency-craft]] · [[sql-agent-jobs-craft]] · [[sql-maintenance-craft]]
- [[sql-code-structure]] · [[sql-flow-choices]]

## Ingest

- [[python-ingest]]

## Schema release and host (SSDT)

- [[ssdt-sqlproj]] · [[ssdt-publish-scripts]] · [[dacpac-publish]] · [[compiled-schema-release]]
- [[schema-change-models]] · [[sql-env-release-assembly]] · [[sql-server-env-branches]]
- [[host-activation]] · [[single-lived-source-of-truth]]

## SSIS (optional ETL path)

- [[ssis-dtproj-dtsx]]

## Delivery

- [[delivery-gates]] (warehouse subsection)

## Praxis

- Zoo [[dim-scd2-fact-snapshot-outline]] · [[ssdt-publish-scripts-outline]] · [[ssis-dtproj-outline]]
- Stubs `lab/stubs/sql-server/scd2-merge-outline.sql` · `dim-scd2-fact-snapshot-outline.sql` · `ssdt-sqlproj-outline.xml` · `ssdt-publish-scripts-outline.sql`

## Related

- [[catalog-maps]] · [[platform-atlas]] · [[trainer-atlas]] · [[data-atlas]] · [[languages-atlas]]
