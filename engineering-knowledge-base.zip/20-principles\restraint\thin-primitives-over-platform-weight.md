---
type: principle
status: canonical
description: Prefer thin owned primitives over accumulating platform weight without a clear job.
id: engineering-knowledge-base-p-007
category: "[[restraint]]"
derived_from:
  - "[[restraint]]"
updated: 2026-07-13
---

# Thin primitives over platform weight

## Statement

Add the smallest owned primitive that preserves the contract. Do not accumulate frameworks, layers, or shared platforms unless they enforce an ownership or honesty job we are willing to maintain.

## Rationale

Platform gravity grows faster than discipline. Thin primitives keep replacement and understanding cheap.

## Encourages

- Small shared kernels; role-scoped dependencies; explicit refusal of “convenience frameworks”

## Prevents

- Dependency sprawl and ceremonial layering mistaken for architecture

## Evidence (thin)

Warehouse ingest primitives; capability-scoped installs. Counter-pressure from heavy gateway stacks — keep those as patterns to *evaluate*, not as a license to bloat.

**Architecture spine (wide · Fowler microservices):** independently deployable services, **smart endpoints / dumb pipes**, and organization around business capability are *options*, not mandates. Our lived stack already centralises policy on one ingress ([[policy-ingress-contract]]) — that is a deliberate central pipe, not Fowler orthodoxy. Prefer thin owned primitives and honest deploy boundaries over “must microservice everything.”

## Related

- Category: [[restraint]]
- [[domain-free-of-transport-io]]
