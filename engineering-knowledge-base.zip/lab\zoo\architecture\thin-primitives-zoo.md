---
type: example
status: canonical
domain: [architecture]
derived_from:
  - "[[thin-primitives-over-platform-weight]]"
updated: 2026-07-16
---

# Thin primitives zoo

## When

Preferring thin primitives over heavy platform frameworks.

## When not

Platform weight without a clear capability gain.

```text
→ [[thin-primitives-over-platform-weight]]
```

## Related

- [[thin-primitives-over-platform-weight]] · [[restraint]]
