---
type: guidance
status: canonical
id: engineering-knowledge-base-g-compose
concern: compose
description: Accumulated Docker Compose / VM runtime knowledge for gateway families.
domain: [compose, docker]
aliases: [compose, docker-compose, vm-lab]
derived_from:
  - "[[ownership]]"
  - "[[honesty]]"
  - "[[trust]]"
  - "[[docker-containers]]"
updated: 2026-07-19
---

# Compose deploy

Atlas: [[platform-atlas]]. Host VM provision: [[host-opentofu]]. Wire: [[envelope-call]]. Auth honesty: [[gateway-auth]]. Ownership: [[credential-owning-bridge]].

## Authoritative paths

**Local:** `docker compose -f deploy/compose/docker-compose.yml [--profile …] up`  
**VM (`host/`):** tofu `deploy.sh plan|create` stages compose/schema/smoke under host path (e.g. `/opt/framework`); then compose pull/up; apply SQL schema; write `.env`.

Access often SSH tunnel to gateway `:8000`. Helm is **absent** as live path in Compose families (migrate leftovers are quarantine).

**Docker spine (wide):** containers are isolated, portable processes sharing a host kernel — compose profiles package those processes for lab/VM runtimes. Prefer images that carry their deps; do not confuse “containerised” with “securely least-privileged” ([[gateway-auth]], secret sprawl below).

## Profiles / topology

| Family | Notes |
| --- | --- |
| single-plane | Unprofiled core + product profile; smoke `scripts/smoke-<product>.sh` |
| dual-plane | Workflow profile + bootstrap; optional frontend; second DB plane |

Only publish gateway (and intentional UIs); bridges stay mesh-local.

## Secrets honesty

Universal `env_file: ../../.env` on most services is the **practiced anti-pattern**. Claiming bridge isolation while broadcasting full `.env` is theatre. Dual-plane frontend (GATEWAY_URL + webhook token only) is exemplar for **one** service, not proof the family fixed sprawl.

### Must (when claiming least privilege)

1. **Per-service env** — inject only the keys that service needs (`environment:` and/or small env files per role). Credential ownership follows the process that calls the third party ([[credential-owning-bridge]]).
2. Do **not** dump the whole host `.env` into every container. Bridges must not receive gateway or sibling-bridge secrets they do not use.
3. Target end-state matches Helm honesty: per-workload secret refs ([[helm-deploy]]), not one broadcast file.
4. **Confirm injection boundaries before blaming application logic:** host `.env` presence ≠ container presence. Prove with `docker compose exec <svc> printenv <VAR>` (and compare roles). Optional-integration secrets belong on the bridge; enable flags may live on the orchestrator only ([[in-process-orchestration]]).

Lived families may still ship sprawl — label that **practiced debt** and do not claim isolation in reviews until per-service slices are real.

Helm families use per-Deployment `secretKeyRef` instead ([[helm-deploy]]).

## Registry-backed recreate (host shape)

On Droplet/VM Compose that **pulls** images from a registry (e.g. DOCR), the **immutable image** is the unit of application change ([[service-packaging]]).

| Change class | Must |
| --- | --- |
| App/code or Dockerfile | CI build → push tag → host `compose pull` → recreate the service(s) |
| Compose/env wiring only | Stage compose/env on host; recreate affected services — **does not** pick up unbuilt source |

Verify loop after a code fix: change → image → pull/recreate → `printenv`/health → exercise the path. Redeploying compose alone after a source edit is the wrong loop.

## Edge / TLS

Private gateway + tunnel = practiced. Caddy / public HTTPS often **docs or TF residue without assets** — quarantine as “working edge.”

## Smoke

Family-specific scripts (`smoke-<product>.sh`, `smoke-demo.sh`). Platform-only smoke without product profile often **absent**.

## Quarantine

Caddy theatre · TF `enable_public_edge` without assets · env_file sprawl as security model · legacy compose under CODE_TO_MIGRATE as supported · treating `compose up` as a code-deploy when images come from the registry.

## Related

- [[host-opentofu]] · [[capability-bridges]] · [[credential-owning-bridge]] · [[service-packaging]] · [[gateway-auth]] · [[in-process-orchestration]] · [[envelope-call]] · [[platform-atlas]]
