---
type: example
status: canonical
domain: [helm]
derived_from:
  - "[[helm-deploy]]"
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Helm template compile

## When

Compiling manifests in CI as an honesty seam.

## When not

Shipping charts never rendered in CI.

```bash
helm template release ./chart -f values.yaml > /dev/null
```

## Related

- [[helm-deploy]] · [[delivery-gates]] · [[delivery-ci]]
