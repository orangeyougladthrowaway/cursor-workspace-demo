---
type: example
status: canonical
domain: [docker]
derived_from:
  - "[[docker-containers]]"
updated: 2026-07-16
---

# Healthcheck restart thin

## When

Declaring container health for orchestrators/Compose.

## When not

Restart loops hiding crash bugs without logs/metrics.

```dockerfile
HEALTHCHECK CMD curl -f http://127.0.0.1:8080/health || exit 1
```

## Related

- [[docker-containers]] · [[compose-deploy]]
