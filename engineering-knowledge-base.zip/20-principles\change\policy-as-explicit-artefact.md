---
type: principle
status: canonical
description: Changeable policy belongs in explicit artefacts with one source of truth, not scattered call-site literals.
id: engineering-knowledge-base-p-005
category: "[[change]]"
derived_from:
  - "[[change]]"
  - "[[authority]]"
updated: 2026-07-15
---

# Policy as explicit artefact

## Statement

Product and platform policy that changes faster than code structure — rules, prompts, registries, auth matrices, thresholds — should live in explicit artefacts (config/schema/data) with a single authoritative compilation or load path.

## Rationale

Buried literals force code churn for policy edits and fork truth across call sites. Artefacts make review and replacement possible.

## Encourages

- Versioned config; build-time compile when needed; load-time validation

## Prevents

- Duplicated rule text in code
- Undocumented behavioural forks

## Evidence (thin)

Recurring compiled/domain config and packaged policy trees in service platforms; experiment config surfaces in training systems. Specific formats are guidance later, not this principle.

## Related

- Category: [[change]]
- [[colocated-authority]]
