---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[tsql-set-based-merge]]"
updated: 2026-07-16
---

# Plans decision thin

## When

Reading why a MERGE/select is slow before adding indexes casually.

## When not

Index-spray without actual plan evidence.

```sql
SET STATISTICS IO ON;
-- Inspect actual plan; prefer seeks on join/filter keys used by MERGE
```

## Related

- [[tsql-set-based-merge]] · [[delivery-gates]]
