---
type: principle
status: canonical
id: engineering-knowledge-base-p-015
category: "[[proof]]"
description: Observable behaviour becomes dependency (Hyrum's Law) — publish and test contracts at honesty seams.
derived_from:
  - "[[proof]]"
  - "[[change]]"
  - "[[programming-over-time]]"
updated: 2026-07-15
---

# Published contract stability

## Statement

**Hyrum’s Law:** with a sufficient number of users of an API, it does not matter what you promise in the contract — **all observable behaviours of your system will be depended on by somebody**. Prefer explicit published contracts over accidental surface. Treat “happens to work” as short-lived programming; treat maintainable, documented behaviour as software engineering ([[programming-over-time]]).

## Rationale

Primary (D1 #1b): *Software Engineering at Google* ch01 (time, scale, trade-offs; Hyrum’s Law). With enough time and users, even “innocuous” observables (hash iteration order, serialization shape, soft AuthZ fall-open) become de-facto contracts. Changing them is a deliberate trade-off, not a surprise. Reinforces [[prove-honesty-contracts]] and lived wire seams ([[envelope-call]], [[policy-ingress-contract]]).

## Encourages

- Documenting intended contracts at honesty seams
- Tests that lock **published** behaviour (public API / state), not private call graphs
- Explicit analysis of breakages before “cleanup” changes at scale
- Distinguishing short-lived hacks from long-lived systems (“clever” is an accusation in engineering)

## Prevents

- Assuming unpublished behaviour is free to change
- Calling accidental couplings “not the API”
- Perfect-adherence fantasies after code review (“we followed the docs”)

## Collisions (lived)

- Envelope fields, fall-open AuthZ, soft manifests: **observable** — either published in threat model / contract notes or treated as debt ([[gateway-auth]], [[threat-model-declaration]])

## Untapped

SE@Google remaining chapters · API versioning guides · Large-Scale Changes chapter.

## Related

- [[programming-over-time]] · [[prove-honesty-contracts]] · [[code-review-norm]] · [[rest-resource-design-norm]] · [[engineering-craft-atlas]]
