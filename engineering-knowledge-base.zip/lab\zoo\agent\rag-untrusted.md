---
type: example
status: canonical
domain: [agent]
derived_from:
  - "[[rag-retrieval-pressure]]"
  - "[[deterministic-before-probabilistic]]"
updated: 2026-07-15
---

# Rag untrusted

## When

Retrieved chunks remain untrusted until validated/cited.

## When not

Treating RAG context as ground truth.

```text
Validate / cite / fail loud when empty
→ [[rag-retrieval-pressure]] · [[deterministic-before-probabilistic]]
```

## Related

- [[rag-retrieval-pressure]] · [[coding-agent-projection]]
