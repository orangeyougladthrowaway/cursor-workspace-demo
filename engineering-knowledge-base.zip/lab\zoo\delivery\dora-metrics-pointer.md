---
type: example
status: canonical
domain: [delivery]
derived_from:
  - "[[dora-metrics]]"
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Dora metrics pointer

## When

Talking change-lead-time / fail rate as delivery health signals.

## When not

Vanity dashboard without gate honesty.

```text
DORA metrics are outcome lenses — still need hard gates ([[delivery-gates]])
→ [[dora-metrics]] · [[dora-capabilities-index]]
```

## Related

- [[dora-metrics]] · [[dora-capabilities-index]] · [[delivery-ci]]
