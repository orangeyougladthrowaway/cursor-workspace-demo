---
type: example
status: canonical
domain: [helm]
derived_from:
  - "[[helm-deploy]]"
updated: 2026-07-15
---

# Values honesty

## When

Documenting which values are lab-only vs required for real deploy.

## When not

Hidden defaults that silently diverge Debug/lab from Release.

```yaml
# values.yaml — label lab-only knobs explicitly
replicaCount: 1  # lab default; set explicitly in prod values
```

## Related

- [[helm-deploy]] · [[compose-deploy]]
