variable "env" {
  type = string
}

resource "null_resource" "marker" {
  triggers = {
    env = var.env
  }
}

output "env" {
  value = var.env
}
