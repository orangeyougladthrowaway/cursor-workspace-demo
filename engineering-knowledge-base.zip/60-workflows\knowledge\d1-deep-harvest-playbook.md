---
type: workflow
status: canonical
id: engineering-knowledge-base-wf-004
concern: knowledge
description: Deep harvest playbook (D1 retro → D2+ / Axis F) — session vs program budgets, anti-shrink, fetch honesty, Stage G.
domain: []
aliases: [d1-retro, deep-playbook, d2-playbook, axis-f-playbook]
derived_from:
  - "[[knowledge-ingestion]]"
  - "[[ingest-coverage]]"
  - "[[post-capture-review]]"
  - "[[common-case-coverage]]"
updated: 2026-07-16
---

# D1 deep harvest playbook

Retro after theme-ordered D1 ([[roadmap]]). Binding for **D2+** residual deeps and **Axis F** source waves (F3) unless a later retro supersedes.

## Playbook

1. **Theme → primary source:** pick one leftover primary (or tight cluster). Prefer sources that **unblock [[common-case-coverage]] cells**. Fetch **primary pages** before claiming deep done — search snippets alone ≠ done.
2. **Amend-first:** elevate into existing theme homes under `maps/themes/`. Scaffold freeze stays **on** — no new empty stubs without orphan proof + [[navigation]] amend.
3. **Budgets:**
   - **Session (default):** ~≤60 claims · ≤8 amends · ≤2 new drafts per source session; prefer promote/thin over invent. Note overrides on [[roadmap]] / [[ingest-coverage]].
   - **Program (Axis F):** multi-session until track threshold — session caps do **not** redefine the destination bar ([[purpose]], [[common-case-coverage]]).
4. **Anti-shrink:** do not call a language/tool “done” because a zoo facet was seeded or a theme was skimmed. Score matrices.
5. **Collide + name models:** when remote pressure fights lived lab (e.g. OWASP vs gateway fall-open), write an explicit collision table and keep lab exceptions **named**.
6. **Twin cleanup on promote:** one living answer per question — thin duplicate spine paragraphs (especially [[coding-agent-projection]] dumps).
7. **Fetch honesty:** if HTML is body-poor (TotT blogs), cross-check via a second primary (SE@Google) and record corpus remains backlog — do not claim “source complete.”
8. **Depth labels:** `deep` on [[ingest-coverage]] only for harvested claims; leave **Untapped** sections explicit. Do not use `deep` to mean “theme touched.”
9. **Health:** run `pytest tests/ -v` after the wave; fix **manually** — no bulk auto-fix / note-generation scripts.
10. **Post-capture:** run [[post-capture-review]] before marking the wave `done`.
11. **Praxis:** zoo/skeletons use [[praxis-ingestion]] — separate session budgets; densify to G4; never mark doctrine `deep` from a zoo fill.

## Non-goals carried forward

- Course mirrors / Awesome claim dumps / 25-domain folder trees
- Promoting TotT corpus or unread book chapters as complete
- Unfreezing scaffold without orphan proof
- Quietly lowering majority coverage to “facet seeded”

## Related

- [[knowledge-ingestion]] · [[post-capture-review]] · [[vault-health-checks]] · [[roadmap]] · [[common-case-coverage]] · [[praxis-ingestion]]
