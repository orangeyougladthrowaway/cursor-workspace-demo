---
type: foundation
status: canonical
description: Starting engineering landscape — direction of travel; not elevated doctrine.
updated: 2026-07-15
---

# Starting landscape

Distilled from cross-repo inventories (gateway platforms, warehouse, trainer). **Reference map only.** Conflicts and soft practice are first-class. Promote into principles/standards/patterns only via normal altitude rules.

## Engineering families in play

| Family | Variants (informal) | Shape |
| --- | --- | --- |
| Service platform | K8s gateway family; Compose single-plane; Compose dual-plane | Gateway-first Python monorepo; envelope `/call`; credential bridges; YAML manifests/auth; WAL/observer; FastAPI+Pydantic |
| Data warehouse | SQL Server layered warehouse | SSDT multi-DB; Python→Staging; SQL owns transforms/SCD2; DACPAC release bundles; single-VM Compose |
| Local ML library | Local RL trainer family | Hydra config; Adapter+metadata routing; in-process PyTorch; no gateway |

Same owner, different topologies — engineering-knowledge-base must not force warehouse or RL into gateway law, or vice versa.

## Direction of travel (themes)

See family atlases: [[platform-atlas]] · [[warehouse-atlas]] · [[trainer-atlas]]. Themes: [[catalog-maps]].

Platform & boundaries · Change & config · Honesty & quality · Trust · Operability · Data/warehouse · ML/local train · Knowledge practice — as listed historically in inventories; elevate via living notes, not by growing this file.

## Explicit quarantine (never silent doctrine)

DigitalOcean / Spaces / DOKS / DO Inference as the only cloud model · product/demo taxonomies and provider schemas · self-signed TLS + shared basic auth · soft `|| true` CI · fall-open auth · silent `except` in ETL/LLM helpers · README “production-ready” ahead of tree · fat demo/script modules as architecture · nested zip layouts · unlimited gateway timeouts as platform law.

## Elevation status (2026-07-15)

Lived knowledge elevated into **canonical** responsibility notes under `50-guidance/` (+ patterns/standards), indexed by atlases:

| Family | Atlas |
| --- | --- |
| Platform | [[platform-atlas]] |
| Warehouse | [[warehouse-atlas]] |
| Trainer | [[trainer-atlas]] |

Harvest trees under `temp/replies/` are **not** user-facing doctrine (cleared after elevation). Agents: [[coding-agent-projection]].

1. Widen retrieval via atlases — do not cite this landscape as a standard.
2. Product/`host/` lore stays quarantine.
