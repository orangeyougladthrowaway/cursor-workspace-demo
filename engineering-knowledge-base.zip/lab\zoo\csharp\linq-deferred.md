---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-linq-api]]"
updated: 2026-07-15
---

# Linq deferred

## When

Composing query operators before a single execution.

## When not

Mutating the source between definition and enumeration and pretending results are stable.

```csharp
var q = items.Where(x => x > 0); // not executed yet
foreach (var x in q) { }         // executes here
```

## Related

- [[csharp-linq-api]]
