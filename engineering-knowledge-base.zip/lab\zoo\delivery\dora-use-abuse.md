---
type: example
status: canonical
domain: [delivery]
derived_from:
  - "[[dora-metrics]]"
updated: 2026-07-16
---

# Dora use abuse

## When

Using DORA metrics as outcome lenses for delivery health.

## When not

Vanity dashboards without hard gate honesty.

```text
Lead time / fail rate inform — they do not replace [[delivery-gates]]
```

## Related

- [[dora-metrics]] · [[dora-capabilities-index]]
