---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-core-concepts]]"
updated: 2026-07-16
---

# Relational types thin

## When

Choosing PG types for keys/text/time.

## When not

Overusing `text`/`varchar` without constraints when domain types exist.

```sql
-- Prefer timestamptz for instants; uuid/bigint for ids as contracted
-- See [[postgres-core-concepts]]
```

## Related

- [[postgres-core-concepts]] · [[postgres-sql-craft]]
