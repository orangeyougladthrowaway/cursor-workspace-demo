---
type: workflow
status: draft
id: engineering-knowledge-base-wf-010
concern: delivery
description: Implement an accepted engineering plan in small working slices under engineering-knowledge-base authority.
domain: ["cursor"]
derived_from:
  - "[[coding-agent-projection]]"
  - "[[plan-engineering-change]]"
  - "[[cohesive-code-units]]"
  - "[[readable-control-flow]]"
updated: 2026-07-17
---

# Build engineering change

Use after an accepted plan exists.

For engineering-knowledge-base doctrine or praxis changes, route to [[knowledge-ingestion]] or [[praxis-ingestion]].

## Preconditions

- Accepted outcome and scope
- Acceptance conditions
- Binding engineering-knowledge-base ids
- Verification path
- Required approvals obtained

## Retrieve

1. Reopen the plan and binding engineering-knowledge-base notes.
2. Retrieve stack guidance for each active slice ([[languages-atlas]] / family atlas as needed).
3. Inspect the closest implementation and tests.
4. Confirm the repository's local conventions and authority files (`AGENTS.md`).

## Steps

1. Implement one vertical slice at a time.
2. Keep responsibility boundaries and authority ownership explicit.
3. Reuse existing helpers and contracts before creating new abstractions.
4. Add or amend related tests with behaviour.
5. Keep the tree working after each slice.
6. Surface conflicts, scope expansion, or unexpected dependencies.
7. Stop and return to [[plan-engineering-change]] if acceptance or architecture materially changes.
8. Record what changed and which acceptance conditions it serves.

## Output

- Implemented slices
- Files changed
- Acceptance conditions addressed
- Binding engineering-knowledge-base ids applied
- Deviations or unresolved risks
- Tests added or changed

## Handoff

Pass the implementation and change evidence to [[verify-engineering-change]].

## Forbidden

- Silent scope expansion
- Drive-by cleanup
- Fallbacks that conceal failure ([[required-happy-path]], [[happy-path-only]])
- Weakening gates to complete the task
- Editing engineering-knowledge-base from a product consumer session

## Related

- [[coding-agent-projection]] · [[delivery-gates]] · [[tooling-proficiency]] · [[required-happy-path]]
