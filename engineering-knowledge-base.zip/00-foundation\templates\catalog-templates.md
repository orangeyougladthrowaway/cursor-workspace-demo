---
type: catalog
status: canonical
id: engineering-knowledge-base-cat-templates
description: Note starter templates + product-init copy-pack.
updated: 2026-07-16
---

# Catalog — Templates

| Template |
| --- |
| [[principle]] |
| [[category]] |
| [[standard]] |
| [[pattern]] |
| [[guidance]] |
| [[workflow]] |
| [[agents-projection]] |
| [[product-init]] |
