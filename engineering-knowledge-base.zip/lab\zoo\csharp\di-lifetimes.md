---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-async-di]]"
updated: 2026-07-15
---

# Di lifetimes

## When

Registering services with intentional Singleton / Scoped / Transient lifetimes.

## When not

Defaulting everything to Singleton because “reuse.”

```csharp
services.AddSingleton<IClock, SystemClock>();
services.AddScoped<IUnitOfWork, EfUnitOfWork>();
services.AddTransient<IValidator, OrderValidator>();
```

## Related

- [[csharp-async-di]]
