---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-concurrency-async]]"
updated: 2026-07-16
---

# Http client timeout

## When

Outbound HTTP from async Python with bounded waits **and** a cancel path.

## When not

Default/no timeout “until we see problems,” or Timeout config with no way to abort the wait.

```python
client = httpx.AsyncClient(timeout=httpx.Timeout(5.0, connect=2.0))

async def fetch(url: str) -> httpx.Response:
    # Caller must ensure this task can be cancelled (request scope / TaskGroup).
    return await client.get(url)
```

## Related

- [[python-concurrency-async]] · [[fail-loud-on-control-paths]]
