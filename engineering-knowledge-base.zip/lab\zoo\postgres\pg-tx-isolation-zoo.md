---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-wal-concurrency]]"
updated: 2026-07-16
---

# Pg tx isolation zoo

## When

Choosing READ COMMITTED vs stronger isolation for writes.

## When not

Serializing everything without a concurrency story.

```sql
BEGIN;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
-- Prefer documenting anomalies you accept ([[postgres-wal-concurrency]])
COMMIT;
```

## Related

- [[postgres-wal-concurrency]]
