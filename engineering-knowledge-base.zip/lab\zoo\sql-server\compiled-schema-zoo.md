---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[compiled-schema-release]]"
updated: 2026-07-16
---

# Compiled schema zoo

## When

Releasing schema as a compiled artefact (DACPAC/build).

## When not

Hand-running DDL scripts as the lived SoT.

```text
Build → DACPAC → SqlPackage publish ([[compiled-schema-release]])
```

## Related

- [[compiled-schema-release]] · [[dacpac-publish]]
