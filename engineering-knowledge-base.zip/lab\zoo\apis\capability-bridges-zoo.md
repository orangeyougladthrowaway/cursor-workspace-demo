---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[capability-bridges]]"
updated: 2026-07-16
---

# Capability bridges zoo

## When

Crossing to an external capability via a bridge.

## When not

Spreading vendor SDKs through domain modules.

```text
Capability bridge owns external I/O ([[capability-bridges]])
```

## Related

- [[capability-bridges]] · [[credential-owning-bridge]]
