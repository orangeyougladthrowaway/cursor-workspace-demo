---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[published-contract-stability]]"
updated: 2026-07-16
---

# Contract versioning thin

## When

Evolving published HTTP/OpenAPI contracts with many consumers.

## When not

Breaking fields without a version/compat story.

```text
Additive change preferred; version when breaking ([[published-contract-stability]])
```

## Related

- [[published-contract-stability]] · [[openapi-specification]]
