---
type: example
status: canonical
domain: [argo]
derived_from:
  - "[[in-process-orchestration]]"
updated: 2026-07-16
---

# In process orch zoo

## When

Orchestrating steps inside a service process.

## When not

Replacing domain procs with opaque in-process spaghetti without tests.

```text
In-process orchestration stays testable ([[in-process-orchestration]])
```

## Related

- [[in-process-orchestration]] · [[argo-workflows]]
