---
type: example
status: canonical
domain: [observability]
derived_from:
  - "[[dora-capabilities-index]]"
  - "[[metrics-tracing-logging-pressure]]"
updated: 2026-07-15
---

# Monitoring vs observability

## When

Distinguishing predefined dashboards from unknown-unknown exploration.

## When not

Equating `/metrics` scrape with full observability.

```text
monitoring ≠ observability
→ [[dora-capabilities-index]] · [[metrics-tracing-logging-pressure]]
```

## Related

- [[dora-capabilities-index]] · [[dora-metrics]] · [[metrics-tracing-logging-pressure]]
