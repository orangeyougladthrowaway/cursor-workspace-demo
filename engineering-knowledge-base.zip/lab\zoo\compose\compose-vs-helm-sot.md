---
type: example
status: canonical
domain: [compose]
derived_from:
  - "[[compose-deploy]]"
  - "[[helm-deploy]]"
updated: 2026-07-16
---

# Compose vs helm sot

## When

Choosing Compose for lab/local and Helm for cluster SoT.

## When not

Two conflicting “official” prod deploy paths.

```text
Lab/local → Compose profiles
Cluster SoT → Helm ([[helm-deploy]]) — one lived production path
```

## Related

- [[compose-deploy]] · [[helm-deploy]] · [[single-lived-source-of-truth]]
