---
type: guidance
status: canonical
id: engineering-knowledge-base-g-openapi
concern: apis
description: OpenAPI Description — Paths/components contract surface; not Envelope /call.
domain: []
aliases: [openapi, oas, swagger]
derived_from:
  - "[[honesty]]"
  - "[[boundaries]]"
  - "[[public-http-vs-internal-envelope]]"
  - "[[published-contract-stability]]"
updated: 2026-07-16
---

# OpenAPI specification

Primary (D1 #4 + D2 #7): [OpenAPI Specification 3.1](https://spec.openapis.org/oas/v3.1.0.html) — intro + Paths/Components structure.

## Applies when

Publishing or consuming **public** HTTP APIs (partner/edge).

## Does not apply when

- Documenting internal Envelope `/call` as if it were REST
- Dumping every internal DTO into `components` without a consumer

## House defaults

1. An **OpenAPI Description** formally describes API surface so consumers need minimal custom logic.
2. Document MUST contain at least one of: `paths`, `components`, or `webhooks`.
3. **Paths:** relative paths begin with `/`; concrete paths match before templated; identical templated hierarchies with different parameter *names* are invalid duplicates.
4. Path template expressions MUST have corresponding path parameters; values MUST NOT contain unescaped `/`, `?`, or `#`.
5. **Components** hold reusable schemas — they have **no effect** until referenced.
6. OAS is language-agnostic **HTTP** — it does **not** replace Envelope v1 internal `/call` ([[envelope-call]]).

### Minimal skeleton (house)

```yaml
openapi: 3.1.0
info: { title: Partner API, version: "1.0.0" }
paths:
  /items:
    get:
      responses:
        "200":
          description: OK
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/ItemList"
components:
  schemas:
    ItemList:
      type: object
      required: [items]
      properties:
        items:
          type: array
          items: { $ref: "#/components/schemas/Item" }
    Item:
      type: object
      required: [id]
      properties:
        id: { type: string, format: uuid }
```

## Collision

Dual dialects without a named product job are debt ([[public-http-vs-internal-envelope]]).

## Untapped

Full Operation/Parameter encyclopaedia · codegen · JSON Schema 2020-12 edge cases · webhooks deep.

## Related

- [[rest-resource-design]] · [[rest-resource-design-norm]] · [[apis-atlas]]
