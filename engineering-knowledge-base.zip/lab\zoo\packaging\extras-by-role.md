---
type: example
status: canonical
domain: [packaging]
derived_from:
  - "[[service-packaging]]"
updated: 2026-07-15
---

# Extras by role

## When

Declaring optional-dependencies per image/role.

## When not

One fat extra that installs the whole universe.

```toml
[project.optional-dependencies]
gateway = ["pyjwt"]
db = ["psycopg", "sqlalchemy"]
storage = ["boto3"]
```

## Related

- [[service-packaging]] · [[python-packaging-layout]]
