---
type: foundation
status: canonical
id: engineering-knowledge-base-lab-root
description: Praxis plane contract — zoo, skeletons, stubs subordinate to doctrine.
updated: 2026-07-15
---

# Praxis plane

**Praxis plane** under `lab/`. Exemplars that apply doctrine — not a second bible, not a curriculum.

| Asset | Path | Role |
| --- | --- | --- |
| Zoo | `lab/zoo/{facet}/` | Thin `type: example` idiom notes |
| Skeletons | `lab/skeletons/{name}/` | Copy-out starters + README |
| Stubs | `lab/stubs/{facet}/` | Tiny fragments |
| Index | [[lab-atlas]] · [[catalog-lab]] | Browse only |

**Law:** open a canon first; lab second. [[praxis-ingestion]] · [[dependency-rules]] · [[scope]].

**Facet allowlist:** python · csharp · sql-server · postgres · opentofu · docker · compose · helm · kubernetes · github-actions · apis · auth · observability · packaging · delivery · argo · agent · bash · **architecture**

Architecture facet holds **common boundary/decision** exemplars (prereqs, pipes, tradeoffs) — not a Fowler curriculum. Indexed with [[architecture-atlas]].

## Prove

| Layer | What proves it |
| --- | --- |
| Zoo / stubs / indexes | `pytest tests/lab` structural suite ([[vault-health-checks]]) |
| Doctrine remaining law | living notes — never zoo alone ([[dependency-rules]]) |
| Majority common cases | [[common-case-coverage]] matrix % (Axis F) — seed counts ≠ done |
| Runnable skeleton behaviour | **only** `lab/skeletons/python-src-pkg/` ships a unit test today; others are copy-out sketches until Honesty claims otherwise |

Workstreams (not doctrine): `temp/praxis-expansion/` (Axis P) · `temp/bible-full-coverage/` (Axis F).
