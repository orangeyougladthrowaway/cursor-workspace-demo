---
type: guidance
status: canonical
id: engineering-knowledge-base-g-owasp-mfa
concern: auth
description: OWASP MFA — independent factors, TOTP preferred over SMS; collide with mesh-only lived AuthN.
domain: []
aliases: [mfa, 2fa, totp, passkeys]
derived_from:
  - "[[owasp-authentication-pressure]]"
  - "[[gateway-auth]]"
updated: 2026-07-15
---

# OWASP multifactor authentication pressure

Primary (D2 #2): [OWASP Multifactor Authentication Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Multifactor_Authentication_Cheat_Sheet.html).

## Applies when

Human or admin identity edges (product login, privileged elevation, partner portals). Not when the product is service-mesh actors only — still document the absence.

## Guidance (claims elevated)

1. MFA = **independent** factors (know / have / are / …). Password + PIN alone is **not** MFA.
2. Assume passwords will leak; MFA is the primary defense against stuffing/spraying (sheet cites strong industry evidence).
3. Default starting posture: require some MFA; offer **TOTP**; require MFA for admins/high privilege; implement a **secure** MFA reset; consider MFA-as-a-service.
4. Require MFA at login **and** for sensitive actions (change password/email, disable MFA, elevate to admin). Cover **all** login paths (API/mobile too).
5. OTP hygiene: short TTL, single-use, attempt limits, invalidate on success; do **not** log OTP values or store long-term plaintext. Hashing OTPs is short-term exposure control — not password-strength offline resistance.
6. Prefer phishing-resistant options (WebAuthn/FIDO2/U2F/passkeys) where risk warrants. **SMS/PSTN OTP is restricted** (NIST): do not use for high-value/PII apps without documented risk acceptance + rate limits + migration plan to TOTP/push/WebAuthn.
7. Security questions are **not** an acceptable factor (NIST). Secure MFA recovery (multiple enrolled factors, backup codes carefully, trusted vouch) — reset paths are attack surfaces.
8. Factor change: re-auth with an enrolled factor; do not rely on session alone; out-of-band notify on MFA changes.

## Collision with lived gateway

| Sheet pressure | Lived ([[gateway-auth]]) |
| --- | --- |
| MFA for all / admins | Often **no** human password login — actor / optional JWT |
| TOTP / passkeys | Not present on Envelope `/call` |
| SMS restricted | N/A until an identity edge exists |

**Resolution:** MFA law binds **human-credential and admin surfaces**. Mesh-only lab stays under named threat model; claiming product AuthN without MFA (or documented accept) is a gap map entry, not compliance.

## Untapped

Forgot Password sheet · full factor catalogue deep · ASVS MFA controls · WebAuthn implementer guides.

## Related

- [[owasp-authentication-pressure]] · [[owasp-password-storage-pressure]] · [[owasp-top10-mapping]] · [[security-atlas]]
