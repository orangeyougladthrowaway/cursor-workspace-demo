---
type: pattern
status: draft
id: engineering-knowledge-base-pat-015
concern: delivery
description: "Pick-and-choose SQL product releases by merging selected feature tips into release/* cut from prod."
domain:
  - sql-server
aliases:
  - release-assembly
  - feature-tip-selection
derived_from:
  - "[[compiled-schema-release]]"
  - "[[single-lived-source-of-truth]]"
  - "[[fail-at-the-gate]]"
updated: 2026-07-20
---

# Sql env release assembly

Stack detail: [[sql-server-env-branches]] · [[schema-change-models]] · [[dacpac-publish]]. Atlas: [[warehouse-atlas]] · [[delivery-atlas]].

## Context

SQL Server product repos ship schema (and related code) to **persistent** DEV / UAT / PROD instances. Multiple features progress in parallel; not every integrated experiment should ship in the next train.

## Problem

If a shared integrate branch is the only release SoT, it clogs with work that is not release-ready. Cherry-picking commits out of that clog is fragile — especially under **state-based** sqlproj/dacpac publish, which applies a **whole tip**, not a commit list.

## Forces

- Need early integration / conflict detection without forcing every merge to ship
- Selectable unit must be reviewable and coherent (a feature, not random SHAs)
- UAT should prove an **assembled** candidate, then promote to prod
- Last shipped baseline must be an honest cut point (`prod`)
- Dual SoTs (clogged integrate tip **and** ad-hoc cherry-picks) confuse operators

## Solution

1. **Selectable unit** = approved **feature branch tip** (`feature/<name>`), not arbitrary commits on an integrate branch.
2. Cut **`release/<name>` from `prod`** (last shipped baseline).
3. **Merge** the chosen feature tips into that release branch (resolve conflicts on the release branch).
4. PR-promote: `release/*` → **`uat`** → deploy UAT → prove → **`prod`** → deploy PROD.
5. After ship: merge shipped result back into long-lived integrate/`dev` (if used) and refresh open feature branches from `prod`/`dev` so nothing stays based on stale prod forever.
6. Treat optional **`dev`** as an **integration sandbox** (early conflict detection / DEV instance), **not** the release membership SoT — membership is decided at release assembly.
7. Refuse **cherry-pick-from-clogged-dev as house law**. Emergency cherry-picks are explicit exceptions with residual risk named.
8. Schema publish remains [[compiled-schema-release]]: build/publish the **tip** that represents the assembled release (or the env branch tip after merge) — do not invent a second schema SoT.

## Consequences

**Easier:** Explicit pick-and-choose; UAT gates a real candidate; features stay reviewable units; aligns with dacpac whole-tip publish.

**Harder:** Feature branches live longer; release-time merge cost; discipline to sync features with `prod`/`dev` before assembly.

**Watch:**

- Merging unfinished features into `dev` and then treating `dev` as the release bag again (recreates the clog).
- Cutting `release/*` from `dev` while claiming pick-and-choose — that ships the clog.
- Assembling by cherry-pick SHA lists under sqlproj.
- Leaving release fixes only on `uat`/`prod` without back-merge to open work.

## Pattern statement

1. Release membership = merge selected **feature tips** into `release/*` cut from **`prod`**.
2. UAT proves that assembly; prod receives only promoted tips.
3. `dev` may integrate early but is not the pick-and-choose SoT.
4. Schema ships as compiled tip publish ([[compiled-schema-release]]), not commit archaeology.

## Related

- [[sql-server-env-branches]] · [[schema-change-models]] · [[compiled-schema-release]] · [[ssdt-publish-scripts]] · [[dacpac-publish]]
- [[delivery-gates]] · [[host-activation]] · [[warehouse-atlas]] · [[delivery-atlas]]
