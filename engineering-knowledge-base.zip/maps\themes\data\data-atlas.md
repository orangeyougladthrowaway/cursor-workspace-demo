---
type: map
status: canonical
id: engineering-knowledge-base-map-data
concern: data
description: Theme atlas — datastores, Kimball/dimensional, dbt/Airflow pointers, reliability storage.
domain: []
aliases: [postgres, kimball, dbt, ddia]
updated: 2026-07-20
---

# Atlas — Data

Datastores, warehouse modeling, ETL tool pressure, durable-storage themes. Index only.

## Canonical

- Kimball (D1 #6): [[kimball-type2-scd]] · [[kimball-scd-vocabulary]] · [[dimensional-modeling-kimball]]
- Grain / dim-fact house law: [[declare-the-grain]] · [[atomic-grain-first]] · [[warehouse-grain]] · [[grain-cardinality]] · [[scd2-dimension-envelope]] · [[snapshot-fact-shape]] · [[scd2-dim-snapshot-fact]] · [[warehouse-table-design]] · [[design-warehouse-tables]]
- Postgres (D2 #4 + L + Q): [[postgres-core-concepts]] · [[postgres-wal-concurrency]] · [[postgres-sql-craft]] · [[postgres-jsonb-craft]]
- Reliability (D2 #5): [[ddia-reliability-themes]] · [[durable-storage-tradeoffs]]
- Lived: [[warehouse-historisation]] · [[historisation-layers]] · [[dacpac-publish]] · [[ssdt-sqlproj]] · [[ssdt-publish-scripts]] · [[sql-server-craft-map]] · [[observer-wal]]

## Still thin / D2+

- [[dbt-transform-as-code]] · [[airflow-dag-orchestration]] (pointer drafts)
- DDIA **book chapters** (owned copy) · replication/partitioning deep

## Coverage

- Scoreboard: [[common-case-coverage]] (**F threshold met**; Axis Q deepens hot homes)

## Related

- [[catalog-maps]] · [[warehouse-atlas]] · [[architecture-atlas]] · [[common-case-coverage]]
