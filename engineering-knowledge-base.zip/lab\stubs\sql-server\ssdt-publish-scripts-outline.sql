-- SSDT PreDeploy / PostDeploy outline (lab stub) — not production-ready.
-- Canons: [[ssdt-publish-scripts]] · [[ssdt-sqlproj]] · [[dacpac-publish]]
-- Zoo: [[ssdt-publish-scripts-outline]]

/*
-- Script.PreDeployment.sql (sqlproj PreDeploy item; Build Action = Remove for fragments)
-- Plan is calculated BEFORE this runs.

:r .\Guards\AssertTargetDatabase.sql

-- Script.PostDeployment.sql
:r .\Seed\ReferenceMerge.sql

-- AssertTargetDatabase.sql (sketch)
-- IF DB_NAME() <> '$(TargetDatabaseName)' RAISERROR('Wrong database', 16, 1);

-- ReferenceMerge.sql — idempotent seed only; schema objects belong in the model
-- MERGE dbo.RefStatus AS t
-- USING (VALUES (1, N'Open'), (2, N'Closed')) AS s(Id, Name)
-- ON t.Id = s.Id
-- WHEN NOT MATCHED THEN INSERT (Id, Name) VALUES (s.Id, s.Name);
*/
