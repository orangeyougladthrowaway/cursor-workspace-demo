---
type: guidance
status: canonical
id: engineering-knowledge-base-g-kimball-types
concern: historisation
description: Kimball SCD types 0–7 vocabulary — Type 2 deep; others named for collision only.
domain: [warehouse]
aliases: [scd-types]
derived_from:
  - "[[kimball-type2-scd]]"
updated: 2026-07-20
---

# Kimball SCD vocabulary

## Applies when

Naming history strategies beyond lived Type 2.

## Guidance

1. Use Kimball type numbers as **shared vocabulary**, not as a mandate to implement every type.
2. Lived warehouse SoT is **Type 2** ([[kimball-type2-scd]], [[warehouse-historisation]]) with house envelope [[scd2-dimension-envelope]]. Facts stay snapshot-shaped ([[snapshot-fact-shape]]).
3. Other types (0 overwrite, 1 overwrite, 3 prior value, 4 mini-dimension, 6 hybrid, 7 dual) stay **named** until a D* Kimball pass elevates claims with collisions.

## Untapped

Per-type Kimball technique pages · Toolkit chapters.

## Related

- [[dimensional-modeling-kimball]] · [[scd2-dim-snapshot-fact]] · [[data-atlas]]
