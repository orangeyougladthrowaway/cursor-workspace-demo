---
type: guidance
status: canonical
id: engineering-knowledge-base-g-tf-state
concern: opentofu
description: Remote state + locking — Azure Blob and S3 backends; local state is a named lab exception.
domain: [opentofu, terraform]
aliases: [state, backends, azurerm, s3]
derived_from:
  - "[[host-opentofu]]"
updated: 2026-07-15
---

# Terraform state backends

Primary (D1 #7): [Terraform — Remote State](https://developer.hashicorp.com/terraform/language/state/remote).  
Product deeps: [azurerm](https://developer.hashicorp.com/terraform/language/settings/backends/azurerm) (D2 #10) · [s3](https://developer.hashicorp.com/terraform/language/settings/backends/s3) (D2 #15).

## Applies when

Multiple operators share a stack or CI runs plan/apply.

## Guidance

1. Default local `terraform.tfstate` fails teamwork — each runner needs latest state and exclusive apply.
2. Prefer a **remote backend** (S3, Azure Blob, GCS, HCP Terraform, etc.) so state is the shared SoT.
3. For fully featured backends, enable **state locking** to prevent concurrent applies against the same state.
4. Remote state can also **delegate outputs** to other configs (`terraform_remote_state`) — prefer deliberate stores when cross-team read-only share matters.
5. State often holds secrets — never commit plaintext state to VCS. Lab/local state is allowed only when [[threat-model-declaration]] / notes label it.

### Azure Blob (`azurerm`) — D2 #10

6. Backend writes state as a blob; configure at least `storage_account_name`, `container_name`, and blob `key`.
7. Supports **state locking and consistency checking** via Azure Blob native capabilities.
8. Auth via Microsoft Entra ID (preferred patterns) or access key (`access_key` / `ARM_ACCESS_KEY`) — treat keys as secrets; prefer identity-based auth in CI.
9. Optional management-plane lookup (`resource_group_name`, `lookup_blob_endpoint`) when data-plane URI cannot be inferred.

### Amazon S3 (`s3`) — D2 #15

10. State is an object at `bucket` + `key` (+ region). Non-default workspaces use `<workspace_key_prefix>/<workspace_name>/` (default prefix `env:`).
11. Enable **S3 Bucket Versioning** — recovery path for accidental deletion/human error.
12. Locking is **opt-in**: set `use_lockfile = true` for native S3 lockfile (`.tflock`). DynamoDB locking (`dynamodb_table`) is **deprecated** — migrate off; dual-config only for transition.
13. Minimum IAM for default workspace: `s3:ListBucket` on the bucket; `s3:GetObject`/`PutObject` on the state key. With lockfiles also `Get`/`Put`/`Delete` on `*.tflock`. Workspaces need broader object prefixes + delete on non-default workspace objects.
14. Prefer encryption at rest (`encrypt`, optional `kms_key_id` / SSE-C) — never leave state secrets unprotected in shared buckets.
15. Prefer **partial configuration** for credentials; `assume_role` / web-identity patterns for CI — avoid baking long-lived keys into committed backend blocks.

## Untapped

GCS · workspace strategy deep · state migration runbooks · full S3 argument encyclopaedia · OpenTofu deltas vs HashiCorp docs.

## Related

- [[terraform-modules-composition]] · [[host-opentofu]] · [[infrastructure-atlas]]
