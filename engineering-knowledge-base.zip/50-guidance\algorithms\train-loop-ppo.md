---
type: guidance
status: canonical
id: engineering-knowledge-base-g-algos
concern: algorithms
description: Accumulated PPO train-loop knowledge and unwired algo honesty.
domain: [pytorch]
aliases: [ppo, train_pve, train_pvp, retrievalppo]
updated: 2026-07-15
---

# Train loop PPO

Atlas: [[trainer-atlas]]. Config: [[hydra-config]]. Adapter: [[adapter-routing]].

## Wired path

`train_pve` / `train_pvp` construct **`PPO`** (`universal_trainer/algo/ppo.py`) after `build_model`.

`train_step`: single pass; GAE; clip; entropy; **no** multi-epoch / minibatch shuffle despite YAML keys.

## Present but unwired on default Hydra path

| Piece | Status |
| --- | --- |
| `RetrievalPPO` | never constructed by train_lib |
| Continual EMA/EWC | files/flags; not default path |
| PEFT essays / docs | discount |

GUI retrieval radio → model name flip only.

## Checkpoints / logging

`models/<save_prefix>_<ts>/`, best.pt on mean return; MetricsLogger tb/none (wandb soft).

## Quarantine

RetrievalPPO as lived default · PEFT lore · claiming masked PvP when collect path unmasked.

## Related

- [[hydra-config]] · [[adapter-routing]] · [[trainer-packaging]] · [[trainer-atlas]]
