---
type: example
status: canonical
domain: [bash]
derived_from:
  - "[[tooling-proficiency]]"
  - "[[delivery-ci]]"
updated: 2026-07-15
---

# Quote expansions

## When

Expanding variables that may contain spaces/paths.

## When not

Unquoted `$var` in scripts that must be deterministic.

```bash
path="$1"
cp -- "$path" "$dest/"
```

## Related

- [[tooling-proficiency]] · [[strict-shell-mode]]
