---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-style-conventions]]"
updated: 2026-07-15
---

# Fdg naming thin

## When

Reviewing public types/members for Framework Design Guidelines–style clarity.

## When not

Treating a naming nit as a substitute for behaviour/tests.

```csharp
// Prefer: Clear noun/verb names at API boundary
public interface IOrderStore { Task SaveAsync(Order order, CancellationToken ct); }

// Avoid vague: IManager / DoStuff / data1
```

## Related

- [[csharp-style-conventions]] · [[csharp-project-toolchain]]
