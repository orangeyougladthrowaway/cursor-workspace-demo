---
type: principle
status: canonical
id: engineering-knowledge-base-p-016
category: "[[proof]]"
description: Line coverage percentage is not a quality score — honesty seams matter more.
derived_from:
  - "[[proof]]"
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Coverage not quality

## Statement

High coverage can coexist with weak architecture proof. Coverage metrics are **diagnostic**, not **definition of done**. Over-ambitious %-goals waste effort on low-value edge cases (MS unit-testing guidance). Prefer hard gates on honesty seams ([[delivery-gates]]) over vanity line coverage.

## Rationale

D1 #2: Microsoft “Code coverage and code quality” section — measurement ≠ quality. SE@Google values coverage for **confidence to change**, but only via maintainable behaviour tests — brittle high-coverage suites destroy productivity (ch12 Mary scenario).

## Encourages

- Using coverage to find **untouched honesty seams**, then adding meaningful tests
- Rejecting “≥N%” marketing when the gate is soft/absent

## Prevents

- Coverage theatre as Done
- Expanding coverage by testing implementation trivia ([[tott-culture]])

## Related

- [[unit-testing-norm]] · [[prove-honesty-contracts-in-delivery]] · [[delivery-atlas]]
