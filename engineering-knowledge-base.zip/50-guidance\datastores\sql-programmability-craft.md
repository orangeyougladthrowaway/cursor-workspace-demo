---
type: guidance
status: canonical
id: engineering-knowledge-base-g-sql-programmability
concern: datastores
description: How to build and maintain views, procedures, functions, and triggers in house SQL projects.
domain: [sql-server, t-sql]
aliases: [stored-proc-craft, views-triggers]
derived_from:
  - "[[sql-code-structure]]"
  - "[[sql-flow-choices]]"
  - "[[tsql-batch-craft]]"
  - "[[ssdt-sqlproj]]"
updated: 2026-07-20
---

# Sql programmability craft

Systems: programmability object kinds. Eng: **which object, how structured, how deployed**.

## Choose

| Need | Prefer | Avoid |
| --- | --- | --- |
| Stable read projection | view | Proc that only `SELECT` without side-effect boundary need |
| Expensive stable projection | indexed view **with** refresh/ownership plan | Accidental schemabinding theatre |
| Command / ETL step | procedure ([[tsql-batch-craft]]) | Trigger chains as orchestration |
| Set-returning calc | inline TVF when possible | Scalar UDF in hot set joins without measure |
| Enforce side effect on base write | trigger only when constraint/app cannot | Business orchestration in triggers |

## Build

1. One deployable object ≈ one file in sqlproj ([[sql-code-structure]]).
2. Proc reading order: params → settings → guards → transaction ownership → set-based body → output → errors.
3. Keep transaction ownership at one layer — callees must not silently commit caller work.
4. Triggers: document locking/logging impact; keep short; no cross-DB hop theatre.

## Maintain

- Change body in model; compile dacpac; publish with tier-safe profile.
- Permission changes: model principals or idempotent PostDeploy ([[ssdt-publish-scripts]]) — pick one SoT.
- Plan-check after signature/index changes on hot load procs ([[sql-index-plan-craft]]).

## Related

- [[historisation-layers]] · [[tsql-set-based-merge]] · [[sql-server-craft-map]]
