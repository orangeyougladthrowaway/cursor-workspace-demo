---
type: example
status: canonical
domain: [sql-server, ssis]
derived_from:
  - "[[ssis-dtproj-dtsx]]"
  - "[[historisation-layers]]"
updated: 2026-07-20
---

# Ssis dtproj outline

## When

Naming SSIS artefacts vs sqlproj/dacpac.

## When not

Using SSIS as a second SCD2 SoT beside StageToODS without ownership.

```text
.dtproj (project) + .dtsx (packages) → build → .ispac → SSISDB catalog
sqlproj → dacpac remains schema SoT for warehouse DBs
```

## Related

- [[ssis-dtproj-dtsx]] · [[ssdt-sqlproj]] · [[sql-server-craft-map]]
