---
type: workflow
status: draft
id: engineering-knowledge-base-wf-011
concern: testing
description: Verify an engineering change with the smallest hard gates that prove its acceptance conditions.
domain: ["cursor"]
derived_from:
  - "[[coding-agent-projection]]"
  - "[[delivery-gates]]"
  - "[[unit-testing-norm]]"
  - "[[prove-honesty-contracts-in-delivery]]"
updated: 2026-07-17
---

# Verify engineering change

Use after implementation and before review.

For engineering-knowledge-base vault changes, also follow [[vault-health-checks]].

## Preconditions

- Acceptance conditions
- Implemented change
- Identified verification commands or runtime evidence

If no credible proof can be defined, return to [[plan-engineering-change]].

## Retrieve

1. Open [[delivery-gates]] (and [[delivery-ci]] when CI claims are involved).
2. Retrieve stack-specific testing and toolchain guidance.
3. Open the closest relevant tests and CI configuration.
4. For defects, identify or create a failing reproduction where practical.

## Steps

1. Map each acceptance condition to evidence.
2. Run the narrowest test that proves changed behaviour.
3. Run lint, type, contract, integration, or runtime gates where the claim requires them.
4. Distinguish test failure, environment failure, and missing evidence.
5. Fix failures and rerun; never soften the gate.
6. Check changed behaviour for relevant negative and boundary cases.
7. Record exact commands and terminal outcomes.
8. Mark unverified conditions explicitly.

## Output

- Acceptance-to-evidence mapping
- Commands and results
- Failures encountered and resolutions
- Unverified conditions
- Residual risks
- Verification verdict: pass, fail, or blocked

## Handoff

Only a passing or explicitly qualified result proceeds to [[review-engineering-change]].

## Forbidden

- “Seems correct” as proof
- Test counts as quality ([[coverage-not-quality]])
- `continue-on-error` or ignored failures
- Broad suites when a smaller sufficient gate exists
- Claiming success when the environment prevented proof

## Related

- [[coding-agent-projection]] · [[build-engineering-change]] · [[vault-health-checks]]
