---
type: example
status: canonical
domain: [compose]
derived_from:
  - "[[compose-deploy]]"
  - "[[service-packaging]]"
updated: 2026-07-15
---

# Service slice

## When

Minimal service block for local Compose.

## When not

Inventing a second “official” deploy SoT next to Helm/host notes.

```yaml
services:
  api:
    build: .
    ports:
      - "8080:8080"
```

## Related

- [[compose-deploy]] · [[helm-deploy]]
