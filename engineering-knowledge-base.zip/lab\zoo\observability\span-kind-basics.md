---
type: example
status: canonical
domain: [observability]
derived_from:
  - "[[metrics-tracing-logging-pressure]]"
updated: 2026-07-15
---

# Span kind basics

## When

Labeling spans with correct kind (server/client/internal/producer/consumer).

## When not

Everything as INTERNAL with no parent/child honesty.

```text
HTTP server → SERVER; outbound call → CLIENT; messaging → PRODUCER/CONSUMER
```

## Related

- [[metrics-tracing-logging-pressure]]
