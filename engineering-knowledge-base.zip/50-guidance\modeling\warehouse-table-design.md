---
type: guidance
status: canonical
id: engineering-knowledge-base-g-warehouse-table-design
concern: modeling
description: How to design warehouse dims/facts from grain and cardinality through column lists.
domain: [warehouse, sql-server]
derived_from:
  - "[[warehouse-grain]]"
  - "[[scd2-dim-snapshot-fact]]"
  - "[[grain-cardinality]]"
updated: 2026-07-20
---

# Warehouse table design

## Applies when

Designing or reviewing DWH dim/fact/bridge tables fed from SCD2 ODS (or equivalent).

## Guidance

1. **List entities and relationships** in scope (warranted).  
2. **Run cardinality test** for every pair ([[grain-cardinality]]).  
3. **Declare grains** (atomic first) — one sentence each ([[declare-the-grain]]).  
4. **For each grain:** choose dim vs fact vs bridge; apply [[scd2-dimension-envelope]] to dims; [[snapshot-fact-shape]] to facts.  
5. **Column list Ready only when** L12 on [[warehouse-grain]] passes.  
6. **Load path:** Stage → ODS SCD2 merge (write SoT) → DWH: sync dims with SCD2 envelope; truncate+reload snapshot facts. Name each fact’s join policy (current vs as-was) separately from dim retention ([[historisation-layers]]).  
7. **Do not** invent SoR fields — escalate systems-KB / user.

## Done test

Grain sentences · grain keys · cardinality matrix · dim envelope · fact `created_at` + surrogate FKs · join policy named · Gaps listed.

## Related

- Workflow [[design-warehouse-tables]] · [[dimensional-modeling-kimball]] · zoo [[dim-scd2-fact-snapshot-outline]]
