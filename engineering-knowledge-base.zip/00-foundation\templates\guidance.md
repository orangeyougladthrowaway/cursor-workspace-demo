---
type: template
status: canonical
description: Starter template for guidance notes.
updated: 2026-07-14
---

# Template — Guidance

```markdown
---
type: guidance
status: draft
id: engineering-knowledge-base-g-NNN
concern: contracts
description: ""
domain: []
aliases: []
derived_from: []
updated: YYYY-MM-DD
---

# Guidance title

## Applies when

## Does not apply when

## Guidance

## Derivation

## Related
```

Path: `50-guidance/{concept}/{slug}.md`. See [[navigation]].
