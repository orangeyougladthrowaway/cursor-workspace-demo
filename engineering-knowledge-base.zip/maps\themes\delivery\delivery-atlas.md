---
type: map
status: canonical
id: engineering-knowledge-base-map-delivery
concern: delivery
description: Theme atlas — testing craft, gates, DORA, review norms.
domain: []
aliases: [testing, ci, dora]
updated: 2026-07-19
---

# Atlas — Delivery

Testing, CI honesty, review culture, and delivery metrics. Index only.

## Living notes

- [[code-review-norm]] · [[unit-testing-norm]] · [[coverage-not-quality]] — **canonical** (D1 craft + D1 #2)
- [[unit-test-fast-isolated]] · [[tott-culture]] — **canonical** (D1 #2 + **D2 #3** sample = 7 TotT URLs)
- [[delivery-gates]] · [[delivery-ci]] · [[prove-honesty-contracts]] · [[prove-honesty-contracts-in-delivery]] — canonical
- Failure honesty adjacency: [[required-happy-path]] · [[happy-path-only]] · [[fail-at-the-gate]]
- [[dora-metrics]] · [[dora-capabilities-index]] — **canonical**
- [[pytest-practices]] — **canonical** (D2 #14)
- SE@Google CI pressure landed in [[delivery-gates]] §12–15 (D2 #16)
- Packaging honesty (adjacency): [[service-packaging]] · [[docker-containers]] — registry image is the app-change unit on host Compose ([[compose-deploy]])
- SQL Server product env promotion (adjacency): [[sql-env-release-assembly]] · [[sql-server-env-branches]] · [[schema-change-models]] — warehouse atlas owns depth
- Agent lifecycle workflows: [[plan-engineering-change]] · [[build-engineering-change]] · [[verify-engineering-change]] · [[review-engineering-change]] (draft; skills `engineering-knowledge-base-*`)

## Honest skips / backlog

TotT **full** archive · hermetic-testing deep · individual DORA capability articles · Eng Practices speed page · CD chapter.

## Related

- [[catalog-maps]] · [[platform-atlas]] · [[observability-atlas]] · [[infrastructure-atlas]] · [[engineering-craft-atlas]] · [[agent-engineering-atlas]]
