---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-typing-honesty]]"
updated: 2026-07-15
---

# Protocol boundary

## When

Structural typing at a boundary without forcing inheritance.

## When not

Claiming Protocols while callers still `Any`-pass everywhere.

```python
from typing import Protocol

class Greeter(Protocol):
    def greet(self, name: str) -> str: ...

def shout(g: Greeter, name: str) -> str:
    return g.greet(name).upper()
```

## Related

- [[python-typing-honesty]]
