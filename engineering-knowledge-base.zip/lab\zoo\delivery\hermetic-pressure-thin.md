---
type: example
status: canonical
domain: [delivery]
derived_from:
  - "[[delivery-gates]]"
  - "[[unit-testing-norm]]"
updated: 2026-07-16
---

# Hermetic pressure thin

## When

Preferring hermetic/reproducible proof for integration-class checks.

## When not

Flaky shared-env green as “proven.”

```text
Name size: unit (hermetic) vs integration (declared deps)
Hermetic depth remains Untapped on [[delivery-gates]] — still prefer honesty over theatre
```

## Related

- [[delivery-gates]] · [[unit-test-fast-isolated]] · [[prove-honesty-contracts]]
