---
type: standard
status: canonical
id: engineering-knowledge-base-s-016
concern: languages
description: Control flow exposes decisions and side effects; choose the simplest construct that preserves intent.
domain: []
aliases: [branching, guards, loops]
derived_from:
  - "[[honesty]]"
  - "[[failure]]"
  - "[[restraint]]"
  - "[[programming-over-time]]"
updated: 2026-07-16
---

# Readable control flow

## Requirement

Control flow must make the normal path, exceptional paths, and side effects evident without mentally executing clever syntax.

Normally:

1. Validate preconditions and fail-loud conditions near the boundary; use an early guard when it removes nesting.
2. Keep the principal operation visually continuous. Put uncommon failure/absence exits before it when that improves scanning.
3. Prefer positive conditions, but use a negative guard when it states the rejected case directly.
4. Use a transformation expression only while it remains a pure, readable transformation. Use an explicit loop or statement when state, branching, early exit, retries, or side effects matter.
5. Avoid boolean flag parameters that make callers select hidden control-flow modes; prefer named operations or explicit policy types.
6. Do not introduce async, parallel, vectorised, or functional forms merely because they are available. Choose them for a named workload or semantic advantage.
7. Flatten incidental nesting; do not flatten code when doing so separates a resource, transaction, or invariant from its owner.

## Decision test

Choose the construct that best answers:

- Is this a pure mapping/filtering operation or a stateful process?
- Must it stop early, retry, mutate, log, or own a resource?
- Is concurrency required, and is the work I/O-bound or CPU-bound?
- Does the branch describe invalid input, expected absence, or a normal business alternative?
- Will the next reader see the same decision without reconstructing hidden evaluation order?

## Rationale

Explicit control flow is an honesty contract. Dense expressions can conceal failure, ordering, resource ownership, and performance costs.

## Exceptions

Hot paths may use less direct constructs after measurement and with focused tests. Domain algorithms may require nested structure that mirrors the problem; explain the invariant rather than mechanically flattening it.

## Related

- [[cohesive-code-units]] · [[fail-loud-on-control-paths]] · [[happy-path-only]] · [[code-review-norm]] · [[languages-atlas]]
