---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[envelope-call]]"
updated: 2026-07-16
---

# Envelope call zoo

## When

Internal calls use Envelope as the platform shape.

## When not

Leaking Envelope to public HTTP clients.

```text
Internal Envelope ↔ public HTTP split ([[public-http-vs-internal-envelope]])
```

## Related

- [[envelope-call]] · [[public-http-vs-internal-envelope]]
