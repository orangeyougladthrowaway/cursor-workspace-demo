---
type: example
status: canonical
domain: [architecture]
derived_from:
  - "[[microservices-tradeoffs]]"
  - "[[modular-monolith-default]]"
updated: 2026-07-16
---

# Modular monolith default zoo

## When

Defaulting to a modular monolith until prerequisites for split are met.

## When not

Microservices-by-fashion.

```text
Default modular monolith ([[modular-monolith-default]]) until [[microservice-prerequisites]]
```

## Related

- [[modular-monolith-default]] · [[microservices-tradeoffs]]
