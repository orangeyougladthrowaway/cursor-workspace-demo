---
type: principle
status: canonical
id: engineering-knowledge-base-p-023
category: modeling
description: Declare fact/association grain before choosing dimensions, measures, or DDL columns.
derived_from:
  - "[[modeling]]"
  - "[[deterministic-before-probabilistic]]"
updated: 2026-07-20
---

# Declare the grain

## Statement

Before designing a warehouse fact, bridge, or serving dim load, **declare the grain** as a business sentence: what one row represents. Every column must be **true to that grain**. Mixing grains in one table is forbidden.

## Rationale

Grain is the binding contract of dimensional design (Kimball). Vague grain produces wrong joins, double-counted measures, and SCD2 keys pointed at the wrong version.

Remote pressure: [Kimball — Grain](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/grain/) · [Declaring the Grain](https://www.kimballgroup.com/2003/03/declaring-the-grain/).

## Encourages

- Written grain sentence before FK/measure lists
- Cardinality test on relationships ([[grain-cardinality]])
- One physical table per declared grain

## Prevents

- “Sales by day and by line” in one fact
- Stuffing M:N into a fact without a bridge
- Natural-key-only joins across SCD2 history

## Related

- [[atomic-grain-first]] · [[warehouse-grain]] · [[dimensional-modeling-kimball]] · [[design-warehouse-tables]]
