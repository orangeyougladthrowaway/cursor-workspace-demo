---
type: standard
status: canonical
aliases: ["docs-authority"]
domain: []
concern: authority
id: engineering-knowledge-base-s-001
description: One authoritative home per concept; update it in the same change as behaviour; READMEs point only.
derived_from:
  - "[[colocated-authority]]"
  - "[[policy-as-explicit-artefact]]"
updated: 2026-07-13
---

# Single authority for documentation

## Requirement

1. Each engineering concept or public contract has **exactly one** authoritative note (or generated artefact) that defines current meaning.
2. When behaviour or a public contract changes, that authority is updated in the **same change** (same PR/commit set).
3. Entry points (README, hub pages, comments) **link**; they must not restate or fork the authoritative meaning.
4. Prefer short notes and links over duplicated explanation. If two notes disagree, fix authority and demote or remove the duplicate — do not leave both as current.

## Derived from

- [[colocated-authority]]
- [[policy-as-explicit-artefact]]
- Category: [[authority]]

## Rationale

Lagging or parallel docs teach false confidence to humans and agents. One home makes review and retrieval deterministic.

## Exceptions

- Transient migration notes clearly marked non-authoritative and time-bounded.
- Generated docs may be the authority when the generator + source artefacts are the controlled inputs (declare which is authoritative).
- Vendor manuals are references, never local authority for *our* decisions.

## Related

- [[methodology]]
- [[prove-honesty-contracts-in-delivery]]
- [[threat-model-declaration]]
