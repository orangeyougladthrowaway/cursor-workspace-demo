---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[policy-ingress-contract]]"
updated: 2026-07-16
---

# Policy ingress zoo

## When

Ingress/policy manifests must match declared contracts.

## When not

Drifting ingress annotations as the silent SoT.

```text
Policy-as-artefact at ingress ([[policy-ingress-contract]])
```

## Related

- [[policy-ingress-contract]] · [[policy-as-artefact]]
