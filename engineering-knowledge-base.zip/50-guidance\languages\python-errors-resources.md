---
type: guidance
status: canonical
id: engineering-knowledge-base-g-py-err
concern: languages
description: Python errors and resources — raise loud; no bare except; pathlib; context managers for ownership.
domain: [python]
aliases: [exceptions, context-managers]
derived_from:
  - "[[python-ingest]]"
  - "[[failure]]"
updated: 2026-07-16
---

# Python errors resources

Primary (L-py #3): [Python tutorial — Errors and Exceptions](https://docs.python.org/3/tutorial/errors.html).  
Paths: [pathlib](https://docs.python.org/3/library/pathlib.html).

## Applies when

Writing Python control flow, I/O, or job loops (esp. ingest/workers).

## Guidance

1. Separate **syntax errors** (must fix before run) from **exceptions** (runtime). Handle only what you can meaningfully recover from.
2. Prefer **specific** `except` types. Bare `except:` / `except Exception: pass` swallows bugs and KeyboardInterrupt paths — **forbidden as house virtue** (matches [[scope]] quarantine).
3. Use `else` on try for code that runs only when no exception occurred; `finally` for unconditional cleanup.
4. Prefer **context managers** (`with`) for files, locks, connections — ownership and cleanup stay local. `ExitStack` when resource count is dynamic.
5. Re-raise with context (`raise … from err`) when wrapping; do not invent empty `except` “for resilience” in staging loops.
6. Soft partial-success jobs (ingest) must **surface** failure (non-zero exit, metrics, logs) — silent continue is a named anti-pattern ([[python-ingest]]).
7. Prefer **`pathlib.Path`** for path composition and existence checks; open files with `with path.open(...)` — stringy path glue is a common foot-gun.

## Collision with lived

Provider soft skips and bare `except` in stage loops — quarantine; do not elevate as craft.

## Untapped

Exception groups (3.11+) deep · `contextlib` recipes · asyncio cancellation errors (see [[python-concurrency-async]]).

## Related

- [[python-ingest]] · [[python-concurrency-async]] · [[python-logging-modeling]] · [[languages-atlas]] · [[fail-loud-on-control-paths]]
