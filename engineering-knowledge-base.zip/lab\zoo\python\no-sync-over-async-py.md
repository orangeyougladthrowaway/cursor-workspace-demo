---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-concurrency-async]]"
updated: 2026-07-15
---

# No sync over async py

## When

Calling async from async (or dedicated runner) paths.

## When not

`asyncio.run` inside already-running loops / blocking `.result()` habits.

```python
# Prefer: await fetch()
# ANTI: loop.run_until_complete inside request handlers that are already async
```

## Related

- [[python-concurrency-async]] · [[csharp-async-di]]
