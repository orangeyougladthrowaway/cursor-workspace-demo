---
type: example
status: canonical
domain: [argo]
derived_from:
  - "[[dbt-transform-as-code]]"
updated: 2026-07-16
---

# Dbt pointer zoo

## When

dbt is considered for transforms.

## When not

Duplicating SCD2/historisation law into dbt-only folklore.

```text
Pointer: [[dbt-transform-as-code]] — collide with [[warehouse-historisation]]
```

## Related

- [[dbt-transform-as-code]] · [[warehouse-historisation]]
