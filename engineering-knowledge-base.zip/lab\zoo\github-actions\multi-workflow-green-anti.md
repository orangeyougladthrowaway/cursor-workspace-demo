---
type: example
status: canonical
domain: [github-actions]
derived_from:
  - "[[delivery-ci]]"
updated: 2026-07-16
---

# Multi workflow green anti

## When

Multiple workflows can paint green independently.

## When not

Shipping on any-one-green when required gates live elsewhere.

```yaml
# Document which workflow is the SoT gate for merge
# ANTI: lint.yml green while unit.yml skipped / failing elsewhere
```

## Related

- [[delivery-ci]] · [[delivery-gates]] · [[single-lived-source-of-truth]]
