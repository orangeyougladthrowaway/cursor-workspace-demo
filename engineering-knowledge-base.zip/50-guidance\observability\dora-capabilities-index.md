---
type: guidance
status: canonical
id: engineering-knowledge-base-g-dora-cap
concern: observability
description: DORA capability catalog — index + monitoring/observability capability pressure (not Goodhart gates).
domain: []
aliases: [dora, capabilities, monitoring-observability]
derived_from:
  - "[[dora-metrics]]"
  - "[[metrics-tracing-logging-pressure]]"
updated: 2026-07-15
---

# DORA capabilities index

Primary (D2 #12): [DORA Capability catalog](https://dora.dev/capabilities/) + [Monitoring and observability](https://dora.dev/capabilities/monitoring-and-observability/).

## Applies when

Planning delivery/ops improvement beyond the five metrics ([[dora-metrics]]).

## Guidance

1. DORA lists **capabilities** (CI/CD, trunk-based, test automation, monitoring/observability, culture, …) that correlate with performance — they are **improvement levers**, not merge gates by default ([[delivery-gates]]).
2. **Monitoring** = watch predefined metrics/logs. **Observability** = debug via exploring properties **not** defined in advance (unknown unknowns) — aligns with OTEL primer ([[metrics-tracing-logging-pressure]]).
3. Good solutions need: system health + **customer-experienced** state, business/system metrics, production debug tooling, cross-service diagnosis.
4. Prefer **symptom-based** alerting over enumerating every cause; track MTTD/MTTR; avoid dedicated-only “monitoring team” / email-blast alert fatigue.
5. Instrument code; treat monitoring config as reviewed/versioned (like code). Cap cardinality when recording high-dimension metrics.
6. Core catalog anchors for this vault: continuous delivery/integration, test automation, version control, working in small batches, documentation quality, loosely coupled teams, pervasive security — each deep-fetchable later.

## Untapped

Individual capability articles (CI, CD, trunk-based, …) · “How to Transform” guide · Accelerate book.

## Related

- [[dora-metrics]] · [[metrics-tracing-logging-pressure]] · [[delivery-gates]] · [[observability-atlas]]
