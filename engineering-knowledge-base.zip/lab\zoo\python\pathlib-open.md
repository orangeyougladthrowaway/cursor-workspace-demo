---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-errors-resources]]"
updated: 2026-07-16
---

# Pathlib open

## When

Composing filesystem paths and reading files.

## When not

Building paths with raw string concatenation across OSes.

```python
from pathlib import Path

path = Path("data") / "input.json"
with path.open(encoding="utf-8") as handle:
    text = handle.read()
```

## Related

- [[python-errors-resources]] · [[failure]]
