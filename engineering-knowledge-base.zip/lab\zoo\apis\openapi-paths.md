---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[openapi-specification]]"
updated: 2026-07-15
---

# Openapi paths

## When

Paths and components are the public contract spine.

## When not

Implementation drift without Spec update.

```yaml
paths:
  /items/{id}:
    get:
      operationId: getItem
      parameters:
        - name: id
          in: path
          required: true
          schema:
            type: string
```

## Related

- [[openapi-specification]] · [[rest-resource-design]]
