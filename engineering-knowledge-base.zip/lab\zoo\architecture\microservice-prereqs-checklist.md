---
type: example
status: canonical
domain: [architecture]
derived_from:
  - "[[microservice-prerequisites]]"
updated: 2026-07-16
---

# Microservice prereqs checklist

## When

Deciding whether to split a modular monolith into services.

## When not

Defaulting to microservices without CI/CD, monitoring, and ownership maturity.

```text
Before split: automated delivery, observability, clear boundaries, on-call ownership
See [[microservice-prerequisites]] — not a “services by default” rule
```

## Related

- [[microservice-prerequisites]] · [[microservices-tradeoffs]] · [[smart-endpoints-dumb-pipes-contrast]]
