---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-014
concern: historisation
description: SCD2 dims with envelope columns; snapshot facts with created_at and surrogate FK at same grain.
domain: [warehouse, sql-server]
derived_from:
  - "[[scd2-dimension-envelope]]"
  - "[[snapshot-fact-shape]]"
  - "[[historisation-layers]]"
  - "[[declare-the-grain]]"
updated: 2026-07-20
---

# Scd2 dim snapshot fact

## Context

House Staging → ODS (SCD2 merge SoT) → DWH serving. Dims mirror SCD2 for joins; facts stay snapshots — DWH must not run a second Type-2 merge.

## Problem

Copying SCD2 columns onto facts, or joining facts to natural keys across versions, corrupts history and grain.

## Solution

```text
ODS / Dim (SCD2)
  surrogate_key PK
  business_key
  attributes…
  effective_from, effective_to
  is_current, is_deleted, row_hash

Fact (snapshot)
  fact_key optional
  grain keys / degenerates
  dim_surrogate_fk  →  dim at same grain (+ as-of policy)
  created_at (datetime)
  measures…
```

1. Maintain dims with Type-2 envelope ([[scd2-dimension-envelope]]); merge rules [[historisation-layers]].  
2. Rebuild or insert **facts** as snapshots: `created_at` + surrogate FK(s) true to [[warehouse-grain]].  
3. Default serving: load facts against **current** dim rows after ODS current filter.  
4. As-was: resolve surrogate valid at event/`created_at`.  
5. Bridges for M:N at association grain ([[grain-cardinality]]).

## Consequences

**Easier:** clear history ownership in ODS/dims; simple mart facts.  
**Harder:** as-was requires careful point-in-time join.  
**Watch:** fact DDL that mirrors full SCD2 envelope — schema theatre ([[historisation-layers]]).

## Related

- [[snapshot-fact-shape]] · [[warehouse-historisation]] · lab [[dim-scd2-fact-snapshot-outline]]
