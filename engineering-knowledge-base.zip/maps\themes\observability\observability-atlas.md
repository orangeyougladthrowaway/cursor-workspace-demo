---
type: map
status: canonical
id: engineering-knowledge-base-map-observability
concern: observability
description: Theme atlas — metrics, tracing, logging, DORA capabilities beyond gate honesty.
domain: []
aliases: [metrics, tracing, logging, otel]
updated: 2026-07-19
---

# Atlas — Observability

Operability and measurement pressure beyond CI gate honesty. Index only.

## Canonical (D1 #9 + D2 #11–#12)

- [[metrics-tracing-logging-pressure]] · [[dora-metrics]] · [[dora-capabilities-index]]
- Lived: [[delivery-gates]] · [[envelope-call]] · [[service-packaging]]

**Navigation tip:** practiced multi-hop `/call` failure diagnosis (correlate `trace_id` / service / method across gateway + leaf) lives on [[envelope-call]] — do not wait for full OTEL Collector wiring. Secret/env misfires that look like opaque 500s: [[compose-deploy]] · [[credential-owning-bridge]].

## Deep backlog (D2+)

OTEL logs/Collector · individual DORA capability articles · SRE books · Osmani observability skill.

## Related

- [[catalog-maps]] · [[delivery-atlas]] · [[platform-atlas]] · [[infrastructure-atlas]] · [[security-atlas]]
