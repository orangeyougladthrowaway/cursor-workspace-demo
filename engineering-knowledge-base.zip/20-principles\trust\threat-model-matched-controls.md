---
type: principle
status: canonical
description: Match security controls to the declared threat model; avoid theatre and accidental exposure alike.
id: engineering-knowledge-base-p-009
category: "[[trust]]"
derived_from:
  - "[[trust]]"
  - "[[ownership]]"
updated: 2026-07-17
---

# Threat-model matched controls

## Statement

Security controls must match an explicit threat model for the deployment. Do not fake production posture in demos, and do not leave privileged surfaces ambiently reachable when the model says otherwise. Fall-open AuthZ plus network containment is a **lab control pair** only when the model says so — not a silent substitute for enforced RBAC ([[threat-model-declaration]], [[gateway-auth]]). Silent soft recovery that hides missing controls is forbidden under [[happy-path-only]].

## Rationale

Theatre creates false confidence. Missing allow-lists and fall-open auth create real risk. Honesty about scope is part of security.

## Encourages

- Written threat model; minimal public surface; enumerated trust (allow-lists, private defaults)
- Naming AuthZ theatre (`auth.yaml` unused on hot path) instead of claiming matrices
- Separating **AuthN, AuthZ, and session/token** concerns — do not treat gateway actor strings or JWT-off meshes as access control ([[gateway-auth]])
- Mapping declared controls to named external risk themes when useful (e.g. OWASP A01/A07) without importing a full AppSec programme as doctrine

## Prevents

- Copying demo TLS/auth choices into production doctrine
- “Authenticated means authorized”
- Shared secret sprawl described as least privilege ([[credential-owning-bridge]])
- “OWASP compliant” marketing without threat-model match

## Evidence (thin)

Explicit demo threat-model writing in Compose dual-plane platforms; recurrent NetworkPolicy / unpublished-port containment with fall-open HTTP AuthZ. Specific edge stacks stay quarantined as local.

## Related

- Category: [[trust]]
- [[privileged-capability-ownership]] · [[prove-honesty-contracts]] · [[gateway-auth]]
- [[happy-path-only]] · [[required-happy-path]]
