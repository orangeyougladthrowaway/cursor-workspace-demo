---
type: guidance
status: canonical
id: engineering-knowledge-base-g-historisation
concern: historisation
description: Accumulated Staging/ODS/DWH ownership and SCD2 knowledge.
domain: [sql-server, t-sql]
aliases: [scd2, ods, staging, dwh]
derived_from:
  - "[[historisation-layers]]"
updated: 2026-07-20
---

# Warehouse historisation

Atlas: [[warehouse-atlas]]. Pattern: [[historisation-layers]]. Grain/dim/fact: [[declare-the-grain]] · [[scd2-dim-snapshot-fact]]. Ingest edge: [[python-ingest]]. Publish: [[dacpac-publish]].

Portable success rule (engine-agnostic): unchanged business key / hash on re-ingest may yield durable **noop** — treat as success when layers stay consistent ([[historisation-layers]]). Do not invent product poll telemetry here.

## Diagram

```text
Python ingest (edge) → Staging (landing snapshot + row_hash)
       → StageToODS SCD2 merge → ODS (durable history = Type-2 merge SoT)
       → ODSToDWH load → DWH
            dims: mirror SCD2 envelope (surrogate joins)
            facts: truncate+reload snapshots (created_at + dim SK)
ETL DB owns procs; Reports is a published slot (often hollow).
```

## Layer contracts

| Layer | Must | Must not |
| --- | --- | --- |
| Staging | Truncate+insert current snapshot; business keys; `row_hash` | Own SCD2 / long-term BI |
| ODS | Multi-version history via StageToODS procs only (merge SoT) | Truncate in normal ETL |
| DWH | Dims mirror SCD2 envelope; facts are snapshots at declared grain | Run a second SCD2 merge / be history **write** SoT |
| ETL | Orchestrate Stage→ODS→DWH (`usp_Run_All`) | Hold business data |

### ODS envelope (practiced columns)

`ods_rowid`, `effective_from`, `effective_to`, `is_current`, `is_deleted`, `row_hash`. Unique current-per-key often **not** enforced by constraint.

Writers: `[StageToODS].[usp_Scd2Merge_*]` via `usp_StageToODS_All`. DWH loads: `[ODSToDWH].[usp_Load_*]` — fact loads commonly filter `is_current = 1`; **`is_deleted` not consistently applied** (defect when omitted).

**Kimball spine (wide):** ODS SCD2 aligns with dimensional **Type 2** (add row; effective/expiry + current indicator). House dim envelope also requires `is_deleted` + `row_hash` ([[scd2-dimension-envelope]]). Other SCD types (0/1/3–7) are named vocabulary for later deep — do not silently mix Type 1 overwrite into ODS history.

**DWH serving (House A):** **dims** keep/sync the SCD2 envelope for current and as-was surrogate joins; **facts** are **snapshots** (`created_at` + surrogate FK at same grain) truncate+reloaded — [[snapshot-fact-shape]] · [[scd2-dim-snapshot-fact]]. “Not a second history SoT” means **no second merge engine** in DWH, not “dims must be current-only.” Declare grain before dim/fact columns ([[declare-the-grain]] · [[warehouse-grain]] · [[design-warehouse-tables]]).

**dbt / Airflow spine:** dbt = transform-as-code (models as SELECT → warehouse objects); Airflow = batch workflows-as-Python-code (DAGs). Both are **pointers** here unless lived — our warehouse orchestration is SQL procs + [[host-activation]]; platform stages use [[argo-workflows]]. Do not invent a dbt/Airflow L1 folder from spine interest.

## SCD2 Phase C honesty (quarantine as bug)

Lived merge can insert a tombstone **without closing prior current** → dual-current rows; re-runs amplify. Document as defect, not pattern. Soft ingest × absence-delete interactions worsen empties.

## Related

- [[historisation-layers]] · [[kimball-type2-scd]] · [[scd2-dimension-envelope]] · [[snapshot-fact-shape]] · [[scd2-dim-snapshot-fact]] · [[tsql-set-based-merge]] · [[python-ingest]] · [[dacpac-publish]] · [[host-activation]] · [[warehouse-atlas]] · [[dimensional-modeling-kimball]]
