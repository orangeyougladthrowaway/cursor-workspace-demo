---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-linq-api]]"
updated: 2026-07-15
---

# Tolist when needed

## When

You need a stable snapshot, multiple enumeration, or explicit materialization before side effects.

## When not

`ToList()` on every intermediate step as cargo cult.

```csharp
var snapshot = query.Where(x => x.Active).ToList();
// safe to enumerate twice / pass to sync code
```

## Related

- [[csharp-linq-api]] · [[linq-deferred]]
