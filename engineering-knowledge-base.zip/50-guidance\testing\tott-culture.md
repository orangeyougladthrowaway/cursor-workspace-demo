---
type: guidance
status: canonical
id: engineering-knowledge-base-g-tott
concern: testing
description: TotT sample — behaviour/state over implementation; public APIs; no test logic; clear names.
domain: []
aliases: [tott, change-detector, brittle-tests]
derived_from:
  - "[[unit-testing-norm]]"
updated: 2026-07-15
---

# TotT culture

## Applies when

Borrowing Google Testing-on-the-Toilet culture for test design reviews.

## Guidance (sample — D1 #2 + D2 #3)

**Fetch honesty:** TotT blog HTML is often **comment-only** in fetch. Claims below use verified titles/URLs + author/comment restatement + cross-check against *SE@Google* ch12 / [[unit-testing-norm]]. This is **not** TotT corpus complete.

### Behaviour & brittleness (D1 #2)

1. [Test Behavior, Not Implementation](https://testing.googleblog.com/2013/08/testing-on-toilet-test-behavior-not.html) — assert user-facing behaviour; setup may change with DI, **assert path** should not for pure refactors.
2. [Change-Detector Tests Considered Harmful](https://testing.googleblog.com/2015/01/testing-on-toilet-change-detector-tests.html) — tests that lock call graphs fail on harmless refactors and do not document requirements; prefer public behaviour/state.

### D2 #3 elevates (5 posts)

3. [Prefer Testing Public APIs Over Implementation-Detail Classes](https://testing.googleblog.com/2015/01/testing-on-toilet-prefer-testing-public.html) — exercise **public** surfaces; helper/implementation-detail classes need deep own tests only when complexity blocks defect localization from the public path; do not mock every collaborator by default (author clarification in comments).
4. [Testing State vs. Testing Interactions](https://testing.googleblog.com/2013/03/testing-on-toilet-testing-state-vs.html) — prefer verifying **results/state**; use interaction asserts when deps are slow/flaky/inaccessible or you must force failures — still check the SUT handles returned values.
5. [Test Behaviors, Not Methods](https://testing.googleblog.com/2014/04/testing-on-toilet-test-behaviors-not.html) — one discrete **behaviour** per test; call the SUT in each test so cases stay independent (order must not matter).
6. [Don't Put Logic in Tests](https://testing.googleblog.com/2014/07/testing-on-toilet-dont-put-logic-in.html) — avoid branching/`if`/`switch` in tests; **obviousness beats DRY** in unit tests.
7. [Writing Descriptive Test Names](https://testing.googleblog.com/2014/10/testing-on-toilet-writing-descriptive.html) — names document scenario + expected outcome so failures and reviews read as requirements.

## Does not apply when

- Temporary characterisation tests while extracting a seam — label them, replace with behaviour tests.
- Broader-scoped honesty-seam proofs ([[prove-honesty-contracts-in-delivery]]) — different job than unit TotT advice.

## Untapped

Rest of TotT archive (~100+ posts) · GTAC · Keep Cause and Effect · Don't Overuse Mocks · coverage TotT variants.

## Related

- [[unit-testing-norm]] · [[unit-test-fast-isolated]] · [[coverage-not-quality]] · [[code-review-norm]] · [[delivery-atlas]]
