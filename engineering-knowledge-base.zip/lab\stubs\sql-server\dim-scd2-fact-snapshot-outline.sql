-- SCD2 dimension + snapshot fact outline (lab stub) — not production-ready.
-- Canons: [[scd2-dimension-envelope]] · [[snapshot-fact-shape]] · [[scd2-dim-snapshot-fact]] · [[warehouse-grain]]
-- Zoo: [[dim-scd2-fact-snapshot-outline]]

/*
-- Dimension at goods grain (SCD2 envelope)
CREATE TABLE dwh.dim_goods (
    goods_sk           BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY, -- surrogate / version
    goods_bk           VARCHAR(64) NOT NULL,                     -- business key
    agreement_bk       VARCHAR(64) NULL,                         -- parent (1:N) — not a separate fact grain
    goods_name         NVARCHAR(256) NULL,
    row_hash           CHAR(64) NULL,                            -- null on tombstone
    effective_from     DATETIME2 NOT NULL,
    effective_to       DATETIME2 NULL,
    is_current         BIT NOT NULL CONSTRAINT DF_dim_goods_cur DEFAULT (1),
    is_deleted         BIT NOT NULL CONSTRAINT DF_dim_goods_del DEFAULT (0)
);
-- Unique versioning helper (does not alone enforce single-current):
-- CREATE UNIQUE INDEX UX_dim_goods_bk_from ON dwh.dim_goods (goods_bk, effective_from);

-- Snapshot fact at same goods grain
CREATE TABLE dwh.fact_goods_snapshot (
    fact_id            BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    goods_sk           BIGINT NOT NULL,                          -- FK → dim_goods.goods_sk
    snapshot_date      DATE NOT NULL,                            -- grain degenerate / period
    created_at         DATETIME2 NOT NULL,                       -- when this fact row was written
    quantity_on_hand   DECIMAL(18,4) NOT NULL,
    CONSTRAINT FK_fact_goods_dim FOREIGN KEY (goods_sk) REFERENCES dwh.dim_goods (goods_sk)
);
-- Grain key example: (goods_sk, snapshot_date) or (goods_bk, snapshot_date) via sk
-- CREATE UNIQUE INDEX UX_fact_goods_snap ON dwh.fact_goods_snapshot (goods_sk, snapshot_date);

-- Current-serving load (conceptual): join ODS/dim WHERE is_current = 1 AND is_deleted = 0
-- As-was: pick goods_sk where effective_from <= @event AND (effective_to IS NULL OR effective_to > @event)

-- M:N bridge sketch (account *-* customer) — association grain ([[grain-cardinality]])
-- Membership may be Type-2 dated (not a snapshot fact); prefer full dim envelope when historised
-- FKs here use dim version SKs — document SK vs BK policy on the design
CREATE TABLE dwh.bridge_account_customer (
    account_customer_sk BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    account_sk         BIGINT NOT NULL,
    customer_sk        BIGINT NOT NULL,
    weight             DECIMAL(9,6) NULL,                        -- allocation if needed
    row_hash           CHAR(64) NULL,
    effective_from     DATETIME2 NOT NULL,
    effective_to       DATETIME2 NULL,
    is_current         BIT NOT NULL DEFAULT (1),
    is_deleted         BIT NOT NULL DEFAULT (0)
);
*/
