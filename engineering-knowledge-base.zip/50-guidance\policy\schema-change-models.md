---
type: guidance
status: draft
id: engineering-knowledge-base-g-schema-change-models
concern: policy
description: State-based sqlproj/dacpac vs additive migration ledgers — house default and refuse dual SoT.
domain: [sql-server, postgres]
aliases: [additive-migrations, state-based-schema, flyway-vs-ssdt]
derived_from:
  - "[[compiled-schema-release]]"
  - "[[ssdt-sqlproj]]"
  - "[[postgres-sql-craft]]"
  - "[[single-lived-source-of-truth]]"
updated: 2026-07-20
---

# Schema change models

## Applies when

Choosing how schema change is authored, versioned, and applied for a datastore — especially SQL Server warehouse vs Postgres app DBs.

## Does not apply when

- One-off lab scratch DBs with no promotion path
- Non-schema content (reports-only, docs-only)

## Two models

| Model | Idea | Typical tools | Apply unit |
| --- | --- | --- | --- |
| **State-based** | Project declares desired schema; tool computes delta to target | SSDT / Microsoft.Build.Sql → dacpac → SqlPackage | **Whole tip** model |
| **Additive** | Ordered scripts + history table of applied versions | Alembic, Flyway, DbUp, Liquibase-class | **Next script(s)** in order |

PreDeploy/PostDeploy on a dacpac are **deploy hooks**, not an additive migration ledger ([[ssdt-publish-scripts]]).

## House defaults

| Stack | Default SoT | Notes |
| --- | --- | --- |
| SQL Server warehouse / multi-DB sqlproj | **State-based** [[compiled-schema-release]] | Lived house spine |
| Postgres app schema | Additive allowed ([[postgres-sql-craft]] Alembic honesty) | One migration SoT — no dual hand-SQL + Alembic |
| Demo idempotent `CREATE IF NOT EXISTS` trees | Explicit **exception** (e.g. short cloud demos) | Not SQL Server warehouse law |

## Guidance

1. Name **one** schema SoT per database family. Dual SoT is refuse ([[single-lived-source-of-truth]]).
2. For SQL Server warehouse: author in **sqlproj**; CI **compiles** dacpac; publish with env profiles; couple tip selection to [[sql-env-release-assembly]].
3. Additive ledgers need strict ordering and branch discipline — cherry-picks and out-of-order applies are foot-guns; prefer state-based when the house already compiles dacpacs.
4. Data motion (backfill, expand/contract) is **not** solved by model choice alone — document in Pre/Post or separate jobs; durable history tiers must not inherit lab `CreateNewDatabase=True` ([[dacpac-publish]]).
5. If additive is chosen for a SQL Server app DB, pick one tool and elevate lived guidance later — do not paste vendor encyclopaedia here.

## Decision cues

| Signal | Lean |
| --- | --- |
| Multi-DB warehouse, lived SSDT CI | State-based |
| Need pick-and-choose feature tips → env instances | State-based tip publish + [[sql-env-release-assembly]] |
| Small Postgres service, Alembic already SoT | Additive |
| “We’ll keep sqlproj **and** Flyway for the same DB” | **Refuse** until one is retired |

## Refuse

- Two schema SoTs for the same DB
- Treating PostDeploy as a hidden migration history
- Claiming CI compile green equals publish-safe ([[delivery-gates]])

## Related

- [[compiled-schema-release]] · [[ssdt-sqlproj]] · [[ssdt-publish-scripts]] · [[dacpac-publish]] · [[postgres-sql-craft]]
- [[sql-env-release-assembly]] · [[sql-server-env-branches]] · [[warehouse-atlas]]
