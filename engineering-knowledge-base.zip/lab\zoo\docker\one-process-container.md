---
type: example
status: canonical
domain: [docker]
derived_from:
  - "[[docker-containers]]"
  - "[[service-packaging]]"
updated: 2026-07-15
---

# One process container

## When

One main process / capability per image role.

## When not

Shipping app + sidecar + cron in one container as the house default.

```text
Prefer one concern per image — map optional deps via [[service-packaging]] extras
```

## Related

- [[docker-containers]] · [[service-packaging]]
