---
type: map
status: canonical
id: engineering-knowledge-base-map-craft
concern: engineering-craft
description: Theme atlas — SE@Google/time, tooling proficiency, review culture.
domain: []
aliases: [se-google, tooling, missing-semester]
updated: 2026-07-17
---

# Atlas — Engineering craft

Software-engineering-over-time and craft tooling. Index only.

## Living notes

- [[programming-over-time]] · [[published-contract-stability]] · [[code-review-norm]] — **canonical** (D1 Eng Practices + SE@Google ch01/Hyrum)
- Source-unit craft: [[cohesive-code-units]] · [[readable-control-flow]] — cross-language standards; stack choices via [[languages-atlas]]
- Failure craft: [[happy-path-only]] · [[required-happy-path]] · [[happy-path-construction]] · [[fail-loud-on-control-paths]]
- [[tooling-proficiency]] — Missing Semester syllabus only
- Agent binding: [[coding-agent-projection]]

## Deep backlog

1. SE@Google remaining chapters (CI, larger-scale changes, …)
2. Eng Practices speed + pushback pages (retry)
3. Missing Semester lecture notes

## Related

- [[catalog-maps]] · [[delivery-atlas]] · [[agent-engineering-atlas]]
