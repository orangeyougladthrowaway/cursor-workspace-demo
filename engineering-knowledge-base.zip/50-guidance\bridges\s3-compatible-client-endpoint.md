---
type: guidance
status: draft
id: engineering-knowledge-base-g-s3-client-endpoint
concern: bridges
description: >-
  S3-compatible (Spaces) app clients use regional/path-style origin endpoint_url
  plus Bucket — never virtual-host endpoint when Bucket is also set.
domain: [python, digitalocean]
aliases: [spaces-endpoint, boto-endpoint, object-storage-endpoint]
derived_from:
  - "[[credential-owning-bridge]]"
  - "[[capability-bridges]]"
  - "[[config-fail-at-load]]"
  - "[[required-happy-path]]"
updated: 2026-07-19
---

# S3-compatible client endpoint

Atlas: [[platform-atlas]]. Ownership: [[credential-owning-bridge]]. Catalogue: [[capability-bridges]].

## Applies when

Application code (or a storage bridge) builds an S3-compatible client — boto3 / aws-sdk style — against DigitalOcean Spaces or a similar origin that accepts `Bucket` on the API call.

## Does not apply when

- Terraform / OpenTofu **remote state** S3 backends ([[terraform-state-backends]]) — different concern
- Browser or CDN download URLs that are intentionally virtual-hosted or CDN-fronted
- Calling Spaces through the house storage bridge RPC only (no local SDK) — still configure the **owner** correctly

## House rule

1. Set client `endpoint_url` to the **regional origin** (or other path-style origin), **not** a bucket-virtual host and **not** the CDN host.
2. Pass the bucket name as the API **`Bucket`** parameter (or SDK bucket field), separately from `endpoint_url`.
3. Prefer fail-at-config / fail-at-first-use ([[config-fail-at-load]], [[required-happy-path]]) when env would force a virtual-host origin **and** a separate `Bucket` for list/get/put — do not soft-retry onto another host shape.

### DigitalOcean Spaces (practiced minority case)

| Role | Shape | Use as boto `endpoint_url`? |
| --- | --- | --- |
| Regional origin | `https://{region}.digitaloceanspaces.com` | **Yes** — with `Bucket=<name>` |
| Bucket virtual host | `https://{bucket}.{region}.digitaloceanspaces.com` | **No** when `Bucket` is also set for list/get/put |
| CDN | `https://{bucket}.{region}.cdn.digitaloceanspaces.com` | **No** for the SDK client |

Lived failure class: `ListObjectsV2` with `Bucket=<name>` against a virtual-host `endpoint_url` can surface as `NoSuchKey` (or equivalent odd object errors) instead of a clean config fault. Same call against the regional origin succeeds.

### Generic S3-compatible framing

Keep one construction story: **origin base URL + Bucket argument**. Do not bake the bucket into `endpoint_url` when the SDK still takes `Bucket`. Path-style addressing against that origin is the safe default for Spaces-class hosts; do not assume AWS virtual-host auto-behaviour is the house happy path.

## Praxis pressure (not dual SoT)

Sibling product `microservices-framework` already ships origin-only storage config (`storage.endpoint = https://lon1.digitaloceanspaces.com`; Helm comment: origin only, not CDN) and builds boto with that `endpoint_url` plus env `SPACES_BUCKET`. Elevate that shape into this note — **product trees remain consumers**, not a second doctrine home.

## Quarantine

- Compose/`deploy.sh` forcing `https://{bucket}.{region}.digitaloceanspaces.com` into app env as the SDK endpoint
- Treating CDN URL as interchangeable with origin for list/get/put
- Duplicating long Spaces URL encyclopaedias here — keep the construction rule thin; platform product facts stay in systems-knowledge-base if needed

## Related

- [[capability-bridges]] · [[credential-owning-bridge]] · [[service-packaging]] · [[helm-deploy]] · [[compose-deploy]]
- [[config-fail-at-load]] · [[required-happy-path]] · [[platform-atlas]]
- [[terraform-state-backends]] (not this — TF remote state only)
