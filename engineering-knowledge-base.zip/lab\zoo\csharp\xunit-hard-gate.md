---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[unit-testing-norm]]"
  - "[[delivery-gates]]"
updated: 2026-07-16
---

# Xunit hard gate

## When

xUnit tests are the unit proof for .NET changes.

## When not

Soft-skipping the only test job.

```xml
<!-- CI: dotnet test — no continue-on-error -->
```

## Related

- [[unit-testing-norm]] · [[delivery-gates]] · [[hard-unit-gate]]
