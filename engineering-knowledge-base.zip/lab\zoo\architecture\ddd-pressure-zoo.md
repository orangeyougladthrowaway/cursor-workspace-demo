---
type: example
status: canonical
domain: [architecture]
derived_from:
  - "[[domain-driven-design-pressure]]"
updated: 2026-07-16
---

# Ddd pressure zoo

## When

Aligning ubiquitous language with concern folders.

## When not

Importing a full DDD ceremony curriculum into engineering-knowledge-base.

```text
Pressure only → [[domain-driven-design-pressure]] · [[bounded-context-language]]
```

## Related

- [[domain-driven-design-pressure]] · [[bounded-context-language]]
