---
type: example
status: canonical
domain: [apis]
derived_from:
  - "[[credential-owning-bridge]]"
updated: 2026-07-16
---

# Credential bridge zoo

## When

A bridge owns credentials for an external system.

## When not

Passing long-lived secrets through every caller.

```text
Credential-owning bridge — least privilege tokens ([[credential-owning-bridge]])
```

## Related

- [[credential-owning-bridge]] · [[ownership]]
