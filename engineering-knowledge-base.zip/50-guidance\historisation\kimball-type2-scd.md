---
type: guidance
status: canonical
id: engineering-knowledge-base-g-kimball-t2
concern: historisation
description: Kimball Type 2 SCD — add row with effective/expiry/current; maps to house dim envelope + hash/delete.
domain: [sql-server, warehouse]
aliases: [type2, scd]
derived_from:
  - "[[warehouse-historisation]]"
  - "[[scd2-dimension-envelope]]"
  - "[[declare-the-grain]]"
updated: 2026-07-20
---

# Kimball type 2 SCD

Primary: [Kimball Group — Type 2: Add New Row](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/type-2/).

## Applies when

Designing durable history in warehouse layers (ODS / dimensions).

## Guidance

1. Type 2 changes **add a new row** with updated attributes — do not overwrite history in place (Type 1).
2. Generalize the dimension key beyond the natural key: multiple rows per member need a **surrogate** primary key used as the fact FK.
3. House minimum Type 2 columns ([[scd2-dimension-envelope]]): `effective_from`, `effective_to`, `is_current`, plus **`is_deleted`** and **`row_hash`**.
4. Lived ODS columns align ([[warehouse-historisation]]); facts stay snapshot-shaped ([[snapshot-fact-shape]]).
5. Merge honesty: never leave dual current ([[historisation-layers]] Watch).

## Untapped

Types 0/1/3/4/6/7 technique pages as elevated house law.

## Related

- [[kimball-scd-vocabulary]] · [[dimensional-modeling-kimball]] · [[scd2-dim-snapshot-fact]] · [[data-atlas]]
