---
type: guidance
status: canonical
id: engineering-knowledge-base-g-argo
concern: argo
description: Accumulated Argo Workflows knowledge as outer stage grain for K8s gateway family.
domain: [argo, kubernetes]
aliases: [argo, workflowtemplate, wt]
updated: 2026-07-15
---

# Argo Workflows

Outer orchestration for K8s gateway family. Argo is a **caller of Envelope `/call`**, not a second RPC stack. Wire: [[envelope-call]]. Deploy merge: [[helm-deploy]]. WAL correlation: [[observer-wal]].

## Place in the stack

```text
Argo WorkflowTemplate
    → POST gateway /call  (actor often service:argo)
        → forward to services
```

Chart values: `infrastructure/helm/argo-workflows-values.yaml` — practiced chart **0.47.4**, app **v3.7.10** (per values comments). Namespace `argo` labeled for NetworkPolicy; SA token via `argo-workflow-sa-token.yaml`.

## Grain honesty

| Grain | Lived |
| --- | --- |
| Typical product pipeline WT | **One long HTTP** `run_pipeline` (timeout ~86400s) — stage pods as default architecture are **docs/TARGET_STATE**, not code |
| Item fan-out (`withParam`) | Example templates exist; not primary lived path |
| Inner orchestrator | Thread pools / chunk loops **in memory** inside the worker; crash loses run — **no** WAL resume |
| Argo `retryStrategy` | **absent** on lived templates |

Timeout triad for long `/call`: Argo WT timeout ↔ gateway forward timeout ↔ client read timeout — set deliberately; unlimited forward is a hang footgun.

## Job correlation

Argo `workflow.uid` → `X-Job-Id` at gateway → `jobs.workflow_uid` UNIQUE → WAL rows under `jobs.id`. Operator recovery CLI wants **`jobs.id`**, not blindly reusing workflow uid (can create spurious jobs).

Re-run = submit new Workflow / new uid → new job row. Audit is **not** a redo engine ([[observer-wal]]).

## Artefacts

| Path | Role |
| --- | --- |
| `workflows/templates/*.yaml` | Lived WTs (e.g. product pipeline) |
| `infrastructure/helm/argo-workflows-values.yaml` | Argo install values |
| `scripts/argo-ui.sh` | UI helper |

## Quarantine

TARGET_STATE “stage pods + BatchProcessor resume” as current architecture · treating Argo as replacing Envelope · product pipeline lore as platform law.

## Related

- [[envelope-call]] · [[observer-wal]] · [[helm-deploy]] · [[in-process-orchestration]] · [[platform-atlas]]
