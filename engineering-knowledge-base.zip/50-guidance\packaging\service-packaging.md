---
type: guidance
status: canonical
id: engineering-knowledge-base-g-packaging
concern: packaging
description: Multi-image extras by role — one monorepo, many images; quarantine fat/dual-Poetry theatre.
domain: [python, docker]
aliases: [extras, pyproject, images]
derived_from:
  - "[[ownership]]"
  - "[[boundaries]]"
  - "[[restraint]]"
  - "[[capability-bridges]]"
updated: 2026-07-19
---

# Service packaging

Atlas: [[platform-atlas]]. Bridges: [[capability-bridges]]. Layout: [[python-packaging-layout]]. Images: [[docker-containers]].

## Applies when

Gateway monorepos that ship multiple runtime images from one Python package tree.

## Does not apply when

- Single-library packages with one install story
- Trainer dual-Poetry layouts without naming the exception ([[trainer-packaging]])

## House defaults

One monorepo, **many images**, optional-dependencies by role:

| Extra (K8s example) | Installs | Typical image |
| --- | --- | --- |
| `gateway` | pyjwt, cryptography, … | gateway |
| `db` | psycopg, sqlalchemy, alembic | db-api |
| `storage` | boto3 | storage-api |
| `<product>` | OCR/PDF/… | product workers |
| `dev` | pytest, ruff, mypy | CI |
| `tracing` | OTEL | only when wired |

Base may include FastAPI/httpx/pydantic — purity is **not** “no HTTP in package.”

**Local-tool bridges** (OCR / similar): the Python extra installs the bindings; the **Dockerfile** must also install the OS binary **and** any language / data packs that product config selects. Extra alone is not a complete OCR runtime ([[credential-owning-bridge]], [[docker-containers]]).

## Decision rules

| Question | Rule |
| --- | --- |
| Does this image need sqlalchemy? | Only if it owns DB I/O — else omit `db` extra |
| Can we ship one fat image? | No as default — extras map to capability ([[ownership]]) |
| Is OTEL claimed? | Extra present ≠ observability done ([[metrics-tracing-logging-pressure]]) |
| Does a local-tool bridge image match config? | Dockerfile ships binary + lang/data packs for every selected `ocr_lang` (etc.); verify with `tesseract --list-langs` / missing-traineddata failure class — not only “pip install succeeded” |
| Compose vs Helm packaging | Same extras idea; different Dockerfile layouts under `deploy/docker/` |

## CI image matrices

Build/push on main (often not on PR). Tag shapes family-specific (DOCR repo names are `host/` detail). Rebuild/push after Dockerfile apt/lang-pack changes — ephemeral `apt` in a running container dies on recreate.

**Registry-backed hosts:** the **image content** is the unit of application change. Code or packaging fixes require CI build → push → pull/recreate on the host. Compose recreate alone does **not** ship unbuilt source ([[compose-deploy]]). Verify with health / `printenv` / the failing path after recreate — not only “compose file updated.”

## Quarantine

Shipping sqlalchemy/boto3 on every image · dual Poetry+pip theatre · OTEL extra claimed as observability · slim OCR image with only the engine package while config asks for non-default tessdata · copying trainer packaging into gateway without cause · treating host `compose up` as sufficient after a source edit when the service runs a registry image.

## Related

- [[capability-bridges]] · [[credential-owning-bridge]] · [[helm-deploy]] · [[compose-deploy]] · [[docker-containers]] · [[delivery-ci]] · [[python-packaging-layout]] · [[platform-atlas]]
