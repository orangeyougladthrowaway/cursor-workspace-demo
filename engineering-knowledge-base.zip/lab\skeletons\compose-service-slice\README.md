---
description: Thin Compose service slice for lab local stacks — not a second prod SoT.
updated: 2026-07-15
---

# compose-service-slice

## Purpose

Minimal Compose service for local/lab bring-up with profile honesty.

## Required canons

- [[compose-deploy]]
- [[service-packaging]]
- [[docker-containers]]

## Copy steps

1. Copy `compose.yaml` (+ optional `Dockerfile`) beside the service.
2. Use `profiles: ["lab"]` for stacks that are not prod-parity claims.
3. `docker compose --profile lab up --build`.

## Honesty

- Do not invent a dual official deploy path next to Helm/host notes.
- Prefer non-root images when practical ([[non-root-user]]).
- Extras/images by role — not one fat image ([[image-extras-not-fat]]).
