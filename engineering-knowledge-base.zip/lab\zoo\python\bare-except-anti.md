---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-errors-resources]]"
  - "[[python-ingest]]"
updated: 2026-07-15
---

# Bare except anti

## When

Documenting a forbidden pattern in ingest/worker loops.

## When not

Encoding silent `except` as resilience.

```python
# ANTI — quarantine ([[python-ingest]])
try:
    fetch()
except Exception:
    pass

# Prefer specific types + surface failure
try:
    fetch()
except TimeoutError as err:
    raise RuntimeError("fetch failed") from err
```

## Related

- [[python-errors-resources]] · [[scope]]
