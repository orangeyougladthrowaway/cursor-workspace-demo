---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-wal-concurrency]]"
updated: 2026-07-16
---

# Mvcc thin zoo

## When

Explaining why readers don’t block writers (typical RC).

## When not

Equating vacuum deferral with “no WAL.”

```text
MVCC versions rows; vacuum reclaims — see [[postgres-wal-concurrency]]
```

## Related

- [[postgres-wal-concurrency]] · [[durable-storage-tradeoffs]]
