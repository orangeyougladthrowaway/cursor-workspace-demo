---
type: guidance
status: canonical
id: engineering-knowledge-base-g-sql-agent-jobs
concern: datastores
description: How to build and maintain SQL Agent jobs that run warehouse/SSIS work without dual SoT.
domain: [sql-server]
aliases: [sql-agent, job-schedule]
derived_from:
  - "[[host-activation]]"
  - "[[historisation-layers]]"
  - "[[ssis-dtproj-dtsx]]"
  - "[[single-lived-source-of-truth]]"
updated: 2026-07-20
---

# Sql agent jobs craft

Systems: Agent capability (jobs/steps/schedules). Eng: **job as controlled activation**, not hidden business logic SoT.

## Build

1. Job steps call **versioned artefacts** — `usp_Run_All`, catalog SSIS executions, or host activation scripts — not ad-hoc SQL pasted only in Agent UI.
2. Store job definitions as scripts in repo (or IaC) when the estate requires rebuild; click-ops-only jobs are Gaps.
3. Schedules express cadence; completeness gates stay in the load proc/host ([[historisation-layers]]).
4. Notifications/operators: fail loud to monitored channel; do not email-success on noop without honesty.

## Maintain

| Change | Do |
| --- | --- |
| New pipeline | Add step → artefact in source → deploy job script with release |
| Secret/connection | Prefer proxy/credential objects owned explicitly |
| SSIS step | Point at catalog path/environment; align with [[ssis-dtproj-dtsx]] |

## Refuse

- Business rules that exist only inside Agent step text
- Dual schedulers (Agent + external) both “primary” ([[host-activation]])

## Related

- [[sql-maintenance-craft]] · [[dacpac-publish]] · [[sql-server-craft-map]]
