---
type: foundation
status: canonical
description: Taxonomy of knowledge types — includes catalog and map.
updated: 2026-07-15
---

# Knowledge model

Types are kinds of knowledge, not folder bureaucracy.

## Type overview

| Type | Stability | Primary question |
| --- | --- | --- |
| `philosophy` | Very high | What do we believe engineering is for? |
| `category` | Very high | What stable theme organises related principles? |
| `principle` | High | What enduring constraint guides decisions in a theme? |
| `standard` | High | What must we normally do? |
| `pattern` | Medium–high | What recurring solution shape do we use? |
| `guidance` | Medium–low | How does a domain/technology apply higher knowledge? |
| `workflow` | Medium–low | What sequence do we follow? |
| `map` | Medium | What accumulated body of knowledge should I open first? (family or theme atlas) |
| `catalog` | N/A | Inventory / lens for taxonomic browse |
| `template` | Medium | What starter shape helps **write a vault note**? (`00-foundation/templates/` only) |
| `example` | Low | What clarifies a higher concept without becoming law? (includes `lab/zoo/` entries) |
| `glossary` | High | What does this term mean here? |
| `foundation` | Highest | How does this bible itself work? |

## Layering

```text
philosophy → category → principle → standard → pattern
                          ↓
                    guidance / workflow / example
                          ↑
              maps (family / theme atlases cite any altitude)
```

## Writing rules

- **Category before leaf** for principles.
- Technology/stack detail belongs in `guidance`, never in philosophy.
- Every standard/pattern/guidance/workflow/**map** declares **`concern`** matching its folder ([[navigation]]; maps use the family or theme leaf folder).
- Prefer stable **`id`**. Use **`domain`** for stack tags; **`aliases`** only for informal search ([[methodology]]).
- Catalogs and maps have **unique** filenames — never `_index.md`.
- Naming, stem↔H1, and link form: [[methodology]].
- **Praxis:** zoo markdown uses `type: example` and must cite doctrine via `derived_from` / Related. Copy-out **skeletons** live under `lab/skeletons/` (directories + README) — they are not `type: template` note stubs. Do not confuse with `00-foundation/templates/`. Densify toward [[common-case-coverage]] (Axis F); seeded facets ≠ majority done.

## Status

| Status | Meaning |
| --- | --- |
| `draft` | Unfinished — do not treat as doctrine |
| `canonical` | Living doctrine |
| `deprecated` | **Brief migration only** while links move — then delete. Not a permanent redirect. Target: none in the vault |

Detail: [[changing-this-bible]].

## Related

- [[navigation]]
- [[dependency-rules]]
- [[methodology]]
- [[changing-this-bible]]
- [[common-case-coverage]]
- [[praxis-ingestion]]
