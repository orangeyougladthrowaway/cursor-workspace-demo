---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[pytest-practices]]"
updated: 2026-07-15
---

# Request fixture

## When

Fixtures that need test metadata or nested fixture access.

## When not

Hidden globals for “current test name.”

```python
import pytest

@pytest.fixture
def case_id(request: pytest.FixtureRequest) -> str:
    return request.node.name
```

## Related

- [[pytest-practices]]
