---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[ddia-reliability-themes]]"
updated: 2026-07-16
---

# Ddia reliability pointer

## When

Talking replication/durability tradeoffs beyond engine knobs.

## When not

Claiming DDIA-complete without chapter fetch ([[ingest-coverage]] Untapped).

```text
Themes: reliability · replication · partitioning pressure → [[ddia-reliability-themes]]
```

## Related

- [[ddia-reliability-themes]] · [[durable-storage-tradeoffs]]
