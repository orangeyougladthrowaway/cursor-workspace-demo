---
type: map
status: canonical
id: engineering-knowledge-base-map-security
concern: security
description: Theme atlas — auth, session, OWASP, threat-model pressure.
domain: []
aliases: [owasp, auth, trust]
updated: 2026-07-19
---

# Atlas — Security

Cross-cutting security knowledge (remote pressure + lived threat/auth honesty). Index only.

## Canonical (D1 #3 + D2 #1/#2/#6/#9)

- [[owasp-authentication-pressure]] · [[owasp-session-pressure]] · [[owasp-top10-mapping]] · [[asvs-authentication-mapping]]
- [[owasp-password-storage-pressure]] · [[owasp-multifactor-authentication-pressure]] · [[owasp-forgot-password-pressure]]
- Lived: [[gateway-auth]] · [[threat-model-declaration]] · [[threat-model-matched-controls]]

**Navigation tip:** Compose secret sprawl and per-service injection live under infrastructure ([[compose-deploy]]); credential ownership / optional-integration fail-closed vs skip under [[credential-owning-bridge]] (platform atlas).

## Deep backlog (D2+)

ASVS session/access chapters · remaining Top 10:2021 · Top 10:2025 · WAHH · Security Engineering.

## Related

- [[catalog-maps]] · [[platform-atlas]] · [[infrastructure-atlas]] · [[delivery-atlas]]
