---
type: standard
status: canonical
id: engineering-knowledge-base-s-010
concern: delivery
description: Unit tests — small/fast, behaviour-focused, maintainable; coverage is diagnostic not Done.
domain: []
aliases: [unit-test, aaa, damp]
derived_from:
  - "[[prove-honesty-contracts]]"
  - "[[coverage-not-quality]]"
  - "[[published-contract-stability]]"
updated: 2026-07-15
---

# Unit testing norm

Primary sources (D1 #2): [Microsoft unit-testing best practices](https://learn.microsoft.com/en-us/dotnet/core/testing/unit-testing-best-practices); *Software Engineering at Google* ch11–12. TotT sample expanded D2 #3 ([[tott-culture]] — 7 posts; blog body often unfetchable, cross-checked here).

## Requirement

1. Prefer **narrow, fast, deterministic** unit tests for domain/pure logic; aim roughly **~80% unit / ~20% broader** where a suite mixes sizes (Google rule of thumb — not a hard gate here).
2. Honesty-seam proofs (envelope, deploy, auth) remain **hard** where load-bearing — units alone are insufficient ([[prove-honesty-contracts-in-delivery]], [[delivery-gates]]).
3. **Avoid infrastructure** in unit tests (DB, network, filesystem) — reserve for integration; DI/explicit deps make this possible (MS).
4. Name tests so they document behaviour (method/scenario/expected **or** behaviour-first names — prefer clarity over formula dogmatism) ([[tott-culture]] descriptive-names theme).
5. Structure with readable **Arrange / Act / Assert** (or When/Then); **one behaviour per test** where practical (TotT behaviours-not-methods).
6. Prefer **state assertions** and **public APIs** over interaction/mocks of internals (SE@Google ch12; TotT state-vs-interactions + public-API + change-detector themes).
7. Tests should strive to be **unchanging** under pure refactor / new features / bug-fix addenda — only behaviour-contract changes force edits.
8. Prefer **DAMP** (descriptive and meaningful phrases) over clever DRY in tests — clarity beats shared helpers that hide intent; **no branching logic in tests**.
9. Clear failure messages; **no logic in tests** that conceals bugs.
10. **Coverage % is not quality** ([[coverage-not-quality]]).

## Collisions (lived)

- Soft/absent coverage thresholds marketed as quality — forbidden ([[delivery-gates]])
- Brittle mock-heavy gateway tests — pressure toward state at honesty seams

## Untapped

xUnit books · TotT **full** archive · SE@Google hermetic-testing / Takeout case-study remainder · MS guide remainder (legacy patterns sections).

## Related

- [[unit-test-fast-isolated]] · [[tott-culture]] · [[pytest-practices]] · [[code-review-norm]] · [[delivery-atlas]]
