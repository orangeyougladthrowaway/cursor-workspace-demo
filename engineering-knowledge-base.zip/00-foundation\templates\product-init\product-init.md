---
type: template
status: canonical
id: engineering-knowledge-base-tpl-product-init
description: Copy-pack for new product repos — AGENTS + primary-source engineering-knowledge-base rule; fill fields; do not commit the pack folder.
domain: [cursor]
updated: 2026-07-16
---

# Product init

Copy the **listed sibling files** into a **new product repo root**, then fill brackets. Do **not** copy the engineering-knowledge-base vault into the product tree as committed doctrine.

**Hard cleanup:** after copying, the product repo must **not** keep a `product-init/` folder (or a second copy of this pack). Commit only root `AGENTS.md`, `.cursor/rules/engineering-knowledge-base-readonly.mdc`, and the gitignore lines — never the template directory as a parallel tree.

## Agent binding

Product control files (`AGENTS.md`, `.cursor/rules/engineering-knowledge-base-readonly.mdc`) must encode:

- engineering-knowledge-base as **primary** engineering source
- External research allowed for domain gaps
- **engineering-knowledge-base wins** on house engineering conflicts
- **Retrieve before build** (atlas → canons → code)

Do not weaken these into optional tips. Wording SoT: [[coding-agent-projection]].

## Does this contradict engineering-knowledge-base?

| Practice | OK? |
| --- | --- |
| Product agents **read** engineering-knowledge-base; **do not write** it | **Yes** — product sessions are consumers |
| Local junction/symlink to engineering-knowledge-base, **gitignored** | **Yes** — never commit a fork |
| Elevate new law later in the **engineering-knowledge-base workspace** | **Yes** — one SoT, separate change |
| Copy note bodies / strip `.git` into the product | **No** — forbids [[single-lived-source-of-truth]] |

Softens “amend engineering-knowledge-base in the same product PR” ([[coding-agent-projection]]) by design: amend engineering-knowledge-base when you open the vault, not from product agent runs.

## Copy checklist (product repo)

1. From this folder, copy **only** `AGENTS.md` → product repo root; fill `<…>` fields.
2. Copy **only** `engineering-knowledge-base-readonly.mdc` → `.cursor/rules/engineering-knowledge-base-readonly.mdc`.
3. Append lines from `gitignore-snippet.txt` into the product `.gitignore` (do not copy the snippet file as a leftover).
4. Mount engineering-knowledge-base locally (pick one):
   - **Preferred:** keep engineering-knowledge-base as sibling `../engineering-knowledge-base` and set path in `AGENTS.md` only.
   - **One-repo Cursor:** Windows junction — `mklink /J .engineering-knowledge-base X:\repos\engineering-knowledge-base` (then open/add `.engineering-knowledge-base` if needed). Linux/mac: `ln -s ../engineering-knowledge-base .engineering-knowledge-base`.
5. Confirm `.engineering-knowledge-base/` is ignored and **not** staged.
6. **Delete** any accidental `product-init/` (or full pack copy) from the product tree before the first commit — no second AGENTS/template tree.
7. Start work in the product repo; agents read engineering-knowledge-base via path in `AGENTS.md` / `.engineering-knowledge-base`.

## Files in this folder

| File | Role |
| --- | --- |
| `AGENTS.md` | Product agent entry — primary source + operating law |
| `engineering-knowledge-base-readonly.mdc` | Always-on: engineering-knowledge-base primary; research fills gaps; house rules win |
| `gitignore-snippet.txt` | Ignore local engineering-knowledge-base mount |

## Related

- [[agents-projection]] · [[coding-agent-projection]] · [[colocated-authority]] · [[single-lived-source-of-truth]]
