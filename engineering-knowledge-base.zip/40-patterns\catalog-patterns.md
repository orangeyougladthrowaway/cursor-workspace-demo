---
type: catalog
status: canonical
id: engineering-knowledge-base-cat-patterns
description: Pattern inventory by concept folder.
updated: 2026-07-20
---

# Catalog — Patterns

| Concept | Notes |
| --- | --- |
| ownership | [[credential-owning-bridge]], [[historisation-layers]] |
| boundaries | [[domain-io-edge-packaging]], [[smart-endpoints-dumb-pipes-contrast]], [[microservice-prerequisites]] |
| contracts | [[policy-ingress-contract]], [[adapter-metadata-routing]], [[public-http-vs-internal-envelope]] |
| policy | [[config-fail-at-load]], [[compiled-schema-release]], [[happy-path-construction]] |
| delivery | [[sql-env-release-assembly]] |
| audit | [[write-ahead-call-audit]] |
| modeling | [[grain-cardinality]] |
| historisation | [[scd2-dim-snapshot-fact]] |

Atlases: [[catalog-maps]].
