---
type: example
status: canonical
domain: [architecture]
derived_from:
  - "[[smart-endpoints-dumb-pipes-contrast]]"
updated: 2026-07-16
---

# Smart endpoints zoo

## When

Keeping intelligence in endpoints/services; pipes stay dumb.

## When not

Smart ESB pipes as silent house default.

```text
→ [[smart-endpoints-dumb-pipes-contrast]]
```

## Related

- [[smart-endpoints-dumb-pipes-contrast]] · [[microservice-prerequisites]]
