---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-wal-concurrency]]"
  - "[[observer-wal]]"
updated: 2026-07-15
---

# Wal vs app audit

## When

Distinguishing engine durability WAL from application audit tables.

## When not

Calling Observer/app audit relations “Postgres WAL.”

```text
Engine durability → [[postgres-wal-concurrency]]
App audit tables  → [[observer-wal]] (ordinary relations)
```

## Related

- [[postgres-wal-concurrency]] · [[observer-wal]] · [[durable-storage-tradeoffs]]
