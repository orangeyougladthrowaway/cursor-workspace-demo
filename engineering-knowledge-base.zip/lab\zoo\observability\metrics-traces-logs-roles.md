---
type: example
status: canonical
domain: [observability]
derived_from:
  - "[[metrics-tracing-logging-pressure]]"
updated: 2026-07-16
---

# Metrics traces logs roles

## When

Choosing metrics vs traces vs logs for a signal.

## When not

One telemetry type forced for every question.

```text
Metrics = aggregates · Traces = request paths · Logs = events
→ [[metrics-tracing-logging-pressure]]
```

## Related

- [[metrics-tracing-logging-pressure]]
