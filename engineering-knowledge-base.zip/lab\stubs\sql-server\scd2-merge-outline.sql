-- SCD2 MERGE outline (lab stub) — not production-ready.
-- Canons: [[kimball-type2-scd]] · [[tsql-set-based-merge]] · [[warehouse-historisation]]
-- Zoo: [[dual-current-scd-anti]] · [[merge-output-holdlock]]

-- Sketch only: close prior current, insert new current, HOLDLOCK on target.
-- Fill real keys/columns from your warehouse model.

/*
MERGE dbo.DimExample WITH (HOLDLOCK) AS tgt
USING #staging AS src
  ON tgt.BusinessKey = src.BusinessKey
 AND tgt.IsCurrent = 1
WHEN MATCHED AND (
     tgt.Attr1 <> src.Attr1 OR tgt.Attr2 <> src.Attr2
) THEN UPDATE SET
     tgt.IsCurrent = 0,
     tgt.ValidTo   = src.EffectiveFrom
WHEN NOT MATCHED BY TARGET THEN
  INSERT (BusinessKey, Attr1, Attr2, IsCurrent, ValidFrom, ValidTo)
  VALUES (src.BusinessKey, src.Attr1, src.Attr2, 1, src.EffectiveFrom, '9999-12-31')
OUTPUT $action, inserted.BusinessKey;
*/

-- After close-update, typically insert the new current row in the same batch
-- (pattern varies — prefer set-based; never leave dual IsCurrent=1).
