---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-typing-honesty]]"
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Gradual typing annotation

## When

Annotating a public function so mypy can catch call-site mistakes.

## When not

Claiming “typed codebase” while CI soft-skips mypy ([[delivery-gates]]).

```python
def greeting(name: str) -> str:
    return f"Hello {name}"

greeting(3)  # mypy: incompatible type
```

## Related

- [[python-typing-honesty]] · [[delivery-ci]]
