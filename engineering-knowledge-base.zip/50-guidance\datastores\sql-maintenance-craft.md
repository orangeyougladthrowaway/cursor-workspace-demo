---
type: guidance
status: canonical
id: engineering-knowledge-base-g-sql-maintenance
concern: datastores
description: How to schedule CheckDB, index maintain, and stats care without confusing them with historisation.
domain: [sql-server]
aliases: [checkdb, index-rebuild, stats-update]
derived_from:
  - "[[sql-index-plan-craft]]"
  - "[[sql-agent-jobs-craft]]"
  - "[[historisation-layers]]"
updated: 2026-07-20
---

# Sql maintenance craft

Systems: CheckDB / index maintain **capabilities**. Eng: **house jobs and evidence**, not Ola-as-religion without ownership.

## Build

1. Separate **integrity** (CheckDB), **index maintain**, and **stats** from **ETL historisation** jobs.
2. Prefer scripted Agent jobs ([[sql-agent-jobs-craft]]) with explicit DB lists (Staging ≠ ODS retention posture).
3. Index rebuild/reorg thresholds follow measured fragmentation **and** workload windows — ODS Type-2 tables are write-heavy; avoid copy-paste weekly rebuild of everything.
4. Stats: rely on auto-update where sufficient; add targeted `UPDATE STATISTICS` after large loads when plans prove stale ([[sql-index-plan-craft]]).

## Maintain

- Capture outcomes (job history / monitoring) — silent failed CheckDB is a gate fail.
- After dacpac publish that changes indexes, confirm maintenance scripts still reference real names.

## Refuse

- Using index rebuild to “fix” bad MERGE designs
- One undifferentiated maintenance plan across lab-destructive and durable history DBs

## Untapped

Named Ola/house schedule matrix as canonical law · Azure SQL automated tuning as default.

## Related

- [[sql-concurrency-craft]] · [[dacpac-publish]] · [[sql-server-craft-map]]
