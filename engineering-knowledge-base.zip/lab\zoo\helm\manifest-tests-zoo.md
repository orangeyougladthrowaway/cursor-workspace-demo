---
type: example
status: canonical
domain: [helm]
derived_from:
  - "[[delivery-gates]]"
  - "[[helm-deploy]]"
updated: 2026-07-16
---

# Manifest tests zoo

## When

Generated manifests deserve hard tests.

## When not

`helm lint` green as sole ship proof.

```text
helm template → fixtures/tests on manifests → hard gate
```

## Related

- [[delivery-gates]] · [[helm-deploy]] · [[manifest-test-pointer]]
