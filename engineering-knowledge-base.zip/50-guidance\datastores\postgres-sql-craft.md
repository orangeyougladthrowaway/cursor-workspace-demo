---
type: guidance
status: canonical
id: engineering-knowledge-base-g-pg-sql
concern: datastores
description: Postgres SQL craft — CTE, ON CONFLICT upsert, RETURNING; app SQL vs engine WAL.
domain: [postgres]
aliases: [upsert, cte, on-conflict]
derived_from:
  - "[[postgres-core-concepts]]"
  - "[[postgres-wal-concurrency]]"
updated: 2026-07-15
---

# Postgres sql craft

Primary (L-sql #2 + L+): [INSERT — ON CONFLICT](https://www.postgresql.org/docs/current/sql-insert.html); [Window Functions tutorial](https://www.postgresql.org/docs/current/tutorial-window.html); [Using EXPLAIN](https://www.postgresql.org/docs/current/using-explain.html).

## Applies when

Writing application or migration SQL against Postgres (jobs/audit/domain), not replacing engine durability doctrine.

## Guidance

1. Engine durability/isolation stays [[postgres-wal-concurrency]]. This note is **dialect craft** for writers.
2. Prefer set-based SQL; use **CTEs** to name intermediate result sets for readable upserts/hist steps.
3. **`INSERT … ON CONFLICT`** is the upsert primitive: `DO NOTHING` or `DO UPDATE`. For `DO UPDATE`, name a **conflict_target** (infer unique index or name constraint). Outcome is atomic insert-or-update under concurrency.
4. Proposed row is available as **`EXCLUDED`** in `DO UPDATE` expressions. Optional `WHERE` on the update still locks candidates.
5. Do not let conflict statements affect the same existing row twice (cardinality violation). Unique indexes must match the business key you mean.
6. Prefer **`RETURNING`** to observe inserted/updated rows (defaults, generated ids) instead of blind follow-up SELECTs.
7. Migrations (Alembic, etc.) should collide with packaging `db` extras — versioned schema changes, not ad-hoc prod edits.

### Window functions (L+)

8. Windows compute across related rows **without collapsing** them (unlike GROUP BY aggregates). Always use `OVER` (`PARTITION BY` / `ORDER BY`).
9. Default frame with `ORDER BY` is often “start of partition through current peers” — running totals differ from partition-wide aggregates with no `ORDER BY`.
10. Windows belong in `SELECT`/`ORDER BY` only — not `WHERE`/`GROUP BY`. Filter post-window via subquery. Name shared frames with `WINDOW w AS (…)`.

### EXPLAIN (L+)

11. Use **`EXPLAIN`** to read the planner’s tree (startup cost, total cost, rows, width). Upper-node cost includes children. Costs are planner units — not wall-clock.
12. Prefer **`EXPLAIN (ANALYZE, BUFFERS)`** when diagnosing real slowness (actually runs the query). Keep `ANALYZE` off production write paths unless intentional.
13. Seq Scan vs Index Scan choices follow selectivity/stats — **`VACUUM ANALYZE`** freshness matters. Plan-reading is skill; treat surprising row estimates as a stats/index question first.

## Untapped

JSONB operators · partitioning · extension catalogue · frame clause encyclopaedia · auto_explain.

## Related

- [[postgres-core-concepts]] · [[postgres-wal-concurrency]] · [[tsql-set-based-merge]] · [[data-atlas]] · [[languages-atlas]]
