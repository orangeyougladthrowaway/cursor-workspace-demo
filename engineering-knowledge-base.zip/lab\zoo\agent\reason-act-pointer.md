---
type: example
status: canonical
domain: [agent]
derived_from:
  - "[[react-reason-act-pressure]]"
  - "[[coding-agent-projection]]"
updated: 2026-07-15
---

# Reason act pointer

## When

Agents alternate reason → act with explicit observations.

## When not

Unbounded tool loops without checkpoints.

```text
Reason → Act → Observe → (bound steps)
→ [[react-reason-act-pressure]] · [[coding-agent-projection]]
```

## Related

- [[react-reason-act-pressure]] · [[coding-agent-projection]] · [[deterministic-before-probabilistic]]
