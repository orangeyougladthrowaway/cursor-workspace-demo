---
type: example
status: canonical
domain: [opentofu]
derived_from:
  - "[[terraform-state-backends]]"
  - "[[threat-model-declaration]]"
updated: 2026-07-15
---

# No plaintext state

## When

Any remote or shared state that may hold secrets.

## When not

Committing `*.tfstate` to VCS “for convenience.”

```text
# ANTI
git add terraform.tfstate
# Prefer remote backend + ignore local state files
```

## Related

- [[terraform-state-backends]] · [[threat-model-declaration]]
