---
type: example
status: canonical
domain: [packaging]
derived_from:
  - "[[hydra-config]]"
updated: 2026-07-16
---

# Hydra config zoo

## When

Hydra/OmegaConf for experiment config honesty.

## When not

Undeclared overrides as the only config story.

```text
Config compose must fail loud on missing required keys ([[hydra-config]])
```

## Related

- [[hydra-config]] · [[config-fail-at-load]]
