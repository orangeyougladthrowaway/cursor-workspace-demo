---
type: guidance
status: canonical
id: engineering-knowledge-base-g-helm
concern: helm
description: Accumulated Helm / merged-manifest deploy knowledge (K8s gateway family).
domain: [helm, kubernetes]
aliases: [helm, charts, manifests]
derived_from:
  - "[[config-fail-at-load]]"
updated: 2026-07-15
---

# Helm deploy

Atlas: [[platform-atlas]]. Host provision: [[host-opentofu]]. Outer stage: [[argo-workflows]]. Wire: [[envelope-call]].

## Authoritative app apply path

Lived happy path is **not** bare `helm install` alone:

1. Host/cluster ready ([[host-opentofu]])
2. `scripts/k8s-setup.sh` — namespaces `framework` + `argo`; pull secret
3. Create owner secrets (`framework-db-secret`, `spaces-secret` if keys)
4. Schema ConfigMap / DB password Job as scripted
5. Export deploy env → **`scripts/generate-manifests.sh`** (Helm template compile)
6. Placeholder sed → **`kubectl apply -f infrastructure/manifests.yaml`** (**gitignored**, regenerated every deploy)
7. Argo SA/labels + apply `workflows/templates/*.yaml`

**Practiced chart:** `helm/<gateway-chart>/`.  
**Incomplete theatre:** `helm install framework ./helm/<gateway-chart>` without merge/inject/Argo steps.

**Remote pressure (Helm `template` / Using Helm):** `helm template` **locally renders** charts (cluster API lookups faked; no full server-side validity). That matches our **compile-then-apply** lived path (`generate-manifests.sh` → `kubectl apply`). Official docs centre on `helm install`/`upgrade` as the package manager SoT — for this family, treat install-without-generate as **non-authoritative residue** ([[single-lived-source-of-truth]]).

CI validates Helm/manifests and builds images; **does not** apply to cluster.

**Kubernetes The Hard Way spine:** learning bootstrap (CA, etcd, control plane, workers by hand) is pedagogy, **not** this family’s lived SoT. We provision via [[host-opentofu]] + apply compiled manifests — do not elevate Hard Way steps as deploy doctrine.

## Images

| Piece | Lived |
| --- | --- |
| Dockerfiles | `docker/core/*`, `docker/custom/<product>/*` |
| CI | `.github/workflows/build-multi-path.yml` → DOCR `framework` tags `SERVICE-VERSION` / `SERVICE-latest` |
| Values | `global.registry`, `imageRepository`, per-service repository prefix |

## Config / secrets injection

| Mechanism | Use |
| --- | --- |
| ConfigMaps | Gateway/db-api/worker configs; endpoint + timeout env |
| `secretKeyRef` | DB/Spaces on **owning** Deployments only |
| Chart `secrets.create` | Off (`false`) — secrets created by deploy scripts |
| Sealed Secrets | absent |

Mount isolation is practiced; broad SA `get/list` Secrets remains a sprawl risk.

## Ingress / TLS

Helm Ingress default **`enabled: false`** — ClusterIP gateway; private lab by default. Certificates/cert-manager/Caddy are **not** the in-chart practiced path. Do not call Ingress-off + self-signed later “prod TLS.”

## NetworkPolicy

Default-deny + allow-list toward gateway is part of lived isolation (workers must not peer `/call` by DNS). Argo namespace labels required or WT→gateway blocked.

## Failure modes

- Edit values/chart → forget regenerate → cluster drift  
- Missing Spaces keys → storage-api crash  
- Apply docs that assume committed `manifests.yaml` → file missing  
- Wrong GPU / external-LLM env → bad egress/URLs  

## Quarantine

Committed-manifests dogma · bare helm install as complete · Ingress-off called production-ready · DO registry brand as portable law ([[host-opentofu]] keeps host honesty).

## Related

- [[host-opentofu]] · [[argo-workflows]] · [[envelope-call]] · [[credential-owning-bridge]] · [[config-fail-at-load]] · [[platform-atlas]]
