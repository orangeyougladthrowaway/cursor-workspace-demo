# Remote state required for shared work — fill and uncomment ONE backend.
# See [[terraform-state-backends]] · lab zoo: [[azurerm-backend-minimal]] · [[s3-backend-lockfile]]

terraform {
  required_version = ">= 1.6.0"

  # backend "azurerm" {
  #   resource_group_name  = "rg-tfstate"
  #   storage_account_name = "sttfstate"
  #   container_name       = "tfstate"
  #   key                  = "stack.tfstate"
  # }

  # backend "s3" {
  #   bucket       = "my-tfstate"
  #   key          = "stack/terraform.tfstate"
  #   region       = "eu-west-1"
  #   use_lockfile = true
  # }
}

variable "env" {
  type = string
  validation {
    condition     = contains(["lab", "prod"], var.env)
    error_message = "env must be lab or prod."
  }
}

module "example" {
  source = "./modules/example"
  env    = var.env
}

output "env" {
  value = var.env
}
