---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[host-activation]]"
updated: 2026-07-16
---

# Host activation zoo

## When

Activating a warehouse/host release through the declared drop-zone path.

## When not

SSH hotfix DDL as the official release path.

```text
Host activation owns promote/apply ([[host-activation]]) — one lived SoT
```

## Related

- [[host-activation]] · [[single-lived-source-of-truth]]
