---
type: principle
status: canonical
description: Control and config paths have one required happy path; silent fallbacks and workarounds are not resilience.
id: engineering-knowledge-base-p-022
category: "[[failure]]"
derived_from:
  - "[[failure]]"
  - "[[fail-loud-on-control-paths]]"
  - "[[fail-at-the-gate]]"
updated: 2026-07-17
---

# Happy path only

## Statement

Control paths, configuration, and load-bearing contracts have **one** required happy path. When a required input, authority, or contract is missing or invalid, the system **fails**. Silent fallbacks, invented substitutes, dual construction paths, and “keep it up somehow” workarounds that conceal misconfiguration are **forbidden** — they are not resilience.

## Rationale

Quiet recovery invents a second truth. Operators and agents then debug a process that looks healthy while running on guesswork. Named, bounded exceptions (lab threat models, transport-only retries, explicit migrations, test doubles) stay honest; unnamed soft recovery is debt or quarantine.

## Encourages

- One construction and load path for required config and control authority
- Fail-at-load / fail-at-gate for missing or invalid required inputs
- Explicit, documented exceptions with scope and retirement bound

## Prevents

- Soft default chains that invent load-bearing values
- Dual sources of truth sold as both official
- Catch-all continue / empty-policy allow that paints green
- Immortal “legacy compat” branches with no migration owner

## Evidence (thin)

Lived pressure: empty-policy AuthZ allow, soft-merged “locked” manifests, Helm/code timeout dual defaults, CI `continue-on-error` theatre — see [[config-fail-at-load]], [[policy-ingress-contract]], [[delivery-gates]].

## Related

- Category: [[failure]]
- [[fail-loud-on-control-paths]] · [[fail-at-the-gate]]
- [[required-happy-path]] · [[happy-path-construction]]
- [[threat-model-matched-controls]] · [[single-lived-source-of-truth]]
