---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[tsql-set-based-merge]]"
  - "[[warehouse-historisation]]"
updated: 2026-07-15
---

# Merge output holdlock

## When

SCD/upsert MERGE under concurrency; observe `$action`.

## When not

Filtering the target in `ON` to “skip” rows; omitting `;`.

```sql
MERGE dbo.Target WITH (HOLDLOCK) AS t
USING src AS s ON t.bk = s.bk
WHEN MATCHED THEN UPDATE SET t.col = s.col
WHEN NOT MATCHED THEN INSERT (bk, col) VALUES (s.bk, s.col)
OUTPUT $action, inserted.bk;
```

## Related

- [[tsql-set-based-merge]] · [[kimball-type2-scd]]
