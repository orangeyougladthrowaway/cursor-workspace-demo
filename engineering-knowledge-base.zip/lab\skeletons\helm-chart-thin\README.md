---
description: Thin Helm chart skeleton — template compile honesty, not a full platform.
updated: 2026-07-15
---

# helm-chart-thin

## Purpose

Minimal chart so CI can `helm template` compile manifests.

## Required canons

- [[helm-deploy]]
- [[delivery-gates]]
- [[kubernetes-hard-way-pedagogy]] (pedagogy ≠ SoT)

## Copy steps

1. Copy `chart/` into a service repo as `deploy/chart` (or similar).
2. Set image/name in `values.yaml`.
3. CI: `helm template release ./chart -f values.yaml` (hard if you claim deployability).

## Honesty

- Hard Way labs are pedagogy — this chart is lived surface ([[hard-way-pedagogy]]).
- Prefer generated-manifest tests over lint-only green ([[manifest-test-pointer]]).
- Label lab-only values explicitly ([[values-honesty]]).
