---
type: example
status: canonical
domain: [opentofu]
derived_from:
  - "[[terraform-state-backends]]"
  - "[[host-opentofu]]"
updated: 2026-07-15
---

# Remote state required

## When

Shared stacks or CI plan/apply.

## When not

Local `terraform.tfstate` as team SoT.

```hcl
terraform {
  backend "azurerm" {
    # partial config for secrets preferred
  }
}
```

## Related

- [[terraform-state-backends]] · [[host-opentofu]]
