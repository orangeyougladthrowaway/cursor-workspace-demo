---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-013
concern: modeling
description: Cardinality test — 1:N collapses to child grain; M:N creates association grain (bridge).
domain: [warehouse]
derived_from:
  - "[[declare-the-grain]]"
  - "[[atomic-grain-first]]"
  - "[[warehouse-grain]]"
updated: 2026-07-20
---

# Grain cardinality

## Context

Designing dims/facts from related entities (often SCD2 in ODS).

## Problem

Teams either explode M:N into fact rows (wrong grain) or invent an “account-customer” fact when 1:N already lives at the child.

## Forces

- Correct measures and joins  
- Atomic preference  
- Kimball multivalued dims / bridges  

## Solution

For each legal relationship in scope:

| Cardinality | Grain outcome | Physical |
| --- | --- | --- |
| **1:1 / 1:N** (parent→child) | **Child grain** already includes parent | Fact/dim at child; parent as dim FK |
| **M:N** | **Association grain** distinct from both ends | Bridge (group key + member) and/or fact at membership grain; weights if allocating |

**Test:** if adding the other entity’s key as a free-varying column would change row cardinality for the same measurement, you are crossing grains.

Examples (fictional):

- Agreement 1—* Goods → facts at **goods** grain; agreement is a dimension key.  
- Account *—* Customer → **account–customer** membership grain (bridge); not folded into account or customer alone.

Remote: [Multivalued Dimensions and Bridge Tables](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/multivalued-dimension-bridge-table/) · [Building Bridges](https://www.kimballgroup.com/2012/02/design-tip-142-building-bridges/).

## Consequences

**Easier:** clear roll-ups from atomic child or association.  
**Harder:** bridge ETL and allocation weights.  
**Watch:** double-counting when joining bridge without weights.

## Related

- [[warehouse-grain]] · [[scd2-dim-snapshot-fact]] · [[design-warehouse-tables]] · [[dimensional-modeling-kimball]]
