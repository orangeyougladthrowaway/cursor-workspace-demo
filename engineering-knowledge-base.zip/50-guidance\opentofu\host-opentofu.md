---
type: guidance
status: canonical
id: engineering-knowledge-base-g-opentofu
concern: opentofu
description: Accumulated OpenTofu/Terraform host knowledge for gateway platforms.
domain: [opentofu, terraform]
aliases: [terraform, tofu, iac, doks]
derived_from:
  - "[[honesty]]"
  - "[[ownership]]"
  - "[[terraform-state-backends]]"
  - "[[terraform-modules-composition]]"
updated: 2026-07-16
---

# Host OpenTofu

Provisioning for gateway families. Tag knowledge `host/` — this is **practiced host**, not universal cloud law. Atlas: [[platform-atlas]]. App runtime after provision: [[helm-deploy]] or [[compose-deploy]].

## House defaults

| Concern | Prefer |
| --- | --- |
| State | remote backend + lock ([[terraform-state-backends]]); no plaintext state in VCS |
| Layout | concept modules under `infrastructure/modules/*` ([[terraform-modules-composition]]) |
| Workflow | plan then apply; do not hand-edit state JSON |
| Backend brands | azurerm / s3 practiced; GCS = Gap unless house needs (O10) |

## K8s family (K8s gateway family)

**Paths:** `infrastructure/*.tf`, `infrastructure/modules/{compute,database,kubernetes,network,registry,storage}/`

**Practiced resources (DigitalOcean-shaped):** VPC, DOKS, managed Postgres, container registry, Spaces, GPU/CPU node pools, LLM node topology flags.

**Order relative to app:** tofu apply → kubeconfig/cluster verify → k8s-setup → secrets → generate-manifests → kubectl apply → Argo templates ([[helm-deploy]], [[argo-workflows]]).

Host credentials live in `infrastructure/.env` for deploy scripts — not pod `env_file`.

## Compose families

**Paths:** `deploy/terraform/` + `deploy.sh plan|create|destroy` (dual-plane may add `workflow-bootstrap`).

Provisions the **VM / droplet** that then runs Compose. OpenTofu is the host layer; Compose is the app runtime ([[compose-deploy]]). Do not treat “K8s vs Terraform” as the choice — choice is cluster+Helm vs VM+Compose; tofu appears in both.

## Honesty

| Claim | Label |
| --- | --- |
| Lab / single stack host | practiced |
| Multi-env promo (staging/prod TF workspaces richly separated) | weak / absent |
| README “production-ready” TF defaults | claimed — challenge |
| DO resource names as engineering-knowledge-base portable law | quarantine — strip brand, keep capability classes |

**Remote pressure (OpenTofu intro · Terraform state docs · modules):** config is desired end-state; **plan then apply**; **state** binds real resources to config and is the infra SoT for drift detection. Do **not** hand-edit state JSON; use state CLI/`import` carefully. Prefer remote backends with locking when multiple operators share a stack. State often contains secrets — do not commit plaintext state to VCS. **Modules** raise abstraction (compose resources into an architectural concept); avoid thin single-resource wrappers and deeply nested module trees — lived `infrastructure/modules/{compute,database,…}` is the practiced shape.

Lived note: host credentials in `infrastructure/.env` for scripts remain practiced lab; that does not license unchecked state leakage.

## Quarantine

Elevating Spaces/DOKS/DOCR as the only cloud model · TF residue for edge/TLS claiming a working public edge when Caddy assets absent (Compose single-plane).

## Related

- [[helm-deploy]] · [[compose-deploy]] · [[platform-atlas]]
