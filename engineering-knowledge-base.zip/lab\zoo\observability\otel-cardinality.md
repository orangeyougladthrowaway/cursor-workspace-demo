---
type: example
status: canonical
domain: [observability]
derived_from:
  - "[[metrics-tracing-logging-pressure]]"
updated: 2026-07-15
---

# Otel cardinality

## When

Choosing metric attributes with bounded cardinality.

## When not

`user_id` / raw URL paths as metric dimensions.

```text
Prefer bounded attrs; watch otel.metric.overflow / cost explosions
```

## Related

- [[metrics-tracing-logging-pressure]]
