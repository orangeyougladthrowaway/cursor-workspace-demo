---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-001
concern: contracts
description: "Cross-boundary calls use one policy ingress and one versioned envelope; pods share a /call seam."
domain:
  - python
  - fastapi
aliases:
  - envelope
  - /call
  - gateway
  - ingress
  - kubernetes
  - microservices
derived_from:
  - "[[ownership]]"
  - "[[privileged-capability-boundaries]]"
  - "[[prove-honesty-contracts]]"
updated: 2026-07-15
---

# Policy ingress contract

Stack detail: [[envelope-call]] · [[gateway-auth]]. Atlas: [[platform-atlas]].

## Context

Python multi-service platforms need shared auth hooks, routing, audit correlation, and a stable wire shape — without every peer inventing HTTP dialects or talking vendor SDKs directly.

## Problem

Peer-to-peer couples trust, credentials, and error shapes; bypasses become the real architecture.

## Forces

- One place for policy and observation
- Stable contract across many capability pods
- Long-running work without a second job protocol
- Local/network convenience (compose mesh, open pod ports) vs published ingress
- Docs want YAML auth matrices; MVP wants fall-open actors

## Solution

1. **One policy ingress process** exposes `POST /call` (plus ops-only `/health`, `/metrics`).
2. Ingress runs a **layer pipe** then **forwards the same envelope** to `{target}/call` (`ServiceForwarder`). It does not own domain rules or privileged data stores (except intended side-doors like gateway→`db_api` for job/WAL resolution).
3. **One wire version:** Envelope v1 — `envelope_version="1.0"`, `kind`, `schema_version`, `trace_id`, `request_id`, `actor` (`service:*`|`user:*`), `timestamp`, `target.{service,method}`, `payload`, optional `metadata`/`tags`. Success responses carry `payload`; errors carry `{code, message, retryable}`.
4. **Homogeneous pod seam:** `@wrapper_method` + `create_service_api` → every capability exposes the same `/call` (+ `/health`/`/ready`).
5. **Shared outbound client:** `call_via_gateway` / `call_db_api` (and storage helpers) build envelopes to `GATEWAY_URL` — not raw peer DNS.
6. **Manifests** register routable `service:method` at gateway boot; unknown routes → 404 `ROUTING_ERROR`.
7. **Job correlation via headers** (`X-Job-Id`, `X-Trace-Id`, optional `X-Workflow-Name`): enables WAL when resolved; missing job id skips audit, not the call.
8. Where AuthZ is soft, **network policy / unpublished ports** are part of the lived isolation story — document them; do not pretend HTTP matrices enforce what they do not.

## Layer pipe (canonical order)

Ingress runs the same named layers everywhere; only step count/numbering and header strictness differ ([[envelope-call]] has the deploy-shape table). Canonical order:

1. Trace/job header read (`X-Trace-Id`, `X-Job-Id`, `X-Workflow-Name`, `Authorization`).
2. Optional **job resolve** — `X-Job-Id` → `DbApiClient.get_or_create_job_by_workflow_uid` → `context["job_id"]`. Failure here returns a **thin** `{detail, status:"error"}` at 502/503 **before** the envelope pipeline — not an `EnvelopeV1Response`.
3. **Authenticator** — JWT Bearer or legacy actor fallback.
4. Re-bind / **Validator** — envelope shape, `target.{service,method}`, non-empty `payload` (Validator rejects falsy/`{}` even though Pydantic alone would accept it).
5. **Authorizer** — scope/policy check (fall-open in every lived repo — see Watch).
6. **Router** — `service:method` lookup against the boot-time registry.
7. **Enricher** — stamps `received_at` / service / method / actor; does not itself set `job_id`.
8. **Observer.record_pending** — WAL insert iff a `job_id` resolved ([[write-ahead-call-audit]]).
9. **Executor.execute** — retries (`max_retries=2`, ~100ms backoff) on **any** exception, not just retryable ones — non-idempotent side effects can double-fire.
10. **ResponseHandler** — maps result to HTTP; success path returns the full `EnvelopeV1Response`; **most layer failures return the thin `{status, error:{code,message,retryable}}` shape**, not a parsed envelope.
11. **Observer.observe** — WAL update + metrics + execution log, after the response is decided.

Bypasses at every deploy shape: `GET /health`, `GET /metrics` (JSON-wrapped Prometheus text — scrape-awkward, not `text/plain`). Backend pod `/call` has **no AuthN of its own** — it trusts the network path from gateway.

## Consequences

**Easier:** Uniform callers; credential isolation at bridges; contract unit tests; one choke point for audit.

**Harder:** Extra hop; ingress is critical path; gate/error paths often return shorthand `{status,error}` not full envelopes.

**Watch:**

| Debt | Fact |
| --- | --- |
| `auth.yaml` / Authorizer | Present; `_load_auth_config` never on hot path → theatre |
| Fall-open actors | No Bearer → `service:*` scopes → allow-all (`_authorize_by_scopes` treats `service:*` as a wildcard against *any* `service:method`) |
| Empty-policy fallback | `Authorizer(policies={})` at construction ⇒ `_authorize_by_policy` returns `True` unconditionally when scopes are absent |
| Backend `/call` | No AuthN/AuthZ; trusts network |
| Legacy `{status,data}` | Outbound client rejects with `ValueError` (Compose family — both single-plane and dual-plane); K8s gateway family client may still tolerate `data` |
| Method JSON Schema / `input_schema_url` / `output_schema_url` | Declared on `@wrapper_method`; accepted then discarded — never enforced at gateway or pod |
| Static `schemas/*.schema.json` | Dual SoT vs Pydantic — e.g. actor pattern `^service:[a-z0-9_-]+$` forbids `user:` while runtime allows it; not loaded by Validator anywhere |
| Manifest ↔ wrapper drift | Surfaces at request time (404 `ROUTING_ERROR` / `NOT_FOUND`), not boot |
| Soft custom manifests | Invalid extras warn/skip (K8s soft beyond `_framework.yaml`; Compose family soft only under an unexercised `config/services/custom/`) |
| Blind Executor retries | `max_retries=2` retries **all** exceptions, including non-idempotent forward side effects |
| Unlimited forward timeout | `GATEWAY_FORWARD_READ_TIMEOUT_SECONDS` unset ⇒ unlimited read on the forward hop in every family — deliberate (enables multi-hour jobs) but a hang risk; document, don't hide |
| Dead HTTP dialect metadata | Wrapper `CallInterface.HTTP` implies per-method `/{method}` routes that are never mounted — theatre |
| 200 with `status:"error"` body | Gateway can return HTTP 200 while the envelope body says `error` (service executed, returned an error envelope) — callers must check the body, not just the status code |

## Differs by deploy shape

| Facet | K8s gateway family | Compose single-plane | Compose dual-plane |
| --- | --- | --- | --- |
| Gateway `X-Trace-Id` | Not enforced by middleware | **Required** — thin 400 if missing | **Required** — thin 400 if missing |
| Service pod headers | Looser | **Both** `X-Trace-Id` and `X-Job-Id` required at dispatch | Same lib as simple — required |
| "Locked core" manifest claim | Only `_framework.yaml` hard-fails; `core.yaml` is **soft** merge despite docs calling it locked | **All** root YAML (`core.yaml`, `bridges.yaml`) hard-fails via `strict=True` | Same as single-plane, plus `workflow.yaml` |
| Outbound default read timeout | Helm ConfigMap sets `"86400"`; code fallback `120` | `120` (env `GATEWAY_CALL_READ_TIMEOUT_SECONDS`) | `120`; frontend orchestrator caller overrides to `300` |
| Bridge count on the same spine | db-api, storage-api, pipeline workers, LLM sidecars | db_api, storage_api, inference_api, ocr_api, `<orchestrator>` | db_api (+ db_api_workflow), storage_api, inference_api, `<crm_bridge>`, `<mail_bridge>`, `<workflow-runner>`, frontend |
| Extra dual DB plane | Absent (single Postgres) | Absent (single Postgres) | **Present** — platform (`db_api`) vs workflow/product (`db_api_workflow`), see [[write-ahead-call-audit]] |

## When not this pattern

- Single-process apps with no cross-service boundary
- Public partner REST as first-class surface (this family’s public edge is frontend/SSH/edge, not open gateway REST per method)
- A second peer protocol (gRPC, per-method REST) already product-normal — that falsifies the pattern

**OpenAPI / REST spine (wide):** OpenAPI describes a language-agnostic **HTTP** surface so humans/tools can discover capabilities without reading source. Envelope v1 is an **internal** wire contract on `POST /call` — coexist: use OpenAPI (or partner REST guidelines) where the public HTTP edge is the product; do not pretend Envelope is an OpenAPI resource model, and do not dilute Envelope honesty for REST fashion.

## Examples (names vary by repo)

| Concept | Compose / dual-plane | K8s gateway family |
| --- | --- | --- |
| Envelope types | `lib/contracts/envelopes.py` | `framework/platform_core/envelopes.py` |
| Gateway app | `services/gateway/app.py` `create_integrated_app` | `framework/app.py` |
| Wrapper | `lib/runtime/decorators.py` | `framework/service_framework/wrapper.py` |
| Client | `lib/gateway_client/outbound.py` | `framework/platform_core/gateway_db_call.py` |

## Related

- [[envelope-call]] · [[gateway-auth]] · [[platform-atlas]]
- [[credential-owning-bridge]] · [[config-fail-at-load]] · [[write-ahead-call-audit]]
- [[prove-honesty-contracts]] · [[threat-model-matched-controls]]
