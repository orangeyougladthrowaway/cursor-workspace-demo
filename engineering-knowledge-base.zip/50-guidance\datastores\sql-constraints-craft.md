---
type: guidance
status: canonical
id: engineering-knowledge-base-g-sql-constraints
concern: datastores
description: How to declare and evolve tables/constraints in sqlproj without silent data-loss or grain lies.
domain: [sql-server, ssdt]
aliases: [pk-fk, check-constraint, table-design-sql]
derived_from:
  - "[[sql-code-structure]]"
  - "[[warehouse-grain]]"
  - "[[ssdt-sqlproj]]"
  - "[[scd2-dimension-envelope]]"
updated: 2026-07-20
---

# Sql constraints craft

Systems: table/constraint capability classes. Eng: **declare invariants in the model** and publish them safely.

## Build

1. Primary key matches the **declared grain** (or surrogate version key for SCD2 — natural key alone is not unique across versions).
2. Foreign keys only when both ends are in the same publishable model **or** cross-DB refs are intentional and ordered.
3. Unique constraints enforce business keys at the correct grain (landing: BK; ODS current: often filtered unique is aspirational — lived may lack single-current constraint; document [[historisation-layers]] Watch).
4. Check constraints for closed domains; prefer lookup tables when values evolve.
5. Defaults sparingly — prefer explicit inserts in load procs.

## Maintain

- Evolve via **sqlproj model** + publish profile with `BlockOnPossibleDataLoss` appropriate to the tier ([[ssdt-publish-scripts]]).
- Widening/nullability changes: plan review before apply on durable tiers.
- Do not “fix” bad data only in PostDeploy while the model claims a stricter constraint.

## SCD2-specific

Surrogate PK + `(business_key, effective_from)` uniqueness helper ≠ single-current guarantee. Enforce single-current in merge logic; treat missing DB constraint as known gap until designed.

## Related

- [[sql-programmability-craft]] · [[snapshot-fact-shape]] · [[dacpac-publish]] · [[sql-server-craft-map]]
