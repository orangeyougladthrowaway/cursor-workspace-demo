---
type: standard
status: canonical
aliases: ["capability-boundaries"]
domain: []
concern: ownership
id: engineering-knowledge-base-s-004
description: Secrets and privileged I/O stay with the smallest owning boundary; others consume via explicit contracts only.
derived_from:
  - "[[privileged-capability-ownership]]"
  - "[[domain-free-of-transport-io]]"
updated: 2026-07-13
---

# Privileged capability boundaries

## Requirement

1. Secrets, privileged persistence, and dangerous external I/O are held only by the **smallest owning boundary** that requires them.
2. Other components obtain capability through **explicit contracts** — never by sharing env/files/credentials “for convenience.”
3. Adding a new consumer of a privileged capability is an architecture change: update ownership authority, threat model, and honesty-seam checks in the **same change**.
4. Domain/business rules must not import privileged clients/SDKs ([[domain-free-of-transport-io]]).

## Derived from

- [[privileged-capability-ownership]]
- [[domain-free-of-transport-io]]

## Exceptions

Demo/local spikes may relax placement only under an explicit [[threat-model-declaration]] that declares non-production scope.

## Related

- [[threat-model-declaration]]
- [[prove-honesty-contracts-in-delivery]]
