---
type: example
status: canonical
domain: [sql-server]
derived_from:
  - "[[tsql-batch-craft]]"
updated: 2026-07-16
---

# Temp vs table var

## When

Choosing `#temp` vs `@table` for intermediate sets.

## When not

Assuming table variables always avoid logging / always outperform temp.

```sql
-- #temp: statistics, indexes possible, larger sets
-- @table: scoped, limited recompiles — measure when unsure
```

## Related

- [[tsql-batch-craft]]
