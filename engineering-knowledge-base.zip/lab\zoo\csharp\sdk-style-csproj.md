---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-project-toolchain]]"
updated: 2026-07-15
---

# Sdk style csproj

## When

Starting a tooling/library project on modern .NET SDK-style projects.

## When not

Defaulting to non-SDK Framework csproj theatre for new work.

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>
</Project>
```

## Related

- [[csharp-project-toolchain]] · [[csharp-style-conventions]]
