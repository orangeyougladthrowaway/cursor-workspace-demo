---
type: guidance
status: canonical
id: engineering-knowledge-base-g-delivery-ci
concern: delivery
description: Accumulated CI / gate honesty for platform repos.
domain: [github-actions, python]
aliases: [ci, gates, ruff, mypy]
derived_from:
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Delivery CI

Normative framing: [[delivery-gates]]. Atlas: [[platform-atlas]].

## Hard (meaningful fail)

| Check | Evidence (K8s) |
| --- | --- |
| Unit pytest | workflows without continue-on-error |
| Integration pytest | `test.yml` |
| Helm lint + generate-manifests + `tests/test_manifests.py` | hard |
| Ruff | hard on build workflow (soft on some lint jobs — **conflict**) |
| Image build | main push only |

## Soft / theatre

| Check | Mechanism |
| --- | --- |
| mypy | `\|\| true` / head truncations; `strict = true` in pyproject **conflicts** |
| Ruff on lint job | sometimes `\|\| true` + continue-on-error |
| Coverage threshold | absent — collect only |
| Codecov fail | `fail_ci_if_error: false` |
| black | dep, not gated |
| Job-resolution app tests | skipped |
| Pre-commit | absent |

Compose families: hard ruff+unit common; mypy/black/coverage soft — same honesty rule.

**Language idiom spine (wide):** PEP 8 / C# coding conventions are **style craft** — consistency beats personal taste; automated formatters/linters encode the house dialect. Elevate only as gate honesty (hard vs soft ruff/analyzers), not as textbook language dumps into engineering-knowledge-base.

## Local

```bash
pytest tests/unit -q
ruff check .
# mypy soft-spirit matches CI — do not claim hard typing
```

## Quarantine

Soft mypy/cov as “quality bar met” · skipped contract tests as coverage · README strict typing vs soft CI.

## Collision — SE@Google CI pressure (D2 #16)

Lived soft/theatre checks violate remote CI pressure that feedback be early **and** honest ([[delivery-gates]] §12–15). Soft mypy on every PR is neither a fast reliable gate nor an actionable quality signal — migrate or label; do not cite green as typed.

## Related

- [[delivery-gates]] · [[pytest-practices]] · [[helm-deploy]] · [[envelope-call]] · [[platform-atlas]] · [[delivery-atlas]]
