---
type: standard
status: canonical
domain: []
concern: policy
id: engineering-knowledge-base-s-005
description: Changeable policy lives in explicit validated artefacts with one load/compile path — not scattered literals.
derived_from:
  - "[[policy-as-explicit-artefact]]"
  - "[[single-authority-for-documentation]]"
updated: 2026-07-17
---

# Policy as artefact

## Requirement

1. Product/platform policy that changes faster than code structure (rules, thresholds, registries, auth matrices, prompts-as-policy, feature tables) lives in **explicit artefacts** (config/schema/data), not duplicated call-site literals.
2. There is **one** authoritative load or compile path for each policy set; invalid **core** policy **fails at the gate** ([[fail-at-the-gate]], [[required-happy-path]]). Soft extension paths must be **named** — docs must not call soft-merged files “locked” when the loader does not hard-fail them ([[config-fail-at-load]], [[gateway-auth]]).
3. Policy meaning is documented in a single authority note or generated from the artefact under [[single-authority-for-documentation]].
4. Changing policy does not require forking business logic modules when an artefact edit suffices.
5. Artefacts that nothing on the hot path loads (`auth.yaml` theatre, unused JSON Schema next to Pydantic, decorator schema URLs discarded) are **documentation or scaffolding**, not architecture — label them until wired.

## Derived from

- [[policy-as-explicit-artefact]]
- [[single-authority-for-documentation]]

## Exceptions

True one-off constants with no change expectation may remain in code if named and justified; promote to artefacts at second change.

## Related

- [[config-fail-at-load]] · [[gateway-auth]] · [[single-lived-source-of-truth]]
- [[extend-by-established-patterns]] · [[fail-at-the-gate]] · [[required-happy-path]] · [[happy-path-construction]]
