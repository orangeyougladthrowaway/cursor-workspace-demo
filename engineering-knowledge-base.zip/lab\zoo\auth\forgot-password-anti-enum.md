---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[owasp-forgot-password-pressure]]"
  - "[[gateway-auth]]"
updated: 2026-07-15
---

# Forgot password anti enum

## When

Forgot-password responses must not reveal account existence.

## When not

Different messages/timing for known vs unknown emails.

```text
Always generic: "If the account exists, we sent mail."
Same status / approximate timing for unknown users.
```

## Related

- [[owasp-forgot-password-pressure]] · [[owasp-authentication-pressure]] · [[gateway-auth]]
