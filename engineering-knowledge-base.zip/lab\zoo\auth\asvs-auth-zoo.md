---
type: example
status: canonical
domain: [auth]
derived_from:
  - "[[asvs-authentication-mapping]]"
updated: 2026-07-16
---

# Asvs auth zoo

## When

Tracing auth requirements to ASVS mappings.

## When not

Claiming ASVS-complete without mapped controls.

```text
ASVS auth mapping → [[asvs-authentication-mapping]]
```

## Related

- [[asvs-authentication-mapping]] · [[threat-model-matched-controls]]
