---
type: catalog
status: canonical
id: engineering-knowledge-base-cat-workflows
description: Workflow inventory by concept folder.
updated: 2026-07-20
---

# Catalog — Workflows

| Concept | Notes |
| --- | --- |
| knowledge | [[knowledge-ingestion]], [[praxis-ingestion]], [[common-case-coverage]], [[coding-agent-projection]], [[ingest-coverage]], [[d1-deep-harvest-playbook]], [[post-capture-review]], [[tooling-proficiency]], [[vault-health-checks]] |
| delivery | [[plan-engineering-change]], [[build-engineering-change]], [[review-engineering-change]] |
| testing | [[verify-engineering-change]] |
| modeling | [[design-warehouse-tables]] |
