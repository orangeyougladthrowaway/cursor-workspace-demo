---
type: example
status: canonical
domain: [packaging]
derived_from:
  - "[[domain-io-edge-packaging]]"
updated: 2026-07-16
---

# Domain io edge zoo

## When

Keeping IO adapters as optional packaging edges.

## When not

Requiring every adapter in the core runtime.

```text
core ↔ optional extras for IO edges ([[domain-io-edge-packaging]])
```

## Related

- [[domain-io-edge-packaging]] · [[service-packaging]]
