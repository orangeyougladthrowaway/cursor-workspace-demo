---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-style-pep8]]"
  - "[[delivery-gates]]"
updated: 2026-07-16
---

# Style lint honesty

## When

Claiming consistent Python style in CI.

## When not

Formatter/linter soft-skipped while “style required” is marketed.

```text
ruff check / ruff format — hard if you claim style
ANTI: ruff … || true with a quality Done story
```

## Related

- [[python-style-pep8]] · [[delivery-gates]] · [[soft-mypy-anti]]
