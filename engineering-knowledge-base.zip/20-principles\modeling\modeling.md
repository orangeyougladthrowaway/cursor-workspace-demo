---
type: category
status: canonical
id: engineering-knowledge-base-cat-modeling
description: Category spine — warehouse/data modeling constraints (grain, dims, facts).
updated: 2026-07-20
---

# Modeling

## Theme

Warehouse and domain models stay usable only when **grain** and column shapes are declared before DDL and loads.

## Belongs here

Principles about declaring grain, atomic preference, and column laws for dimensional serving.

## Does not belong here

ODS merge craft ([[historisation-layers]]); Python ingest ([[python-ingest]]); CI gates ([[delivery-gates]]).

## Leaves

- [[declare-the-grain]]
- [[atomic-grain-first]]
