---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-async-di]]"
updated: 2026-07-16
---

# Await using dispose

## When

Async resources implement `IAsyncDisposable`.

## When not

Forgetting dispose on HttpResponse/streams in hot paths.

```csharp
await using var stream = await OpenAsync(ct);
await ProcessAsync(stream, ct);
```

## Related

- [[csharp-async-di]]
