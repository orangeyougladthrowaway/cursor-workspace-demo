---
type: map
status: canonical
id: engineering-knowledge-base-map-infra
concern: infrastructure
description: Theme atlas — containers, K8s pedagogy, TF modules/backends beyond lived host.
domain: []
aliases: [docker, kubernetes, terraform, opentofu]
updated: 2026-07-19
---

# Atlas — Infrastructure

Host, containers, cluster pedagogy, and IaC composition. Index only.

## Canonical (D1 #7 + D2 #10/#15)

- [[terraform-state-backends]] · [[terraform-modules-composition]] · [[docker-containers]]
- Pedagogy (not SoT): [[kubernetes-hard-way-pedagogy]]
- Lived: [[host-opentofu]] · [[compose-deploy]] · [[helm-deploy]] · [[service-packaging]]

**Navigation tip:** image/process craft lives in [[docker-containers]]; extras-by-role and fat-image quarantine in [[service-packaging]]; lab/VM packaging + per-service secrets in [[compose-deploy]]. Start at the question, not the first Docker link. Secret ownership pattern: [[credential-owning-bridge]]. Multi-hop `/call` diagnosis: [[envelope-call]] (observability theme).

## Deep backlog (D2+)

GCS backend · Hard Way labs · CNCF courses · Docker networking deep.

## Related

- [[catalog-maps]] · [[platform-atlas]] · [[security-atlas]] · [[observability-atlas]] · [[delivery-atlas]] · [[data-atlas]]
