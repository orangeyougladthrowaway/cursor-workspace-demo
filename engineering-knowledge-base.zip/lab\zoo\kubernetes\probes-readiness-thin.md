---
type: example
status: canonical
domain: [kubernetes]
derived_from:
  - "[[helm-deploy]]"
updated: 2026-07-16
---

# Probes readiness thin

## When

Separating readiness from liveness for traffic/safety.

## When not

Liveness that kills pods on transient dependency blips.

```yaml
readinessProbe:
  httpGet: { path: /ready, port: 8080 }
livenessProbe:
  httpGet: { path: /health, port: 8080 }
```

## Related

- [[helm-deploy]] · [[docker-containers]]
