---
type: category
status: canonical
description: Spine for authority — each concept has one home; behaviour stays with its authoritative note.
id: engineering-knowledge-base-cat-006
derived_from:
  - "[[accountable-meaning-under-change]]"
updated: 2026-07-13
---

# Authority

## Theme

Each concept or contract has **one authoritative home**. Behaviour and its explanation must not fork into tribal lore or parallel markdown mythologies.

## Belongs here

Single source of truth for meaning, co-updating authority with behaviour, generated truth where humans will not keep docs fresh.

## Does not belong here

Policy artefact mechanics as change practice ([[change]]); vault how-to (`00-foundation`).

## Leaves

- [[colocated-authority]]
