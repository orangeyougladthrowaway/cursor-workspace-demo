---
type: guidance
status: canonical
id: engineering-knowledge-base-g-sql-flow
concern: languages
description: SQL flow choices — sets before rows; predicates, CASE, CTEs, materialisation, windows, and bounded procedural flow.
domain: [sql-server, t-sql, postgres]
aliases: [set-based, cte, cursor]
derived_from:
  - "[[readable-control-flow]]"
  - "[[tsql-set-based-merge]]"
  - "[[postgres-sql-craft]]"
  - "[[restraint]]"
updated: 2026-07-16
---

# SQL flow choices

## Applies when

Choosing between relational, procedural, and materialised SQL forms in T-SQL or Postgres.

## House defaults

### Relational before procedural

1. Prefer set-based `SELECT`/DML over row-by-row cursors or loops.
2. Use `WHERE` to remove rows, `CASE` to choose a value per row, and `IF` for batch-level alternatives.
3. Use `EXISTS` for existence questions; do not count all matching rows only to test whether one exists.
4. Use joins for relationships; use correlated subqueries when they state the local question more clearly and plans remain sound.
5. Use aggregation when collapsing row grain; use window functions when retaining rows while computing across a partition.

### Inline, CTE, temporary materialisation

| Need | Prefer |
| --- | --- |
| Small expression used once | inline/subquery |
| Named logical phase used once | CTE |
| Reuse, indexing, statistics, debugging boundary, or large phase break | temporary table/materialisation |
| Typed client-to-T-SQL rowset | TVP ([[tsql-batch-craft]]) |
| Tiny T-SQL intermediate with understood estimates | table variable; do not assume it equals a temp table |

A CTE improves naming, not automatically performance. Materialise only for a named planning, reuse, or ownership reason.

### Branching and guards

Validate required parameters and impossible states before opening a transaction when possible. Keep normal set logic continuous; avoid deeply nested `IF` trees that reproduce relational predicates procedurally.

Use a cursor/`WHILE` only when work is inherently sequential, externally effectful, or cannot be expressed safely as a set. Document why and bound/restart the operation.

### Transactions, errors, dynamic SQL

Keep transactions as short as correctness permits. Propagate errors; do not catch and report success. T-SQL uses `TRY/CATCH` + `XACT_STATE()` discipline ([[tsql-batch-craft]]); Postgres transaction/isolation semantics remain [[postgres-wal-concurrency]].

Prefer static SQL. When statement shape/object identity must vary, whitelist/quote identifiers and parameterise values. Never concatenate untrusted values ([[tsql-batch-craft]]).

## Performance

Use actual plans (`EXPLAIN (ANALYZE, BUFFERS)` where safe; SQL Server actual plan) before rewriting readable SQL. Measure row estimates, scans, joins, spills, and repeated work rather than assuming a syntactic form is faster.

## Related

- [[sql-code-structure]] · [[tsql-set-based-merge]] · [[tsql-batch-craft]] · [[postgres-sql-craft]] · [[postgres-wal-concurrency]] · [[languages-atlas]]
