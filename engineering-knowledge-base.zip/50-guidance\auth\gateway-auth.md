---
type: guidance
status: canonical
id: engineering-knowledge-base-g-auth
concern: auth
description: Accumulated auth/AuthZ and manifest-policy honesty for gateway platforms.
domain: [python, kubernetes]
aliases: [authz, rbac, auth.yaml, jwt]
derived_from:
  - "[[threat-model-matched-controls]]"
  - "[[config-fail-at-load]]"
updated: 2026-07-15
---

# Gateway auth

Atlas: [[platform-atlas]]. Wire gate: [[envelope-call]].

## Manifests as route registry

YAML under `config/services/*.yaml` (K8s) registers `service:method` at gateway boot.

| File class | Fail behaviour (K8s) |
| --- | --- |
| `_framework.yaml` | Invalid → hard `ValueError` |
| Missing `_framework.yaml` | Skipped (no hard fail) |
| `core.yaml`, product YAML | Invalid → warn + continue (**soft**) |

Docs often call `core.yaml` “locked”; **runtime hard-fail authority is `_framework.yaml`**. Compose families typically hard-fail more root YAML files (dual-plane/single-plane: root manifests including bridges/workflow YAML).

Validation is structural (`services` + `service_name`), not deep JSON Schema on methods/ports.

## auth.yaml theatre

`config/auth.yaml` (callers, rbac_policies, service_trust) exists. **Authorizer hot path does not load it** (`_load_auth_config` unused by `authorize()`). Treat as theatre unless/until wired.

## AuthN path

1. If Authenticator disabled → allow (tests).  
2. If `Authorization: Bearer` → JWT attempt (keys often unset/off in chart).  
3. Else → legacy `_authenticate_actor` requiring `service:`/`user:` actor → grants wild scopes (`service:*`).

Argo / many callers send **no Bearer** — lived mesh depends on actor fall-open + NetworkPolicy.

## AuthZ path (fall-open)

Authorizer constructed with empty policies in app: `if not self.policies: return True`. Scopes `service:*` / `*` allow all methods. **Internal traffic is effectively fall-open HTTP AuthZ.**

## Isolation that actually works

| Control | Label |
| --- | --- |
| NetworkPolicy default-deny + gateway allow-list | practiced (K8s) |
| Unpublished Compose ports / SSH tunnel | practiced (Compose) |
| JWT keys / auth.yaml matrices | off / theatre |
| Shared SA `get/list` Secrets | practiced risk |
| Compose universal `env_file` | practiced anti-pattern ([[compose-deploy]]) |

Threat model: **lab-friendly fall-open AuthZ + network containment**, not mTLS zero-trust. Document honestly ([[threat-model-declaration]]).

## OWASP spine (wide pass)

Pressure from Authentication / Session Management cheat sheets and Top 10:2021 — not a full control catalogue:

| Theme | Implication for this family |
| --- | --- |
| **AuthN ≠ AuthZ ≠ session** | Three separate concerns that must be wired deliberately. Actor-string “auth” without a real AuthZ decision is not three-legged security. |
| **A01 Broken Access Control** | Empty policies / `service:*` fall-open is exactly access-control failure if the threat model claims “secured API.” Lab models must name fall-open + NetworkPolicy (or unpublished ports) as the pair. |
| **A07 Identification & Authentication Failures** | JWT-off + unused `auth.yaml` = authentication theatre — quarantine, don’t market as MFA/JWT posture. |
| **A05 Security Misconfiguration** | Soft/unlocked auth knobs and shared SA secret sprawl are misconfiguration risks — label them. |
| **Session/token ≡ AuthN strength** | After AuthN, bearer/session tokens are as powerful as the login method. Protect transit; do not treat fall-open scopes as “authenticated privilege.” |
| **No backend admin identities on public front doors** | Aligns with credential-owning edges ([[credential-owning-bridge]]) — do not expose DB/IdP break-glass via the gateway UI/mesh. |

Defer deep OWASP (password storage, full session cookie flags, MFA sheet, Top 10 control recipes) to Security D* / later W deepen.

## Quarantine

auth.yaml as enforced RBAC · fall-open as “secured API” · shared basic auth / self-signed TLS as prod · missing-policy allow-all presented as convenience virtue · claiming OWASP compliance without a matching threat model.

## Related

- [[envelope-call]] · [[helm-deploy]] · [[compose-deploy]] · [[credential-owning-bridge]] · [[delivery-gates]] · [[platform-atlas]]
