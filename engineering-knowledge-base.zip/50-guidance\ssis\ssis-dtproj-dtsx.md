---
type: guidance
status: canonical
id: engineering-knowledge-base-g-ssis-dtproj
concern: ssis
description: SSIS project craft — dtproj, dtsx, ispac build/deploy, vs SSDT sqlproj and house warehouse SQL.
domain: [sql-server, ssis]
aliases: [dtproj, dtsx, ispac, integration-services-project]
derived_from:
  - "[[historisation-layers]]"
  - "[[compiled-schema-release]]"
  - "[[fail-at-the-gate]]"
updated: 2026-07-20
---

# Ssis dtproj dtsx

## Applies when

Building or maintaining Integration Services projects (package ETL) alongside or instead of T-SQL warehouse loads.

## Artefact roles

| Artefact | Role |
| --- | --- |
| `.dtproj` | IS **project** file — packages list, configs, target server version, project params |
| `.dtsx` | **Package** XML — control flow + data flow |
| `.ispac` | **Project deployment** unit for SSIS Catalog (SSISDB) |
| Legacy `.dtsConfig` / file deploy | Package deployment model — prefer catalog understanding for modern estates |

Product catalog/deploy mechanics: systems-knowledge-base `ssis-deployment-build` · `ssis-catalog-model` (read-only). This note owns **engineering build/maintain**.

## Contrast with sqlproj

| Concern | Database project | SSIS project |
| --- | --- | --- |
| Project file | `.sqlproj` | `.dtproj` |
| Unit of work | Declarative objects → `.dacpac` | Packages → `.ispac` |
| Deploy tool | SqlPackage | Catalog deploy / SSISDeploy / SSMS wizard |
| CI agent | `dotnet build` common | Often needs VS+SSIS extension **or** SSIS DevOps standalone tools |
| House default warehouse path | SQL procs + dacpac ([[historisation-layers]]) | Optional; do not invent SSIS as SoT when SQL owns Stage→ODS→DWH |

## Build / deploy (project model)

```text
Author (.dtproj + .dtsx)
  → Build → .ispac
  → Deploy to SSISDB folder
  → Configure environments/parameters
  → Execute (catalog / Agent / API)
```

Remote pressure: [SSIS projects](https://learn.microsoft.com/en-us/sql/integration-services/integration-services-ssis-projects-and-solutions) · [Deploy SSIS projects](https://learn.microsoft.com/en-us/sql/integration-services/packages/deploy-integration-services-ssis-projects-and-packages) · [SSIS DevOps overview](https://learn.microsoft.com/en-us/sql/integration-services/devops/ssis-devops-overview).

## Maintain

1. Prefer **project deployment model** (ispac → catalog) over scattering dtsx+configs.
2. Parameters/environments for connection strings — not hardcoded package passwords in source.
3. Version packages with the project; catalog retains versions until purged (ops policy).
4. CI: name whether build uses full VS+SSIS designer or standalone SSIS Build/Deploy tools; gate ispac produce + catalog deploy validation.
5. Do not paste package XML dumps into knowledge vaults; keep craft here, inventory Gaps in systems-KB.

## Refuse

- Treating `.dtproj` as a dacpac substitute for schema
- Silent dual SoT (SSIS package SCD2 **and** SQL StageToODS) without named ownership
- Agent-only deploy with no artefact in source control

## Related

- [[ssdt-sqlproj]] · [[historisation-layers]] · [[python-ingest]] · [[sql-server-craft-map]] · [[warehouse-atlas]]
