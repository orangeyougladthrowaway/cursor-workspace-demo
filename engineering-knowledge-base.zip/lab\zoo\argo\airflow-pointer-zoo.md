---
type: example
status: canonical
domain: [argo]
derived_from:
  - "[[airflow-dag-orchestration]]"
updated: 2026-07-16
---

# Airflow pointer zoo

## When

Airflow is considered for scheduling.

## When not

Treating Airflow as warehouse historisation law.

```text
Pointer: [[airflow-dag-orchestration]] — prefer house SoT (Argo/SQL) when already lived
```

## Related

- [[airflow-dag-orchestration]] · [[argo-workflows]]
