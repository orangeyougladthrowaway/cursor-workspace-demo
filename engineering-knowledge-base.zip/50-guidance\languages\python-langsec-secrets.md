---
type: guidance
status: canonical
id: engineering-knowledge-base-g-py-langsec
concern: languages
description: Python language-level secrets — secrets module over random; token size; constant-time compare.
domain: [python]
aliases: [secrets, tokens]
derived_from:
  - "[[trust]]"
  - "[[honesty]]"
  - "[[python-errors-resources]]"
  - "[[owasp-forgot-password-pressure]]"
updated: 2026-07-16
---

# Python langsec secrets

Primary (L+): [`secrets` — secure random](https://docs.python.org/3/library/secrets.html) (PEP 506).

## Applies when

Generating reset tokens, API secrets, hard-to-guess URLs, or comparing secrets in Python.

## Does not apply when

Password storage (hashing) — that is [[owasp-password-storage-pressure]], not `secrets`.

## House defaults

1. Use **`secrets`**, not `random`, for security-sensitive randomness.
2. Prefer `token_urlsafe` / `token_hex` / `token_bytes`; **~32 bytes (256 bits)** as the common sufficiency bar unless a threat model says otherwise.
3. Compare with **`secrets.compare_digest`** — not `==`.
4. Never log raw tokens; redact at the logging edge ([[python-logging-modeling]], [[metrics-tracing-logging-pressure]]).
5. Passwords: hash (Argon2/bcrypt family per OWASP) — this module does not replace hashing.
6. No “safe pickle” for untrusted blobs.

## Untapped

`tempfile` hygiene · safe YAML/JSON load · `hashlib`/`hmac` recipes · cryptography library deep.

## Related

- [[owasp-forgot-password-pressure]] · [[owasp-password-storage-pressure]] · [[python-errors-resources]] · [[languages-atlas]]
