---
type: category
status: canonical
description: Spine for change — policy and extensions stay explicit and pattern-aligned.
id: engineering-knowledge-base-cat-004
derived_from:
  - "[[accountable-meaning-under-change]]"
updated: 2026-07-13
---

# Change

## Theme

Behaviour must be able to change without forking meaning. Changeable policy lives in **explicit artefacts**; new work **extends established patterns** unless a decision says otherwise.

## Belongs here

Config/policy-as-data, pattern continuity, intentional forks vs drive-by redesign (including AI-assisted edits).

## Does not belong here

Where docs live (see [[authority]]); tool accumulation (see [[restraint]]).

## Leaves

- [[policy-as-explicit-artefact]]
- [[extend-established-patterns]]
