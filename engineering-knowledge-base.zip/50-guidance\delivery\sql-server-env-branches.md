---
type: guidance
status: draft
id: engineering-knowledge-base-g-sql-env-branches
concern: delivery
description: Operable SQL Server product env branches, release assembly, conflict sync, and rollback.
domain: [sql-server]
aliases: [dev-uat-prod-branches, release-train, sql-promotion]
derived_from:
  - "[[sql-env-release-assembly]]"
  - "[[compiled-schema-release]]"
  - "[[schema-change-models]]"
  - "[[single-lived-source-of-truth]]"
updated: 2026-07-20
---

# Sql server env branches

## Applies when

Operating a **SQL Server product** repo with persistent **DEV / UAT / PROD** instances and PR-gated long-lived branches. Pattern: [[sql-env-release-assembly]].

## Does not apply when

- Knowledge-base / harness repos (those stay short-lived `feature/*` → `main` — see sibling agent-harness `docs/source-control.md`)
- Demo idempotent `.sql` trees without env branches (explicit exception, not this law)

## Branch and instance map

| Git branch (persistent, PR-gated) | Instance | May deploy |
| --- | --- | --- |
| `dev` | DEV | Tip of `dev` (sandbox / early integrate — **not** release membership SoT) |
| `uat` | UAT | Tip of `uat` after release merge |
| `prod` | PROD | Tip of `prod` after promote |
| `feature/<name>` | (none required) | Local / optional DEV sandbox only until selected |
| `release/<name>` | (via merge to uat) | Assembly line only — delete after ship |
| `hotfix/<name>` | → prod path | Cut from `prod` for production fixes |

Named instance inventory is **systems-knowledge-base** lived fact (often Untapped) — do not invent hostnames here.

## Guidance

### Feature work

1. Branch `feature/<name>` from latest **`prod`** (pick-and-choose baseline). Regularly **merge `prod` into the feature** (and merge `dev` into the feature if you use the sandbox) before assembly or before PR to `dev`.
2. Prefer short-lived features; long isolation increases release-time conflict cost.
3. Optional: PR → `dev` for early integration on DEV instance. That does **not** enrol the feature in the next release.
4. Before release assembly: ensure the feature tip builds (sqlproj Release) and is reviewed.

### Release assembly (pick-and-choose)

1. Cut `release/<name>` from **`prod`**.
2. Merge **selected** `feature/<a>`, `feature/<c>`, … tips into `release/<name>` (not cherry-pick commit lists).
3. Resolve conflicts on the release branch; rebuild dacpacs from that tip.
4. PR `release/<name>` → **`uat`**. Merge only with approval + CI compile green.
5. Publish to **UAT** with UAT publish profile ([[ssdt-publish-scripts]] · [[dacpac-publish]]). Prove.
6. PR **`uat` → `prod`** (or equivalent promote of the same release tip — name one house path and keep it).
7. Publish to **PROD** with prod profile (`BlockOnPossibleDataLoss=True`, no lab destructiveness).
8. Back-merge shipped commits into `dev` (if retained). Refresh open features from `prod`.
9. Delete `release/<name>`.

### Hotfix

1. Cut `hotfix/<name>` from `prod`.
2. PR → `prod` (and publish PROD) when approved.
3. Back-merge into `uat` and `dev` and open release/feature tips as needed so lower envs are not permanently behind a prod-only fix.

### Conflict handling

| Situation | Do |
| --- | --- |
| Feature diverged from `prod` | Merge `prod` into feature before assembly or before PR to `dev` |
| Two features both touch same objects | Surface on release assembly merge; fix on release or re-sequence trains |
| Shared remote feature branch | Prefer **merge** over rebase rewrite |
| Private local-only branch | Rebase onto `prod` allowed if not shared |

### Rollback

| Plane | Move | Caveat |
| --- | --- | --- |
| Git on `dev` / `uat` | `git revert` of merge commit(s) on shared branches | Do not rewrite shared history |
| UAT schema wrong, prod good | Republish **prod tip** (or last-good prod artefact) to UAT with UAT profile — “restore UAT toward prod” means **artefact republish**, not silent DB file restore unless data plane also requires it |
| Prod schema/data | Prefer forward-fix; controlled restore per systems RPO/backup doctrine — git revert alone does not undo data |

### Schema model coupling

Default publish path is **state-based** sqlproj ([[schema-change-models]] · [[compiled-schema-release]]). Assembly chooses **which tip** to build; SqlPackage applies that model to the instance.

## Refuse

- Cherry-pick-from-clogged-`dev` as standard membership selection
- Deploying an instance from a branch that was not PR-merged into that env line
- Lab destructive publish profiles on UAT/PROD
- Inventing systems instance names in this note

## Related

- [[sql-env-release-assembly]] · [[schema-change-models]] · [[compiled-schema-release]] · [[ssdt-publish-scripts]] · [[dacpac-publish]] · [[delivery-gates]] · [[sql-server-craft-map]] · [[warehouse-atlas]] · [[delivery-atlas]]
