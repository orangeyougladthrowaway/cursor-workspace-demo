---
type: pattern
status: canonical
id: engineering-knowledge-base-pat-002
concern: ownership
description: "Privileged capabilities owned by bridge pods; peers call via envelope. Code isolation practiced; Compose env often conflicts."
domain:
  - python
aliases:
  - bridge
  - secrets
  - credential-isolation
derived_from:
  - "[[privileged-capability-boundaries]]"
  - "[[privileged-capability-ownership]]"
updated: 2026-07-19
---

# Credential-owning bridge

## Context

DB, object store, inference, SaaS, and local tools must serve many workflows without every pod holding every secret or SDK.

## Problem

Shared `.env` / broad secret mounts turn “ownership” into theatre even when import paths look clean. Fail-closed credential checks in a **non-owner** process (e.g. orchestrator validating SaaS OAuth env it never receives) produce the same theatre as broad mounts — the call path 500s even when the integration is meant to be skippable.

## Forces

- Blast-radius isolation (code + deploy)
- Same `/call` seam as domain services
- Compose loves one fat `.env`; Helm can mount secrets per Deployment
- Local tools (Tesseract, llama) need ownership without cloud secrets
- Optional third-party integrations need an explicit enable/skip decision without forcing every peer to hold owner secrets

## Solution

1. Each privileged capability has a **smallest owning component** (bridge/service image).
2. Only that component’s **code** imports the vendor/local SDK and reads the credential env vars.
3. **Fail-closed credential validation lives only on the owner** — the process that receives the secrets. Non-owners must not require those env vars to exist.
4. Everyone else requests the capability through the **shared call contract** (`call_via_gateway` / helpers) — never by importing the SDK.
5. Bridges speak the **same** `@wrapper_method` + `create_service_api` seam; gateway forwards like any other service.
6. Deploy must **not** rebroadcast owner secrets to all services — treat Compose shared `env_file` and shared K8s SA Secret RBAC as **conflicts** when present, not as the pattern. Prefer per-service `environment:` / sliced env files ([[compose-deploy]]).
7. Own local capabilities the same way (OCR binary, model filesystem) even without cloud keys.
8. **Optional integrations:** the owner fail-closes when the integration is **enabled** and secrets are missing/invalid. When a named feature flag disables the integration (orchestrator/routing owns the flag only — [[in-process-orchestration]]), peers must **skip-closed**: complete the happy path with an explicit structured skip (reason named), not a half-fail across the gateway. Never validate owner secrets in a process that never mounts them.

## Trust map

| Capability | Typical owner | Credential env (names vary) | Peers must |
| --- | --- | --- | --- |
| Postgres / audit / WAL | `db_api` (`services/audit_db/` or `framework/db_api/`) | `DATABASE_URL` / `DB_PASSWORD` | `call_db_api` / gateway |
| Postgres / product plane (dual-plane only) | `db_api_workflow` (`services/workflow_db/`) | `WORKFLOW_DATABASE_URL`, `FRONTEND_DATABASE_URL` (± fallback to `DATABASE_URL`) | orchestrator, frontend, demos |
| Object store (Spaces) | `storage_api` | `SPACES_*` | storage helpers / gateway |
| Cloud inference | `inference_api` | `DO_INFERENCE_URL` / `_API_KEY` / `_MODEL`; K8s: `LLAMA_SERVER_URL_*` | gateway |
| SaaS CRM | `<crm_bridge>` (dual-plane only; optional product bridges same rule) | CRM client id/secret/refresh (+ region) — **validated here when enabled** | gateway; orchestrator owns enable/skip flag only |
| Mail (SMTP → lab mail sidecar) | `<mail_bridge>` (dual-plane only) | mail-lab env keys | gateway (`generate_mail`) |
| OCR / local vision | `ocr_api` (Tesseract, no cloud secret) | none | gateway |
| GPU / local LLM | K8s `llm-*-api` + llama-server sidecars | GGUF emptyDir / public HTTPS artifact URLs | gateway |
| Orchestration (owns no vendor SDK in the happy path) | `<workflow-runner>` / `<orchestrator>` | `DEMO_WEBHOOK_TOKEN` (dual-plane); **optional-integration flags** (names product-local) — **not** CRM/Spaces/DB secrets | frontend / Argo |

**Frontend (dual-plane):** practiced clean isolation — no shared `env_file`, only `GATEWAY_URL` + `DEMO_WEBHOOK_TOKEN`. Treat as the exemplar for Compose env hygiene; every other Compose service in the same repo still gets the full `.env` via `env_file: ../../.env`, so the exemplar is one service, not the family norm.

### How to add a bridge (lived checklist, merged across families)

1. Package under the owner's own tree — `services/bridges/<name>/` (Compose families) or `framework/<bridge>/` (K8s) — with `@wrapper_method` + `create_service_api`/`main.py`.
2. Add an optional-extra in `pyproject.toml` and a Dockerfile that installs that extra **plus** any OS packages the local tool needs (for OCR: engine package **and** language/data packs selected by product config). Python extras alone are not a complete local-tool runtime ([[service-packaging]], [[docker-containers]]); COPY only the owner's package tree, not the whole monorepo's vendor code.
3. Register `service_name` + methods in the owning manifest (`config/services/bridges.yaml`/`core.yaml` or `config/services/_framework.yaml`) — put load-bearing methods in a **hard-loaded** file ([[config-fail-at-load]]).
4. Wire the endpoint: Compose service + `SERVICE_ENDPOINTS`/`_SERVICE_ENDPOINT_KEYS` entry in `service_forwarder.py`, or Helm Deployment/Service + shared ConfigMap entry.
5. Mount the credential **only** on this component: Compose `environment:` interpolation (accept that `env_file` still rebroadcasts the rest of `.env` unless you fix the sprawl — don't claim isolation you haven't built); Helm `secretKeyRef` on this Deployment only (this is the practiced least-privilege case).
6. Network-restrict: K8s default-deny NetworkPolicy + allow-list to gateway; Compose keeps the bridge unpublished (`expose`, not `ports`).
7. Peers call through `call_via_gateway` / storage helpers only — never import the vendor SDK from outside the bridge.
8. CI image matrix row; unit-test the wrapper/dispatch happy path.

## Consequences

**Easier:** Reviewable trust map; swap providers behind one method surface; extras (`[db]`, `[storage]`) match images.

**Harder:** More images; every external quirk becomes an RPC surface.

**Watch:**

| Conflict | Where |
| --- | --- |
| `env_file: ../../.env` on nearly all services | Compose dual-plane + single-plane |
| Helm env mounts isolated; shared SA can still `get`/`list` Secrets | K8s gateway family — breaks least privilege as absolute doctrine |
| Fat workflow image installs `[db,storage,inference,…]` extras it never SDK-calls | Compose `<orchestrator>` (single-plane), `<workflow-runner>` (dual-plane) |
| Domain holds inference HTTP directly (`call_do_inference` / `domain/<product>/metadata_json.py`) | dual-plane `domain/<product>/inference.py`; single-plane `domain/<product>/metadata_json.py` → `gateway_client.storage.get_bytes` |
| Docs claim “only bridge has credentials” while env rebroadcasts | Compose family (both single-plane and dual-plane) |
| Legacy privileged clients still importable | `framework.core.db_client.PostgreSQLClient` / `storage_client.StorageClient` remain exported alongside logging helpers in K8s `framework/core` — confuses the ownership story even though no peer imports them |
| Frontend as the isolation exemplar, not the norm | Only dual-plane `apps/web` skips `env_file`; every sibling Compose service (gateway, bridges, orchestrator) still gets the full `.env` |
| Slim OCR image ships engine but not config-selected tessdata | `ocr_api` — config can ask for a traineddata lang (e.g. `eng`, `deu`, `jpn_vert`, …) while the image only ships a subset (often default `eng`/`osd`); verify with list-langs / missing-traineddata; fix in Dockerfile + rebuild, not ephemeral container apt |
| Non-owner fail-closes on absent third-party secrets | Orchestrator (or any peer) checks SaaS/OAuth env it never receives → 500 even when the integration flag says skip; validation ownership must equal credential ownership |
| Enabled integration without secrets on owner | Bridge must fail closed; do not soft-succeed a push that never authenticated |

## Differs by deploy shape

| Facet | K8s gateway family | Compose single-plane | Compose dual-plane |
| --- | --- | --- | --- |
| Secret mount mechanism | Helm `secretKeyRef` per Deployment — **practiced least-privilege** | Compose `environment:` `${VAR:?}` interpolation from one shared `.env` | Same as single-plane |
| Env isolation reality | Mounts are scoped; SA `get`/`list` Secrets is the real leak vector | `env_file: ../../.env` on almost every service — sprawl is the default, not an edge case | Same sprawl; **frontend** is the lone clean exception (no `env_file`) |
| Extra bridges beyond DB/storage | LLM/GPU sidecars, pipeline workers | `inference_api`, `ocr_api`, `<orchestrator>` | `inference_api`, `<crm_bridge>`, `<mail_bridge>`, `<workflow-runner>`, `frontend` — widest bridge catalogue of the three |
| Local-tool ownership | GGUF emptyDir models on LLM pods | Tesseract binary on `ocr_api` | Tesseract absent; lab SMTP sidecar is the local-tool analogue |

## Pattern statement

1. Capability → one owner component → one credential surface.
2. Peers use the envelope hop; owners alone use SDKs **and** fail-closed credential checks.
3. Same `/call` seam for bridges and domain services.
4. Measure isolation by **process environment and RBAC**, not ADR text alone.
5. Local tools are first-class owners too.
6. Optional integrations: owner fail-closes when enabled; routing skip-closes when disabled — never validate owner secrets off-owner.

## Related

- [[capability-bridges]] · [[service-packaging]] · [[docker-containers]] · [[compose-deploy]] · [[in-process-orchestration]] · [[platform-atlas]]
- [[policy-ingress-contract]] · [[domain-io-edge-packaging]] · [[required-happy-path]]
- [[privileged-capability-boundaries]] · [[privileged-capability-ownership]]
