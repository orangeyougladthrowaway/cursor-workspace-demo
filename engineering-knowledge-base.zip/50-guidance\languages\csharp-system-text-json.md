---
type: guidance
status: canonical
id: engineering-knowledge-base-g-cs-stj
concern: languages
description: System.Text.Json boundary honesty — DTOs at edges, host options once, no JsonElement through core.
domain: [csharp]
derived_from:
  - "[[boundaries]]"
  - "[[honesty]]"
  - "[[csharp-project-toolchain]]"
  - "[[csharp-async-di]]"
updated: 2026-07-16
---

# Csharp system text json

Primary: [System.Text.Json overview](https://learn.microsoft.com/dotnet/standard/serialization/system-text-json/overview).

## Applies when

Serializing/deserializing at HTTP/file/message edges in .NET house tooling.

## Does not apply when

- Domain cores need a second JSON dialect “just in case”
- A mandated house library already owns the wire format (document the exception)

## House defaults

1. Prefer **System.Text.Json** for new .NET work unless a lived dependency forces otherwise.
2. Deserialize to **explicit DTO types** at the edge; map inward to domain records. Do not thread `JsonElement` / `JsonDocument` through domain cores.
3. Configure naming / null / case once at the **host edge** (`JsonSerializerOptions` on ASP.NET / worker bootstrap) — not per call-site folklore.

```csharp
// Host edge — set once
services.ConfigureHttpJsonOptions(o =>
{
    o.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    o.SerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
});
```

4. Fail loud on bad payloads (`null` after deserialize → throw / 400). Silent defaults hide contract drift.
5. Prefer source-generated contexts only when measured cold-start / AOT pressure warrants — do not default to codegen theatre.

## Decision rules

| Situation | Do |
| --- | --- |
| Partner HTTP body | DTO + STJ at edge |
| Internal Envelope payload | Separate contract type; still STJ unless Envelope owns another serializer |
| Unknown JSON shape | Bound `JsonDocument` at the adapter only; extract known fields |

## Untapped

Polymorphic converters encyclopaedia · full source-generator recipes · Newtonsoft migration playbooks.

## Related

- [[csharp-project-toolchain]] · [[openapi-specification]] · [[public-http-vs-internal-envelope]] · [[languages-atlas]]
