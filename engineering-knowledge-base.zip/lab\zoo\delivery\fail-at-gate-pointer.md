---
type: example
status: canonical
domain: [delivery]
derived_from:
  - "[[fail-at-the-gate]]"
  - "[[delivery-gates]]"
updated: 2026-07-15
---

# Fail at gate pointer

## When

Preferring early hard failure over soft downstream recovery theatre.

## When not

“We’ll catch it in prod monitoring” as the primary quality plan.

```text
Fail loud at the gate → [[fail-at-the-gate]] · [[delivery-gates]]
```

## Related

- [[fail-at-the-gate]] · [[delivery-gates]] · [[tott-culture]]
