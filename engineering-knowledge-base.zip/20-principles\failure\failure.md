---
type: category
status: canonical
description: Spine for failure — fail loudly on control paths; one happy path; do not invent quiet truth.
id: engineering-knowledge-base-cat-002
derived_from:
  - "[[accountable-meaning-under-change]]"
updated: 2026-07-17
---

# Failure

## Theme

A system should tell the truth about its state. Broken contracts and invalid control flow **stop where they break**. Soft-fail is exceptional and declared — including constrained probabilistic/AI paths. Silent fallbacks that hide missing authority are **forbidden** ([[happy-path-only]]).

## Belongs here

Gate failure, control-path failure posture, happy-path-only construction, and rules for untrusted media (including models).

## Does not belong here

What tests must prove (see [[proof]]); security theatre vs real scope (see [[trust]]).

## Leaves

- [[fail-at-the-gate]]
- [[fail-loud-on-control-paths]]
- [[happy-path-only]]

**Distributed / networking spine (wide):** treat partitions, timeouts, and partial failure as **expected** — fail loud at contracts, not silent “eventually consistent theatre” across bridges. Deep courses deferred; pressure lands on [[fail-loud-on-control-paths]] and bridge ownership walls.
