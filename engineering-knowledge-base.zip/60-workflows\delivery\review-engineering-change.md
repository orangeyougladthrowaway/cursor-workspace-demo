---
type: workflow
status: draft
id: engineering-knowledge-base-wf-012
concern: delivery
description: Independently review a planned, implemented, and verified change for correctness, health, and evidence.
domain: ["cursor"]
derived_from:
  - "[[coding-agent-projection]]"
  - "[[code-review-norm]]"
  - "[[delivery-gates]]"
  - "[[programming-over-time]]"
updated: 2026-07-17
---

# Review engineering change

Use after verification or when explicitly asked to review an existing change.

For knowledge-ingestion waves, also use [[post-capture-review]].

## Preconditions

- Stated outcome and acceptance conditions
- Change set or review target
- Verification evidence, or an explicit statement that it is absent

## Retrieve

1. Open [[code-review-norm]] and [[delivery-gates]].
2. Retrieve the engineering-knowledge-base notes cited by the change.
3. Retrieve additional doctrine required by the actual diff.
4. Inspect the complete relevant change, not only its summary.

## Steps

1. Check correctness against acceptance conditions.
2. Check authority, boundaries, contracts, failure behaviour, and security.
3. Check complexity, cohesion, control flow, and maintainability.
4. Check tests and whether their evidence supports the claims.
5. Identify scope drift and unrelated churn.
6. Distinguish defects from optional improvements.
7. Rank findings by impact and cite affected locations.
8. Reject health-decreasing or insufficiently evidenced changes.
9. State residual risks and required follow-up.

## Output

Findings first, ordered by severity:

- Location
- Problem
- Consequence
- Required correction
- Relevant engineering-knowledge-base id

Then:

- Open questions
- Verification gaps
- Overall verdict: approve, request changes, or blocked

## Handoff

Corrections return to [[build-engineering-change]], then [[verify-engineering-change]] and review again.

Shipping remains subject to [[delivery-gates]], [[single-lived-source-of-truth]], and human approval where risk warrants.

## Forbidden

- Reimplementing the change during review unless asked
- Approving because tests merely exist
- Style-only findings presented as correctness defects
- Reviewing only the latest file when the contract spans callers
- Green verdict with unresolved material findings

## Related

- [[coding-agent-projection]] · [[plan-engineering-change]] · [[post-capture-review]]
