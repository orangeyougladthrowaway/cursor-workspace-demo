---
type: guidance
status: canonical
id: engineering-knowledge-base-g-owasp-forgot
concern: auth
description: OWASP Forgot Password — anti-enumeration, side-channel tokens, no lockout-as-DoS; mesh N/A until human identity.
domain: []
aliases: [forgot-password, password-reset, recovery]
derived_from:
  - "[[owasp-authentication-pressure]]"
  - "[[owasp-password-storage-pressure]]"
updated: 2026-07-15
---

# OWASP forgot password pressure

Primary (D2 #6): [OWASP Forgot Password Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Forgot_Password_Cheat_Sheet.html).

## Applies when

Product or admin UIs expose **password reset / recovery**. Not when AuthN is mesh actors only — document the absence.

## Guidance (claims elevated)

1. Anti-enumeration: **same message** and **uniform timing** for existent and non-existent accounts (async or equal-path logic).
2. Rate-limit / CAPTCHA / other controls against bulk reset requests (inbox/SMS flooding).
3. Communicate reset via a **side-channel**; prefer HTTPS **URL tokens** (or PINs via SMS etc.). Tokens/codes: CSPRNG, long enough vs brute force, user-linked, **single-use**, time-limited, stored securely ([[owasp-password-storage-pressure]] hygiene).
4. Do **not** change account state (e.g. lockout) until a **valid token** is presented.
5. Hard-code or allow-list reset URL hosts — **do not** build reset links from the Host header (host-header injection).
6. Reset page: Referrer-Policy `noreferrer`; apply same password policy; confirm password twice; store with secure hashing; notify user by email (**never** send the new password).
7. After reset: require **normal login** — do not auto-login; offer or auto-invalidate existing sessions.
8. Security questions alone are insufficient; combine sparingly. MFA recovery is on [[owasp-multifactor-authentication-pressure]], not this sheet.
9. Do **not** lock accounts on forgot-password abuse — that enables denial-of-service against known usernames.

## Collision with lived gateway

| Sheet pressure | Lived ([[gateway-auth]]) |
| --- | --- |
| Password reset flows | Typically **no** human password account surface |
| Side-channel tokens | N/A on Envelope `/call` |

**Resolution:** binds human-credential products. Mesh lab stays under named threat model; claiming “account recovery” without these controls is a gap-map entry.

## Untapped

ASVS recovery controls · Security Questions sheet · JWT-as-reset-token pitfalls · Top 10 remaining categories.

## Related

- [[owasp-authentication-pressure]] · [[owasp-password-storage-pressure]] · [[owasp-multifactor-authentication-pressure]] · [[security-atlas]]
