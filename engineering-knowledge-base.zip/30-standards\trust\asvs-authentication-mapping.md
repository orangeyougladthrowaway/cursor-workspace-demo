---
type: standard
status: canonical
id: engineering-knowledge-base-s-014
concern: trust
description: ASVS verification levels + V2 authentication chapter pressure — map to cheat sheets; mesh stays named.
domain: []
aliases: [asvs, verification-levels]
derived_from:
  - "[[owasp-top10-mapping]]"
  - "[[threat-model-declaration]]"
updated: 2026-07-15
---

# ASVS authentication mapping

Primary (D2 #9): [OWASP ASVS 4.0](https://owasp.org/www-project-application-security-verification-standard/) PDF — verification levels + **V2 Authentication** chapter framing (not the entire standard).

## Requirement

1. Treat ASVS **levels** as assurance choices: **L1** minimum/all apps (pen-testable); **L2** most apps with sensitive data; **L3** high-value/high-assurance. Pick a level in the threat model — do not imply L3 for lab mesh.
2. ASVS V2 aligns toward **NIST 800-63**-style evidence-based AuthN: MFA expected where risk warrants; usernames/KBA treated as non-secret; SMS/email as restricted authenticator types; password rotation/complexity theatre de-emphasized vs length and breach resistance.
3. Map V2 subsection intent to living cheat-sheet homes rather than duplicating every control ID here:
   - passwords / storage → [[owasp-password-storage-pressure]], [[owasp-authentication-pressure]]
   - MFA / OTP / out-of-band → [[owasp-multifactor-authentication-pressure]]
   - recovery → [[owasp-forgot-password-pressure]]
   - session adjacent → [[owasp-session-pressure]]
4. Architectural AuthN rules that collide with gateway: single vetted AuthN strength across pathways; AuthZ at trusted enforcement points (not client); consistent control strength — lab fall-open remains **named theatre** unless scoped ([[gateway-auth]], [[owasp-top10-mapping]]).
5. Do not auto-elevate full ASVS L2/L3 control matrices onto Envelope `/call` without a human-credential product surface.

## Untapped

ASVS V3 session · V4 access control deep · ASVS 5.x delta · full control CSV.

## Related

- [[security-atlas]] · [[threat-model-matched-controls]] · [[owasp-authentication-pressure]]
