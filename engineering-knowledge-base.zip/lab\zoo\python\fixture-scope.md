---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[pytest-practices]]"
updated: 2026-07-15
---

# Fixture scope

## When

Choosing function vs session fixture scope deliberately.

## When not

Session-scoped mutable shared state that crosses tests.

```python
import pytest

@pytest.fixture
def client():
    return make_client()  # function scope default — isolated

@pytest.fixture(scope="session")
def settings():
    return load_settings()  # immutable/config only
```

## Related

- [[pytest-practices]] · [[unit-testing-norm]]
