---
type: workflow
status: canonical
id: engineering-knowledge-base-wf-003
concern: knowledge
description: Working ledger of remote-source topic coverage — not doctrine; update every ingest batch.
domain: []
aliases: []
derived_from:
  - "[[knowledge-ingestion]]"
updated: 2026-07-15
---

# Ingest coverage

**Not doctrine.** Working ledger of remote sources: what we tapped, how deep, what remains. Living notes are law ([[knowledge-ingestion]]).

Update this note in the **same change** as any remote ingest elevate (Stage F).

## Coverage axes

| Axis | Status | Meaning |
| --- | --- | --- |
| **W — Wide spine** | **`done`** + maps reshape | Touch every portfolio theme + **subtopic spine** at skim/section; map concerns; list deep-dive backlog |
| **D1 — One deep** | **`done`** (#1–#10 + [[d1-deep-harvest-playbook]]) | Theme-ordered deeps into atlas homes |
| **D2+ — Residual deep** | **`in progress`** — D2 #1–#16 **done**; non-language queue parked while L runs | ≤3 waves/batch; Stage G [[post-capture-review]] |
| **L — Language deep** | **`done`** (core + L+ planned families); residual Untapped named | Same playbook; ledger on this note |
| **P — Praxis plane** | **`P0–P4 done`** — capacity (84+ zoo · 6 skeletons · 2 stubs); **≠** majority common cases | [[praxis-ingestion]]; never doctrine `deep` |
| **F — Majority common cases** | **`done`** — all tracks ≥70% G4 · **~99%** overall (166/168) | [[common-case-coverage]] |

## Praxis ledger (axis P)

Working counts. Inventory: `temp/praxis-expansion/` (kept for review). Index: [[lab-atlas]] · [[catalog-lab]].

| Kind | Count | Notes |
| --- | --- | --- |
| Zoo entries | **85** | + architecture facet seed (F0) |
| Skeletons | **6** | python · csharp · opentofu · helm · compose · gha |
| Stubs | **2** | sql-server SCD2 outline · postgres upsert |
| Lab suite | **9** checks | facet coverage includes `architecture` |

**Budget note (P1/P2):** session overrides noted historically — Axis P complete.

## Common-case ledger (axis F)

Scoreboard: [[common-case-coverage]].

| Phase | Status |
| --- | --- |
| F0–F7 | **done** |
| Overall G4 | **~99%** (166/168; P27/V06 intentional G2) |
| Tracks ≥70% | **16 / 16** |
| Threshold | ~70% G4 / track — **met** |

**Budget note:** Axis F completion pass overrode session zoo/doctrine caps (program override on [[roadmap]]).

Folder changes: if a subtopic has no honest home, **amend [[navigation]] first**, then add the note — never invent L1 product/domain folders ([[methodology]], [[changing-this-bible]]).

## Language deep — concept family ledger (axis L)

Working checklist only. Depth: `none` · `spine` · `section` · `deep`. Prefer sections inside few canons (program budget ≤~15 language leaves). C# = tooling-first.

### Python

| Family | Depth | Home |
| --- | --- | --- |
| Style / consistency | `section` | [[python-style-pep8]] |
| Packaging / layout / envs | `deep` (L-py #2) | [[python-packaging-layout]] (+ lived [[service-packaging]]) |
| Typing / mypy honesty | `deep` (L-py #1) | [[python-typing-honesty]] |
| Errors / resources | `deep` (L-py #3) | [[python-errors-resources]] |
| Data modeling | `section` (L-py #5) | [[python-logging-modeling]] |
| Concurrency / async | `deep` (L-py #4) | [[python-concurrency-async]] |
| Logging | `deep` (L-py #5) | [[python-logging-modeling]] |
| Testing beyond layout | `section`+ (L+ fixtures) | [[pytest-practices]], [[unit-testing-norm]] |
| CLI entrypoints | `section` | [[python-packaging-layout]] |
| Lang-sec / perf | `section` (secrets; perf defer) | [[python-langsec-secrets]] |

### C# (tooling-first)

| Family | Depth | Home |
| --- | --- | --- |
| Style / naming | `section` | [[csharp-style-conventions]] |
| SDK / NuGet / `dotnet` CLI | `deep` (L-cs #1) | [[csharp-project-toolchain]] |
| Nullable reference types | `deep` (L-cs #1) | [[csharp-project-toolchain]] |
| Async / CancellationToken | `deep` (L-cs #2) | [[csharp-async-di]] |
| DI / generic host | `deep` (L-cs #2) | [[csharp-async-di]] |
| Exceptions / FDG / LINQ / Span | `section` (LINQ+FDG overview; Span Untapped) | [[csharp-linq-api]] |
| Test craft (xUnit) | `spine` | [[unit-testing-norm]] |
| SSDT adjacency | `spine` | [[dacpac-publish]] |

### SQL — T-SQL / warehouse

| Family | Depth | Home |
| --- | --- | --- |
| DACPAC / schema-as-code | `section`+ | [[dacpac-publish]] |
| Layering / SCD2 architecture | `deep` (hist) | [[warehouse-historisation]], [[kimball-type2-scd]] |
| Set-based + MERGE safety | `deep` (L-sql #1) | [[tsql-set-based-merge]] |
| T-SQL tx / isolation | `section` (via MERGE concurrency) | [[tsql-set-based-merge]] |
| Indexes / plans (decision) | `spine` (MERGE page) | [[tsql-set-based-merge]] Untapped |
| Temp/TVP / dynamic SQL / TRY-CATCH | `deep` (L+) | [[tsql-batch-craft]] |
| SQL testing / hard gates | `spine` (named gaps) | [[delivery-gates]] warehouse — still Absents |

### SQL — Postgres

| Family | Depth | Home |
| --- | --- | --- |
| Relational core | `spine` | [[postgres-core-concepts]] |
| Dialect craft (CTE, upsert, windows) | `deep` (L+ windows) | [[postgres-sql-craft]] |
| Engine WAL/MVCC | `deep` | [[postgres-wal-concurrency]] |
| Indexes / EXPLAIN | `deep` (L+ EXPLAIN basics) | [[postgres-sql-craft]] |
| Migrations (alembic) | `spine` (named) | [[postgres-sql-craft]] |
| JSON / extensions | defer | — |

## Wide spine — subtopic checklist

Mark `spine` when a primary page/section was read and ≥1 claim collided (elevate or explicit reinforce/reject). Mark `gap` if home folder/note missing (then navigation proposal).

| Theme | Subtopics (spine targets) | Home concern(s) | W |
| --- | --- | --- | --- |
| Agent eng | Skills meta; MCP host/tools; projection | knowledge, contracts | **spine** |
| SE meta | Review standard; small CLs; SE@Google ch themes; Missing Semester tooling | knowledge, delivery, change | **D1 #1/#1b done** |
| Testing/CI | TDD prove-it; pyramid/sizes; CI gates; coverage honesty; MS testing docs | delivery, proof | **D1 #2 + D2 #3/#14/#16** |
| OpenTofu/TF | Intro workflow; state; backends/locking; modules | opentofu | **spine** |
| Helm/K8s | Template compile; install/upgrade; Hard Way / workload basics | helm, packaging | **spine** |
| SQL/SqlPackage | Publish properties; variables; lab vs prod defaults | policy, activation | **spine** |
| Security | AuthN; session; Top10 A01/A07; password/MFA/forgot | auth, trust | **D1 #3 + D2 #1/#2/#6** |
| Python | Language idioms + packaging/typing (axis L) | languages, packaging | **L core** |
| C#/.NET | Tooling conventions + SDK/nullable/async/DI (axis L) | languages | **L core (tooling)** |
| Postgres/jobs | Official docs spine vs lived WAL/jobs | audit | **D2 #4 postgres engine** |
| Warehouse/ETL | Kimball themes; SCD; dbt/Airflow as pointer vs pattern | historisation, ingest, orchestration | **spine** |
| Architecture | Boundaries; modular monolith vs services; hard parts tradeoffs | boundaries, ownership, restraint | **spine** |
| DDD/patterns | Ubiquitous language vs our concern model; GoF as pointer | boundaries, change | **spine** |
| APIs/REST | Microsoft REST/API design; OpenAPI honesty | contracts | **D1 #4 + D2 #7** |
| Docker/Compose | Image/runtime spine vs lived compose | compose, packaging | **spine** |
| Networking/distrib | Failure/honesty pressure only (spine) | failure, bridges | **spine** |
| DevOps culture | Accelerate/CD / DORA themes vs delivery-gates | delivery, change | **D1 #9 + D2 #12** |
| AI eng | RAG/ReAct as product-LLM pressure | honesty, knowledge | **D1 #10 + D2 #13** |

### W-gate — folder proposals (structural expansion applied)

**New concern folders (2026-07-15):** `datastores` · `apis` · `languages` · `testing` · `observability` · `modeling` · `apis` (standards) · principle concept `reliability`. Cross-cutting indexes live under `maps/themes/` (lived families under `maps/families/`).

Each W theme now has ≥1 note home indexed by `maps/themes/` atlases ([[catalog-maps]]). Scaffold freeze is **on**. Paragraph-only elevates in lived notes remain; residual deeps (D2+) target Untapped on existing homes.

## W1–W10 — skipped or ignored (honest ledger; refresh after D1/D2+)

| W | Claimed / touched | Still skipped or thin |
| --- | --- | --- |
| W1 | OWASP + Password/MFA/Forgot + ASVS V2 map → **D2 #9** | ASVS session/access chapters · remaining Top 10 · WAHH |
| W2 | SE@Google selected ch + Eng Practices D1; CI ch23 → **D2 #16** | Rest of book · lecture notes · author guide · hermetic deep |
| W3 | MS unit-testing D1 + TotT sample **7 posts** (D2 #3); pytest → **D2 #14** | TotT **rest of archive** · xUnit books |
| W4 | Docker/TF D1; azurerm + S3 backends → **D2 #10/#15** | Hard Way labs · CNCF · Docker networking · GCS |
| W5 | Kimball Type 2 D1 #6 | Toolkit · types 0/1/3+ deep · dbt/Airflow operators |
| W6 | Postgres WAL/MVCC D2 #4; Kleppmann public reliability D2 #5 | **DDIA book chapters** (owned) · CMU · replication deep |
| W7 | Fowler microservices D1; Prerequisites + trade-offs → **D2 #8** | Hard Parts book · Evans/Vernon · GoF |
| W8 | OpenAPI Paths/components + Azure pagination/versioning → **D2 #7** | Full Operation/Schema encyclopaedia · HATEOAS deep |
| W9 | PEP 8 / C# conventions D1 #8 | Fluent/Effective Python · .NET Learn / FDG |
| W10 | DORA metrics + OTEL primer D1 #9; capabilities + OTEL signals → **D2 #11/#12**; ReAct/RAG → **D2 #13** | RAG **surveys**/methods · rest of DORA capability articles · OTEL logs/Collector/SDKs · Osmani obs skill |

## How to read rows

| Field | Meaning |
| --- | --- |
| Admit | `pressure` \| `specialise` \| `pointer` \| `defer` \| `reject` |
| Cov | Rough % of that **source’s topic surface** examined |
| Depth | `none` \| `skim` \| `section` \| `chapter` \| `deep` |
| Untapped | Remainder for a later pass |

## Portfolio scoreboard (original resource themes)

| Theme | Status | Cov (max of theme) | Notes |
| --- | --- | --- | --- |
| Agent engineering / skills / MCP | **elevated (thin)** | ~15–40% per source | Cluster closed for coding-agent rails |
| Software eng meta (SE@Google, Eng Practices, Missing Semester) | **D1 + D2 #16 CI** | Eng Practices ~70%; SE@Google ch01+ch09/ch11/ch12 + **ch23 CI** | [[code-review-norm]], [[programming-over-time]], [[published-contract-stability]], [[unit-testing-norm]], [[delivery-gates]] |
| Testing / CI honesty | **D1 #2 + D2 #3/#14/#16** | MS unit-testing; TotT sample 7; pytest integration practices; SE@Google CI | [[unit-testing-norm]], [[tott-culture]], [[pytest-practices]], [[delivery-gates]] |
| OpenTofu / Terraform | **D1 #7 + D2 #10/#15** | remote state + modules + azurerm + **S3** backends | [[terraform-state-backends]], [[terraform-modules-composition]] |
| Helm / K8s packaging | **D1 #7 pedagogy** | Hard Way = education; lived SoT unchanged | [[kubernetes-hard-way-pedagogy]] |
| SQL Server / SqlPackage | **elevated (thin)** | publish props ~30% | Earlier practiced-stacks |
| Security honesty | **D1 #3 + D2 auth cluster + #9 ASVS** | Cheat sheets + ASVS levels/V2 map | [[asvs-authentication-mapping]] |
| Python textbooks/courses | **L core (not textbooks)** | Typing/packaging/errors/async/logging canons | [[python-typing-honesty]], [[python-packaging-layout]], … — no Fluent dump |
| C# / .NET books+Learn | **L core tooling** | Conventions + SDK/nullable + async/DI | [[csharp-project-toolchain]], [[csharp-async-di]] |
| PostgreSQL / CMU DB / DDIA | **D2 #4 PG**; **D2 #5 Kleppmann public** (not book PDF) | WAL/MVCC deep; DDIA chapters 0% body | [[postgres-wal-concurrency]], [[ddia-reliability-themes]] |
| Data warehouse / Kimball / dbt / Airflow | **D1 #6 Type 2** | Type 2 page deep; Toolkit deferred | [[kimball-type2-scd]]; dbt/Airflow still pointer |
| Architecture / microservices / DDD / GoF | **D1 #5 + D2 #8 prereqs** | Fowler article + prerequisites + trade-offs | [[microservice-prerequisites]] |
| REST / OpenAPI | **D1 #4 + D2 #7** | Paths/components + pagination/versioning/idempotency | [[openapi-specification]], [[rest-resource-design]] |
| Docker / K8s Hard Way / CNCF | **D1 #7 container** | Docker container basics canonical; Hard Way pedagogy | [[docker-containers]] |
| Networking / distributed systems | **D1 pressure** | [[distributed-systems-expectations]] promoted | Courses/DDIA still D2+ |
| DevOps handbooks / Accelerate | **D1 #9 + D2 #11/#12** | Five metrics + OTEL traces/metrics + DORA capabilities (monitoring/obs) | [[dora-metrics]], [[metrics-tracing-logging-pressure]], [[dora-capabilities-index]] |
| Awesome-* lists | `reject`/`pointer` | — | No claim extraction |
| AI eng books / RAG·ReAct papers | **D1 #10 + D2 #13** | ReAct abstract/intro; Lewis RAG abstract+framing | [[react-reason-act-pressure]], [[rag-retrieval-pressure]] |

**Portfolio rough elevated surface:** all W themes have ≥1 primary-source spine touch; **≪15%** of total page/chapter mass. Deep value remaining by design (caps + amend-first).

## Cluster — Agent engineering / craft (D1 Eng Practices)

| Source | Admit | Cov | Depth | Untapped | Land |
| --- | --- | --- | --- | --- | --- |
| Osmani agent-skills | `pressure` | ~30% | section | Most non-TDD/CI skills | [[coding-agent-projection]], [[delivery-gates]] |
| MCP spec | `pressure` | ~15% full | section | Protocol/auth/schema deep pages | [[coding-agent-projection]] |
| Google Eng Practices | `pressure` | ~70% | **deep** | Speed page (timeout); pushback-handling; nav-of-CL | [[code-review-norm]], [[programming-over-time]], [[coding-agent-projection]], [[delivery-gates]], [[prove-honesty-contracts]] |
| SE@Google book | `pressure` | ~20% (ch01 + ch09 themes + ch11/12 testing + **ch23 CI**) | **deep** (selected chapters) | Rest of book — LSC, culture, hermetic deep remainder | [[programming-over-time]], [[published-contract-stability]], [[unit-testing-norm]], [[code-review-norm]], [[delivery-gates]] |
| SDKs / AutoGen / LangGraph | `pointer` | 0% | none | — | — |
| Missing Semester | `pressure` | syllabus + framing | skim | Lecture notes deep | [[tooling-proficiency]] |
| Awesome/blogs | `reject` | — | — | — | — |

**D1 claim collision (Eng Practices → elevate):** review standard = improve code health / approve imperfect improvements / refuse worsenings; small self-contained CLs + tests in same CL; CL descriptions what+why as permanent history; looking-for lenses (design, YAGNI/complexity, valid tests, why-comments); facts over preference + escalate; fix code not chat-only explanations; kindness + Nit/Optional severity. Twin spine paragraphs removed from [[coding-agent-projection]] in favor of these notes.

## Cluster — Testing / delivery honesty

| Source | Admit | Cov | Depth | Untapped | Land |
| --- | --- | --- | --- | --- | --- |
| Osmani TDD skill | `pressure` | ~70% | section | Browser MCP combo | [[prove-honesty-contracts]], [[delivery-gates]], [[coding-agent-projection]] |
| Osmani CI/CD skill | `pressure` | ~40% | section | Previews, flags, YAML encyclopaedia | [[delivery-gates]], [[coding-agent-projection]] |
| Eng Practices — Small CLs | `pressure` | ~80% page | section | Rest of developer guide | same |
| Testing Blog — coverage 2014 | `pressure` | skim | skim | TotT corpus | [[delivery-gates]] |
| MS unit-testing best practices | `specialise` | ~40% page | **deep** (core practices) | Legacy/anti-pattern remainder of guide | [[unit-testing-norm]], [[unit-test-fast-isolated]], [[coverage-not-quality]] |
| TotT — behaviour cluster sample | `pressure` | **7 posts** (2 D1 + 5 D2 #3) | **deep** (sample only; HTML often comment-only) | Full TotT archive (~100+) | [[tott-culture]], [[unit-testing-norm]] |
| pytest — Good Integration Practices | `specialise` | full explanation page | **deep** (D2 #14) | Fixtures/parametrize/plugins/CI Pipeline pages | [[pytest-practices]] |
| SE@Google ch23 Continuous Integration | `pressure` | full chapter themes | **deep** (D2 #16; Takeout scenarios skimmed for lesson bullets) | Hermetic chapter deep · CD chapter · LSC | [[delivery-gates]], [[delivery-ci]] |
| xUnit / Unit Testing books | `defer` | 0% | none | — | — |
| DORA metrics guide | `pressure` | five metrics | **deep** (metrics; capabilities → D2 #12) | — | [[dora-metrics]], [[delivery-gates]] |

## Cluster — Practiced stacks + infra remainder

| Source | Admit | Cov | Depth | Untapped | Land |
| --- | --- | --- | --- | --- | --- |
| OpenTofu intro | `specialise` | ~60% page | section | Product deep | [[host-opentofu]] |
| Terraform state (HashiCorp) | `specialise` | page | **deep** | Backend product pages | [[terraform-state-backends]] |
| Terraform modules (structure) | `specialise` | page | **deep** | Module testing/registry | [[terraform-modules-composition]] |
| Helm Using Helm + `helm template` | `specialise` | ~20% Helm docs | section | Chart deep / Helm 4 | [[helm-deploy]] |
| SqlPackage publish (Microsoft Learn) | `specialise` | ~30% props | section | Full property matrix | [[dacpac-publish]] |
| Kubernetes The Hard Way README | `pointer` | README only | skim | Labs 01–13 | [[kubernetes-hard-way-pedagogy]] |
| Docker — what is a container | `specialise` | page | **deep** | Images/networking deep | [[docker-containers]] |

## Cluster — Security honesty (D1 #3 + D2 #1/#2/#6)

| Source | Admit | Cov | Depth | Untapped | Land |
| --- | --- | --- | --- | --- | --- |
| OWASP Authentication Cheat Sheet | `pressure` | ~50% core | **deep** (claims elevated) | MFA/ASVS | [[owasp-authentication-pressure]], [[gateway-auth]] |
| OWASP Session Management Cheat Sheet | `pressure` | ~40% core | **deep** | Cookie/logout recipes | [[owasp-session-pressure]] |
| OWASP Top 10:2021 A01 + A07 | `pressure` | A01/A07 pages | **deep** | Other categories / 2025 | [[owasp-top10-mapping]] |
| OWASP Password Storage Cheat Sheet | `pressure` | core algos + salt/pepper/work | **deep** | Cryptographic Storage · Secrets Mgmt | [[owasp-password-storage-pressure]] |
| OWASP Multifactor Authentication Cheat Sheet | `pressure` | factors + TOTP/SMS/OTP hygiene + recovery | **deep** | ASVS · WebAuthn guides | [[owasp-multifactor-authentication-pressure]] |
| OWASP Forgot Password Cheat Sheet | `pressure` | anti-enum + tokens + reset UX | **deep** (D2 #6) | Security Questions sheet · ASVS | [[owasp-forgot-password-pressure]] |
| WAHH / Security Engineering | `defer` | 0% | none | Full books | — |

## Cluster — APIs / architecture / data / infra / langs / obs / agent (D1 #4–#10)

| Source | Admit | Cov | Depth | Untapped | Land |
| --- | --- | --- | --- | --- | --- |
| OpenAPI Specification Paths/Components (3.1) | `pressure` | Paths + Components structure | **deep** (D2 #7 section) | Full Operation/Schema encyclopaedia | [[openapi-specification]] |
| Azure REST — pagination/filtering + versioning | `pressure` | those sections + PUT idempotency | **deep** (D2 #7) | HATEOAS deep · async patterns | [[rest-resource-design]], [[rest-resource-design-norm]] |
| Fowler — Microservice Prerequisites | `pressure` | full bliki | **deep** (D2 #8) | Hard Parts book | [[microservice-prerequisites]] |
| Fowler — Microservice Trade-Offs | `pressure` | primary trade-offs sections | **deep** (D2 #8 themes) | Full article remainder | [[microservice-prerequisites]], [[microservices-tradeoffs]] |
| OWASP ASVS 4.0 — levels + V2 AuthN | `pressure` | levels + V2 chapter framing | **deep** (D2 #9 section; not full ASVS) | V3/V4 chapters · ASVS 5 | [[asvs-authentication-mapping]] |
| Terraform azurerm backend | `specialise` | product page | **deep** (D2 #10) | — | [[terraform-state-backends]] |
| Terraform s3 backend | `specialise` | product page (locking/IAM/encrypt) | **deep** (D2 #15) | GCS · full arg encyclopaedia | [[terraform-state-backends]] |
| Kimball Type 2 technique | `specialise` | page | **deep** | Types 0–7 + Toolkit | [[kimball-type2-scd]], [[kimball-scd-vocabulary]] |
| Terraform remote state | `specialise` | page | **deep** | Backend products | [[terraform-state-backends]] |
| Terraform standard module structure | `specialise` | page | **deep** | Module testing/registry | [[terraform-modules-composition]] |
| Docker — what is a container | `specialise` | page | **deep** | Images/networking | [[docker-containers]] |
| PEP 8 | `pointer` | consistency + style framing | **deep** (framing) | Full bible / books | [[python-style-pep8]] |
| C# coding conventions | `pointer` | conventions page | **deep** (page) | Learn tracks / FDG | [[csharp-style-conventions]] |
| OTEL observability primer | `pressure` | primer | **deep** (D1 #9) | — | [[metrics-tracing-logging-pressure]] |
| OTEL Traces + Metrics signals | `pressure` | concepts pages | **deep** (D2 #11) | Logs signal · Collector · language SDKs · sampling | [[metrics-tracing-logging-pressure]] |
| DORA metrics guide | `pressure` | five metrics | **deep** (metrics) | — | [[dora-metrics]] |
| DORA Capability catalog + Monitoring and observability | `pressure` | catalog framing + monitoring capability page | **deep** (D2 #12; not every capability) | CI/CD/trunk/test-automation articles · Accelerate book | [[dora-capabilities-index]] |
| ReAct (arXiv 2210.03629) | `pressure` | abstract+intro | **deep** (pressure) | Full methods | [[react-reason-act-pressure]] |
| Lewis et al. RAG (arXiv 2005.11401) | `pressure` | abs+intro framing | **deep** (D2 #13 pressure; not full methods) | Methods/ablations · successor surveys · chunking/eval | [[rag-retrieval-pressure]] |
| dbt / Airflow | `pointer`/`defer` | spine only | skim/none | D2+ only if product job | [[data-atlas]] drafts |
| PostgreSQL WAL + MVCC intros | `specialise` | 3 doc pages | **deep** (D2 #4) | Replication · checkpoints · isolation chapter | [[postgres-wal-concurrency]], [[observer-wal]] |
| Kleppmann — DB inside-out + DDIA site thesis | `pressure` | full essay + author site | **deep** (public primary; **not** DDIA PDF) | Owned DDIA chapters | [[ddia-reliability-themes]], [[durable-storage-tradeoffs]] |
| DDIA book chapters | `defer` | 0% body | none | Buy/read then elevate | [[ddia-reliability-themes]] Untapped |
| Kubernetes The Hard Way | `pointer` | README | skim | Labs 01–13 | [[kubernetes-hard-way-pedagogy]] |

## Related

- [[knowledge-ingestion]] · [[d1-deep-harvest-playbook]] · [[post-capture-review]] · [[roadmap]] · [[gateway-auth]] · [[threat-model-declaration]] · [[threat-model-matched-controls]] · [[delivery-gates]] · [[host-opentofu]] · [[helm-deploy]] · [[dacpac-publish]] · [[coding-agent-projection]] · [[warehouse-historisation]] · [[observer-wal]] · [[compose-deploy]] · [[policy-ingress-contract]]
