---
type: glossary
status: canonical
description: Local definitions as used in this bible.
updated: 2026-07-16
---

# Glossary

| Term | Meaning |
| --- | --- |
| Aliases | Frontmatter search tokens only — never old basenames, spelling twins, or a substitute for rename |
| Atlas | Knowledge index under `maps/families/` or `maps/themes/` — not a task playbook |
| Axis F | Full-coverage program: majority common cases for house languages/tools ([[common-case-coverage]], [[roadmap]]) |
| Axis P | Praxis-plane capacity program (`lab/` scaffold + seeds) — done; not majority coverage |
| Common case | Recurring ship/break engineering question for a house language or tool |
| Common-case matrix | Scored checklist of common cases per track; gates G1–G4 on [[common-case-coverage]] |
| Concern | Folder name in frontmatter (must match parent folder; maps use family/theme leaf name) |
| Family atlas | Lived project body (`maps/families/{family}/`) |
| Theme atlas | Cross-cutting / remote topic body (`maps/themes/{theme}/`) |
| G1–G4 | Coverage gates: law · rooted · depth · praxis (see [[common-case-coverage]]) |
| Lab / praxis | Subordinate plane under `lab/` — zoo, skeletons, stubs that cite doctrine |
| Lab atlas | Index of praxis (`lab/maps/lab-atlas.md`) — not a curriculum |
| Zoo | Thin `type: example` idiom notes under `lab/zoo/{facet}/` |
| Skeleton | Copy-out starter under `lab/skeletons/` — not `00-foundation/templates/` note stubs |
| Stub | Tiny fragment under `lab/stubs/` or a stub-tagged zoo entry |
| Deprecated | Brief migration status only — then delete; not a long-lived redirect |
| Domain (facet) | Stack/ecosystem tags in frontmatter — never L1 folders |
| Elevate | Move a claim to a higher altitude only when it earns it |
| Guidance | Domain/technology specialisation of higher knowledge |
| Maturity / altitude | Organisation by abstraction/stability |
| Navigation | Constitution for browse/retrieve — [[navigation]] |
| Principle leaf | Specific enduring constraint under exactly one category |
| Quarantine | Practiced or documented habits that must not become doctrine |
| Redirect | Forbidden as long-lived pattern — retire by rename + link update + delete |
| Rename | Correct stem by moving the file and updating all wikilinks / catalogs |
| Responsibility folder | One-idea folder under an altitude (`helm/`, `historisation/`, …) |
| Starting landscape | Scoped map of existing-repo practice — direction of travel, not law |
| Stem ↔ H1 | Basename kebab and note title must agree in meaning |
| Wikilink basename | Globally unique **vault note** handle used as `[[navigation]]` (basename only; never path-style; never `.mdc`/skill paths) |
