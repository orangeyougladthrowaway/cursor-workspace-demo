---
type: example
status: canonical
domain: [github-actions]
derived_from:
  - "[[delivery-gates]]"
  - "[[delivery-ci]]"
updated: 2026-07-15
---

# Hard unit gate

## When

Unit tests must fail the change.

## When not

`continue-on-error` on the only unit job.

```yaml
- name: Unit tests
  run: pytest tests/unit -q
  # no continue-on-error
```

## Related

- [[delivery-gates]] · [[delivery-ci]] · [[unit-testing-norm]]
