---
type: workflow
status: canonical
id: engineering-knowledge-base-wf-005
concern: knowledge
description: How to run vault health checks after every change — pytest suite, manual fix loop.
domain: []
aliases: [vault-health, cleanliness]
derived_from:
  - "[[changing-this-bible]]"
  - "[[methodology]]"
updated: 2026-07-15
---

# Vault health checks

Automated checks enforce testable rules from [[changing-this-bible]] and [[methodology]]. **No auto-fix scripts** — failures are fixed manually in the vault, then re-run.

## Run locally

```bash
python -m pip install pytest pyyaml
pytest tests/ -v
# When lab/ changed:
pytest tests/lab -v
```

## Run in CI

GitHub Actions workflow `vault-health.yml` on push/PR to default branch.

## What is tested

### Doctrine (`tests/` excluding `lab/`)

| Rule source | Tests (see `tests/`) |
| --- | --- |
| Broken wikilinks | `test_wikilinks.py` (targets may include lab indexes) |
| `concern` = folder | `test_frontmatter.py` |
| Stem ≈ H1 | `test_naming.py` |
| No `and` in folder/stem | `test_naming.py` |
| No `deprecated` doctrine | `test_frontmatter.py` |
| Catalog completeness | `test_catalogs.py` |
| Navigation enum folders | `test_navigation.py` |
| Principle `category` present | `test_frontmatter.py` |
| Doctrine `id` present | `test_frontmatter.py` |
| No path-style wikilinks | `test_wikilinks.py` |
| Map `concern` = family | `test_frontmatter.py` |

### Praxis (`tests/lab/`)

| Rule | Intent |
| --- | --- |
| Plane index files exist | [[praxis-plane]] · [[catalog-lab]] · [[lab-atlas]] |
| Zoo `type: example` + doctrine cite | No orphan tutorials |
| Facet allowlist + ≥1 entry each | No silent empty facets |
| Doctrine `derived_from` not zoo | Snippet ≠ law |
| Skeleton README sections + required set | Contract for P3 copy-outs |
| Required stubs present | SCD2 / upsert fragments kept |
| Zoo bodies thin | Snippets stay exemplars |
| `python-src-pkg` unit file | Only skeleton claiming runnable behaviour |

## When checks fail

1. Read pytest output (file + rule).
2. Fix the vault note(s) manually — rename, link update, catalog row, frontmatter.
3. Re-run until green.
4. Do **not** disable tests to paper over drift.

## Beyond pytest

Shape-green ≠ coverage-honest. After elevate batches, also run [[post-capture-review]] (Stage G): depth labels, ledger sync, budget overrides, twin scan, **lab orphans**, **[[common-case-coverage]] matrix honesty** (Axis F).

Majority common-case progress is **not** proven by zoo totals alone — score tracks on [[common-case-coverage]]. Pytest does not compute matrix %.

## Related

- [[changing-this-bible]] · [[knowledge-ingestion]] · [[praxis-ingestion]] · [[common-case-coverage]] · [[post-capture-review]] · [[coding-agent-projection]]
