---
type: guidance
status: canonical
id: engineering-knowledge-base-g-owasp-auth
concern: auth
description: OWASP Authentication Cheat Sheet — AuthN pressure mapped to lived gateway honesty.
domain: []
aliases: [owasp, authentication]
derived_from:
  - "[[gateway-auth]]"
  - "[[owasp-top10-mapping]]"
  - "[[threat-model-matched-controls]]"
updated: 2026-07-15
---

# OWASP authentication pressure

Primary (D1 #3): [OWASP Authentication Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html). Pressure on lab/prod choices — **not** silent upgrade of fall-open mesh to “OWASP-compliant.”

## Applies when

Designing or reviewing **AuthN** (password, MFA, recovery, credential storage) or claiming production identity controls.

## Guidance (claims elevated)

1. Separate **AuthN**, **AuthZ**, and **session** — AuthN verifies identity; AuthZ is elsewhere ([[gateway-auth]] fall-open is AuthZ debt, not AuthN).
2. Password policy: enforce **length** + breached/common blocklists; avoid composition theatre; prefer MFA over forced rotation (NIST-aligned sheet themes).
3. Store passwords only via modern password hashing ([[owasp-password-storage-pressure]]).
4. Compare hashes with constant-time / framework verify helpers.
5. Change-password requires **authenticated session + current password**.
6. Harden registration/recovery/API against **account enumeration** (same messages).
7. Rate-limit / delay failed logins without creating easy DoS; log and alert on stuffing/brute force.
8. Prefer **MFA** where attacker-automated credential reuse matters ([[owasp-multifactor-authentication-pressure]]).

## Collision with lived gateway

| OWASP pressure | Lived ([[gateway-auth]]) |
| --- | --- |
| Strong AuthN + MFA | Often **no Bearer**; JWT keys off; actor fall-open |
| Deny-by-default identity | Authenticator may allow when disabled; legacy actor path grants `service:*` |
| Session invalidation | Internal `/call` is **not** browser-session AuthN |

**Resolution (named):** lab/demo model keeps fall-open **only** when [[threat-model-declaration]] says so; OWASP becomes the **gap map** for any claimed prod surface, not ambient law.

## Untapped

ASVS V2 · remaining Top 10 categories.

## Related

- [[owasp-session-pressure]] · [[owasp-top10-mapping]] · [[owasp-password-storage-pressure]] · [[owasp-multifactor-authentication-pressure]] · [[owasp-forgot-password-pressure]] · [[security-atlas]]
