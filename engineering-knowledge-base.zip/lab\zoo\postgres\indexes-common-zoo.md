---
type: example
status: canonical
domain: [postgres]
derived_from:
  - "[[postgres-sql-craft]]"
updated: 2026-07-16
---

# Indexes common zoo

## When

Adding indexes for equality/range filters used by hot queries.

## When not

Indexing every column “just in case.”

```sql
CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_t_key ON t (business_key);
-- Confirm with EXPLAIN before/after
```

## Related

- [[postgres-sql-craft]] · [[explain-basics]]
