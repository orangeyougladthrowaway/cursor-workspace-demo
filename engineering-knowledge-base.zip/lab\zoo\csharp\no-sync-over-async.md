---
type: example
status: canonical
domain: [csharp]
derived_from:
  - "[[csharp-async-di]]"
updated: 2026-07-15
---

# No sync over async

## When

Calling async APIs from async code paths.

## When not

`.Result` / `.Wait()` on async work (deadlock / threadpool hazard).

```csharp
await client.GetAsync(url, ct);

// ANTI: client.GetAsync(url).Result;
// ANTI: client.GetAsync(url).Wait();
```

## Related

- [[csharp-async-di]]
