---
type: foundation
status: canonical
description: How to change this bible — current-state doctrine, not an audit trail.
updated: 2026-07-15
---

# Changing this bible

This vault is a **current-state** engineering bible. Edit the living notes. Do not maintain a decision log, evidence warehouse, or proposal archive here.

## When changing knowledge

1. Start from [[README]] / [[navigation]] / [[scope]] / [[knowledge-model]] as needed.
2. Place content at the right **altitude** and **responsibility folder** ([[layout]], [[navigation]]).
3. **Category before leaf** for principles; **one primary concern folder** for standards/patterns/guidance/workflows/maps.
4. Prefer amending an existing note over adding a parallel one. **One concept → one note**; no fat twin + thin sibling — pick a winner and delete the other.
5. Put rationale **in the note** (short). No separate ADR/proposal artefact in this repo.
6. Use `status: draft` while sketching; `canonical` when it is doctrine.
7. New responsibility enum values require amending [[navigation]] — do not invent folders ad hoc.
8. New or widened family/theme knowledge → amend atlas under `maps/families/` or `maps/themes/` and [[catalog-maps]].
9. Create / rename / delete notes → update the layer `catalog-*.md` in the same change.
10. Naming and linking follow [[methodology]].
11. New or changed **praxis** (`lab/zoo`, skeletons, stubs) → follow [[praxis-ingestion]]; update [[lab-atlas]] / [[catalog-lab]]; never elevate lab as sole doctrine.

## Retirement (rename, don’t shim)

When a basename or note is wrong:

1. **Rename** the file (stem = correct concept).
2. Update **every** wikilink (and catalog rows) to the new stem.
3. Align `# Title` to the new stem.
4. Do **not** add the old basename to `aliases:`.
5. Do **not** leave a long-lived deprecated redirect note.
6. `status: deprecated` is **migration-only** — allowed briefly while links move, then **delete** the note. Target state: zero deprecated doctrine notes.

Git history remembers the old path.

## Cleanliness accept (before calling structure “done”)

- [ ] No broken wikilinks (basename-only targets resolve to existing `.md` notes — not `.mdc`/skills/paths)
- [ ] `concern` equals parent folder (maps: family or theme leaf folder)
- [ ] Stem ≈ H1 (no `/` `&` title glue; no episode/family suffixes on stems)
- [ ] No empty responsibility folders
- [ ] No `status: deprecated` residue
- [ ] Layer `catalog-*.md` and family atlases list current stems
- [ ] No old basenames parked in `aliases:`
- [ ] Lab entries (if touched): `type: example`, doctrine cite present, [[lab-atlas]] / [[catalog-lab]] updated
- [ ] Doctrine suite + `pytest tests/lab -v` green when lab changed ([[vault-health-checks]])
- [ ] Axis F waves: [[common-case-coverage]] scores updated; no “seeded = done”

## Conflicts

- If new guidance fights a canonical note, update the canonical note (or retire it via the protocol above) in the same change.
- If a lab exemplar fights a canonical note, **fix or delete the exemplar** (or elevate a new canon deliberately) — snippet never wins by silence.
- User direction overrides vault guidance after a brief challenge — then update the note so the bible stays true.

## Out of band

Git history is enough if you care how something looked last month. This vault does not mirror that story.
