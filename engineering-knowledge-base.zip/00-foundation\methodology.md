---
type: foundation
status: canonical
description: Note structure, frontmatter, linking, naming-as-navigation.
updated: 2026-07-15
---

# Methodology

Portable Markdown. Obsidian for navigation; meaning must survive as plain files in Git. Full navigation law: [[navigation]]. Change protocol: [[changing-this-bible]].

## Note shape

```markdown
---
type: …
status: draft | canonical | deprecated
id: engineering-knowledge-base-…
concern: …                 # matches folder (maps: family folder)
description: "≤160 chars"
domain: []
aliases: []
derived_from: []
updated: YYYY-MM-DD
---

# Title matching the basename
```

One question per note. Split if it answers two.

## Frontmatter

| Field | Use |
| --- | --- |
| `type` | Required — see [[knowledge-model]] |
| `status` | `draft` \| `canonical` \| `deprecated` (migration only — see [[changing-this-bible]]) |
| `description` | Scan-without-open summary |
| `updated` | ISO date |
| `id` | **Required** on doctrine notes — stable key |
| `concern` | **Required** on standard/pattern/guidance/workflow/**map** — matches folder |
| `category` | **Required on principles** |
| `derived_from` | Upward links |
| `domain` | Stack / ecosystem tags (`python`, `helm`, `sql-server`, …) — never a folder |
| `aliases` | Informal **search** tokens only — never a rename substitute |

No supersession chains or archive paths in metadata.

### `domain` vs `aliases`

| Field | Holds | Example |
| --- | --- | --- |
| `domain` | Stack / product / ecosystem tags | `python`, `helm`, `pytorch` |
| `aliases` | Informal search tokens (tool short names, file nicknames) | `tofu`, `wt`, `scd2` |

Both are facets. Neither invents L1 folders. Prefer `domain` when tagging a stack; use `aliases` only for extra findability.

### `aliases` forbid list

Do **not** put in `aliases:`:

- An **old basename** after a rename
- A **spelling twin** of the stem (`artifact` ↔ `artefact`)
- An **acronym** that hides a mismatched stem (`single-lived-sot` when the note is `single-lived-source-of-truth`)

Retire by **rename + link update** ([[changing-this-bible]]), not by alias shim.

## Writing order

1. Philosophy still holds?
2. Right responsibility folder / category spine? ([[navigation]], [[catalog-principles]])
3. Then leaf / standard / pattern / guidance.
4. New family or theme body of knowledge? Add/update atlas under `maps/families/` or `maps/themes/` and [[catalog-maps]].
5. Agents: open atlas or category before bulk-reading leaves.

## Linking

- Wikilinks use **basename only** — e.g. link to `methodology`, never a path-style `00-foundation/methodology` target.
- Wikilink targets must be **vault notes** (`.md` stems). Do **not** wikilink Cursor rules, skills, scripts, or other non-notes — cite those as paths in backticks (e.g. `` `.cursor/rules/engineering-knowledge-base-authority.mdc` ``).
- Structural links in frontmatter; contextual in body.
- Link the authoritative note; don’t duplicate it.
- Prefer `id` in prose when rename-resilience matters.
- Prefer **rename** over aliasing retired titles.
- Do not invent placeholder wikilinks (fake stems like “principle-leaf”). Prefer plain prose or a real note.
- Avoid nested double-bracket shapes inside typed code examples (Obsidian will treat them as links).
- After edits: every new wikilink must resolve to an existing stem (cleanliness gate in [[changing-this-bible]]).

## Naming (architecture)

| Piece | Rule |
| --- | --- |
| Path | `NN-altitude/{responsibility}/{slug}.md` |
| Responsibility folders | **One idea** — **no `and`** in folder or basename |
| Basename | Globally unique kebab; pattern = portable shape; guidance = stack detail (distinct basenames) |
| Stem ↔ H1 | H1 is the prose form of the basename (`delivery-ci` → `# Delivery CI`) |
| Title glue | No `/`, `&`, or trailing “and …” compounds that drift from the stem |
| Guidance stems | Concept only — **no** family/episode suffixes (`-lived`, `-platform`, `-warehouse`, …). Family via atlas + `domain` |
| Spelling | One canon across related notes (this vault: **artefact**) |
| Cross-altitude | Unique basenames at every altitude; parallel ideas must not invent near-duplicate stems casually |
| Catalogs | `catalog-*.md` only — never `_index.md` |
| Maps | `maps/families/{family}/*-atlas.md` or `maps/themes/{theme}/*-atlas.md` (+ `maps/catalog-maps.md`); atlas `concern` = leaf folder |
| Lab zoo | `lab/zoo/{facet}/{slug}.md` — `type: example`; stem ↔ H1; soft ≤15 lines code · ≤8 lines prose; must cite doctrine |
| Lab atlas | `lab/maps/lab-atlas.md` — index only; `concern` may be omitted or treated as lab map (see tests) |

Full law: [[navigation]]. Retirement and cleanliness checks: [[changing-this-bible]]. Praxis workflow: [[praxis-ingestion]]. Majority coverage: [[common-case-coverage]].

## AI retrieval

Follow [[navigation]] AI protocol. Short form:

1. Prefer `status: canonical` (doctrine)
2. Family → `maps/families/` atlas; theme → `maps/themes/` atlas; law → altitude × responsibility folder; stack → `domain`
3. For exemplars → [[lab-atlas]] after the canon
4. Read `description` / `aliases` first
5. Walk `derived_from` upward
6. Do not invent folders or standards absent from the vault
