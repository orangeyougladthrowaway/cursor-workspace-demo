---
type: workflow
status: canonical
id: engineering-knowledge-base-wf-006
concern: knowledge
description: Post-capture review after elevate — ledger honesty, depth labels, budgets, twins (beyond pytest).
domain: []
aliases: [stage-g, future-proof-review]
derived_from:
  - "[[knowledge-ingestion]]"
  - "[[changing-this-bible]]"
  - "[[d1-deep-harvest-playbook]]"
updated: 2026-07-16
---

# Post capture review

Run at the **end** of every remote-ingest / deep / Axis F wave after Stage F cleanliness ([[knowledge-ingestion]] Stage G). Pytest proves shape; this review proves **honesty of coverage claims**.

## When

After declaring W-gate, D1 theme, **D2+** residual deep, or **Axis F** track wave `done` on [[roadmap]]. Also after any batch that promoted multiple notes to `canonical`.

## Checklist

1. **Depth honesty** — For each source marked `deep` on [[ingest-coverage]], confirm primary text was fetched (not search snippets). Downgrade label or expand Untapped if not.
2. **Ledger sync** — Same batch facts appear in: scoreboard · cluster table · atlas backlog · [[roadmap]] health · [[common-case-coverage]] track scores when cells moved.
3. **Budget note** — If session exceeded [[d1-deep-harvest-playbook]] deep caps, record the override in one sentence on [[roadmap]] or coverage (do not silently normalize overruns). Program multi-session work is expected for Axis F — do not confuse session caps with destination done.
4. **Canonical bar** — Prefer `draft` when the note is pressure-without-primary. Canonical notes need primary cite(s), collision/resolution where lived fights remote, and explicit Untapped.
5. **Twin / projection scan** — One question → one living answer; thin duplicate spines (esp. [[coding-agent-projection]]).
6. **Scaffold freeze** — No new empty homes unless orphan proven + [[navigation]] amended.
7. **Health** — `pytest tests/ -v` green ([[vault-health-checks]]); if `lab/` touched, also `pytest tests/lab -v`.
8. **Praxis orphans** — Every new zoo entry cites doctrine; [[lab-atlas]] / [[catalog-lab]] updated; no curriculum ordering ([[praxis-ingestion]]).
9. **Matrix honesty** — If the wave claimed Axis F progress: update [[common-case-coverage]]; do not treat “facet seeded” as majority done; catalog-sweep any guidance/pattern that answers a cell but lacks G2/G4|Gap.
10. **Manual write** — Confirm no bulk-generated note flood landed this batch.

## Anti-patterns this catches

- Theme sweep marked “complete” while W skipped / Untapped tables still describe spine-only state
- `deep` used to mean “opened the theme atlas”
- Scoreboard says elevated; cluster table still skim; atlas still lists the note under Draft homes
- Promoting RAG-style honesty stubs without admitting harvest gap
- Lab zoo without canon cite, or treating snippets as sole law
- Declaring language/tool coverage done from zoo counts alone

## Related

- [[knowledge-ingestion]] · [[praxis-ingestion]] · [[ingest-coverage]] · [[common-case-coverage]] · [[d1-deep-harvest-playbook]] · [[vault-health-checks]] · [[roadmap]]
