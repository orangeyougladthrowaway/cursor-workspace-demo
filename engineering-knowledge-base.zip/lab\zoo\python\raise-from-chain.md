---
type: example
status: canonical
domain: [python]
derived_from:
  - "[[python-errors-resources]]"
updated: 2026-07-15
---

# Raise from chain

## When

Re-raising with cause so stacks stay honest.

## When not

Bare `raise Other()` that hides the original failure.

```python
try:
    parse(raw)
except ValueError as exc:
    raise ConfigError("bad config") from exc
```

## Related

- [[python-errors-resources]] · [[bare-except-anti]]
