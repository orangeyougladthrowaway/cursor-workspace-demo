---
type: foundation
status: canonical
description: Roadmap — F threshold met; Axis Q quality deepening (depth/alignment) active.
updated: 2026-07-16
---

# Roadmap

## Done

- Foundation + atlases + vault health + D1 + Stage G
- **D2 #1–#16** · **L0 + L core + L+** language deep
- **P0–P4** — dual-plane `lab/` capacity
- **F0–F7** — original majority common-case coverage threshold met; later craft scope keeps all tracks ≥70%

## Strategy

```text
W → D1 → D2+ / L
       → P (praxis capacity)
       → F (majority common-case coverage)  ← threshold met
       → Q (quality: depth · alignment · consistency)  ← active
```

## Axis Q — Quality deepening (active)

**Freeze width:** no new matrix rows / facets unless a lived house case forces them. Amend-first; change only when pros clearly outweigh cons.

| Phase | Status |
| --- | --- |
| Q0 Change discipline + target list | **`done`** |
| Q1 Health hold | **`done`** (suites green) |
| Q2 Navigability (atlas hygiene) | **`done`** |
| Q3 Purpose (house defaults, not docs mirrors) | **`done`** on hot set |
| Q4 Coverage honesty (depth ≠ G4 %) | **`done`** — see [[common-case-coverage]] Axis Q |
| Q5 Depth wave (hot homes) | **`done`** first wave |
| Q6 Principle/standard cites | **`done`** on hot set |
| Q7 Praxis sharpen (linked zoos) | **`done`** first wave |
| Q8 Code-craft doctrine (micro → macro) | **`done` at G2** — two standards + Python/C#/SQL structure/flow |
| Q9 Craft skeletons + agent dry-runs | **next** — prove choices, then move new cells toward G4 |

**Leave alone (already decision-ready):** [[config-fail-at-load]] · [[delivery-gates]] · [[coding-agent-projection]] · [[helm-deploy]] · [[gateway-auth]] · [[capability-bridges]]

**Intentional G2:** P27 · V06 — do not cosmetic-promote.

Scoreboard: [[common-case-coverage]]. Review: [[post-capture-review]].

## Axis P — Praxis capacity

| Phase | Status |
| --- | --- |
| P0–P4 | **`done`** |

## Axis F — Full coverage (majority common cases)

| Phase | Work | Status |
| --- | --- | --- |
| F0 | Law / bar / facet policy | **`done`** |
| F1 | Ledger matrices + Today scores | **`done`** |
| F2 | Principle roots + Gaps named | **`done`** |
| F3–F5 | Per-track densify | **`done`** — all tracks ≥70% G4 |
| F6 | Family polish | **`done`** (shapes via tracks; no lore) |
| F7 | Harden / scoreboard | **`done`** |

Scoreboard: [[common-case-coverage]] — **166/176 G4 (~94%)** after honest code-craft scope expansion; all tracks remain ≥70%.

**Budget note:** program override of session zoo/doctrine caps for Axis F completion pass.

## Axis L / D2+

| Band | Status |
| --- | --- |
| L | **`done`** |
| D2 #17+ | optional residual (prefer Untapped on atlases; not blocking F) |

### Health

| Metric | Last |
| --- | --- |
| Scaffold freeze (doctrine) | **on** |
| Width freeze (Axis Q) | **on** |
| Common-case overall G4 | **~94%** |
| Tracks ≥70% G4 | **16 / 16** |
| Suites | `pytest tests/` + `tests/lab` |
| Next | Axis Q9 craft skeletons + agent dry-runs; optional D2 Untapped after Q |

## Deferred / non-goals

- Per-snippet unit zoo · curriculum atlases · soft-theatre skeletons
- Hard Way labs 01–13 as zoo dump · Awesome dumps · product lore
- Bulk-scripted vault floods
- Claiming unread DDIA/TotT corpora complete
