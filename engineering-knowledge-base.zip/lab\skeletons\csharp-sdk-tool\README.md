---
description: Minimal SDK-style C# tool skeleton — cites csharp toolchain/async canons.
updated: 2026-07-15
---

# csharp-sdk-tool

## Purpose

Copy-out starter for a small .NET 8 console/tool project with Nullable enabled and async-friendly entry.

## Required canons

- [[csharp-project-toolchain]]
- [[csharp-async-di]]
- [[csharp-style-conventions]]
- [[delivery-gates]]

## Copy steps

1. Copy this folder into a new repo (or merge files).
2. Rename `CSharpSdkTool` / assembly names.
3. `dotnet restore` → `dotnet build` → `dotnet test` (add tests when you claim behaviour).
4. Pass `CancellationToken` through async APIs — no `.Result`.

## Honesty

- Nullable is on — do not drown warnings in `!`.
- Unit tests are a **hard** gate if you claim quality ([[delivery-gates]]).
- Scoped-into-singleton DI is an anti-pattern ([[scoped-in-singleton-anti]]).
