---
type: example
status: canonical
domain: [opentofu]
derived_from:
  - "[[terraform-state-backends]]"
updated: 2026-07-16
---

# Gcs backend gap

## When

Documenting that GCS backend is **not** a house SoT today.

## When not

Copying GCS recipes as lived law without adopting the backend.

```text
Praxis Gap: house uses azurerm/s3 paths today — GCS remains optional Untapped
```

## Related

- [[terraform-state-backends]] · [[common-case-coverage]]
