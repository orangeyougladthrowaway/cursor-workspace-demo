---
type: guidance
status: canonical
id: engineering-knowledge-base-g-wal
concern: audit
description: Accumulated Observer WAL / job audit knowledge across gateway families.
domain: [postgres, python]
aliases: [wal, observer, jobs, task_execution]
derived_from:
  - "[[write-ahead-call-audit]]"
updated: 2026-07-15
---

# Observer WAL

Atlas: [[platform-atlas]]. Pattern: [[write-ahead-call-audit]]. Argo correlation: [[argo-workflows]].

## Model

| Table | Role |
| --- | --- |
| `jobs` | Per run; `workflow_uid` UNIQUE |
| `task_executions` | pending→terminal; JSONB inputs/outputs |
| `execution_logs` | Level/message/context |
| `workflows` | Stored WT YAML (when used) |

**Flow:** resolve `X-Job-Id` → `record_pending` (full envelope payload) → execute → `observe` terminal + log. No job header → skip DB WAL (metrics may still fire).

**Opt-in:** `OBSERVER_DB_ENABLED` (default true in code; may be absent from Helm ConfigMap).

## Planes

| Family | Planes |
| --- | --- |
| K8s / Compose single-plane | **Single** Postgres for audit + platform persistence |
| Compose dual-plane | **Dual** — platform audit DB vs product/workflow DB |

Do not treat dual-plane as the family default.

**Postgres spine:** audit tables are ordinary relational **tables/rows/columns** ([[postgres-core-concepts]]). Engine durability/isolation: [[postgres-wal-concurrency]] (WAL-before-data, sync vs async commit, MVCC). Application write-ahead audit is a **different layer** ([[write-ahead-call-audit]]) — do not confuse the two “WAL”s. DDIA chapters remain D2+ ([[ddia-reliability-themes]]).

## Not WAL

| Name | Reality |
| --- | --- |
| Compose `@trace_wal` / stdout helpers | Print/correlation — not durable Observer |
| K8s `trace_wal`-adjacent tracer | Crash/correlation helper |
| Dead `@write_audit_log` | Invents job UUID; no call sites — theatre if revived |

## Operator recipes

1. From Argo/UI note `workflow.uid`, prefer resolve to `jobs.id`  
2. `recovery_cli --job-id <jobs.id> --report` (deps honesty: `tabulate` may be undeclared) or `get_job_execution_history`  
3. Re-run = new workflow / new uid — **not** resume-from-WAL  

Observe-path DB failure can 500 **after** backend already ran — durable state may lag.

## Quarantine

Unredacted payload WAL as privacy-safe · TARGET_STATE resume architecture · JSON `/metrics` as Prom-ready · conflating `@trace_wal` with Observer.

## Related

- [[write-ahead-call-audit]] · [[argo-workflows]] · [[envelope-call]] · [[capability-bridges]] · [[postgres-wal-concurrency]] · [[platform-atlas]]
