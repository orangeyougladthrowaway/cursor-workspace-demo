---
type: workflow
status: canonical
id: engineering-knowledge-base-wf-008
concern: knowledge
description: Common-case coverage instrument — majority bar, G1–G4 gates, track + cell scoreboard for Axis F.
domain: []
aliases: [majority-coverage, axis-f-ledger]
derived_from:
  - "[[purpose]]"
  - "[[scope]]"
  - "[[knowledge-ingestion]]"
  - "[[praxis-ingestion]]"
  - "[[ingest-coverage]]"
updated: 2026-07-16
---

# Common case coverage

Living **scoreboard** for Axis F ([[roadmap]]). Not doctrine for engineering choices — doctrine lives in responsibility notes. This note answers: **how covered are we** toward majority common cases for house languages/tools.

Approach / planning harvest: `temp/bible-full-coverage/`. **Cell truth lives here** after F1 (2026-07-16).

## Destination bar

≥ ~**70%** of matrix cells per track at **G4** (or G1–G3 + explicit praxis Gap). Human may lower a track threshold explicitly — agents must not ([[roadmap]]).

**Forbidden exit criteria:** facet seeded · pointer-only atlas row · “inventory themes touched” · zoo count without matrix %.

## Gates (per cell)

| Gate | Meaning |
| --- | --- |
| **G1 Law** | Living guidance/standard/pattern (or named Gap) answers the question |
| **G2 Root** | Principle cite + primary/trusted source and/or lived collision |
| **G3 Depth** | `section` or `deep` on [[ingest-coverage]] — not skim-as-done |
| **G4 Praxis** | Zoo/skeleton/stub cites that law — or explicit praxis Gap |

`Open` = below G1. Scores use the **highest completed** gate.

## Track scoreboard

| Track | Cells | G4 | % G4 | ≥70%? | Notes |
| --- | --- | --- | --- | --- | --- |
| Python | 29 | 26 | **90%** | **yes** | P27 target G2; P28–P29 craft at G2 |
| C# | 20 | 18 | **90%** | **yes** | C19–C20 craft at G2 |
| T-SQL / warehouse adj. | 26 | 26 | **100%** | **yes** | T13/T15 target still G3 (activation/testing densify) |
| Postgres | 15 | 13 | **87%** | **yes** | G14–G15 craft at G2 |
| Delivery + GHA | 12 | 12 | **100%** | **yes** | |
| Packaging · Docker · Compose | 10 | 10 | **100%** | **yes** | |
| OpenTofu | 10 | 10 | **100%** | **yes** | O10 Gap documented |
| Helm · K8s ops | 10 | 10 | **100%** | **yes** | |
| APIs · contracts | 12 | 12 | **100%** | **yes** | |
| Auth · trust | 10 | 10 | **100%** | **yes** | |
| Observability | 7 | 6 | **86%** | **yes** | V06 at target G2 |
| Argo · orchestration | 5 | 5 | **100%** | **yes** | |
| Agent craft | 6 | 6 | **100%** | **yes** | |
| Architecture · boundaries | 7 | 7 | **100%** | **yes** | |
| Bash glue | 3 | 3 | **100%** | **yes** | |
| Trainer thin | 3 | 3 | **100%** | **yes** | eng-only |
| **All tracks** | **176** | **166** | **~94%** | **yes** | Axis F threshold held; code-craft scope added honestly |

## Axis Q honesty (depth ≠ matrix %)

G4 proves **law + praxis cite**, not agent-ready depth. Axis Q ([[roadmap]]) deepens high-traffic homes without changing F cell counts unless a cell was falsely claimed.

| Wave | Homes deepened (amend-first) | Left intentional |
| --- | --- | --- |
| Q0–Q7 | STJ · Span · JSONB · Docker · csharp-async-di · public-HTTP/Envelope · OAS · REST defaults · py concurrency/logging/packaging/style/langsec · TF modules · postgres-core · service-packaging · compose secrets · host-opentofu cites · metrics wire honesty · linq Do/Avoid | P27 · V06 · O10 Gap · DEEP set untouched |
| Q craft | [[cohesive-code-units]] · [[readable-control-flow]] · Python/C#/SQL structure + flow guidance | New cells at G2 until skeleton/dry-run praxis proves G4 |

**Do not** re-score F % upward from this wave — quality is separate from gate counts.

## Cell matrices

Homes are wikilink stems where stable. Update **Today** in the same change as doctrine/praxis moves.

### Python

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| P01 | Style / lint honesty | G4 | G4 | [[python-style-pep8]] |
| P02 | Packaging layout (src) | G4 | G4 | [[python-packaging-layout]] |
| P03 | Editable / lock / install | G4 | G4 | [[python-packaging-layout]] |
| P04 | console_scripts | G4 | G4 | [[python-packaging-layout]] |
| P05 | Typing / mypy honesty | G4 | G4 | [[python-typing-honesty]] |
| P06 | Protocol / TypedDict | G4 | G4 | [[python-typing-honesty]] |
| P07 | raise/from · bare except | G4 | G4 | [[python-errors-resources]] |
| P08 | with / ExitStack | G4 | G4 | [[python-errors-resources]] |
| P09 | TaskGroup / timeout | G4 | G4 | [[python-concurrency-async]] |
| P10 | No sync-over-async | G4 | G4 | [[python-concurrency-async]] |
| P11 | Threads/process when | G4 | G4 | [[python-concurrency-async]] |
| P12 | getLogger / levels | G4 | G4 | [[python-logging-modeling]] |
| P13 | Dataclass vs edge models | G4 | G4 | [[python-logging-modeling]] |
| P14 | secrets / compare_digest | G4 | G4 | [[python-langsec-secrets]] |
| P15 | Env/config fail-loud | G4 | G4 | [[config-fail-at-load]] · [[required-happy-path]] |
| P16 | pytest layout / importlib | G4 | G4 | [[pytest-practices]] |
| P17 | Fixture scopes / request | G4 | G4 | [[pytest-practices]] |
| P18 | Parametrize / markers | G4 | G4 | [[pytest-practices]] |
| P19 | Unit vs integration honesty | G4 | G4 | [[unit-testing-norm]] |
| P20 | Soft quality anti | G4 | G4 | [[delivery-ci]] |
| P21 | HTTP client timeout/cancel | G4 | G4 | [[python-concurrency-async]] |
| P22 | JSON encode/decode boundary | G4 | G4 | [[python-typing-honesty]] |
| P23 | Path / file IO | G4 | G4 | [[python-errors-resources]] |
| P24 | CLI argparse/typer thin | G4 | G4 | [[python-packaging-layout]] |
| P25 | Extras by role | G4 | G4 | [[service-packaging]] |
| P26 | Ingest landing honesty | G4 | G4 | [[python-ingest]] |
| P27 | Perf measure-first thin | G2 | G2 | [[restraint]] |
| P28 | Module/class/function structure | G2 | G4 | [[python-code-structure]] |
| P29 | Branch/iteration/async choice | G2 | G4 | [[python-flow-choices]] |

### C#

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| C01 | SDK-style project | G4 | G4 | [[csharp-project-toolchain]] |
| C02 | Nullable reference types | G4 | G4 | [[csharp-project-toolchain]] |
| C03 | Naming / FDG thin | G4 | G4 | [[csharp-style-conventions]] |
| C04 | Async + CancellationToken | G4 | G4 | [[csharp-async-di]] |
| C05 | No sync-over-async | G4 | G4 | [[csharp-async-di]] |
| C06 | DI lifetimes | G4 | G4 | [[csharp-async-di]] |
| C07 | Scoped-in-singleton anti | G4 | G4 | [[csharp-async-di]] |
| C08 | LINQ deferred / materialize | G4 | G4 | [[csharp-linq-api]] |
| C09 | Exceptions honesty | G4 | G3 | [[csharp-async-di]] |
| C10 | IDisposable / await using | G4 | G4 | [[csharp-async-di]] |
| C11 | Options pattern | G4 | G3 | [[csharp-project-toolchain]] |
| C12 | ILogger | G4 | G4 | [[csharp-async-di]] |
| C13 | xUnit + hard gate | G4 | G4 | [[unit-testing-norm]] |
| C14 | Span/Memory common subset | G4 | G4 | [[csharp-span-memory]] |
| C15 | System.Text.Json boundary | G4 | G4 | [[csharp-system-text-json]] |
| C16 | HttpClient factory / timeout | G4 | G4 | [[csharp-async-di]] |
| C17 | DACPAC / SSDT adjacency | G4 | G3 | [[dacpac-publish]] |
| C18 | Analyzer / warnings | G4 | G3 | [[csharp-project-toolchain]] |
| C19 | File/type/class structure | G2 | G4 | [[csharp-code-structure]] |
| C20 | Guards/LINQ/loop/async choice | G2 | G4 | [[csharp-flow-choices]] |

### T-SQL / warehouse adjacent

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| T01 | Set-based vs RBAR | G4 | G4 | [[tsql-set-based-merge]] |
| T02 | MERGE + OUTPUT + locking | G4 | G4 | [[tsql-set-based-merge]] |
| T03 | TRY/CATCH + XACT_STATE | G4 | G4 | [[tsql-batch-craft]] |
| T04 | TVP + READONLY | G4 | G4 | [[tsql-batch-craft]] |
| T05 | sp_executesql params | G4 | G4 | [[tsql-batch-craft]] |
| T06 | Transactions / isolation | G4 | G4 | [[tsql-set-based-merge]] |
| T07 | Temp vs table var | G4 | G4 | [[tsql-batch-craft]] |
| T08 | Indexes / plans | G4 | G4 | [[sql-index-plan-craft]] |
| T09 | SCD2 dual-current anti | G4 | G4 | [[kimball-type2-scd]] |
| T10 | Historisation layers | G4 | G4 | [[historisation-layers]] |
| T11 | SqlPackage lab vs prod | G4 | G4 | [[dacpac-publish]] |
| T12 | Compiled schema release | G4 | G4 | [[compiled-schema-release]] |
| T13 | Host activation | G4 | G3 | [[host-activation]] |
| T14 | Python ingest landing | G4 | G4 | [[python-ingest]] |
| T15 | SQL testing / hard gates | G4 | G3 | [[delivery-gates]] |
| T16 | SQL object/routine structure | G4 | G4 | [[sql-code-structure]] · [[sql-programmability-craft]] |
| T17 | Set/procedural/materialisation choice | G4 | G4 | [[sql-flow-choices]] |
| T18 | Grain + SCD2 dim / snapshot fact | G4 | G4 | [[warehouse-grain]] · [[scd2-dim-snapshot-fact]] |
| T19 | SSDT sqlproj build | G4 | G4 | [[ssdt-sqlproj]] |
| T20 | PreDeploy / PostDeploy / publish profiles | G4 | G4 | [[ssdt-publish-scripts]] |
| T21 | SSIS dtproj / dtsx / ispac | G4 | G4 | [[ssis-dtproj-dtsx]] |
| T22 | Constraints / table invariants | G4 | G4 | [[sql-constraints-craft]] |
| T23 | Concurrency / isolation craft | G4 | G4 | [[sql-concurrency-craft]] |
| T24 | Agent jobs craft | G4 | G4 | [[sql-agent-jobs-craft]] |
| T25 | Maintenance craft | G4 | G4 | [[sql-maintenance-craft]] |
| T26 | Systems→eng craft map | G4 | G4 | [[sql-server-craft-map]] |

### Postgres

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| G01 | Relational core / types | G4 | G4 | [[postgres-core-concepts]] |
| G02 | ON CONFLICT upsert | G4 | G4 | [[postgres-sql-craft]] |
| G03 | CTE + RETURNING | G4 | G4 | [[postgres-sql-craft]] |
| G04 | Window functions | G4 | G4 | [[postgres-sql-craft]] |
| G05 | EXPLAIN / ANALYZE | G4 | G4 | [[postgres-sql-craft]] |
| G06 | Indexes common | G4 | G4 | [[postgres-sql-craft]] |
| G07 | Transactions / isolation | G4 | G4 | [[postgres-wal-concurrency]] |
| G08 | WAL vs app audit | G4 | G4 | [[postgres-wal-concurrency]] |
| G09 | MVCC thin | G4 | G3 | [[postgres-wal-concurrency]] |
| G10 | Migrations (alembic) | G4 | G4 | [[postgres-sql-craft]] |
| G11 | JSONB common subset | G4 | G4 | [[postgres-jsonb-craft]] |
| G12 | Pooling honesty | G4 | G3 | [[durable-storage-tradeoffs]] |
| G13 | DDIA reliability link | G4 | G3 | [[ddia-reliability-themes]] |
| G14 | SQL object/query structure | G2 | G4 | [[sql-code-structure]] |
| G15 | Set/procedural/materialisation choice | G2 | G4 | [[sql-flow-choices]] |

### Delivery + GitHub Actions

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| D01 | Hard vs soft gates | G4 | G4 | [[delivery-gates]] |
| D02 | continue-on-error anti | G4 | G4 | [[delivery-ci]] |
| D03 | Unit hard gate workflow | G4 | G4 | [[delivery-gates]] |
| D04 | Small CL + tests | G4 | G4 | [[code-review-norm]] |
| D05 | Pre vs post submit | G4 | G4 | [[prove-honesty-contracts-in-delivery]] |
| D06 | Coverage ≠ quality | G4 | G4 | [[coverage-not-quality]] |
| D07 | Fail at the gate | G4 | G4 | [[fail-at-the-gate]] |
| D08 | DORA use/abuse | G4 | G4 | [[dora-metrics]] |
| D09 | Integration/hermetic | G4 | G3 | [[delivery-gates]] Untapped |
| D10 | Multi-workflow green ambiguity | G4 | G4 | [[delivery-ci]] |
| D11 | Secrets in CI | G4 | G4 | [[delivery-ci]] |
| D12 | Review norms applied | G4 | G4 | [[code-review-norm]] |

### Packaging · Docker · Compose

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| K01 | One process / capability | G4 | G4 | [[docker-containers]] |
| K02 | Non-root USER | G4 | G4 | [[docker-containers]] |
| K03 | Extras → images | G4 | G4 | [[service-packaging]] |
| K04 | Dual Poetry anti | G4 | G4 | [[trainer-packaging]] |
| K05 | Domain IO edge packaging | G4 | G4 | [[domain-io-edge-packaging]] |
| K06 | Compose profiles | G4 | G4 | [[compose-deploy]] |
| K07 | Compose vs Helm SoT | G4 | G4 | [[compose-deploy]] |
| K08 | Healthcheck / restart | G4 | G3 | [[docker-containers]] |
| K09 | Multi-stage build | G4 | G4 | [[docker-containers]] |
| K10 | .dockerignore / layers | G4 | G3 | [[docker-containers]] |

### OpenTofu

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| O01 | Remote state required | G4 | G4 | [[terraform-state-backends]] |
| O02 | azurerm backend | G4 | G4 | [[terraform-state-backends]] |
| O03 | s3 + lockfile | G4 | G4 | [[terraform-state-backends]] |
| O04 | No plaintext state | G4 | G4 | [[terraform-state-backends]] |
| O05 | Module composition | G4 | G4 | [[terraform-modules-composition]] |
| O06 | Variable validation | G4 | G4 | [[terraform-modules-composition]] |
| O07 | Workspaces vs dirs | G4 | G3 | [[host-opentofu]] |
| O08 | Plan/apply in CI | G4 | G4 | [[host-opentofu]] |
| O09 | Provider pin / lock | G4 | G4 | [[host-opentofu]] |
| O10 | GCS backend | G4 | Gap|G3 | Gap unless house needs |

### Helm · Kubernetes ops

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| H01 | helm template compile | G4 | G4 | [[helm-deploy]] |
| H02 | Values honesty | G4 | G4 | [[helm-deploy]] |
| H03 | Hard Way ≠ SoT | G4 | G4 | [[kubernetes-hard-way-pedagogy]] |
| H04 | Manifest tests hard | G4 | G4 | [[delivery-gates]] |
| H05 | Deploy/rollback | G4 | G4 | [[helm-deploy]] |
| H06 | Requests/limits | G4 | G3 | [[helm-deploy]] |
| H07 | Probes | G4 | G4 | [[helm-deploy]] |
| H08 | ConfigMap/Secret mounts | G4 | G4 | [[helm-deploy]] |
| H09 | Service/Ingress thin | G4 | G3 | [[helm-deploy]] |
| H10 | Workload basics | G4 | G3 | [[helm-deploy]] |

### APIs · contracts

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| A01 | OpenAPI paths/components | G4 | G4 | [[openapi-specification]] |
| A02 | REST pagination/filter | G4 | G4 | [[rest-resource-design]] |
| A03 | Public HTTP vs Envelope | G4 | G4 | [[public-http-vs-internal-envelope]] |
| A04 | Envelope call | G4 | G4 | [[envelope-call]] |
| A05 | Adapter routing | G4 | G4 | [[adapter-routing]] |
| A06 | Adapter metadata routing | G4 | G4 | [[adapter-metadata-routing]] |
| A07 | Policy ingress | G4 | G4 | [[policy-ingress-contract]] |
| A08 | Capability bridges | G4 | G3 | [[capability-bridges]] |
| A09 | Credential-owning bridge | G4 | G4 | [[credential-owning-bridge]] |
| A10 | Write-ahead call audit | G4 | G4 | [[write-ahead-call-audit]] |
| A11 | Versioning / compatibility | G4 | G3 | [[published-contract-stability]] |
| A12 | Error shape honesty | G4 | G4 | [[rest-resource-design]] |

### Auth · trust

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| S01 | Gateway auth posture | G4 | G4 | [[gateway-auth]] |
| S02 | Password storage | G4 | G4 | [[owasp-password-storage-pressure]] |
| S03 | Session hygiene | G4 | G4 | [[owasp-session-pressure]] |
| S04 | Forgot-password anti-enum | G4 | G4 | [[owasp-forgot-password-pressure]] |
| S05 | MFA factor hygiene | G4 | G4 | [[owasp-multifactor-authentication-pressure]] |
| S06 | Fall-open anti | G4 | G4 | [[gateway-auth]] |
| S07 | OWASP Top10 mapping | G4 | G3 | [[owasp-top10-mapping]] |
| S08 | ASVS auth mapping | G4 | G3 | [[asvs-authentication-mapping]] |
| S09 | Threat model declaration | G4 | G4 | [[threat-model-declaration]] |
| S10 | Matched controls | G4 | G3 | [[threat-model-matched-controls]] |

### Observability

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| V01 | Metrics/traces/logs roles | G4 | G4 | [[metrics-tracing-logging-pressure]] |
| V02 | Cardinality hazards | G4 | G4 | [[metrics-tracing-logging-pressure]] |
| V03 | Span kinds | G4 | G4 | [[metrics-tracing-logging-pressure]] |
| V04 | Monitoring ≠ observability | G4 | G4 | [[dora-capabilities-index]] |
| V05 | Correlation / trace context | G4 | G4 | [[metrics-tracing-logging-pressure]] |
| V06 | SLIs/SLOs thin | G2 | G2 | [[dora-metrics]] |
| V07 | Log PII / redaction | G4 | G4 | [[python-langsec-secrets]] |

### Argo · orchestration

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| R01 | Outer stage grain | G4 | G4 | [[argo-workflows]] |
| R02 | Workflow params honesty | G4 | G4 | [[argo-workflows]] |
| R03 | In-process orchestration | G4 | G3 | [[in-process-orchestration]] |
| R04 | Airflow pointer vs elevate | G4 | G2 | [[airflow-dag-orchestration]] |
| R05 | dbt pointer vs elevate | G4 | G2 | [[dbt-transform-as-code]] |

### Agent craft

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| E01 | Projection / canon-first | G4 | G4 | [[coding-agent-projection]] (+ lifecycle [[plan-engineering-change]] … [[review-engineering-change]]) |
| E02 | RAG untrusted | G4 | G4 | [[rag-retrieval-pressure]] |
| E03 | Claim card shape | G4 | G4 | [[knowledge-ingestion]] |
| E04 | Reason-act bounds | G4 | G4 | [[react-reason-act-pressure]] |
| E05 | Deterministic before probabilistic | G4 | G4 | [[deterministic-before-probabilistic]] |
| E06 | MCP/tools pressure | G4 | G3 | [[coding-agent-projection]] |

### Architecture · boundaries

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| X01 | Microservice prerequisites | G4 | G4 | [[microservice-prerequisites]] + zoo |
| X02 | Smart endpoints / dumb pipes | G4 | G4 | [[smart-endpoints-dumb-pipes-contrast]] |
| X03 | Modular monolith vs services | G4 | G3 | [[microservices-tradeoffs]] |
| X04 | Distributed expectations | G4 | G3 | [[distributed-systems-expectations]] |
| X05 | Thin primitives vs platform weight | G4 | G3 | [[thin-primitives-over-platform-weight]] |
| X06 | DDD pressure ↔ concerns | G4 | G3 | [[domain-driven-design-pressure]] |
| X07 | Privileged capability boundaries | G4 | G4 | [[privileged-capability-boundaries]] |

### Bash · trainer thin

| # | Case | Today | Target | Home |
| --- | --- | --- | --- | --- |
| B01 | set -euo pipefail | G4 | G4 | [[tooling-proficiency]] |
| B02 | Quote expansions | G4 | G4 | [[tooling-proficiency]] |
| B03 | CI glue idempotency | G4 | G3 | [[delivery-ci]] |
| U01 | Dual Poetry anti | G4 | G4 | [[trainer-packaging]] |
| U02 | Hydra config honesty | G4 | G3 | [[hydra-config]] |
| U03 | Train loop pointer | G4 | G2 | [[train-loop-ppo]] |

## Principle roots (F2)

Every common-case note should eventually cite upward. Default spines (do not invent categories):

| Concept | Use when common cases touch… |
| --- | --- |
| [[ownership]] | Credentials, privileged capability |
| [[boundaries]] | Service/module walls, DDD language |
| [[failure]] | Fail-loud, fail-at-gate |
| [[honesty]] | Soft theatre, RAG/claims, determinism |
| [[restraint]] | YAGNI, thin primitives, measure-before-opt (P27) |
| [[change]] | Evolution, extend-by-patterns |
| [[trust]] | Threat model, auth posture |
| [[authority]] | Docs-as-authority |
| [[proof]] | Gates, coverage≠quality, prove honesty |
| [[reliability]] | Storage durability, distributed expectations |

**Named Gaps / deferred backends:**

| Cell | Status |
| --- | --- |
| C14 / C15 | **Elevated** — [[csharp-span-memory]] · [[csharp-system-text-json]] |
| G11 | **Elevated** — [[postgres-jsonb-craft]] |
| O10 | **Praxis Gap** documented (house uses azurerm/s3) — zoo [[gcs-backend-gap]] |

Open cells with an existing home already have a **path** to principles via that home’s layer. F3–F5 densify complete for Axis F threshold.

## Session vs program

| Level | Rule |
| --- | --- |
| **Session** | [[d1-deep-harvest-playbook]] / [[praxis-ingestion]] caps; overrides on [[roadmap]] / [[ingest-coverage]] |
| **Program** | Multi-session until track ≥70% G4 ([[roadmap]] Axis F) |

## Update rules

- Same change as doctrine/praxis that moves a cell.
- Refresh track scoreboard % after each wave.
- [[post-capture-review]] matrix check before calling a wave done.
- Hand-write only — no bulk cell generators.

## Related

- [[purpose]] · [[scope]] · [[roadmap]] · [[ingest-coverage]] · [[praxis-ingestion]] · [[lab-atlas]] · [[architecture-atlas]] · [[catalog-workflows]]
