# Agent notes — containers

## Authority

| Source | Owns | Write? |
| --- | --- | --- |
| `engineering-knowledge-base` | Image/Compose craft, prefer-image, admission | **No** from this repo |
| `systems-knowledge-base` | ACR / ADO SoR facts | **No** from this repo |
| This repo | Dockerfiles, services, pins, `base-images.md`, CI | **Yes** |

## Operating law

1. Retrieve eng prefer-house-platform-image / house-containers-remote before adding a service or changing pins (`engineering-knowledge-base-wf-016`, `engineering-knowledge-base-g-containers`).
2. Custom images install **pinned** `python-lib` from `lib-pin.txt` — never floating `main`, never vendored lib tree as steady state.
3. Bumping the pin requires that version to be published by `python-lib` CI first — release order lives in `agent-harness/docs/release-chain.md`; do not pass feed credentials into `docker build`.
4. **ACR publish path is ADO only** — never `docker push` / `az acr` publish from a laptop agent session. Images reach ACR solely via merge to `main` → `containers-publish`. Local `docker build` for proof is fine; do not push.
5. Third-party images: update `base-images.md` (source + pin); do not paste vendor manuals.
6. No Helm / no Kubernetes as deploy SoT.
7. Inference bridges out of scope until explicitly admitted.
8. Light docs only; point at eng ids — not a second bible.
