"""Finnhub credential-owning bridge."""
