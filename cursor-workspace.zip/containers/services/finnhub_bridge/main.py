"""Finnhub API bridge — quote lookup via Finnhub REST."""

from __future__ import annotations

import os
from typing import Any

import httpx
from python_lib.contracts.envelopes import ServiceRequest
from python_lib.runtime import create_service_api, wrapper_method

_FINNHUB_QUOTE = "https://finnhub.io/api/v1/quote"


class FinnhubBridgeService:
    """Outbound Finnhub bridge. Requires FINNHUB_API_KEY (fail-loud)."""

    @wrapper_method("finnhub_bridge", "get_quote")
    def get_quote(self, request: ServiceRequest) -> dict[str, Any]:
        payload = request.envelope.payload
        symbol = payload.get("symbol")
        if not isinstance(symbol, str) or not symbol.strip():
            raise ValueError("symbol required (string)")
        token = os.environ.get("FINNHUB_API_KEY", "").strip()
        if not token:
            raise ValueError("FINNHUB_API_KEY is required")

        response = httpx.get(
            _FINNHUB_QUOTE,
            params={"symbol": symbol.strip().upper(), "token": token},
            timeout=30.0,
        )
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, dict):
            raise ValueError("finnhub quote response must be an object")
        if data.get("c") is None and data.get("error"):
            raise ValueError(f"finnhub error: {data.get('error')}")
        return {
            "symbol": symbol.strip().upper(),
            "current": data.get("c"),
            "high": data.get("h"),
            "low": data.get("l"),
            "open": data.get("o"),
            "previous_close": data.get("pc"),
            "raw": data,
        }


app = create_service_api("finnhub_bridge", FinnhubBridgeService())

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8002)
