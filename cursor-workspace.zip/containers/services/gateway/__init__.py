"""Gateway service package."""
