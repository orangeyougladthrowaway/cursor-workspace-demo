"""Layer 9: Observation (Logging, Metrics, and Write-Ahead Logging)."""

from __future__ import annotations

import os
import uuid
from datetime import datetime
from typing import Any

from python_lib.observability.structured_logger import get_logger
from services.gateway.support.metrics_collector import MetricsCollector

logger = get_logger(__name__)


class Observer:
    """Layer 9: Log, emit metrics, and write-ahead via db-api (HTTP)."""

    def __init__(
        self,
        metrics: MetricsCollector | None = None,
        db_api_client: Any | None = None,
    ) -> None:
        """Initialize observer. Write-ahead uses db_api_client when available."""
        self.metrics = metrics or MetricsCollector()
        self._db_api_client = db_api_client
        self._db_enabled = os.getenv("OBSERVER_DB_ENABLED", "true").lower() == "true"

    def record_pending(
        self,
        envelope_data: dict[str, Any],
        context: dict[str, Any],
    ) -> str | None:
        """Write-ahead: record pending task execution before service call (via db-api)."""
        if not self._db_enabled or not self._db_api_client:
            return None

        job_id = context.get("job_id")
        if not job_id:
            return None
        workflow_uid = context.get("workflow_uid")
        if not workflow_uid:
            raise ValueError("workflow_uid required in context for write-ahead (X-Job-Id hop)")

        trace_id = context.get("trace_id") or envelope_data.get("trace_id") or str(uuid.uuid4())
        request_id = envelope_data.get("request_id") or ""
        service = envelope_data.get("target", {}).get("service", "unknown")
        method = envelope_data.get("target", {}).get("method", "unknown")
        inputs = envelope_data.get("payload", {})
        item_id = inputs.get("item_id") or inputs.get("file") or inputs.get("id")

        task_id = self._db_api_client.record_task_execution_pending(
            job_id=job_id,
            trace_id=trace_id,
            service=service,
            method=method,
            inputs=inputs,
            request_id=request_id,
            workflow_uid=str(workflow_uid),
            item_id=item_id,
        )
        logger.debug(
            "Recorded pending task",
            task_id=task_id,
            job_id=job_id,
            service=service,
            method=method,
        )
        return task_id

    def observe(
        self,
        envelope_data: dict[str, Any],
        context: dict[str, Any],
        response: dict[str, Any],
    ) -> None:
        """Observe request/response, emit metrics, and update task execution."""
        received_at = context.get("received_at", datetime.utcnow())
        now = datetime.utcnow()
        duration_seconds = (now - received_at).total_seconds()

        service = envelope_data.get("target", {}).get("service", "unknown")
        method = envelope_data.get("target", {}).get("method", "unknown")
        status = response.get("status", "unknown")

        logger.info(
            "Request completed",
            service=service,
            method=method,
            status=status,
            duration_seconds=duration_seconds,
            trace_id=envelope_data.get("trace_id"),
            request_id=envelope_data.get("request_id"),
        )

        self.metrics.record_request(
            service=service,
            method=method,
            status=status,
            duration_seconds=duration_seconds,
        )

        if status == "error" and response.get("error"):
            error_code = response["error"].get("code", "unknown")
            self.metrics.record_error(error_code)

        task_id = context.get("task_execution_id")
        job_id = context.get("job_id")
        request_id = envelope_data.get("request_id") or ""

        workflow_uid = context.get("workflow_uid")
        if self._db_enabled and self._db_api_client and job_id:
            if not workflow_uid:
                raise ValueError("workflow_uid required in context for write-ahead (X-Job-Id hop)")
            outputs = (response.get("payload") or response.get("data")) if status == "success" else None
            error = response.get("error") if status != "success" else None

            self._db_api_client.update_task_execution(
                task_id=task_id,
                job_id=job_id,
                trace_id=context.get("trace_id"),
                service=service,
                method=method,
                status="success" if status == "success" else "failed",
                request_id=request_id,
                workflow_uid=str(workflow_uid),
                outputs=outputs,
                error=error,
                duration_seconds=duration_seconds,
            )
            level = "ERROR" if status != "success" else "INFO"
            message = f"{service}.{method} - {status}"
            context_data = {
                "service": service,
                "method": method,
                "status": status,
                "duration_seconds": duration_seconds,
            }
            if error:
                context_data["error"] = error
            self._db_api_client.record_execution_log(
                job_id=job_id,
                trace_id=context.get("trace_id") or "",
                level=level,
                message=message,
                request_id=request_id,
                workflow_uid=str(workflow_uid),
                task_execution_id=task_id,
                context=context_data,
            )
            logger.debug(
                "Updated task execution",
                task_id=task_id,
                job_id=job_id,
                status=status,
            )
