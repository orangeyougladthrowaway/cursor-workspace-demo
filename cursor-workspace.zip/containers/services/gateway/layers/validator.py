"""Layer 3: Validation."""

from __future__ import annotations

from typing import Any

from python_lib.contracts.envelopes import EnvelopeV1Request
from python_lib.observability.structured_logger import get_logger

logger = get_logger(__name__)


class Validator:
    """Layer 3: Validate request against schema."""

    def validate(
        self,
        envelope: EnvelopeV1Request,
        context: dict[str, Any],
    ) -> tuple[bool, str | None]:
        """Validate request envelope and payload."""
        if not envelope.envelope_version:
            return False, "Missing envelope_version"

        if envelope.envelope_version != "1.0":
            return False, f"Unsupported envelope version: {envelope.envelope_version}"

        if not envelope.target.get("service"):
            return False, "Missing target.service"

        if not envelope.target.get("method"):
            return False, "Missing target.method"

        if envelope.payload is None:
            return False, "Missing payload"

        logger.debug(
            "Request validated",
            service=envelope.target.get("service"),
            method=envelope.target.get("method"),
            trace_id=envelope.trace_id,
        )

        return True, None
