"""Layer 6: Enrichment."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from python_lib.contracts.envelopes import EnvelopeV1Request
from python_lib.observability.structured_logger import get_logger
from python_lib.observability.tracer import Tracer

logger = get_logger(__name__)


class Enricher:
    """Layer 6: Enrich request with context."""

    def enrich(
        self,
        envelope: EnvelopeV1Request,
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Enrich request context."""
        Tracer.set_trace_id(envelope.trace_id)

        context["received_at"] = datetime.utcnow()
        context["service"] = envelope.target.get("service")
        context["method"] = envelope.target.get("method")
        context["actor"] = envelope.actor

        logger.debug(
            "Request enriched",
            service=context["service"],
            method=context["method"],
            trace_id=envelope.trace_id,
        )

        return context
