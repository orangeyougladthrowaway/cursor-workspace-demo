"""Layer 5: Routing."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from python_lib.contracts.envelopes import EnvelopeV1Request
from python_lib.observability.structured_logger import get_logger

logger = get_logger(__name__)

ServiceHandler = Callable[..., dict[str, Any]]


class Router:
    """Layer 5: Route to service handler."""

    def __init__(self) -> None:
        """Initialize router."""
        self.handlers: dict[str, ServiceHandler] = {}

    def register(self, service: str, method: str, handler: ServiceHandler) -> None:
        """Register a service method handler."""
        key = f"{service}:{method}"
        self.handlers[key] = handler
        logger.debug(f"Registered handler: {key}")

    def route(
        self,
        envelope: EnvelopeV1Request,
        context: dict[str, Any],
    ) -> tuple[ServiceHandler | None, str | None]:
        """Route to appropriate handler."""
        service = envelope.target.get("service", "")
        method = envelope.target.get("method", "")
        key = f"{service}:{method}"

        if key not in self.handlers:
            error_msg = f"No handler for {key}"
            logger.warning(error_msg, service=service, method=method)
            return None, error_msg

        handler = self.handlers[key]
        logger.debug(
            "Routed to handler",
            service=service,
            method=method,
            trace_id=envelope.trace_id,
        )

        return handler, None
