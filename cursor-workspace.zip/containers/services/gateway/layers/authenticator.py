"""Layer 2: Authentication."""

from __future__ import annotations

from typing import Any

from python_lib.contracts.envelopes import EnvelopeV1Request
from python_lib.observability.structured_logger import get_logger
from services.gateway.support.token_generator import TokenGenerator

logger = get_logger(__name__)


class Authenticator:
    """Layer 2: Authenticate service identity via JWT tokens."""

    def __init__(self, enabled: bool = True) -> None:
        """Initialize authenticator."""
        self.enabled = enabled

    def authenticate(
        self,
        envelope: EnvelopeV1Request,
        context: dict[str, Any],
    ) -> tuple[bool, str | None]:
        """Authenticate request via JWT token in Authorization header."""
        if not self.enabled:
            return True, None

        auth_header = context.get("auth_header")
        if auth_header:
            return self._authenticate_jwt(auth_header, context)

        return self._authenticate_actor(envelope, context)

    def _authenticate_jwt(
        self, auth_header: str, context: dict[str, Any]
    ) -> tuple[bool, str | None]:
        """Authenticate using JWT token."""
        try:
            token = TokenGenerator.extract_token_from_header(auth_header)
            claims = TokenGenerator.validate_token(token)

            context["auth_subject"] = claims.get("sub")
            context["auth_scopes"] = claims.get("scopes", [])
            context["auth_type"] = claims.get("actor_type", "unknown")

            logger.debug(
                "JWT authentication successful",
                subject=context["auth_subject"],
                actor_type=context["auth_type"],
            )
            return True, None

        except ValueError as e:
            logger.warning(f"JWT authentication failed: {e}")
            return False, f"Invalid token: {e}"
        except Exception as e:
            logger.error(f"Unexpected error during JWT authentication: {e}")
            return False, "Authentication error"

    def _authenticate_actor(
        self, envelope: EnvelopeV1Request, context: dict[str, Any]
    ) -> tuple[bool, str | None]:
        """Authenticate using legacy actor format (internal services)."""
        if not envelope.actor or not (
            envelope.actor.startswith("service:") or envelope.actor.startswith("user:")
        ):
            return False, f"Invalid actor format: {envelope.actor}"

        if not envelope.trace_id:
            return False, "Missing trace_id"

        actor_parts = envelope.actor.split(":", 1)
        actor_type = actor_parts[0]
        context["auth_subject"] = envelope.actor
        context["auth_type"] = actor_type
        context["auth_scopes"] = [f"{actor_type}:*"]

        logger.debug(
            "Actor authentication successful",
            actor=envelope.actor,
            trace_id=envelope.trace_id,
        )

        return True, None
