"""Layer 7: Execution."""

from __future__ import annotations

import time
from typing import Any

import httpx

from python_lib.contracts.envelopes import EnvelopeV1Request
from python_lib.observability.structured_logger import get_logger
from services.gateway.service_forwarder import ServiceUnreachableError

logger = get_logger(__name__)


def _is_retryable(exc: Exception) -> bool:
    return isinstance(
        exc,
        (ServiceUnreachableError, httpx.TimeoutException, httpx.ConnectError),
    )


class Executor:
    """Layer 7: Execute service handler with retry logic."""

    def __init__(self, max_retries: int = 3, retry_delay_ms: int = 100) -> None:
        """Initialize executor."""
        self.max_retries = max_retries
        self.retry_delay_ms = retry_delay_ms

    def execute(
        self,
        handler: Any,
        envelope: EnvelopeV1Request,
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute handler with retry logic."""
        attempt = 0

        while attempt <= self.max_retries:
            try:
                result = handler(envelope, context)

                logger.debug(
                    "Handler executed successfully",
                    service=envelope.target.get("service"),
                    method=envelope.target.get("method"),
                    attempt=attempt,
                    trace_id=envelope.trace_id,
                )

                return result

            except Exception as e:
                if not _is_retryable(e):
                    logger.error(
                        "Handler execution failed (non-retryable)",
                        service=envelope.target.get("service"),
                        method=envelope.target.get("method"),
                        error=str(e),
                        trace_id=envelope.trace_id,
                        exc_info=True,
                    )
                    raise

                attempt += 1

                if attempt > self.max_retries:
                    logger.error(
                        "Handler execution failed after retries",
                        service=envelope.target.get("service"),
                        method=envelope.target.get("method"),
                        attempt=attempt,
                        error=str(e),
                        trace_id=envelope.trace_id,
                        exc_info=True,
                    )
                    raise

                logger.warning(
                    "Handler execution failed, retrying",
                    service=envelope.target.get("service"),
                    method=envelope.target.get("method"),
                    attempt=attempt,
                    error=str(e),
                    trace_id=envelope.trace_id,
                )

                time.sleep(self.retry_delay_ms / 1000.0)

        raise RuntimeError("Handler execution failed without result")
