"""Layer 8: Response Handling."""

from __future__ import annotations

from typing import Any

from python_lib.observability.structured_logger import get_logger

logger = get_logger(__name__)


class ResponseHandler:
    """Layer 8: Format and validate response."""

    def handle_response(
        self,
        response_data: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Handle and format response."""
        if "status" not in response_data:
            response_data["status"] = "success"

        logger.debug(
            "Response handled",
            service=context.get("service"),
            method=context.get("method"),
            status=response_data.get("status"),
            trace_id=context.get("trace_id"),
        )

        return response_data

    def handle_error(
        self,
        error_code: str,
        message: str,
        context: dict[str, Any],
        retryable: bool = False,
    ) -> dict[str, Any]:
        """Handle error response."""
        response = {
            "status": "error",
            "error": {
                "code": error_code,
                "message": message,
                "retryable": retryable,
            },
        }

        logger.error(
            "Error response",
            service=context.get("service"),
            method=context.get("method"),
            error_code=error_code,
            trace_id=context.get("trace_id"),
        )

        return response
