"""Layer 4: Authorization."""

from __future__ import annotations

from typing import Any

from python_lib.contracts.envelopes import EnvelopeV1Request
from python_lib.observability.structured_logger import get_logger

logger = get_logger(__name__)


class Authorizer:
    """Layer 4: Authorize service to call method based on scopes."""

    def __init__(self, policies: dict[str, list[str]] | None = None) -> None:
        """Initialize authorizer."""
        self.policies = policies or {}

    def authorize(
        self,
        envelope: EnvelopeV1Request,
        context: dict[str, Any],
    ) -> tuple[bool, str | None]:
        """Authorize the request based on JWT scopes or policies."""
        service = envelope.target.get("service", "")
        method = envelope.target.get("method", "")

        scopes = context.get("auth_scopes", [])
        subject = context.get("auth_subject", envelope.actor)

        if scopes:
            return self._authorize_by_scopes(scopes, service, method, subject, context)

        return self._authorize_by_policy(envelope, context)

    def _authorize_by_scopes(
        self,
        scopes: list[str],
        service: str,
        method: str,
        subject: str,
        context: dict[str, Any],
    ) -> tuple[bool, str | None]:
        """Authorize using JWT scopes."""
        required_scope = f"{service}:{method}"

        has_access = False
        for scope in scopes:
            if (
                scope == required_scope
                or scope == f"{service}:*"
                or scope == "service:*"
                or scope == "*"
            ):
                has_access = True
                break

        if has_access:
            logger.debug(
                "Request authorized by scope",
                subject=subject,
                service=service,
                method=method,
                scopes=scopes,
            )
            return True, None

        logger.warning(
            "Request denied by scope",
            subject=subject,
            service=service,
            method=method,
            required_scope=required_scope,
            actor_scopes=scopes,
        )
        return (
            False,
            f"Actor {subject} lacks required scope: {required_scope}",
        )

    def _authorize_by_policy(
        self,
        envelope: EnvelopeV1Request,
        context: dict[str, Any],
    ) -> tuple[bool, str | None]:
        """Authorize using legacy policy dict (for MVP internal services)."""
        actor = envelope.actor
        service = envelope.target.get("service", "")
        method = envelope.target.get("method", "")

        if not self.policies:
            logger.warning(
                "Request denied (no authorization policies configured)",
                actor=actor,
                service=service,
                method=method,
            )
            return False, "Authorization policies not configured"

        allowed_methods = self.policies.get(actor, [])

        method_key = f"{service}:{method}"
        if method_key in allowed_methods or "*" in allowed_methods:
            logger.debug(
                "Request authorized by policy",
                actor=actor,
                service=service,
                method=method,
            )
            return True, None

        return (
            False,
            f"Actor {actor} not authorized for {service}:{method}",
        )
