"""HTTP client for service forwarding via compose/DNS service names."""

from __future__ import annotations

import os
from typing import Any

import httpx

from python_lib.observability.structured_logger import get_logger

logger = get_logger(__name__)

# v0.1 admitted backends (Compose DNS kebab-case via env endpoints).
_SERVICE_ENDPOINT_KEYS = {
    "db_api": "DB_API_ENDPOINT",
    "storage_api": "STORAGE_API_ENDPOINT",
    "ocr_api": "OCR_API_ENDPOINT",
}
# Optional product/sandbox bridges — registered only when the env var is set.
_OPTIONAL_SERVICE_ENDPOINT_KEYS = {
    "finnhub_bridge": "FINNHUB_BRIDGE_ENDPOINT",
}


class ServiceUnreachableError(Exception):
    """Raised when gateway cannot reach a backend (connect/timeout)."""


def _require_endpoint_env(name: str) -> str:
    value = os.environ.get(name)
    if value is None or not value.strip():
        raise RuntimeError(f"{name} is required")
    return value.strip()


_ENDPOINTS: dict[str, str] | None = None


def _service_endpoints() -> dict[str, str]:
    global _ENDPOINTS
    if _ENDPOINTS is not None:
        return _ENDPOINTS
    endpoints: dict[str, str] = {}
    for service_name, env_key in _SERVICE_ENDPOINT_KEYS.items():
        endpoints[service_name] = _require_endpoint_env(env_key)
    for service_name, env_key in _OPTIONAL_SERVICE_ENDPOINT_KEYS.items():
        raw = os.environ.get(env_key)
        if raw is not None and raw.strip():
            endpoints[service_name] = raw.strip()
    _ENDPOINTS = endpoints
    return _ENDPOINTS


def get_service_endpoint(service_name: str) -> str:
    endpoints = _service_endpoints()
    if service_name not in endpoints:
        raise ValueError(f"No endpoint for service: {service_name}")
    return endpoints[service_name]


class ServiceForwarder:
    """Forwards HTTP requests to backend service containers."""

    def __init__(self, *, read_timeout: float | None = None) -> None:
        _service_endpoints()
        self._forward_read_timeout = read_timeout
        self.client = httpx.Client(timeout=httpx.Timeout(60.0, read=read_timeout))

    def forward_envelope(
        self,
        service_name: str,
        envelope: dict[str, Any],
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        endpoint = get_service_endpoint(service_name)
        url = f"{endpoint.rstrip('/')}/call"
        headers = headers or {}
        if "Content-Type" not in headers:
            headers["Content-Type"] = "application/json"
        try:
            post_timeout = httpx.Timeout(60.0, read=self._forward_read_timeout)
            response = self.client.post(url, json=envelope, headers=headers, timeout=post_timeout)
            response.raise_for_status()
        except (httpx.ConnectError, httpx.TimeoutException) as exc:
            msg = f"gateway could not reach {service_name}: {exc!s}"
            raise ServiceUnreachableError(msg) from exc
        data = response.json()
        logger.info("Forward success", service=service_name, status=response.status_code)
        return data

    def close(self) -> None:
        self.client.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.close()
