"""Integrated gateway application with dynamic service discovery."""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any

import httpx
from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

from python_lib.contracts.envelopes import EnvelopeV1Request
from python_lib.contracts.errors import ErrorCode
from python_lib.observability.structured_logger import get_logger
from python_lib.observability.tracer import Tracer
from services.gateway.db_api_client import DbApiClient
from services.gateway.layers import (
    Authenticator,
    Authorizer,
    Enricher,
    Executor,
    Observer,
    ResponseHandler,
    Router,
    Validator,
)
from services.gateway.service_forwarder import ServiceForwarder, ServiceUnreachableError
from services.gateway.support.metrics_collector import MetricsCollector
from services.gateway.support.service_manifest_loader import ServiceManifestLoader

logger = get_logger(__name__)


def create_integrated_app() -> FastAPI:
    """Create integrated app with dynamically loaded services."""
    app = FastAPI(
        title="Platform Gateway",
        version="0.1.0",
    )

    try:
        manifest = ServiceManifestLoader.load_all_manifests()
        logger.info("Loaded service manifests", services=len(manifest["services"]))
    except Exception as e:
        logger.error(f"Failed to load service manifests: {e}")
        raise

    forwarder = ServiceForwarder()
    db_api_client = DbApiClient(forwarder=forwarder)

    authenticator = Authenticator(enabled=True)
    validator = Validator()
    authorizer = Authorizer()
    router = Router()
    enricher = Enricher()
    executor = Executor(max_retries=2)
    response_handler = ResponseHandler()
    metrics = MetricsCollector()
    observer = Observer(metrics=metrics, db_api_client=db_api_client)

    _register_forward_handlers(router, manifest, forwarder)

    @app.middleware("http")
    async def trace_middleware(request: Request, call_next: Any) -> Any:
        trace_id: str | None = None
        if request.url.path == "/call":
            trace_id = request.headers.get("X-Trace-Id")
            if not trace_id:
                return JSONResponse(
                    status_code=400,
                    content={
                        "status": "error",
                        "error": {
                            "code": "VALIDATION_FAILED",
                            "message": "X-Trace-Id header required",
                            "retryable": False,
                        },
                    },
                )
            Tracer.set_trace_id(trace_id)
        else:
            trace_id = request.headers.get("X-Trace-Id")
            if trace_id:
                Tracer.set_trace_id(trace_id)

        response = await call_next(request)
        if trace_id:
            response.headers["X-Trace-Id"] = trace_id
        return response

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "healthy"}

    @app.get("/metrics")
    async def metrics_endpoint() -> dict[str, str]:
        from prometheus_client import generate_latest

        return {"metrics": generate_latest().decode("utf-8")}

    @app.post("/call")
    async def gateway_call(request: Request) -> JSONResponse:
        trace_id = request.headers.get("X-Trace-Id") or Tracer.get_trace_id()
        Tracer.set_trace_id(trace_id)
        job_id_header = request.headers.get("X-Job-Id")
        workflow_name_header = (request.headers.get("X-Workflow-Name") or "").strip() or None
        job_id: str | None = None
        try:
            if job_id_header:
                # Defer workflow_name until a workflow entry owns registration.
                job_id = await asyncio.to_thread(
                    db_api_client.get_or_create_job_by_workflow_uid,
                    job_id_header,
                    None,
                    trace_id,
                    trace_id,
                )
        except ServiceUnreachableError as e:
            logger.warning("Job resolution unreachable", error=str(e))
            return JSONResponse(
                {"detail": str(e), "status": "error"},
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            )
        except httpx.HTTPStatusError as e:
            body = e.response.text
            try:
                body = e.response.json()
            except ValueError:
                pass
            logger.warning("db-api returned error", status=e.response.status_code, body=body)
            return JSONResponse(
                {"detail": body, "status": "error"},
                status_code=status.HTTP_502_BAD_GATEWAY,
            )
        context: dict[str, Any] = {
            "trace_id": trace_id,
            "job_id": job_id,
            "workflow_uid": job_id_header,
            "workflow_name": workflow_name_header,
            "received_at": datetime.utcnow(),
            "auth_header": request.headers.get("Authorization"),
        }

        envelope_data: dict[str, Any] = {}
        try:
            envelope_data = await request.json()

            is_auth, auth_error = authenticator.authenticate(
                EnvelopeV1Request(**envelope_data), context
            )
            if not is_auth:
                error_response = response_handler.handle_error(
                    ErrorCode.AUTH_INVALID.value, auth_error or "Authentication failed", context
                )
                observer.observe(envelope_data, context, error_response)
                return JSONResponse(error_response, status_code=status.HTTP_401_UNAUTHORIZED)

            envelope = EnvelopeV1Request(**envelope_data)

            is_valid, validation_error = validator.validate(envelope, context)
            if not is_valid:
                error_response = response_handler.handle_error(
                    ErrorCode.VALIDATION_FAILED.value, validation_error or "Validation failed", context
                )
                observer.observe(envelope_data, context, error_response)
                return JSONResponse(error_response, status_code=status.HTTP_400_BAD_REQUEST)

            is_authed, auth_error = authorizer.authorize(envelope, context)
            if not is_authed:
                error_response = response_handler.handle_error(
                    ErrorCode.AUTH_INSUFFICIENT_PERMISSIONS.value,
                    auth_error or "Authorization failed",
                    context,
                )
                observer.observe(envelope_data, context, error_response)
                return JSONResponse(error_response, status_code=status.HTTP_403_FORBIDDEN)

            handler, route_error = router.route(envelope, context)
            if not handler:
                error_response = response_handler.handle_error(
                    ErrorCode.ROUTING_ERROR.value, route_error or "Routing failed", context
                )
                observer.observe(envelope_data, context, error_response)
                return JSONResponse(error_response, status_code=status.HTTP_404_NOT_FOUND)

            context = enricher.enrich(envelope, context)

            task_execution_id = observer.record_pending(envelope_data, context)
            if task_execution_id:
                context["task_execution_id"] = task_execution_id

            result = await asyncio.to_thread(executor.execute, handler, envelope, context)
            response_data = response_handler.handle_response(result, context)
            observer.observe(envelope_data, context, response_data)

            return JSONResponse(response_data, status_code=status.HTTP_200_OK)

        except ValueError as e:
            error_response = response_handler.handle_error(
                ErrorCode.VALIDATION_FAILED.value, str(e), context
            )
            observer.observe(envelope_data, context, error_response)
            return JSONResponse(error_response, status_code=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            error_response = response_handler.handle_error(
                ErrorCode.INTERNAL_ERROR.value,
                str(e),
                context,
                retryable=True,
            )
            if context.get("task_execution_id") and context.get("job_id"):
                observer.observe(envelope_data, context, error_response)
            return JSONResponse(error_response, status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)

    return app


def _register_forward_handlers(
    router: Router, manifest: dict[str, Any], forwarder: ServiceForwarder
) -> None:
    for service_name, service_def in manifest.get("services", {}).items():
        methods = ServiceManifestLoader.get_service_methods(manifest, service_name)
        for method_name in methods:

            def _make_forward_handler(svc: str, mth: str):
                def handler(envelope: EnvelopeV1Request, context: dict[str, Any]) -> dict[str, Any]:
                    headers: dict[str, str] = {}
                    workflow_uid = context.get("workflow_uid")
                    if workflow_uid:
                        headers["X-Job-Id"] = str(workflow_uid)
                    elif context.get("job_id"):
                        headers["X-Job-Id"] = str(context["job_id"])
                    if context.get("workflow_name"):
                        headers["X-Workflow-Name"] = str(context["workflow_name"])
                    if context.get("trace_id"):
                        headers["X-Trace-Id"] = context["trace_id"]
                    envelope_dict = envelope.model_dump(mode="json")
                    return forwarder.forward_envelope(svc, envelope_dict, headers)

                return handler

            router.register(service_name, method_name, _make_forward_handler(service_name, method_name))
            logger.debug("Registered forward handler", service=service_name, method=method_name)
        logger.info("Forward handlers registered", service=service_name, methods=len(methods))
