"""Metrics collection — gateway-local until python-lib observability v0.2."""

from __future__ import annotations

from typing import Any, Final

try:
    from prometheus_client import REGISTRY, Counter, Histogram
except ImportError:  # pragma: no cover - optional for unit smoke without prometheus
    REGISTRY = None  # type: ignore[assignment]
    Counter = None  # type: ignore[assignment, misc]
    Histogram = None  # type: ignore[assignment, misc]


class MetricsCollector:
    """Collect and emit Prometheus metrics (no-op counters when prometheus absent)."""

    _instance: MetricsCollector | None = None
    _metrics: dict[str, Any] = {}
    _initialized: bool = False

    def __new__(cls, prefix: str = "framework") -> MetricsCollector:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, prefix: str = "framework") -> None:
        if self._initialized:
            return

        self._initialized = True
        self.prefix = prefix
        self._noop = Counter is None

        if self._noop:
            return

        try:
            existing_names = {
                m._name for m in REGISTRY._names_to_collectors.keys() if hasattr(m, "_name")
            }
        except (AttributeError, TypeError):
            existing_names = set()

        if f"{prefix}_requests_total" not in existing_names:
            self.request_count: Final = Counter(
                f"{prefix}_requests_total", "Total requests", ["service", "method", "status"]
            )

        if f"{prefix}_tasks_total" not in existing_names:
            self.task_count: Final = Counter(
                f"{prefix}_tasks_total", "Total tasks", ["task_type", "status"]
            )

        if f"{prefix}_errors_total" not in existing_names:
            self.error_count: Final = Counter(
                f"{prefix}_errors_total", "Total errors", ["error_code"]
            )

        if f"{prefix}_request_duration_seconds" not in existing_names:
            self.request_duration: Final = Histogram(
                f"{prefix}_request_duration_seconds", "Request duration", ["service", "method"]
            )

        if f"{prefix}_task_duration_seconds" not in existing_names:
            self.task_duration: Final = Histogram(
                f"{prefix}_task_duration_seconds", "Task duration", ["task_type"]
            )

    def counter(self, name: str, value: int = 1, labels: dict[str, str] | None = None) -> None:
        key = f"{name}:{labels}" if labels else name
        self._metrics[key] = self._metrics.get(key, 0) + value

    def gauge(self, name: str, value: int | float, labels: dict[str, str] | None = None) -> None:
        self._metrics[f"{name}:{labels}" if labels else name] = value

    def histogram(self, name: str, value: float, labels: dict[str, str] | None = None) -> None:
        key = f"{name}:{labels}" if labels else name
        if key not in self._metrics:
            self._metrics[key] = []
        self._metrics[key].append(value)

    def record_request(self, service: str, method: str, status: str, duration_seconds: float) -> None:
        if self._noop:
            return
        self.request_count.labels(service=service, method=method, status=status).inc()
        self.request_duration.labels(service=service, method=method).observe(duration_seconds)

    def record_task(self, task_type: str, status: str, duration_seconds: float) -> None:
        if self._noop:
            return
        self.task_count.labels(task_type=task_type, status=status).inc()
        self.task_duration.labels(task_type=task_type).observe(duration_seconds)

    def record_error(self, error_code: str) -> None:
        if self._noop:
            return
        self.error_count.labels(error_code=error_code).inc()
