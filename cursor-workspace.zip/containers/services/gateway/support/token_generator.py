"""JWT token generation and validation — gateway-local until python-lib observability v0.2."""

from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta
from typing import Any

try:
    import jwt
except ImportError as exc:  # pragma: no cover
    raise ImportError("PyJWT is required. Install with: pip install pyjwt") from exc

from python_lib.observability.structured_logger import get_logger

logger = get_logger(__name__)


class TokenConfig:
    """JWT token configuration from environment."""

    @staticmethod
    def get_private_key() -> str:
        import base64

        key_b64 = os.environ.get("JWT_PRIVATE_KEY")
        if not key_b64:
            raise ValueError("JWT_PRIVATE_KEY is required")
        return base64.b64decode(key_b64).decode("utf-8")

    @staticmethod
    def get_public_key() -> str:
        import base64

        key_b64 = os.environ.get("JWT_PUBLIC_KEY")
        if not key_b64:
            raise ValueError("JWT_PUBLIC_KEY is required")
        return base64.b64decode(key_b64).decode("utf-8")

    @staticmethod
    def get_algorithm() -> str:
        value = os.environ.get("JWT_ALGORITHM")
        if not value:
            raise ValueError("JWT_ALGORITHM is required")
        return value

    @staticmethod
    def get_internal_expiry() -> int:
        value = os.environ.get("JWT_INTERNAL_TOKEN_EXPIRY")
        if value is None or value == "":
            raise ValueError("JWT_INTERNAL_TOKEN_EXPIRY is required")
        return int(value)

    @staticmethod
    def get_external_expiry() -> int:
        value = os.environ.get("JWT_EXTERNAL_TOKEN_EXPIRY")
        if value is None or value == "":
            raise ValueError("JWT_EXTERNAL_TOKEN_EXPIRY is required")
        return int(value)

    @staticmethod
    def get_issuer() -> str:
        value = os.environ.get("JWT_ISSUER")
        if not value:
            raise ValueError("JWT_ISSUER is required")
        return value

    @staticmethod
    def get_audience() -> str:
        value = os.environ.get("JWT_AUDIENCE")
        if not value:
            raise ValueError("JWT_AUDIENCE is required")
        return value


class TokenGenerator:
    """Generate and validate JWT tokens for services and users."""

    @staticmethod
    def generate_service_token(
        service_name: str, scopes: list[str] | None = None
    ) -> str:
        """Generate JWT token for internal service (no expiry)."""
        if scopes is None:
            scopes = ["service:*"]

        payload = {
            "sub": f"service:{service_name}",
            "actor_type": "service",
            "scopes": scopes,
            "iat": int(datetime.now(UTC).timestamp()),
            "iss": TokenConfig.get_issuer(),
            "aud": TokenConfig.get_audience(),
        }

        return jwt.encode(
            payload,
            TokenConfig.get_private_key(),
            algorithm=TokenConfig.get_algorithm(),
        )

    @staticmethod
    def generate_user_token(username: str, scopes: list[str] | None = None) -> str:
        """Generate JWT token for external user (1-hour expiry)."""
        if scopes is None:
            scopes = ["gateway:submit_workflow", "gateway:query_job"]

        now = datetime.now(UTC)
        exp_time = now + timedelta(seconds=TokenConfig.get_external_expiry())

        payload = {
            "sub": f"user:{username}",
            "actor_type": "user",
            "scopes": scopes,
            "iat": int(now.timestamp()),
            "exp": int(exp_time.timestamp()),
            "iss": TokenConfig.get_issuer(),
            "aud": TokenConfig.get_audience(),
        }

        return jwt.encode(
            payload,
            TokenConfig.get_private_key(),
            algorithm=TokenConfig.get_algorithm(),
        )

    @staticmethod
    def validate_token(token: str) -> dict[str, Any]:
        """Validate JWT token and return claims."""
        try:
            return jwt.decode(
                token,
                TokenConfig.get_public_key(),
                algorithms=[TokenConfig.get_algorithm()],
                audience=TokenConfig.get_audience(),
                issuer=TokenConfig.get_issuer(),
            )
        except jwt.ExpiredSignatureError as e:
            raise ValueError("Token expired") from e
        except jwt.InvalidTokenError as e:
            raise ValueError("Invalid token") from e

    @staticmethod
    def extract_token_from_header(auth_header: str) -> str:
        """Extract JWT token from Authorization header."""
        if not auth_header or not auth_header.startswith("Bearer "):
            raise ValueError("Missing or invalid Authorization header")
        return auth_header.replace("Bearer ", "", 1)

    @staticmethod
    def get_scopes_from_token(token: str) -> list[str]:
        """Extract scopes from token."""
        claims = TokenGenerator.validate_token(token)
        return claims.get("scopes", [])

    @staticmethod
    def get_subject_from_token(token: str) -> str:
        """Extract subject (actor) from token."""
        claims = TokenGenerator.validate_token(token)
        return claims.get("sub", "unknown")
