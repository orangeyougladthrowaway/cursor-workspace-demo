"""Dynamic service loader — gateway-local until python-lib observability v0.2."""

from __future__ import annotations

import importlib
import os
from typing import Any

import yaml

from python_lib.observability.structured_logger import get_logger

logger = get_logger(__name__)


class ServiceManifestLoader:
    """Load and parse service manifests from YAML files."""

    @staticmethod
    def load_all_manifests(manifest_dir: str = "config/services") -> dict[str, Any]:
        """Load all service manifests from directory."""
        combined_manifest: dict[str, Any] = {
            "services": {},
            "metadata": {"framework_locked": True, "loaded_files": []},
        }

        framework_file = os.path.join(manifest_dir, "_framework.yaml")
        if os.path.exists(framework_file):
            framework_manifest = ServiceManifestLoader._load_yaml_file(framework_file)
            is_valid, errors = ServiceManifestLoader.validate_manifest(framework_manifest)
            if not is_valid:
                raise ValueError("Framework manifest validation failed: " + "; ".join(errors))

            combined_manifest["services"].update(framework_manifest.get("services", {}))
            combined_manifest["metadata"]["loaded_files"].append("_framework.yaml")

        if os.path.isdir(manifest_dir):
            for filename in sorted(
                f
                for f in os.listdir(manifest_dir)
                if f.endswith(".yaml") and f != "_framework.yaml"
            ):
                filepath = os.path.join(manifest_dir, filename)
                if not os.path.isfile(filepath):
                    continue
                ServiceManifestLoader._merge_manifest_file(
                    filepath,
                    filename,
                    combined_manifest,
                    strict=True,
                )

        custom_dir = os.path.join(manifest_dir, "custom")
        if os.path.exists(custom_dir):
            for filename in sorted(f for f in os.listdir(custom_dir) if f.endswith(".yaml")):
                filepath = os.path.join(custom_dir, filename)
                try:
                    ServiceManifestLoader._merge_manifest_file(
                        filepath,
                        filename,
                        combined_manifest,
                        strict=False,
                    )
                except Exception as e:
                    logger.warning(f"Skipping invalid custom manifest {filename}: {e}")

        logger.info(
            "Service manifests loaded",
            total_services=len(combined_manifest["services"]),
            files=combined_manifest["metadata"]["loaded_files"],
        )
        return combined_manifest

    @staticmethod
    def _merge_manifest_file(
        filepath: str,
        filename: str,
        combined_manifest: dict[str, Any],
        *,
        strict: bool,
    ) -> None:
        try:
            extra_manifest = ServiceManifestLoader._load_yaml_file(filepath)
            is_valid, errors = ServiceManifestLoader.validate_manifest(extra_manifest)
            if not is_valid:
                msg = f"Manifest {filename} validation failed: {errors}"
                if strict:
                    raise ValueError(msg)
                logger.warning(msg)
                return
            combined_manifest["services"].update(extra_manifest.get("services", {}))
            combined_manifest["metadata"]["loaded_files"].append(filename)
        except Exception as e:
            if strict:
                raise ValueError(f"Failed to load manifest {filename}: {e}") from e
            logger.warning(f"Failed to load manifest {filename}: {e}")

    @staticmethod
    def _load_yaml_file(filepath: str) -> dict[str, Any]:
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Manifest file not found: {filepath}")
        with open(filepath) as f:
            return yaml.safe_load(f) or {}

    @staticmethod
    def get_service_methods(manifest: dict[str, Any], service_name: str) -> list[str]:
        """Get list of method names for a service."""
        services = manifest.get("services", {})
        service_def = services.get(service_name, {})
        methods = service_def.get("methods", [])

        method_names = []
        for method in methods:
            if isinstance(method, str):
                method_names.append(method)
            elif isinstance(method, dict):
                method_names.append(method.get("name", ""))
        return [m for m in method_names if m]

    @staticmethod
    def get_service_info(manifest: dict[str, Any], service_name: str) -> dict[str, Any] | None:
        """Get full service definition."""
        return manifest.get("services", {}).get(service_name)

    @staticmethod
    def validate_manifest(manifest: dict[str, Any]) -> tuple[bool, list[str]]:
        """Validate manifest structure."""
        errors = []

        if not isinstance(manifest, dict):
            return False, ["Manifest must be a dictionary"]

        services = manifest.get("services", {})
        if not isinstance(services, dict):
            errors.append("'services' must be a dictionary")
        else:
            for svc_name, svc_def in services.items():
                if not isinstance(svc_def, dict):
                    errors.append(f"Service '{svc_name}' must be a dictionary")
                elif "service_name" not in svc_def:
                    errors.append(f"Service '{svc_name}' missing 'service_name'")

        return len(errors) == 0, errors

    @staticmethod
    def load_service_class(service_name: str) -> type:
        """Dynamically load service class by name. Used by service containers and tests only."""
        class_name_map = {
            "storage_api": "StorageApiService",
            "ocr_api": "OcrApiService",
        }
        module_path_map = {
            "storage_api": "services.storage_api.service",
            "ocr_api": "services.ocr_api.service",
        }

        if service_name not in class_name_map:
            raise ValueError(f"unknown service for load_service_class: {service_name!r}")

        class_name = class_name_map[service_name]
        module_name = module_path_map[service_name]
        module = importlib.import_module(module_name)
        service_class = getattr(module, class_name)
        if not isinstance(service_class, type):
            raise ValueError(f"{module_name}.{class_name} is not a class")
        return service_class
