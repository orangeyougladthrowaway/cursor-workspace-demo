"""HTTP client for gateway to call db-api (job resolution and write-ahead)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from python_lib.observability.structured_logger import get_logger

from .service_forwarder import ServiceForwarder

logger = get_logger(__name__)


def _envelope(
    method: str,
    payload: dict[str, Any],
    trace_id: str,
    request_id: str,
) -> dict[str, Any]:
    return {
        "envelope_version": "1.0",
        "kind": "request",
        "schema_version": "1.0",
        "trace_id": trace_id,
        "request_id": request_id,
        "actor": "service:gateway",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "target": {"service": "db_api", "method": method},
        "payload": payload,
        "metadata": {},
        "tags": {},
    }


class DbApiClient:
    """Calls db-api over HTTP for job resolution and write-ahead. Used only by the gateway."""

    def __init__(self, forwarder: ServiceForwarder | None = None):
        self._forwarder = forwarder or ServiceForwarder()

    def _call(
        self,
        method: str,
        payload: dict[str, Any],
        trace_id: str,
        request_id: str,
        *,
        workflow_uid: str,
    ) -> dict[str, Any]:
        """POST envelope to db-api /call with the same hop headers as service forwarders."""
        if not trace_id or not str(trace_id).strip():
            raise ValueError("trace_id required for db-api hop (X-Trace-Id)")
        if not workflow_uid or not str(workflow_uid).strip():
            raise ValueError("workflow_uid required for db-api hop (X-Job-Id)")
        headers = {
            "Content-Type": "application/json",
            "X-Trace-Id": str(trace_id).strip(),
            "X-Job-Id": str(workflow_uid).strip(),
        }
        envelope = _envelope(method, payload, trace_id, request_id)
        result = self._forwarder.forward_envelope("db_api", envelope, headers)
        if result.get("status") == "error":
            err = result.get("error")
            msg = err.get("message", str(err)) if isinstance(err, dict) else (err or "db_api error")
            raise ValueError(
                msg
                or "db_api error (check db-api logs: workflow not found, timeout, or gateway restarted)"
            )
        return result.get("payload") or {}

    def store_workflow(
        self,
        name: str,
        yaml_content: str,
        trace_id: str,
        request_id: str,
        *,
        workflow_uid: str,
        description: str | None = None,
        created_by: str | None = None,
    ) -> None:
        self._call(
            "store_workflow",
            {
                "name": name,
                "yaml_content": yaml_content,
                "description": description,
                "created_by": created_by,
            },
            trace_id,
            request_id,
            workflow_uid=workflow_uid,
        )

    def get_or_create_job_by_workflow_uid(
        self,
        workflow_uid: str,
        workflow_name: str | None,
        trace_id: str,
        request_id: str,
    ) -> str:
        # workflow_name may be None until a workflow entry updates the name.
        out = self._call(
            "get_or_create_job_by_workflow_uid",
            {"workflow_uid": workflow_uid, "workflow_name": workflow_name},
            trace_id,
            request_id,
            workflow_uid=workflow_uid,
        )
        job_id = out.get("job_id")
        if not job_id:
            raise ValueError(
                "db_api get_or_create_job_by_workflow_uid did not return job_id "
                "(ensure-workflow path; check db-api logs for workflow not found or timeout)"
            )
        return str(job_id)

    def record_task_execution_pending(
        self,
        job_id: str,
        trace_id: str,
        service: str,
        method: str,
        inputs: dict[str, Any],
        request_id: str,
        *,
        workflow_uid: str,
        item_id: str | None = None,
    ) -> str:
        out = self._call(
            "record_task_execution_pending",
            {
                "job_id": job_id,
                "trace_id": trace_id,
                "service": service,
                "method": method,
                "inputs": inputs,
                "item_id": item_id,
            },
            trace_id,
            request_id,
            workflow_uid=workflow_uid,
        )
        task_id = out.get("task_id")
        if not task_id:
            raise ValueError("db_api record_task_execution_pending did not return task_id")
        return str(task_id)

    def update_task_execution(
        self,
        task_id: str | None,
        job_id: str,
        trace_id: str | None,
        service: str,
        method: str,
        status: str,
        request_id: str,
        *,
        workflow_uid: str,
        outputs: dict[str, Any] | None = None,
        error: dict[str, Any] | None = None,
        duration_seconds: float = 0,
    ) -> None:
        if not trace_id or not str(trace_id).strip():
            raise ValueError("trace_id required for db-api update_task_execution")
        self._call(
            "update_task_execution",
            {
                "task_id": task_id,
                "job_id": job_id,
                "trace_id": trace_id,
                "service": service,
                "method": method,
                "status": status,
                "outputs": outputs,
                "error": error,
                "duration_seconds": duration_seconds,
            },
            str(trace_id).strip(),
            request_id,
            workflow_uid=workflow_uid,
        )

    def record_execution_log(
        self,
        job_id: str,
        trace_id: str,
        level: str,
        message: str,
        request_id: str,
        *,
        workflow_uid: str,
        task_execution_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        self._call(
            "record_execution_log",
            {
                "job_id": job_id,
                "trace_id": trace_id,
                "level": level,
                "message": message,
                "task_execution_id": task_execution_id,
                "context": context,
            },
            trace_id,
            request_id,
            workflow_uid=workflow_uid,
        )
