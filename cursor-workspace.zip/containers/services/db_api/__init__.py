"""Platform db_api — PostgreSQL WAL + smoke helpers."""
