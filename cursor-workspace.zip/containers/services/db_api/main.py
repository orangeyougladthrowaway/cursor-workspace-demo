"""Platform db_api — PostgreSQL smoke helpers + observer WAL surface for gateway."""

from __future__ import annotations

import json
import os
from typing import Any

import psycopg
from python_lib.contracts.envelopes import ServiceRequest
from python_lib.runtime import create_service_api, wrapper_method

_SCHEMA = """
CREATE TABLE IF NOT EXISTS smoke_events (
    id BIGSERIAL PRIMARY KEY,
    kind TEXT NOT NULL,
    detail JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_name VARCHAR(255),
    workflow_uid VARCHAR(255) UNIQUE,
    workflow_name_full VARCHAR(255),
    inputs JSONB,
    outputs JSONB,
    metadata JSONB,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_jobs_workflow_uid ON jobs(workflow_uid);

CREATE TABLE IF NOT EXISTS task_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    trace_id VARCHAR(255),
    service VARCHAR(255) NOT NULL,
    method VARCHAR(255) NOT NULL,
    inputs JSONB NOT NULL,
    outputs JSONB,
    status VARCHAR(50) DEFAULT 'pending',
    error JSONB,
    sequence_order INT,
    duration_seconds FLOAT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_task_executions_job_id ON task_executions(job_id);
CREATE INDEX IF NOT EXISTS idx_task_executions_trace_id ON task_executions(trace_id);

CREATE TABLE IF NOT EXISTS execution_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id UUID REFERENCES jobs(id) ON DELETE CASCADE,
    trace_id VARCHAR(255),
    task_execution_id UUID REFERENCES task_executions(id) ON DELETE SET NULL,
    level VARCHAR(20),
    message TEXT,
    context JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_execution_logs_job_id ON execution_logs(job_id);
CREATE INDEX IF NOT EXISTS idx_execution_logs_trace_id ON execution_logs(trace_id);
"""


def _dsn() -> str:
    return os.environ["DATABASE_URL"]


def ensure_schema() -> None:
    with psycopg.connect(_dsn()) as conn:
        conn.execute(_SCHEMA)
        conn.commit()


def _require_str(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} required (string)")
    return value.strip()


class DatabaseService:
    """Minimal db_api: smoke helpers + gateway observer WAL methods."""

    @wrapper_method("db_api", "ping")
    def ping(self, request: ServiceRequest) -> dict[str, Any]:
        _ = request
        with psycopg.connect(_dsn()) as conn:
            row = conn.execute("SELECT 1 AS ok").fetchone()
        return {"ok": bool(row and row[0] == 1)}

    @wrapper_method("db_api", "record_smoke")
    def record_smoke(self, request: ServiceRequest) -> dict[str, Any]:
        payload = request.envelope.payload
        kind = payload.get("kind")
        if not isinstance(kind, str) or not kind:
            raise ValueError("kind required (string)")
        detail = payload.get("detail")
        if detail is None:
            detail = {}
        if not isinstance(detail, dict):
            raise ValueError("detail must be an object")
        with psycopg.connect(_dsn()) as conn:
            row = conn.execute(
                "INSERT INTO smoke_events (kind, detail) VALUES (%s, %s::jsonb) "
                "RETURNING id",
                (kind, json.dumps(detail)),
            ).fetchone()
            conn.commit()
        return {"id": int(row[0])}

    @wrapper_method("db_api", "get_smoke")
    def get_smoke(self, request: ServiceRequest) -> dict[str, Any]:
        payload = request.envelope.payload
        event_id = payload.get("id")
        if event_id is None:
            raise ValueError("id required")
        with psycopg.connect(_dsn()) as conn:
            row = conn.execute(
                "SELECT id, kind, detail::text, created_at::text FROM smoke_events "
                "WHERE id = %s",
                (int(event_id),),
            ).fetchone()
        if not row:
            raise ValueError(f"smoke event not found: {event_id}")
        return {
            "id": int(row[0]),
            "kind": row[1],
            "detail": json.loads(row[2]),
            "created_at": row[3],
        }

    @wrapper_method("db_api", "get_or_create_job_by_workflow_uid")
    def get_or_create_job_by_workflow_uid(self, request: ServiceRequest) -> dict[str, Any]:
        payload = request.envelope.payload
        workflow_uid = _require_str(payload.get("workflow_uid"), "workflow_uid")
        workflow_name = payload.get("workflow_name")
        name: str | None
        if workflow_name is None or (
            isinstance(workflow_name, str) and not workflow_name.strip()
        ):
            name = None
        else:
            name = str(workflow_name).strip()
        with psycopg.connect(_dsn()) as conn:
            row = conn.execute(
                """
                INSERT INTO jobs (workflow_name, workflow_uid, status)
                VALUES (%s, %s, 'pending')
                ON CONFLICT (workflow_uid) DO UPDATE SET
                  updated_at = NOW(),
                  workflow_name = COALESCE(EXCLUDED.workflow_name, jobs.workflow_name)
                RETURNING id
                """,
                (name, workflow_uid),
            ).fetchone()
            conn.commit()
        return {"job_id": str(row[0])}

    @wrapper_method("db_api", "record_task_execution_pending")
    def record_task_execution_pending(self, request: ServiceRequest) -> dict[str, Any]:
        payload = request.envelope.payload
        job_id = _require_str(payload.get("job_id"), "job_id")
        service = _require_str(payload.get("service"), "service")
        method = _require_str(payload.get("method"), "method")
        trace_id = str(payload.get("trace_id") or "")
        inputs = payload.get("inputs") or {}
        if not isinstance(inputs, dict):
            raise ValueError("inputs must be an object")
        with psycopg.connect(_dsn()) as conn:
            row = conn.execute(
                """
                INSERT INTO task_executions (
                    id, job_id, trace_id, service, method, inputs, status, created_at
                ) VALUES (
                    gen_random_uuid(), %s::uuid, %s, %s, %s, %s::jsonb, 'pending', NOW()
                )
                RETURNING id
                """,
                (job_id, trace_id, service, method, json.dumps(inputs)),
            ).fetchone()
            conn.commit()
        return {"task_id": str(row[0])}

    @wrapper_method("db_api", "update_task_execution")
    def update_task_execution(self, request: ServiceRequest) -> dict[str, Any]:
        payload = request.envelope.payload
        task_id = payload.get("task_id")
        if not task_id:
            raise ValueError(
                "task_id is required to complete a task execution "
                "(pending record must exist; no insert-without-pending path)"
            )
        _require_str(payload.get("job_id"), "job_id")
        _require_str(payload.get("service"), "service")
        _require_str(payload.get("method"), "method")
        status = str(payload.get("status") or "success")
        outputs = payload.get("outputs")
        error = payload.get("error")
        duration_seconds = float(payload.get("duration_seconds") or 0)
        with psycopg.connect(_dsn()) as conn:
            conn.execute(
                """
                UPDATE task_executions
                SET status = %s,
                    outputs = %s::jsonb,
                    error = %s::jsonb,
                    duration_seconds = %s,
                    completed_at = NOW()
                WHERE id = %s::uuid
                """,
                (
                    status,
                    json.dumps(outputs) if outputs is not None else None,
                    json.dumps(error) if error is not None else None,
                    duration_seconds,
                    str(task_id),
                ),
            )
            conn.commit()
        return {"updated": True}

    @wrapper_method("db_api", "record_execution_log")
    def record_execution_log(self, request: ServiceRequest) -> dict[str, Any]:
        payload = request.envelope.payload
        job_id = payload.get("job_id")
        message = payload.get("message")
        if not job_id or not message:
            raise ValueError("job_id and message required (db_api record_execution_log)")
        trace_id = str(payload.get("trace_id") or "")
        level = str(payload.get("level") or "INFO")
        task_execution_id = payload.get("task_execution_id")
        context = payload.get("context")
        with psycopg.connect(_dsn()) as conn:
            if task_execution_id:
                conn.execute(
                    """
                    INSERT INTO execution_logs (
                        id, job_id, trace_id, task_execution_id, level, message, context, created_at
                    ) VALUES (
                        gen_random_uuid(), %s::uuid, %s, %s::uuid, %s, %s, %s::jsonb, NOW()
                    )
                    """,
                    (
                        str(job_id),
                        trace_id,
                        str(task_execution_id),
                        level,
                        str(message),
                        json.dumps(context) if isinstance(context, dict) else None,
                    ),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO execution_logs (
                        id, job_id, trace_id, task_execution_id, level, message, context, created_at
                    ) VALUES (
                        gen_random_uuid(), %s::uuid, %s, NULL, %s, %s, %s::jsonb, NOW()
                    )
                    """,
                    (
                        str(job_id),
                        trace_id,
                        level,
                        str(message),
                        json.dumps(context) if isinstance(context, dict) else None,
                    ),
                )
            conn.commit()
        return {"recorded": True}


async def _startup() -> None:
    ensure_schema()


app = create_service_api("db_api", DatabaseService(), on_startup_hook=_startup)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8001)
