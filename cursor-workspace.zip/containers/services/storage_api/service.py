"""Storage API — list/get/put objects (small payloads) via boto3; no direct DB access."""

from __future__ import annotations

import base64
import os
from typing import Any

from python_lib.contracts.envelopes import ServiceRequest
from python_lib.observability.structured_logger import get_logger
from python_lib.runtime.decorators import wrapper_method

logger = get_logger(__name__)

# Demo safety cap for get/put via JSON (base64 expands ~4/3).
_MAX_BYTES = 10 * 1024 * 1024


class StorageApiService:
    """S3-compatible object storage operations for gateway-forwarded calls.

    Env contract keeps Spaces-shaped names (SPACES_*) as the S3-compatible
    credential surface — Azure Blob rewrite is deferred.
    """

    def __init__(self) -> None:
        self._client = None
        self._bucket: str | None = None

    def _spaces_config(self) -> tuple[str, str, str, str, str]:
        region = os.environ["SPACES_REGION"]
        endpoint = os.environ["SPACES_ENDPOINT"]
        key = os.environ["SPACES_ACCESS_KEY"]
        secret = os.environ["SPACES_SECRET_KEY"]
        bucket = os.environ["SPACES_BUCKET"]
        return region, endpoint, key, secret, bucket

    @property
    def s3(self) -> Any:
        if self._client is None:
            import boto3

            region, endpoint, key, secret, bucket = self._spaces_config()
            self._bucket = bucket
            self._client = boto3.client(
                "s3",
                endpoint_url=endpoint,
                aws_access_key_id=key,
                aws_secret_access_key=secret,
                region_name=region,
            )
        return self._client

    def _bucket_name(self) -> str:
        if self._bucket is None:
            _ = self.s3
        assert self._bucket is not None
        return self._bucket

    @wrapper_method("storage_api", "list_objects")
    def list_objects(self, request: ServiceRequest) -> dict[str, Any]:
        """List object keys under a prefix (folder simulation)."""
        payload = request.envelope.payload
        if "prefix" not in payload:
            raise ValueError("prefix required (storage_api list_objects)")
        if "max_keys" not in payload:
            raise ValueError("max_keys required (storage_api list_objects)")
        prefix = payload["prefix"]
        if not isinstance(prefix, str):
            raise ValueError("prefix must be a string")
        max_keys = min(int(payload["max_keys"]), 1000)

        from botocore.exceptions import ClientError

        try:
            resp = self.s3.list_objects_v2(
                Bucket=self._bucket_name(),
                Prefix=prefix,
                MaxKeys=max_keys,
            )
        except ClientError as e:
            logger.error("list_objects failed", prefix=prefix, error=str(e))
            raise ValueError(f"list_objects failed: {e}") from e

        keys = [o["Key"] for o in resp.get("Contents", [])]
        return {"keys": keys, "prefix": prefix, "is_truncated": resp.get("IsTruncated", False)}

    @wrapper_method("storage_api", "get_object")
    def get_object(self, request: ServiceRequest) -> dict[str, Any]:
        """Return object body as base64 (demo; max size _MAX_BYTES)."""
        payload = request.envelope.payload
        if "key" not in payload:
            raise ValueError("key required (storage_api get_object)")
        key = payload["key"]
        if not isinstance(key, str) or not key.strip():
            raise ValueError("key must be a non-empty string (storage_api get_object)")

        from botocore.exceptions import ClientError

        try:
            resp = self.s3.get_object(Bucket=self._bucket_name(), Key=key)
            body = resp["Body"].read()
        except ClientError as e:
            if e.response.get("Error", {}).get("Code") == "NoSuchKey":
                raise ValueError(f"object not found: {key}") from e
            logger.error("get_object failed", key=key, error=str(e))
            raise ValueError(f"get_object failed: {e}") from e

        if len(body) > _MAX_BYTES:
            raise ValueError(
                f"object too large for get_object API ({len(body)} bytes; max {_MAX_BYTES})"
            )

        return {
            "key": key,
            "content_base64": base64.standard_b64encode(body).decode("ascii"),
            "content_type": resp.get("ContentType", "application/octet-stream"),
            "size": len(body),
        }

    @wrapper_method("storage_api", "put_object")
    def put_object(self, request: ServiceRequest) -> dict[str, Any]:
        """Write object from base64 body (demo; max decoded size _MAX_BYTES)."""
        payload = request.envelope.payload
        if "key" not in payload:
            raise ValueError("key required (storage_api put_object)")
        if "content_base64" not in payload:
            raise ValueError("content_base64 required (storage_api put_object)")
        if "content_type" not in payload:
            raise ValueError("content_type required (storage_api put_object)")
        key = payload["key"]
        b64 = payload["content_base64"]
        content_type = payload["content_type"]

        if not isinstance(key, str) or not key.strip():
            raise ValueError("key required (storage_api put_object)")
        if not isinstance(b64, str) or not b64:
            raise ValueError("content_base64 required (storage_api put_object)")
        if not isinstance(content_type, str) or not content_type.strip():
            raise ValueError("content_type required (storage_api put_object)")

        try:
            raw = base64.b64decode(b64, validate=True)
        except Exception as e:
            raise ValueError(f"invalid content_base64: {e}") from e

        if len(raw) > _MAX_BYTES:
            raise ValueError(f"payload too large ({len(raw)} bytes; max {_MAX_BYTES})")

        from botocore.exceptions import ClientError

        try:
            self.s3.put_object(
                Bucket=self._bucket_name(),
                Key=key,
                Body=raw,
                ContentType=str(content_type),
            )
        except ClientError as e:
            logger.error("put_object failed", key=key, error=str(e))
            raise ValueError(f"put_object failed: {e}") from e

        logger.info("put_object ok", key=key, size=len(raw))
        return {"key": key, "uploaded": True, "size": len(raw)}
