"""Storage API service — runs as independent container."""

from __future__ import annotations

from python_lib.runtime.http_app import create_service_api
from services.storage_api.service import StorageApiService

storage_service = StorageApiService()
app = create_service_api("storage_api", storage_service)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8013)
