"""OCR API package."""
