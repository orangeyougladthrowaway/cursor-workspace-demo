"""OCR API container entrypoint."""

from __future__ import annotations

from python_lib.runtime.http_app import create_service_api
from services.ocr_api.service import OcrApiService

service = OcrApiService()
app = create_service_api("ocr_api", service)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8012)
