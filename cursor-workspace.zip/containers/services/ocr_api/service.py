"""OCR API — workflow-agnostic Tesseract bridge."""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

from python_lib.contracts.envelopes import ServiceRequest
from python_lib.gateway.storage import get_bytes
from python_lib.observability.structured_logger import get_logger
from python_lib.runtime.decorators import wrapper_method
from services.ocr_api.engine import OcrEngine

logger = get_logger(__name__)


class OcrApiService:
    @wrapper_method("ocr_api", "ocr_image")
    def ocr_image(self, request: ServiceRequest) -> dict[str, Any]:
        payload = request.envelope.payload
        source_key = payload.get("source_key")
        if not isinstance(source_key, str) or not source_key.strip():
            raise ValueError("source_key must be a non-empty string")

        if "image_base64" in payload:
            raise ValueError("image_base64 is not supported; use source_key")

        lang = payload.get("lang")
        tesseract_config = payload.get("tesseract_config")
        if not isinstance(lang, str) or not lang.strip():
            raise ValueError("lang required")
        if not isinstance(tesseract_config, str) or not tesseract_config.strip():
            raise ValueError("tesseract_config required")

        page_ref = payload.get("page_ref")
        if page_ref is not None and not isinstance(page_ref, str):
            raise ValueError("page_ref must be a string when provided")

        job_id = request.job_uid
        if job_id is None:
            raise ValueError("job_uid required for ocr_image")

        raw_bytes = get_bytes(
            key=source_key.strip(),
            trace_id=request.trace_id,
            job_id=job_id,
            actor="service:ocr_api",
        )

        engine = OcrEngine(lang=lang, tesseract_config=tesseract_config)
        with tempfile.TemporaryDirectory(prefix="ocr_api_") as tmp_dir:
            image_path = Path(tmp_dir) / "page.png"
            image_path.write_bytes(raw_bytes)
            text, metrics = engine.ocr_with_confidence(image_path)

        logger.info("ocr_image", page_ref=page_ref)
        result: dict[str, Any] = {
            "text": text,
            "metrics": metrics,
            "engine": "tesseract",
        }
        if page_ref is not None:
            result["page_ref"] = page_ref
        return result
