"""Tesseract OCR engine — settings supplied per request."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pytesseract
from PIL import Image


class OcrEngine:
    def __init__(self, *, lang: str, tesseract_config: str) -> None:
        if not lang.strip():
            raise ValueError("lang must be non-empty")
        if not tesseract_config.strip():
            raise ValueError("tesseract_config must be non-empty")
        os.environ["OMP_NUM_THREADS"] = "1"
        self.lang = lang.strip()
        self.config = tesseract_config.strip()

    def ocr_with_confidence(self, image_path: Path) -> tuple[str, dict[str, Any]]:
        img = Image.open(image_path)
        data = pytesseract.image_to_data(
            img,
            lang=self.lang,
            config=self.config,
            output_type=pytesseract.Output.DICT,
        )
        full_text = pytesseract.image_to_string(img, lang=self.lang, config=self.config)
        confidences: list[float] = []
        low_confidence_words: list[dict[str, Any]] = []
        word_count = 0
        for index in range(len(data["text"])):
            text = (data["text"][index] or "").strip()
            confidence = float(data["conf"][index])
            if text:
                word_count += 1
                if confidence >= 0:
                    confidences.append(confidence)
                if 0 <= confidence < 20:
                    low_confidence_words.append(
                        {
                            "text": text,
                            "confidence": confidence,
                            "word_num": data["word_num"][index],
                        }
                    )
        average = sum(confidences) / len(confidences) if confidences else 0.0
        return full_text, {
            "avg_confidence": average,
            "low_confidence_words": low_confidence_words,
            "word_count": word_count,
        }
