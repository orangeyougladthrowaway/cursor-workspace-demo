"""Platform service packages (gateway, storage_api, ocr_api, db_api, finnhub_bridge)."""
