# Trusted third-party images

House register of **approved off-the-shelf / base** images. Explainers + pointers + pins only — do not vendor upstream source.

Update this file in the **same change** as any Compose/Dockerfile that adopts a new base or off-the-shelf image.

| Role | Image (pin) | Source / registry | Mirror to ACR? | Notes |
| --- | --- | --- | --- | --- |
| Slim OS base (default) | `ubuntu:24.04` | Docker Official | TBD | Prefer slim/minimal bases for house Dockerfiles |
| Python slim base | `python:3.12-slim` | Docker Official | TBD | Used by v0.1 gateway / storage_api / ocr_api Dockerfiles |
| Postgres | `postgres:16` | Docker Official | TBD | Pin major; bump deliberately |
| SQL Server | `mcr.microsoft.com/mssql/server:2022-latest` | MCR | TBD | Prefer a dated/tag pin when house picks a lived version — `:latest` is a Gap until locked |
| Reverse proxy | `nginx:1.27-alpine` | Docker Official | TBD | Edge/static where nginx is chosen |
| Edge / TLS helper | `caddy:2` | Docker Official | TBD | Prefer a minor pin (e.g. `2.8`) when lived |

## Rules

1. Products and house Dockerfiles **use this table** — do not invent a parallel base.
2. Lived pin = exact tag or digest recorded here; `:latest` is not the long-term SoT.
3. Optional ACR mirror (`az acr import`) — when enabled, record the ACR reference in **Mirror to ACR?** and prefer that pin in Compose.
4. Systems vault owns *what* Postgres/SQL Server *are* as platforms; this file owns *which image tag* the house runs.

## Gaps

- Exact SQL Server tag (not `…-latest`) — lock when first lived Azure SQL / container wave lands.
- ACR mirror yes/no per row — decide with first ACR setup.
- Prefer digest pins for `python:3.12-slim` when first ACR mirror lands.
