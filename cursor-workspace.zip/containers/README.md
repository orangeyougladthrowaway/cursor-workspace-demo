# containers

House **container** remote: custom platform images **and** a light register of trusted third-party images.

| Layer | Owns |
| --- | --- |
| engineering-knowledge-base | Craft law (prefer-image, packaging, Compose, admission) |
| This repo | Dockerfiles, service entrypoints, image matrix, CI publish, `base-images.md` pins, light local rules |
| systems-knowledge-base | What ACR / ADO Pipelines *are* (SoR, auth class, Usage) |
| Azure Container Registry | Built (and optionally mirrored) image artefacts |

## Admitted services (v0.1)

| Service (envelope) | Compose / ACR | Dockerfile |
| --- | --- | --- |
| gateway | `gateway` / `platform/gateway` | `deploy/docker/Dockerfile.gateway` |
| storage_api | `storage-api` / `platform/storage-api` | `deploy/docker/Dockerfile.storage-api` |
| ocr_api | `ocr-api` / `platform/ocr-api` | `deploy/docker/Dockerfile.ocr-api` |
| db_api | `db-api` / `platform/db-api` | `deploy/docker/Dockerfile.db-api` |
| finnhub_bridge | `finnhub-bridge` / `platform/finnhub-bridge` | `deploy/docker/Dockerfile.finnhub-bridge` |

**Naming:** envelope `service_name` = snake_case; Compose DNS + ACR repository = kebab-case.

Imports use `python_lib.*` and package paths `services.<snake>`.

## Gaps

| Gap | Notes |
| --- | --- |
| db_api engines | **PG-only** in v0.1 — SQL Server / dual dialect still Gap (see below) |
| inference_api | Out of scope |
| ACR login server | Set via `ACR_HOST` (local/deploy env or pipeline var) — never commit a lived registry name |
| python-lib test depth | Public surface partially covered (envelopes/wrapper/outbound); http_app/storage/obs thin |
| python-lib observability | `MetricsCollector`, `ServiceManifestLoader`, `TokenGenerator` under `services/gateway/support/` until python-lib v0.2 |
| Azure Blob rewrite | `SPACES_*` S3-compatible env contract kept |

## db_api readiness Gaps (beyond PG sandbox)

| Gap | Detail |
| --- | --- |
| Engine switch | Today PG-only — SQL Server still Gap |
| Hosting modes | Managed PaaS · full VM · Compose `postgres:16` — config must name which |
| Schema co-location | WAL/smoke schema embeds in image startup for v0.1; versioned `schema/` tree still Gap |
| Dialect | PG `JSONB` / `gen_random_uuid()` ≠ SQL Server types |
| Tests | Hermetic proof per supported engine (or contract + one CI engine matrix) |

## CI (ADO)

Two pipelines, hard split so image push can never happen pre-merge:

| Pipeline | YAML | Fires on | Does |
| --- | --- | --- | --- |
| **containers-test** | `containers-test.yml` | PR into `main` (Build Validation policy) | install pin from feed, assert `python_lib` import, pytest, **docker build (no push)** + image import smoke |
| **containers-publish** | `containers-publish.yml` | merge / push to `main` | re-run tests, build + **push** images to ACR |

PR proves the pin and Dockerfiles; publish only pushes. Test-time deps are in `requirements-test.txt`. Azure Repos ignores YAML `pr:` triggers — Build Validation on `main` points at **containers-test** (never publish).

Set **`ARTIFACTS_FEED`** on **both** pipelines (prefer one variable group) and **`ACR_SERVICE_CONNECTION`** on **containers-publish** only. The pinned wheel is downloaded in the pipeline and installed from the build context — no feed credential enters an image.

Full setup: `agent-harness/docs/release-chain.md`.

**Order:** `python-lib` CI must have published the version in `lib-pin.txt` to the feed before this pipeline’s publish succeeds — an unpublished pin fails the build. Changing the library and the images in one release: publish the lib first, then bump `lib-pin.txt` (and the version asserted in `tests/unit/test_smoke.py`).

## python-lib pin

Images install a **pinned** `python-lib` version (see `lib-pin.txt`) from a wheel placed in `wheels/` — CI resolves it from Azure Artifacts; locally run `python -m build -w -o wheels ../python-lib`. Do not vendor `python_lib` source here.

Local tests: `pythonpath` includes `../python-lib/src` via `pyproject.toml`, or `pip install -e ../python-lib` / `pip install -e ".[dev]"`.

```text
python -m pytest -q
```

## Layout

```text
services/                 # gateway, storage_api, ocr_api
config/services/          # gateway route manifests (v0.1 admitted only)
deploy/docker/            # Dockerfiles
deploy/compose/           # docker-compose.pull.yml (ACR images); .reference.yml → include pointer
tests/unit/               # smoke/unit without live cloud
base-images.md            # trusted third-party register
lib-pin.txt               # python-lib==0.1.1
pyproject.toml            # test workspace only — not a second public lib
```

## Runtime

**Compose on VM** only. No Helm, no Kubernetes in this house posture.

## Authority

Retrieve eng notes: prefer-house-platform-image · house-containers-remote · shared-library-admission · house-shared-python-library.
