# Contributing — containers

1. Retrieve eng prefer-house-platform-image / house-containers-remote before structural changes.
2. Custom services: admit only cross-product platform capability; no product domain.
3. Update `base-images.md` in the same change as any new third-party/base pin.
4. Bump `lib-pin.txt` deliberately when adopting a new `python-lib` version; rebuild images after.
5. ADO Pipelines is the lived publish SoT; GHA may mirror with identical pin rules.
6. No Helm / no Kubernetes.
