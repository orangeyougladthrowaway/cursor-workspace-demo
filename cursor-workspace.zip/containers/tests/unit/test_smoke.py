"""Unit/smoke tests — no live cloud required."""

from __future__ import annotations

from python_lib.contracts.envelopes import ServiceRequest
from python_lib import __version__ as python_lib_version


def test_python_lib_version_pinned_surface() -> None:
    assert python_lib_version == "0.1.1"


def test_service_request_import() -> None:
    assert ServiceRequest is not None


def test_storage_api_service_import() -> None:
    from services.storage_api.service import StorageApiService

    svc = StorageApiService()
    assert svc._client is None


def test_ocr_engine_rejects_empty_lang() -> None:
    from services.ocr_api.engine import OcrEngine

    try:
        OcrEngine(lang=" ", tesseract_config="--psm 6")
        raised = False
    except ValueError:
        raised = True
    assert raised


def test_gateway_validator_requires_target() -> None:
    from datetime import datetime

    from python_lib.contracts.envelopes import EnvelopeV1Request
    from services.gateway.layers.validator import Validator

    envelope = EnvelopeV1Request(
        envelope_version="1.0",
        kind="request",
        schema_version="1.0",
        trace_id="t1",
        request_id="r1",
        actor="service:test",
        timestamp=datetime.utcnow(),
        target={"service": "storage_api", "method": "list_objects"},
        payload={"prefix": "", "max_keys": 10},
    )
    ok, err = Validator().validate(envelope, {})
    assert ok is True
    assert err is None


def test_gateway_router_register_and_route() -> None:
    from datetime import datetime

    from python_lib.contracts.envelopes import EnvelopeV1Request
    from services.gateway.layers.router import Router

    router = Router()

    def _handler(envelope: EnvelopeV1Request, context: dict) -> dict:
        return {"status": "success", "payload": {}}

    router.register("storage_api", "list_objects", _handler)
    envelope = EnvelopeV1Request(
        envelope_version="1.0",
        kind="request",
        schema_version="1.0",
        trace_id="t1",
        request_id="r1",
        actor="service:test",
        timestamp=datetime.utcnow(),
        target={"service": "storage_api", "method": "list_objects"},
        payload={},
    )
    handler, err = router.route(envelope, {})
    assert err is None
    assert handler is _handler


def test_authorizer_denies_when_policies_empty() -> None:
    from datetime import datetime

    from python_lib.contracts.envelopes import EnvelopeV1Request
    from services.gateway.layers.authorizer import Authorizer

    envelope = EnvelopeV1Request(
        envelope_version="1.0",
        kind="request",
        schema_version="1.0",
        trace_id="t1",
        request_id="r1",
        actor="service:test",
        timestamp=datetime.utcnow(),
        target={"service": "storage_api", "method": "list_objects"},
        payload={},
    )
    ok, err = Authorizer().authorize(envelope, {})
    assert ok is False
    assert err is not None
    assert "policies" in err.lower()


def test_manifest_loader_admits_v01_services() -> None:
    from services.gateway.support.service_manifest_loader import ServiceManifestLoader

    manifest = ServiceManifestLoader.load_all_manifests("config/services")
    names = set(manifest["services"].keys())
    assert names == {"storage_api", "ocr_api", "db_api", "finnhub_bridge"}
    assert "list_objects" in ServiceManifestLoader.get_service_methods(manifest, "storage_api")
    assert "ocr_image" in ServiceManifestLoader.get_service_methods(manifest, "ocr_api")
    assert "record_smoke" in ServiceManifestLoader.get_service_methods(manifest, "db_api")
    assert "get_quote" in ServiceManifestLoader.get_service_methods(manifest, "finnhub_bridge")
