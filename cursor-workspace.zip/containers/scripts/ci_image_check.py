"""PR gate for containers: prove house pin + Dockerfiles build (no push).

Assumes the agent already:
  - authenticated to the Artifacts feed
  - installed lib-pin.txt + requirements-test.txt
  - ran `pip download -r lib-pin.txt --no-deps -d wheels`

Does not touch ACR. Fail loud if the installed package is not `python_lib` or an
image builds without that import.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

IMAGES: list[tuple[str, str]] = [
    ("deploy/docker/Dockerfile.gateway", "platform/gateway:pr"),
    ("deploy/docker/Dockerfile.storage-api", "platform/storage-api:pr"),
    ("deploy/docker/Dockerfile.ocr-api", "platform/ocr-api:pr"),
    ("deploy/docker/Dockerfile.db-api", "platform/db-api:pr"),
    ("deploy/docker/Dockerfile.finnhub-bridge", "platform/finnhub-bridge:pr"),
]


def main() -> int:
    print("::: import pinned python_lib", flush=True)
    code = subprocess.run(
        [
            sys.executable,
            "-c",
            "import python_lib; assert python_lib.__version__; print(python_lib.__version__)",
        ]
    ).returncode
    if code != 0:
        print(
            "FAILED: python_lib not importable — pin missing, wrong package, or unset ARTIFACTS_FEED",
            file=sys.stderr,
        )
        return code

    wheels = ROOT / "wheels"
    if not any(wheels.glob("*.whl")):
        print("FAILED: wheels/ empty — download the pin before this script", file=sys.stderr)
        return 1

    for dockerfile, tag in IMAGES:
        print(f"::: docker build {tag}", flush=True)
        code = subprocess.run(
            ["docker", "build", "-f", dockerfile, "-t", tag, "."],
            cwd=ROOT,
        ).returncode
        if code != 0:
            print(f"FAILED: docker build {tag}", file=sys.stderr)
            return code

    print("::: gateway image import smoke", flush=True)
    code = subprocess.run(
        [
            "docker",
            "run",
            "--rm",
            "platform/gateway:pr",
            "python",
            "-c",
            "import python_lib; print(python_lib.__version__)",
        ]
    ).returncode
    if code != 0:
        print("FAILED: gateway image missing python_lib", file=sys.stderr)
        return code

    print("Image check passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
