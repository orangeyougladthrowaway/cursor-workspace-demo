---
name: engineering-knowledge-base-build
description: Implements an accepted engineering plan under engineering-knowledge-base authority. Use when asked to build, implement, refactor, or fix product code.
disable-model-invocation: true
---

Follow `60-workflows/delivery/build-engineering-change.md` (`engineering-knowledge-base-wf-010`).

Require the workflow's preconditions, apply its retrieval protocol, and hand
the result to verification. Do not amend engineering-knowledge-base from a product workspace.
