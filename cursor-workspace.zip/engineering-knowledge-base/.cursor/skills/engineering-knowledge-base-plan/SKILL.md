---
name: engineering-knowledge-base-plan
description: Plans non-trivial product engineering work under engineering-knowledge-base authority. Use when asked to plan, scope, design, or sequence an engineering change.
disable-model-invocation: true
---

Follow `60-workflows/delivery/plan-engineering-change.md` (`engineering-knowledge-base-wf-009`).

Treat engineering-knowledge-base as the primary engineering authority. Produce the workflow's required
output and stop on unresolved preconditions. Do not edit files.
