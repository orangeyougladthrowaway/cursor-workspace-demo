---
name: engineering-knowledge-base-test
description: Verifies an engineering change using evidence-matched hard gates. Use when asked to test, validate, prove, or diagnose verification failures.
disable-model-invocation: true
---

Follow `60-workflows/testing/verify-engineering-change.md` (`engineering-knowledge-base-wf-011`).

Return the workflow's evidence and verdict. Never suppress or reinterpret a
failed quality gate as success.
