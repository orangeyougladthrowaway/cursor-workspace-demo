---
name: engineering-knowledge-base-review
description: Reviews an engineering change against acceptance, engineering-knowledge-base doctrine, and verification evidence. Use when asked for code, design, implementation, or change review.
disable-model-invocation: true
---

Follow `60-workflows/delivery/review-engineering-change.md` (`engineering-knowledge-base-wf-012`).

Return findings first in severity order, then questions, verification gaps,
and the workflow verdict. Do not modify the reviewed change unless asked.
