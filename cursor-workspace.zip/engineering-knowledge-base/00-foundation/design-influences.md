---
type: foundation
status: canonical
description: Design influences — inspiration only, not process to copy.
updated: 2026-07-14
---

# Design influences

| Source | Borrowed | Not copied |
| --- | --- | --- |
| ADR thinking | Short rationale for significant choices | Vault-level decision log / immutability theatre |
| Diátaxis | One job per doc | Folders named tutorial/howto/… |
| Docs-as-code | Markdown in Git | Treating engineering-knowledge-base as app user manuals |
| Obsidian PKM | Wikilinks, frontmatter, small notes | Plugin lock-in; PARA as primary axis |
| AI vault design | `description` for scan-without-open | Giant pasted context packs |

Differentiator: organise by **maturity/abstraction**, keep a **current-state** bible.
