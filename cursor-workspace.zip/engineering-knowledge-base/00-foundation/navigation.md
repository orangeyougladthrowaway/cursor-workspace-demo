---
type: foundation
status: canonical
id: engineering-knowledge-base-fnd-navigation
description: Navigation — altitude × responsibility folders; maps as knowledge atlases (not job playbooks).
updated: 2026-07-15
---

# Navigation

How this vault is browsed. **Folders and names are architecture.**

## Purpose of structure

engineering-knowledge-base stores **accumulated engineering knowledge** from lived projects (and later research) as the base for future work.  
It is **not** a task centre (“how do I build X today”). Maps do **not** answer with a procedure for a job — they **atlas** a body of knowledge.  
`lab/` holds subordinate **praxis** (examples/skeletons/stubs) — also not a task curriculum ([[layout]], [[praxis-ingestion]]).

## Hard naming rule

**No `and` as a compounding join** in folder or concept basenames. One folder = one responsibility. Split siblings.

## Three modes (+ praxis)

| Mode | Question | Mechanism |
| --- | --- | --- |
| **Taxonomic** | What responsibility am I under? | Altitude → **responsibility folder** → note |
| **Atlas** | What body of knowledge? | `maps/families/` or `maps/themes/` |
| **Facet** | Which stack token? | Frontmatter `domain:` / `aliases:` |
| **Praxis** | What does applying a canon look like? | `lab/zoo/` · `lab/skeletons/` · `lab/stubs/` — indexed by [[lab-atlas]]; **never** a curriculum path |

Normative answers live in doctrine. Lab exemplars **cite** doctrine; they do not replace it.

## Axis 1 — altitude

```text
00-foundation → 10-philosophy → 20-principles → 30-standards
  → 40-patterns → 50-guidance / 60-workflows
```

Depend upward; specialise downward. See [[dependency-rules]].

**Guidance** holds the bulk of project-extracted detail. Prefer **many small responsibility folders** over fat multi-topic notes.

## Axis 2 — responsibility folders

Principles: `20-principles/{concept}/{note}.md` with spine `{concept}/{concept}.md`.

Standards / patterns / guidance / workflows: `NN-layer/{responsibility}/{note}.md`.

### Principle concepts

`ownership` · `boundaries` · `failure` · `honesty` · `restraint` · `change` · `trust` · `authority` · `proof` · `reliability` · `modeling`

### Shared responsibilities (30 / 40 / 50 / 60)

Extend this list by amending **this** note before inventing folders:

| Folder | Responsibility |
| --- | --- |
| `ownership` | Privilege / credential ownership |
| `boundaries` | Domain vs edge walls |
| `contracts` | Wire/API shapes (Envelope, adapters) |
| `policy` | Manifests, config-as-data, schema compile |
| `auth` | Authentication / AuthZ honesty |
| `bridges` | Capability bridges / external I/O owners |
| `compose` | Compose/VM runtime packaging |
| `opentofu` | Host/VM provisioning (OpenTofu/Terraform) |
| `orchestration` | In-process / service orchestrators · batch pointers |
| `audit` | WAL / job trails / operator audit |
| `packaging` | Images, extras, install stories; **house shared-library** and **containers** product packaging (see [[house-shared-python-library]], [[house-containers-remote]]) |
| `delivery` | CI / gates honesty |
| `ingest` | Landing data (warehouse) |
| `historisation` | SCD2 / durable history (warehouse) |
| `activation` | Host release activation (warehouse) |
| `hydra` | Experiment config systems (trainer) |
| `algorithms` | Train loops / algos (trainer) |
| `authority` | Docs-as-authority |
| `knowledge` | Vault / agent projection |
| `change` | Evolution norms |
| `trust` | Threat models |
| `datastores` | General DB/storage concepts (Postgres, replication, DDIA themes) |
| `apis` | Public HTTP/REST/OpenAPI product surfaces |
| `languages` | Language style, idioms, house dialect |
| `testing` | Test craft beyond CI gate honesty |
| `observability` | Metrics, tracing, logging, delivery measurement |
| `modeling` | Grain, DDD vocabulary, dimensional modeling (Kimball) |
| `ssis` | Integration Services project craft (dtproj / dtsx / ispac) |

**Primary folder only** per note. Prefer a **new sibling folder** over stuffing unrelated sections into one note.

**Forbidden at altitude L1:** product lore folders, org-chart folders. Lived **families** and cross-cutting **themes** belong under `maps/families/` and `maps/themes/` only — not as parallel altitude trees.

## Axis 3 — maps (atlases)

```text
maps/
  catalog-maps.md
  families/{family}/…-atlas.md    # lived project bodies
  themes/{theme}/…-atlas.md       # cross-cutting / remote bodies
```

**Two kinds — same atlas rules** (indexes only; never task journeys):

| Kind | Folder | Examples | Role |
| --- | --- | --- | --- |
| **Family** | `maps/families/{family}/` | `platform` · `warehouse` · `trainer` | Accumulated knowledge from a lived repo family |
| **Theme** | `maps/themes/{theme}/` | `security` · `delivery` · `infrastructure` · `data` · `architecture` · `apis` · `languages` · `observability` · `agent-engineering` · `engineering-craft` | Cross-cutting / remote topic bodies — index draft+canonical notes elsewhere |

Atlas `concern` = the **leaf folder** (`platform`, `security`, …) — not `families` or `themes`.

Extend family/theme lists by amending **this** note before inventing new atlas folders. Prefer a new theme atlas over fat multi-topic atlases. Banned: `_index.md`; `and`-joined names; curriculum playbooks.

Unique filenames within a kind (`catalog-maps.md` at `maps/` root).

## Axis 4 — facets

```yaml
id: engineering-knowledge-base-{type}-{nnn}
concern: <responsibility folder name>  # map notes: family or theme leaf folder (not families|themes)
domain: []                              # stack / ecosystem tags
aliases: []                             # informal search tokens only — never a rename substitute
status: draft | canonical | deprecated  # deprecated = brief migration only
```

| Field | Use |
| --- | --- |
| `domain` | Stack / ecosystem (`python`, `compose`, …) |
| `aliases` | Informal search tokens — **not** old basenames or spelling twins |

Detail and forbid list: [[methodology]]. Retirement: [[changing-this-bible]].

## Protocols

**Human:** atlas under `maps/families/` or `maps/themes/` · or responsibility folder · or `domain` search.

**AI:**

1. Read [[README]] + this note.
2. Prefer `maps/families/` or `maps/themes/` atlases to locate a body of knowledge, then open linked notes.
3. For “show me the shape,” open [[lab-atlas]] / zoo / skeletons after the canon — do **not** treat lab as sole law.
4. For “how complete is the bible / this language?” open [[common-case-coverage]] — do **not** treat zoo counts as majority done.
5. Do **not** invent task journeys or `and`-joined folders; lab-atlas stays an index.
6. Prefer `canonical`; cite `id`. Treat harvest under `temp/` as source for elevation, not user-facing doctrine.
7. Structural edits: follow [[methodology]] naming and [[changing-this-bible]] retirement / cleanliness. Praxis: [[praxis-ingestion]].

## Related

- [[layout]] · [[methodology]] · [[changing-this-bible]] · [[catalog-maps]] · [[common-case-coverage]] · [[purpose]]
