---
type: foundation
status: canonical
description: Top-level layout — doctrine altitude + maps + subordinate lab praxis plane.
updated: 2026-07-15
---

# Repository layout

**Primary axis:** altitude of knowledge (doctrine).  
**Secondary axis:** **one responsibility per folder**. See [[navigation]].  
**Praxis plane:** `lab/` — exemplars subordinate to doctrine. Naming / retirement: [[methodology]], [[changing-this-bible]].

```text
engineering-knowledge-base/
├── README.md
├── maps/
│   ├── catalog-maps.md
│   ├── families/          # lived project bodies
│   └── themes/            # cross-cutting / remote topic atlases
├── 00-foundation/
│   └── templates/         # NOTE-writing templates only (not stack skeletons)
├── 10-philosophy/
├── 20-principles/{concept}/
├── 30-standards/{responsibility}/
├── 40-patterns/{responsibility}/
├── 50-guidance/{responsibility}/
├── 60-workflows/{responsibility}/
├── lab/                   # PRAXIS — zoo / skeletons / stubs (not doctrine altitude)
│   ├── praxis-plane.md
│   ├── catalog-lab.md
│   ├── maps/lab-atlas.md
│   ├── zoo/{facet}/
│   ├── skeletons/{name}/
│   └── stubs/{facet}/
├── temp/                  # harvest staging — not doctrine
├── tests/                 # doctrine suite skips lab/; tests/lab/ for praxis
└── .cursor/rules/
```

## Folder contracts

| Folder | Belongs |
| --- | --- |
| `maps/families/{family}/` | Knowledge atlases for a lived project family — indexes, not task playbooks |
| `maps/themes/{theme}/` | Knowledge atlases for cross-cutting / remote topics — indexes, not playbooks |
| `00-foundation/` | Meta, [[navigation]], **note** templates, glossary |
| `00-foundation/templates/` | Vault note starters **and** [[product-init]] (product Cursor/AGENTS copy-pack). App/IaC stack skeletons stay under `lab/skeletons/` |
| `10-philosophy/` | Rare worldview |
| `20-principles/{concept}/` | Category spine + leaves |
| `30-standards/{responsibility}/` | Norms |
| `40-patterns/{responsibility}/` | Portable recurring shapes |
| `50-guidance/{responsibility}/` | Accumulated stack/project detail |
| `60-workflows/{responsibility}/` | Sequences for maintaining the bible (incl. [[praxis-ingestion]]) |
| `lab/` | Praxis: [[praxis-plane]], zoo examples, copy-out skeletons, stubs — cite canons; never redefine law |
| `temp/` | Harvest / workstream drafts — not user-facing doctrine |

**Banned:** `_index.md`; `-and-` compound names; product-lore folders at altitude L1; treating `maps/` or `lab-atlas` as “how to do job X” curriculum; empty doctrine homes without orphan proof.

Inventories: unique `catalog-*.md` at each layer (and `maps/catalog-maps.md`, `lab/catalog-lab.md`).
