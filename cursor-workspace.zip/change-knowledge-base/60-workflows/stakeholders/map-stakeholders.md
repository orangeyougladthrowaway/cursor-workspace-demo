---
type: workflow
status: draft
id: change-knowledge-base-wf-013
concern: stakeholders
description: Sequence to produce a stakeholder map against change-knowledge-base-s-004 without inventing org lore.
derived_from:
  - "[[stakeholder-clarity]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Map stakeholders

Agent-operable sequence for BA04.

## Steps

1. **Retrieve** — [[business-analysis-atlas]] → [[stakeholder-clarity]] (`change-knowledge-base-s-004`) → skeleton `lab/skeletons/stakeholder-map/`.
2. **Inputs** — problem frame if present; named parties from brief. Missing org/process ownership → escalate to systems-knowledge-base/user.
3. **Draft map** — party · interest · impact · influence · engagement (via [[influence-interest-grid]]) · warrant · owner.
4. **Verify** — field tests in [[stakeholder-clarity]]. No directory dump; engagement must vary with influence when influence differs.
5. **Cite** — `change-knowledge-base-s-004`.
6. **Hand off** — use map to plan elicitation; do not invent requirements from blank interest fields.

## Forbidden

- Inventing who owns systems/processes
- Org-chart paste as method artefact
