---
type: workflow
status: draft
id: change-knowledge-base-wf-032
concern: delivery
description: Produce one change artefact by following a named change-knowledge-base cell or journey workflow.
domain: ["cursor"]
derived_from:
  - "[[staff-agent-projection]]"
  - "[[plan-change-work]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Produce change artefact

Dispatcher workflow: **require** a named cell or journey workflow and follow it. Do not invent a parallel procedure here.

## Preconditions

- Named target workflow (e.g. [[frame-problem]], [[build-plan]], [[ba-change-pass]])
- Plan or brief with acceptance ([[plan-change-work]] preferred)
- Domain inputs available or Gaps listed

If the target workflow is unnamed, stop and ask (or return to [[plan-change-work]]).

## Retrieve

1. Open [[staff-agent-projection]] and the theme atlas for the profile.
2. Open the **named** cell or journey workflow and its `derived_from` standard.
3. Open [[precision-over-vagueness]] when producing requirements, AC, data model, or test conditions.
4. Open the matching lab skeleton **after** the canon ([[lab-atlas]]).

## Steps

1. Confirm the named workflow’s preconditions; escalate if unmet.
2. Execute that workflow’s steps exactly (retrieve → draft → verify field tests → cite `id`).
3. **Precision check:** before marking Ready, confirm in-scope grain meets the target standard’s precision bar — else Gap/blocked, not theatre.
4. Do not silently expand into a full journey unless the named target is a pass workflow.
5. Record Escalations instead of inventing domain or engineering facts.
6. Hand off only when the named workflow’s output shape is complete.

## Output

Whatever the named cell/journey workflow requires, plus:

- Target workflow stem + `id`
- Cited standard `id`s
- Open escalations (include imprecise grain)

**Where to write:** consumer / product workspace (or PR body) — **never** into this vault as a run log, and never into agent-harness `artefacts/` or committed dumps.

## Handoff

Pass the artefact to [[verify-change-artefact]].

## Forbidden

- Producing without a named change-knowledge-base workflow
- Reprinting standards into chat as a substitute for opening the note
- Implementing code/tests as TA/PM/BA substitute
- Dumping deliverables into this vault or harness programme-dump folders
- Ready status on vague in-scope rows ([[precision-over-vagueness]])
