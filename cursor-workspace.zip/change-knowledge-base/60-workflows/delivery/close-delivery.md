---
type: workflow
status: draft
id: change-knowledge-base-wf-023
concern: delivery
description: Sequence to close a change against change-knowledge-base-s-013 — confirm outcome, residuals, handoff.
derived_from:
  - "[[closure-confirmation]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Close delivery

Agent-operable sequence for PM06.

## Steps

1. **Retrieve** — [[project-management-atlas]] → [[closure-confirmation]] (`change-knowledge-base-s-013`) → skeleton `lab/skeletons/closure-report/`.
2. **Check outcome** — vs initiation mandate/success measure ([[initiation-mandate]]). Benefit unknown → escalate.
3. **Record delivered scope** — vs planned; name descopes.
4. **List residuals** — open items/defects with owners.
5. **Handoff** — who owns run/support/benefit next.
6. **Lessons** — portable learnings as method pressure.
7. **Cite** — `change-knowledge-base-s-013`. No "success" while residuals hide.

## Forbidden

- Declaring done because work stopped
- Residuals with no owner
- Claiming benefit realisation that is unconfirmed
