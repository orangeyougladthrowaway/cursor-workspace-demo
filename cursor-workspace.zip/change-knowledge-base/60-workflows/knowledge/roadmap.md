---
type: foundation
status: draft
id: change-knowledge-base-fnd-roadmap
description: Roadmap — usable G4 matrices + artefact pack; dry-runs and canonical promotion next.
updated: 2026-07-18
---

# Roadmap

Program ambition lives here; cell truth lives on [[common-case-coverage]].

## Done

- Foundation + theme atlases (BA/PM/TA)
- Scaffold standards / workflows / skeletons
- **Axis U0–U3:** honest gates; craft guidance; worked exemplars; Open cells BA08–12, PM07–11, TA06–09 elevated to G4
- Track scoreboard: BA/PM/TA **100% G4** under usable bar (still `draft` status pending dry-runs)
- **Artefact track (AR01–AR21):** Tier-1 BCS-aligned templates + craft + workflows; approach index [[project-artefact-pack]]; journeys wired
- **Change artefact policy:** [[change-artefact-policy]] — class → M/R/O; process path [[small-change-control]]; wired into [[plan-change-work]] / journeys / verify

## Axis U — Usability

| Phase | Work | Status |
| --- | --- | --- |
| U0 | Honest gates + matrix expansion | **done** |
| U1 | Craft guidance on cells | **done** |
| U2 | Worked zoo exemplars | **done** |
| U3 | Open-cell homes to G4 | **done** |
| U3b | Project artefact pack (templates + craft) | **done** |
| U3c | Change artefact policy (mandatory set) | **done** |
| U4 | Human-scored dry-runs on change passes | **next** |
| U5 | Wave-1 primary source collision (user-chosen) | after U4 / when user picks |
| U6 | Promote `draft` → `canonical` | human/user command only |

## Next

1. Human-scored dry-runs (BA/PM/TA passes + sample artefact pack)
2. Optional book/standard collision
3. Canonical promotion on command

## Session budgets

Mirror [[knowledge-ingestion]]. Prefer amend-first over new profiles.
