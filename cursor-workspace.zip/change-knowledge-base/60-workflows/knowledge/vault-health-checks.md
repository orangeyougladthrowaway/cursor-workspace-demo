---
type: workflow
status: draft
id: change-knowledge-base-wf-006
concern: knowledge
description: How to run change-knowledge-base vault-health tests — one SoT in pyproject.toml; pytest + pyyaml only.
updated: 2026-07-17
---

# Vault health checks

Enforce vault cleanliness from [[changing-this-bible]] / [[methodology]] — not application unit tests.

## Deps (one SoT)

Root `pyproject.toml` only. No `requirements.txt` for vault health.

| Piece | Meaning |
| --- | --- |
| `dependencies = []` | No runtime app deps — tests only scan the vault |
| `dev = [pytest, pyyaml]` | Test-only deps |
| `packages = []` | Stub project for tooling — not an installable library |
| `pythonpath = ["."]` | Lets tests do `from tests.vault import …` |
| `testpaths = ["tests"]` | Pytest discovers under `tests/` |

## Run (local / CI)

```text
python -m pip install pytest pyyaml
pytest tests/ -v
# when lab/ changed:
pytest tests/lab -v
```

Equivalent fuller form (matches optional-deps; unused in CI currently):

```text
python -m pip install -e ".[dev]"
pytest tests/ -v
```

## Tree

```text
change-knowledge-base/
├── pyproject.toml                 # ONLY dep declaration for vault tests
├── .github/workflows/
│   └── vault-health.yml           # CI: pip install pytest pyyaml → pytest tests/ -v
├── 60-workflows/knowledge/
│   └── vault-health-checks.md     # this runbook
└── tests/
    ├── vault.py                   # shared helpers
    ├── test_wikilinks.py
    ├── test_frontmatter.py
    ├── test_naming.py
    ├── test_navigation.py
    ├── test_catalogs.py
    └── lab/
        └── test_lab_contract.py
```

No `conftest.py`. No `requirements*.txt` for vault health.

## Suite design

**Core helper** `tests/vault.py`:

- `ROOT` = repo root
- `iter_notes()` walks `*.md`, skips `.git`, `temp`, `node_modules`, `.cursor`, `.obsidian`, `lab`, `.systems-knowledge-base`, `.change-knowledge-base`
- Lab has its own walker `iter_lab_notes()`
- Parses YAML frontmatter with PyYAML; wikilink / stem / navigation helpers

**Doctrine suite** (`tests/*.py`):

| File | Checks |
| --- | --- |
| `test_wikilinks.py` | Basename wikilinks resolve; no path-style / `.md` targets |
| `test_frontmatter.py` | concern = folder; principles have category; doctrine id; no deprecated |
| `test_naming.py` | No `and` in folder/stem; stem ≈ H1 |
| `test_navigation.py` | Guidance/standards folders listed in navigation; no empty responsibility folders |
| `test_catalogs.py` | Layer catalogs link their notes; required atlases exist |

**Praxis suite** (`tests/lab/`): zoo `type: example` + doctrine cites, facet allowlist, skeleton contracts.

**Failure model:** tests fail → fix notes by hand → re-run. No auto-fix.

## Related

- [[changing-this-bible]] · [[methodology]] · [[praxis-ingestion]] · [[common-case-coverage]]
