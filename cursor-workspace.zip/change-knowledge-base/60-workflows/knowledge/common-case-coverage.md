---
type: workflow
status: draft
id: change-knowledge-base-wf-004
concern: knowledge
description: Common-case coverage — usable craft bar; BA/PM/TA + Artefact pack matrices.
derived_from:
  - "[[purpose]]"
  - "[[scope]]"
  - "[[knowledge-ingestion]]"
  - "[[praxis-ingestion]]"
  - "[[ingest-coverage]]"
  - "[[roadmap]]"
updated: 2026-07-18
---

# Common case coverage

Living **scoreboard** for Axis F. Not doctrine for method choices — doctrine lives in responsibility notes. This note answers: **how covered are we** toward *usable* majority common cases for house PM/BA/TA work.

## Destination bar

≥ ~**70%** of matrix cells per active track at **G4** (or G1–G3 + explicit praxis Gap). Agents must not quietly lower the bar.

**Forbidden exit criteria:** facet seeded · pointer-only atlas row · blank skeleton as “done” · zoo count without matrix % · claiming G4 because a retrieve→fill-form workflow exists.

## Gates (per cell) — usability bar

| Gate | Meaning |
| --- | --- |
| **G1 Law** | Living standard/pattern/guidance (or named Gap) answers the question |
| **G2 Root** | Principle cite + trusted/lived source pressure (or explicit Gap on sources) |
| **G3 Depth** | **Craft guidance** answers how to act |
| **G4 Praxis** | **Worked** exemplar (good vs bad) — blank skeleton ≠ G4 |

`Open` = below G1. Scores use the **highest completed** gate.

## Axis Q honesty

Scaffold-only G4 was rescored 2026-07-18. This wave densified craft + worked exemplars across core and expanded cells.

**2026-07-25** — tracker cells added: PM12 [[work-item-hygiene]] and BA13 [[definition-of-ready]] enter at **G3** (standard + craft, no worked exemplar). They deliberately dent BA/PM from 100% rather than claim praxis that does not exist; promote after the first change is tracked end to end. Tracker-state honesty folded into PM04 rather than opening a new cell.

## Track scoreboard

| Track | Cells | G4 | % G4 | ≥70%? | Notes |
| --- | --- | --- | --- | --- | --- |
| **BA** | 13 | 12 | **92%** | **yes** | BA01–BA12 craft + worked; BA13 readiness gate at G3 (no worked exemplar yet) |
| **PM** | 12 | 11 | **92%** | **yes** | PM01–PM11 craft + worked; PM12 work-item hygiene at G3 (no worked exemplar yet) |
| **TA** | 9 | 9 | **100%** | **yes** | TA01–TA09 craft + worked; analysis grain |
| **Artefact** | 21 | 21 | **100%** | **yes** | BCS Tier-1 pack; index [[project-artefact-pack]]; mandatoriness [[change-artefact-policy]] |

## Cell matrices

### BA

| # | Case | Today | Target | Home | Guidance | Workflow | Praxis |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BA01 | Problem framing | G4 | G4 | [[problem-framing]] | [[problem-framing-craft]] | [[frame-problem]] | [[problem-frame-worked]] |
| BA02 | Requirements quality | G4 | G4 | [[requirements-quality]] | [[requirements-quality-craft]] | [[assess-requirements-quality]] | [[requirements-quality-worked]] |
| BA03 | Acceptance criteria | G4 | G4 | [[acceptance-criteria]] | [[acceptance-criteria-craft]] | [[write-acceptance-criteria]] | [[acceptance-criteria-worked]] |
| BA04 | Stakeholders | G4 | G4 | [[stakeholder-clarity]] | [[stakeholder-clarity-craft]] | [[map-stakeholders]] | [[stakeholder-clarity-worked]] |
| BA05 | Prioritisation | G4 | G4 | [[requirements-prioritisation]] | [[requirements-prioritisation-craft]] | [[prioritise-requirements]] | [[requirements-prioritisation-worked]] |
| BA06 | Traceability | G4 | G4 | [[requirements-traceability]] | [[requirements-traceability-craft]] | [[trace-requirements]] | [[requirements-traceability-worked]] |
| BA07 | Elicitation | G4 | G4 | [[elicitation-discipline]] | [[elicitation-craft]] | [[elicit-requirements]] | [[elicitation-worked]] |
| BA08 | Workshop facilitation | G4 | G4 | [[workshop-facilitation]] | [[workshop-facilitation-craft]] | [[facilitate-workshop]] | [[workshop-facilitation-worked]] |
| BA09 | Assumption dependency log | G4 | G4 | [[assumption-log]] | [[assumption-log-craft]] | [[maintain-assumption-log]] | [[assumption-log-worked]] |
| BA10 | Options to sponsors | G4 | G4 | [[options-communication]] | [[options-communication-craft]] | [[communicate-options]] | [[options-communication-worked]] |
| BA11 | Non-functional framing | G4 | G4 | [[nonfunctional-framing]] | [[nonfunctional-framing-craft]] | [[frame-nonfunctionals]] | [[nonfunctional-framing-worked]] |
| BA12 | Requirements conflict | G4 | G4 | [[requirements-conflict]] | [[requirements-conflict-craft]] | [[resolve-requirements-conflict]] | [[requirements-conflict-worked]] |
| BA13 | Readiness gate | **G3** | G4 | [[definition-of-ready]] | [[definition-of-ready-craft]] | via [[plan-change-work]] | **Gap** — praxis after first tracked change |

### PM

| # | Case | Today | Target | Home | Guidance | Workflow | Praxis |
| --- | --- | --- | --- | --- | --- | --- | --- |
| PM01 | Initiation | G4 | G4 | [[initiation-mandate]] | [[initiation-mandate-craft]] | [[initiate-project]] | [[initiation-mandate-worked]] |
| PM02 | Planning | G4 | G4 | [[plan-honesty]] | [[plan-honesty-craft]] | [[build-plan]] | [[plan-honesty-worked]] |
| PM03 | Risk cadence | G4 | G4 | [[risk-cadence]] | [[risk-cadence-craft]] | [[run-risk-cadence]] | [[risk-cadence-worked]] |
| PM04 | Status honesty | G4 | G4 | [[status-reporting-honesty]] | [[status-reporting-craft]] | [[report-status]] | [[status-reporting-worked]] |
| PM05 | Change control | G4 | G4 | [[change-control]] | [[change-control-craft]] | [[control-change]] | [[change-control-worked]] |
| PM06 | Close | G4 | G4 | [[closure-confirmation]] | [[closure-confirmation-craft]] | [[close-delivery]] | [[closure-confirmation-worked]] |
| PM07 | Issue vs risk | G4 | G4 | [[issue-risk-split]] | [[issue-risk-split-craft]] | [[split-issue-risk]] | [[issue-risk-split-worked]] |
| PM08 | Delivery dependencies | G4 | G4 | [[delivery-dependencies]] | [[delivery-dependencies-craft]] | [[manage-delivery-dependencies]] | [[delivery-dependencies-worked]] |
| PM09 | Decision log | G4 | G4 | [[decision-log]] | [[decision-log-craft]] | [[log-decision]] | [[decision-log-worked]] |
| PM10 | Delivery comms | G4 | G4 | [[delivery-comms]] | [[delivery-comms-craft]] | [[run-delivery-comms]] | [[delivery-comms-worked]] |
| PM11 | Kickoff honesty | G4 | G4 | [[kickoff-honesty]] | [[kickoff-honesty-craft]] | [[run-kickoff]] | [[kickoff-honesty-worked]] |
| PM12 | Work item hygiene | **G3** | G4 | [[work-item-hygiene]] | [[work-item-hygiene-craft]] | via [[plan-change-work]] | **Gap** — praxis after first tracked change |

### TA

| # | Case | Today | Target | Home | Guidance | Workflow | Praxis |
| --- | --- | --- | --- | --- | --- | --- | --- |
| TA01 | Conditions from requirements | G4 | G4 | [[test-conditions]] | [[test-conditions-craft]] | [[derive-test-conditions]] | [[test-conditions-worked]] |
| TA02 | Risk-based focus | G4 | G4 | [[risk-based-test-focus]] | [[risk-based-test-focus-craft]] | [[focus-by-risk]] | [[risk-based-test-focus-worked]] |
| TA03 | Intent coverage | G4 | G4 | [[intent-coverage]] | [[intent-coverage-craft]] | [[assess-intent-coverage]] | [[intent-coverage-worked]] |
| TA04 | Defect clarity | G4 | G4 | [[defect-clarity]] | [[defect-clarity-craft]] | [[report-defect]] | [[defect-clarity-worked]] |
| TA05 | UAT readiness | G4 | G4 | [[uat-readiness]] | [[uat-readiness-craft]] | [[assess-uat-readiness]] | [[uat-readiness-worked]] |
| TA06 | Boundary applied | G4 | G4 | [[boundary-applied]] | [[boundary-applied-craft]] | [[apply-boundary]] | [[boundary-applied-worked]] |
| TA07 | Coverage honesty narrative | G4 | G4 | [[coverage-honesty-narrative]] | [[coverage-honesty-narrative-craft]] | [[narrate-coverage-honesty]] | [[coverage-honesty-narrative-worked]] |
| TA08 | Defect severity | G4 | G4 | [[defect-severity]] | [[defect-severity-craft]] | [[judge-defect-severity]] | [[defect-severity-worked]] |
| TA09 | UAT intent scripts | G4 | G4 | [[uat-intent-scripts]] | [[uat-intent-scripts-craft]] | [[write-uat-intent-scripts]] | [[uat-intent-scripts-worked]] |

### Artefact (project documents)

Index: [[project-artefact-pack]]. Mandatoriness: [[change-artefact-policy]] (`change-knowledge-base-s-060`). Small-change path: [[small-change-control]]. Each AR cell = standard + craft + workflow + skeleton + worked.

| # | Case | Today | Target | Home | Guidance | Workflow | Praxis |
| --- | --- | --- | --- | --- | --- | --- | --- |
| AR01 | Terms of reference | G4 | G4 | [[terms-of-reference]] | [[terms-of-reference-craft]] | [[write-terms-of-reference]] | [[terms-of-reference-worked]] |
| AR02 | Business case | G4 | G4 | [[business-case]] | [[business-case-craft]] | [[write-business-case]] | [[business-case-worked]] |
| AR03 | Gap analysis | G4 | G4 | [[gap-analysis]] | [[gap-analysis-craft]] | [[write-gap-analysis]] | [[gap-analysis-worked]] |
| AR04 | Requirements catalogue | G4 | G4 | [[requirements-catalogue]] | [[requirements-catalogue-craft]] | [[maintain-requirements-catalogue]] | [[requirements-catalogue-worked]] |
| AR05 | Use case | G4 | G4 | [[use-case]] | [[use-case-craft]] | [[write-use-case]] | [[use-case-worked]] |
| AR06 | Process swimlane | G4 | G4 | [[process-swimlane]] | [[process-swimlane-craft]] | [[model-process-swimlane]] | [[process-swimlane-worked]] |
| AR07 | Data model | G4 | G4 | [[data-model]] | [[data-model-craft]] | [[model-data]] | [[data-model-worked]] |
| AR08 | NFR schedule | G4 | G4 | [[nfr-schedule]] | [[nfr-schedule-craft]] | [[write-nfr-schedule]] | [[nfr-schedule-worked]] |
| AR09 | Business rules catalogue | G4 | G4 | [[business-rules-catalogue]] | [[business-rules-catalogue-craft]] | [[maintain-business-rules]] | [[business-rules-catalogue-worked]] |
| AR10 | RAID pack | G4 | G4 | [[raid-pack]] | [[raid-pack-craft]] | [[maintain-raid-log]] | [[raid-pack-worked]] |
| AR11 | RACI matrix | G4 | G4 | [[raci-matrix]] | [[raci-matrix-craft]] | [[write-raci-matrix]] | [[raci-matrix-worked]] |
| AR12 | Communications plan | G4 | G4 | [[communications-plan]] | [[communications-plan-craft]] | [[write-communications-plan]] | [[communications-plan-worked]] |
| AR13 | Quality plan | G4 | G4 | [[quality-plan]] | [[quality-plan-craft]] | [[write-quality-plan]] | [[quality-plan-worked]] |
| AR14 | Test plan | G4 | G4 | [[test-plan]] | [[test-plan-craft]] | [[write-test-plan]] | [[test-plan-worked]] |
| AR15 | Test case | G4 | G4 | [[test-case]] | [[test-case-craft]] | [[write-test-case]] | [[test-case-worked]] |
| AR16 | Test procedure | G4 | G4 | [[test-procedure]] | [[test-procedure-craft]] | [[write-test-procedure]] | [[test-procedure-worked]] |
| AR17 | Test completion report | G4 | G4 | [[test-completion-report]] | [[test-completion-report-craft]] | [[write-test-completion-report]] | [[test-completion-report-worked]] |
| AR18 | UAT sign-off | G4 | G4 | [[uat-sign-off]] | [[uat-sign-off-craft]] | [[record-uat-sign-off]] | [[uat-sign-off-worked]] |
| AR19 | Post-implementation review | G4 | G4 | [[post-implementation-review]] | [[post-implementation-review-craft]] | [[write-post-implementation-review]] | [[post-implementation-review-worked]] |
| AR20 | Decision log | G4 | G4 | [[decision-log]] | [[decision-log-craft]] | [[log-decision]] | [[decision-log-worked]] |
| AR21 | Assumption log | G4 | G4 | [[assumption-log]] | [[assumption-log-craft]] | [[maintain-assumption-log]] | [[assumption-log-worked]] |

## Update rules

- Same change as doctrine/praxis that moves a cell.
- Hand-write only — no bulk cell generators as doctrine.
- Dry-runs (Axis U4) still required before promoting notes to `canonical`.

## Related

- [[roadmap]] · [[ingest-coverage]] · [[staff-agent-projection]] · [[praxis-ingestion]] · [[project-artefact-pack]] · [[change-artefact-policy]] · [[small-change-control]]
