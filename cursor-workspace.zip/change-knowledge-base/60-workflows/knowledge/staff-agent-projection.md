---
type: workflow
status: draft
id: change-knowledge-base-wf-003
concern: knowledge
domain: ["cursor"]
description: How PM/BA/TA staff agents stay bound to change-knowledge-base — retrieve protocol, lifecycle, forbidden list.
derived_from:
  - "[[navigation]]"
  - "[[knowledge-ingestion]]"
  - "[[praxis-ingestion]]"
  - "[[common-case-coverage]]"
updated: 2026-07-26
---

# Staff agent projection

Agents do **not** get a second methods bible. change-knowledge-base is the SoT for change methods. Projection is thin pointers + a **mandatory** retrieval protocol.

## Primary source protocol

| Conflict | Winner |
| --- | --- |
| Methods: framing, requirements, acceptance, planning, risk, status, test analysis | **change-knowledge-base** |
| Domain process / system facts | **systems-knowledge-base** (or user if systems-knowledge-base silent) |
| Code-level test craft / CI / engineering implementation | **Out of change-knowledge-base** — host engineering lane |

**Retrieve before act** for non-trivial change work. Skipping retrieval because the task “looks straightforward” is a protocol failure.

## Profiles

| Profile | Primary atlas | First automatable tasks |
| --- | --- | --- |
| **BA** | [[business-analysis-atlas]] | frame, stakeholders, elicit, requirements quality, prioritise, acceptance, trace — via [[ba-change-pass]]; score [[common-case-coverage]] honestly (usable bar) |
| **PM** | [[project-management-atlas]] | initiation, plan, risk cadence, status honesty, change control, close — via [[pm-delivery-pass]] |
| **TA** | [[test-analysis-atlas]] | conditions from requirements/risks, risk focus, intent coverage, defect clarity, UAT readiness — via [[ta-analysis-pass]] |

Profiles are **projection + invoke skills**, not three separate bibles. Cell sets are at usable **G4** on [[common-case-coverage]] (craft + worked exemplars); notes stay `draft` until dry-runs / canonical promotion ([[roadmap]]). Deepen via collision — not proliferation.

## Always-on

`.cursor/rules/change-knowledge-base-authority.mdc` stays skinny — retrieve, prefer canonical, lab after canon, research pressures notes, domain→systems-knowledge-base/user, coverage honesty, hand-write doctrine, TA analysis-only.

## Retrieval protocol

| Need | Open |
| --- | --- |
| Bind a host repo? | [[consumer-init]] · this note |
| BA body of knowledge? | [[business-analysis-atlas]] |
| PM body? | [[project-management-atlas]] |
| TA body? | [[test-analysis-atlas]] |
| Norm (“normally require”)? | Standard under `30-standards/` |
| Sequence to produce artefact? | [[produce-change-artefact]] → named cell/journey under `60-workflows/` |
| Plan / verify / review action? | [[plan-change-work]] · [[verify-change-artefact]] · [[review-change-artefact]] |
| Enduring constraint? | Principle under `20-principles/` |
| How covered? | [[common-case-coverage]] · [[ingest-coverage]] |
| Show me the shape? | [[lab-atlas]] **after** the canon |
| Which project document? | [[change-artefact-policy]] (mandatory?) → [[project-artefact-pack]] → standard → craft → workflow → skeleton |
| BAU / micro / enhancement path? | [[small-change-control]] · class column on [[change-artefact-policy]] · [[plan-change-work]] |
| Good work item / claim grain? | [[work-item-hygiene]] · [[work-item-hygiene-craft]] |

## Lifecycle

For non-trivial change work, follow these workflows (Cursor skills `change-knowledge-base-plan` / `change-knowledge-base-produce` / `change-knowledge-base-verify` / `change-knowledge-base-review` are thin pointers):

1. [[plan-change-work]] (`change-knowledge-base-wf-031`) — change-task acceptance, class, M/R account, process path (cells vs journey)
2. [[produce-change-artefact]] (`change-knowledge-base-wf-032`) — execute a **named** cell or journey workflow
3. [[verify-change-artefact]] (`change-knowledge-base-wf-033`) — standard field tests; escalate Gaps
4. [[review-change-artefact]] (`change-knowledge-base-wf-034`) — honesty of status and evidence; no green-wash

Cell and journey workflows remain the authoritative produce sequences ([[ba-change-pass]] · [[pm-delivery-pass]] · [[ta-analysis-pass]] and BA/PM/TA cells). **Mandatory vs optional documents:** [[change-artefact-policy]]. **Small-change process path:** [[small-change-control]]. Shapes once selected: [[project-artefact-pack]].

## Skills vs rules vs change-knowledge-base

| Layer | Holds | Must not |
| --- | --- | --- |
| change-knowledge-base living notes | Doctrine | Be restated into fat skills |
| Always-on rule | Thin protocol + pointers | Paste full workflows |
| Optional Cursor skills | Invoked procedures | Become a parallel methods bible |

## Functional staff agent (definition of done)

1. Retrieves change-knowledge-base before acting
2. Produces artefacts that meet named standards (cite `id`s) in the **consumer/product** workspace — not as dumps inside this vault
3. Refuses / escalates when inputs or doctrine are missing
4. Separates lanes: systems-knowledge-base/user for domain truth
5. Does not implement engineering solutions as a coding substitute
6. Improves via bible — amend change-knowledge-base, not fat prompt forks

**≈** profile track at majority G4 on the agreed cell set — not “we have a prompt.”

## Forbidden

- Skipping retrieve
- Syllabus dump into vault or chat as law
- Inventing process/domain facts
- Persona-only agents without standards
- Implementing code/tests as TA/PM/BA substitute (out of change-knowledge-base — host engineering lane)
- Declaring profile “done” without [[common-case-coverage]] honesty
- Soft status / evidence theatre

## Related

- [[consumer-init]] · [[plan-change-work]] · [[produce-change-artefact]] · [[verify-change-artefact]] · [[review-change-artefact]] · [[change-artefact-policy]] · [[small-change-control]] · [[project-artefact-pack]] · [[navigation]] · [[methodology]] · [[changing-this-bible]] · [[knowledge-ingestion]] · [[common-case-coverage]]
