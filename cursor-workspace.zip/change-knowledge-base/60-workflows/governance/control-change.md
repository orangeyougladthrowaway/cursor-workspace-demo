---
type: workflow
status: draft
id: change-knowledge-base-wf-022
concern: governance
description: Sequence to control a change against change-knowledge-base-s-012 — delta, impact, options, decision.
derived_from:
  - "[[change-control]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Control change

Agent-operable sequence for PM05.

## Steps

1. **Retrieve** — [[project-management-atlas]] → [[change-control]] (`change-knowledge-base-s-012`) → skeleton `lab/skeletons/change-request/`.
2. **State the delta** — vs the agreed baseline.
3. **Assess impact** — scope, plan, cost, risk. Unknown domain impact → escalate.
4. **Options** — including do-nothing.
5. **Decide** — approve/reject/defer with a named approver.
6. **Trace** — link affected requirements/plan items ([[requirements-traceability]]).
7. **Cite** — `change-knowledge-base-s-012`.

## Forbidden

- Silent scope absorption
- Approval with no named approver
- Inventing impact where domain facts are missing
