---
type: workflow
status: draft
id: change-knowledge-base-wf-062
concern: governance
description: Sequence to produce business case artefact.
derived_from:
  - "[[business-case]]"
  - "[[business-case-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write business case

Agent-operable sequence for [[business-case]].

## Steps

1. **Retrieve** — theme atlas → [[business-case]] → [[business-case-craft]] → [[business-case-worked]] → skeleton `lab/skeletons/business-case/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[business-case]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
