---
type: workflow
status: draft
id: change-knowledge-base-wf-015
concern: requirements
description: Sequence to build or check requirements↔acceptance trace against change-knowledge-base-s-006.
derived_from:
  - "[[requirements-traceability]]"
  - "[[requirements-quality]]"
  - "[[acceptance-criteria]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Trace requirements

Agent-operable sequence for BA06.

## Steps

1. **Retrieve** — [[business-analysis-atlas]] → [[requirements-traceability]] (`change-knowledge-base-s-006`) → skeleton `lab/skeletons/requirements-traceability/`.
2. **Preconditions** — requirements pack + acceptance set (or mark gaps). Frame link present.
3. **Build matrix** — forward and backward links; orphan = `gap — escalate` or fix.
4. **Delta** — if links break after a change, record per [[control-the-delta]].
5. **Verify** — field tests in [[requirements-traceability]]; honesty of “fully traced.”
6. **Cite** — `change-knowledge-base-s-006`. Code-level coverage matrices are out of change-knowledge-base scope.

## Forbidden

- Claiming full trace with missing or untestable criteria
- Inventing domain acceptance to close gaps
