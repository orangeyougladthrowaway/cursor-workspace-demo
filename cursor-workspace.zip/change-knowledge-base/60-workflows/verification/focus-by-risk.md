---
type: workflow
status: draft
id: change-knowledge-base-wf-026
concern: verification
description: Sequence to focus testing by risk against change-knowledge-base-s-015.
derived_from:
  - "[[risk-based-test-focus]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Focus by risk

Agent-operable sequence for TA02.

## Steps

1. **Retrieve** — [[test-analysis-atlas]] → [[risk-based-test-focus]] (`change-knowledge-base-s-015`) → skeleton `lab/skeletons/risk-focus/`.
2. **Rate areas** — likelihood × impact on the outcome. Unknown domain likelihoods → escalate.
3. **Map depth** — higher risk → deeper/earlier; lower risk → lighter (stated).
4. **State tradeoffs** — what is tested lightly or not at all.
5. **Trace** — focus links to conditions ([[test-conditions]]) and product risks.
6. **Cite** — `change-knowledge-base-s-015`. No "exhaustive" claims.

## Forbidden

- Uniform effort with no risk basis
- Claiming full/exhaustive testing
- Inventing domain risk ratings
