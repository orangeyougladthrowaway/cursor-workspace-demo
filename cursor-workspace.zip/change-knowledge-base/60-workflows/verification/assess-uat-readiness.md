---
type: workflow
status: draft
id: change-knowledge-base-wf-029
concern: verification
description: Sequence to assess UAT readiness against change-knowledge-base-s-018 with honest residual risk.
derived_from:
  - "[[uat-readiness]]"
  - "[[intent-coverage]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Assess uat readiness

Agent-operable sequence for TA05.

## Steps

1. **Retrieve** — [[test-analysis-atlas]] → [[uat-readiness]] (`change-knowledge-base-s-018`) → skeleton `lab/skeletons/uat-readiness/`.
2. **Confirm coverage** — intents in UAT scope covered ([[assess-intent-coverage]]).
3. **Set entry/exit** — observable criteria; environment/data/access facts from user/SoR (escalate if unknown).
4. **State residual risk** — open defects/gaps with severity ([[defect-clarity]]).
5. **Name roles** — who tests, who signs off.
6. **Verdict** — ready / not-ready with evidence; no green-wash.
7. **Cite** — `change-knowledge-base-s-018`.

## Forbidden

- "Ready" while material intents uncovered or defects hidden
- Non-observable exit criteria
- Assuming environment/data facts instead of escalating
