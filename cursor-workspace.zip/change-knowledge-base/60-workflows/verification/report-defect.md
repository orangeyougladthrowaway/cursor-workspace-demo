---
type: workflow
status: draft
id: change-knowledge-base-wf-028
concern: verification
description: Sequence to report a defect against change-knowledge-base-s-017 with evidence and trace.
derived_from:
  - "[[defect-clarity]]"
  - "[[defect-report-shape]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Report defect

Agent-operable sequence for TA04.

## Steps

1. **Retrieve** — [[test-analysis-atlas]] → [[defect-clarity]] (`change-knowledge-base-s-017`) → [[defect-report-shape]] → skeleton `lab/skeletons/defect-report/`.
2. **Capture** — summary, expected vs actual, reproduction, evidence.
3. **Assess impact** — severity reasoned from impact + risk.
4. **Trace** — link the condition/intent violated.
5. **Escalate** — if expected behaviour is ambiguous (requirement unclear) → BA/acceptance.
6. **Cite** — `change-knowledge-base-s-017`.

## Forbidden

- "It's broken" with no expected/actual or reproduction
- Severity with no impact reasoning
- Inventing the expected behaviour
