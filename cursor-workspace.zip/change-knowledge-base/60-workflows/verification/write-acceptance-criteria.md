---
type: workflow
status: draft
id: change-knowledge-base-wf-012
concern: verification
description: Sequence to write acceptance criteria against change-knowledge-base-s-003 without leaving the methods lane.
derived_from:
  - "[[acceptance-criteria]]"
  - "[[requirements-quality]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Write acceptance criteria

Agent-operable sequence for BA03.

## Steps

1. **Retrieve** — [[business-analysis-atlas]] → [[acceptance-criteria]] (`change-knowledge-base-s-003`) → [[acceptance-criteria-craft]] → skeleton `lab/skeletons/acceptance-criteria/` → quality bar [[acceptance-criteria-worked]].
2. **Preconditions** — in-scope requirements with stable ids from a pack meeting [[requirements-quality]] (or escalate).
3. **Draft criteria** — follow [[acceptance-criteria-craft]]; observable pass/fail per requirement/scenario; tie to requirement ids.
4. **Domain check** — if a criterion needs a process fact not in inputs → escalate; do not invent.
5. **Verify** — field tests in [[acceptance-criteria]]; honesty of “done.”
6. **Cite** — `change-knowledge-base-s-003`. Do not design pytest/automation craft here.

## Forbidden

- Vague adjective-only criteria
- Implementing tests in code as a substitute for this analysis
- Inventing domain acceptance rules
