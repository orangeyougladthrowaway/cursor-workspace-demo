---
type: workflow
status: draft
id: change-knowledge-base-wf-030
concern: verification
description: End-to-end TA analysis pass — sequence TA cells from intent to UAT readiness.
derived_from:
  - "[[test-conditions]]"
  - "[[risk-based-test-focus]]"
  - "[[intent-coverage]]"
  - "[[defect-clarity]]"
  - "[[uat-readiness]]"
  - "[[project-artefact-pack]]"
  - "[[change-artefact-policy]]"
  - "[[small-change-control]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-20
---

# Ta analysis pass

One supervised pass across the TA cell set. **Not** a curriculum — a dependency order. TA owns **intent/coverage analysis**; code-level test craft is out of change-knowledge-base scope.

## Sequence

1. **Derive conditions** — [[derive-test-conditions]] (`change-knowledge-base-s-014`) from requirements/acceptance/risks. Stop if intent missing/untestable → BA.
2. **Focus by risk** — [[focus-by-risk]] (`change-knowledge-base-s-015`).
3. **Plan / design (policy-selected)** — [[write-test-plan]] / [[write-test-case]] / [[write-test-procedure]] only when the plan’s [[change-artefact-policy]] account marks Produce.
4. **Assess coverage** — [[assess-intent-coverage]] (`change-knowledge-base-s-016`); name gaps.
5. **Report defects** — [[report-defect]] (`change-knowledge-base-s-017`) as found.
6. **UAT readiness** — [[assess-uat-readiness]] (`change-knowledge-base-s-018`) with honest residual risk; scripts / [[record-uat-sign-off]] when selected or mandatory for class.
7. **Complete** — [[write-test-completion-report]] when selected or required at close.
8. **Verify pass** — each artefact cites its `id`; M-set accounted; escalations listed; no green-wash.

## Branching

- **Class path** ([[change-artefact-policy]] §7 · [[small-change-control]]): **micro-fix** — prefer cells (defect clarity **M**; conditions/coverage **R**); full TA journey not default. **Enhancement** — conditions + coverage as **M**; thinned plan OK with named skips. **Project / regulatory** — this sequence is the default.
- Defect reporting recurs whenever a condition fails.
- Any step may **escalate** (ambiguous intent, unknown domain/env facts) and pause.
- Do not implement executable tests here.

## Skeleton

`lab/skeletons/ta-analysis-pass/` — checklist citing this workflow.

## Forbidden

- Conditions/coverage with no upstream intent
- Test counts as coverage proof
- Implementing/automating tests as a substitute (out of change-knowledge-base scope)
