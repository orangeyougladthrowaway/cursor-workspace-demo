---
type: workflow
status: draft
id: change-knowledge-base-wf-031
concern: planning
description: Plan change work — class via change-artefact-policy, pack selection, profile/journey, handoffs.
domain: ["cursor"]
derived_from:
  - "[[staff-agent-projection]]"
  - "[[plan-honesty]]"
  - "[[change-artefact-policy]]"
  - "[[change-artefact-policy-craft]]"
  - "[[small-change-control]]"
  - "[[project-artefact-pack]]"
  - "[[precision-over-vagueness]]"
  - "[[ba-change-pass]]"
  - "[[pm-delivery-pass]]"
  - "[[ta-analysis-pass]]"
updated: 2026-07-20
---

# Plan change work

Use before producing PM/BA/TA artefacts. Read-only unless the user asks to write a plan artefact via a cell workflow. Same planning bar for **micro-fix / enhancement / project** — thinner M-set on small classes, not thinner honesty.

## Preconditions

- Stated change brief or outcome
- No unresolved authority conflict (methods vs domain vs engineering)

If the change task’s acceptance cannot be established, stop and ask.

## Retrieve

1. [[README]] → [[navigation]] → [[staff-agent-projection]].
2. Open [[change-artefact-policy]] (`change-knowledge-base-s-060`), [[change-artefact-policy-craft]], and [[small-change-control]] when class may be micro-fix or enhancement (incl. colloquial BAU).
3. Open the relevant theme atlas ([[business-analysis-atlas]] · [[project-management-atlas]] · [[test-analysis-atlas]]).
4. Open [[project-artefact-pack]] for shapes of items marked Produce.
5. Decide profile(s) and **process path**: **named cells** (default micro-fix), **thinned journey** (typical enhancement), or **full journey** (project/regulatory default) per policy §7 / [[small-change-control]].
6. Domain facts → systems-knowledge-base or user; do not invent.
7. Engineering implementation → out of change-knowledge-base (host engineering lane).

## Steps

1. Restate outcome and observable acceptance for **this change task**.
2. Name in / out / later scope ([[scope-principle]]).
3. **Classify** engagement (micro-fix / enhancement / project / programme / regulatory) per [[change-artefact-policy]]. Map BAU → micro-fix or enhancement — ask if unclear.
4. Build the **M/R set** for that class; for each **M**: Produce | Substitute→artefact | Exempt (decision id — propose only until sponsor/PM confirms).
5. Apply **data/integration override** when material data moves: [[data-model]] **M** + field-map precision on catalogue/AC ([[precision-over-vagueness]]) — including micro-fix that touches stores.
6. For **R**: default include or explicit “not needed because…” on the plan.
7. Choose BA / PM / TA profile and **process path** (cells vs thinned/full journey); name which journey steps run or skip when thinned.
8. Map Produce items to named workflows via [[project-artefact-pack]] (prefer **deltas** on living product artefacts for small change).
9. List inputs and Escalations (domain Gaps, missing mandate, untestable intent, **imprecise in-scope grain**, unconfirmed exemptions).
10. Sequence handoffs (e.g. AC cell → defect clarity → eng; or BA frame → PM plan → TA conditions).
11. Cite binding ids — especially `change-knowledge-base-s-060`, `change-knowledge-base-g-062`, and `change-knowledge-base-p-014`.

## Output

- Change-task acceptance
- Scope bounds
- **Engagement class**
- **M/R account** (produce / substitute / exempt / skip)
- **Process path** (cells | thinned journey | full journey + named skips)
- Data/integration override flagged if applicable
- Profile + first cell or journey workflow stems
- Ordered next produces (workflow stems)
- Input checklist and open Gaps
- Cited `id`s

## Handoff

Pass the accepted plan to [[produce-change-artefact]] (name the cell or journey workflow).

## Forbidden

- Persona-only planning with no standards
- Selecting the pack without classifying ([[change-artefact-policy]])
- “BAU — no docs” without class + M-account + process path
- Skipping **M** without logged/proposed exemption
- Auto-running full BA/PM/TA journeys for micro-fix
- Inventing domain facts to keep the plan green
- Marking catalogue/AC/data Ready when in-scope grain is vague ([[precision-over-vagueness]])
- Jumping to engineering implementation as a methods substitute
