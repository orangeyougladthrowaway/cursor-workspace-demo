---
type: foundation
status: draft
id: change-knowledge-base-fnd-changing-this-bible
description: How to change this bible — current-state doctrine, not an audit trail.
updated: 2026-07-16
---

# Changing this bible

This vault is a **current-state** methods bible. Edit the living notes. Do not maintain a decision log, evidence warehouse, or proposal archive here.

## When changing knowledge

1. Start from [[README]] / [[navigation]] / [[scope]] / [[knowledge-model]] as needed.
2. Place content at the right **altitude** and **responsibility folder**.
3. **Category before leaf** for principles; **one primary concern folder** for standards/patterns/guidance/workflows/maps.
4. Prefer amending an existing note over adding a parallel one.
5. Put rationale **in the note** (short).
6. Use `status: draft` while sketching; promote to `canonical` only with human/user command and no open contradiction.
7. New responsibility enum values require amending [[navigation]] first.
8. New or widened theme knowledge → amend atlas under `maps/themes/` and [[catalog-maps]].
9. Create / rename / delete notes → update the layer `catalog-*.md` in the same change.
10. Naming and linking follow [[methodology]].
11. New or changed **praxis** → follow [[praxis-ingestion]]; update [[lab-atlas]] / [[catalog-lab]].

## Retirement (rename, don’t shim)

1. **Rename** the file (stem = correct concept).
2. Update **every** wikilink and catalog row.
3. Align `# Title` to the new stem.
4. Do **not** add the old basename to `aliases:`.
5. `status: deprecated` is **migration-only** — then **delete**.

## Cleanliness accept

- [ ] No broken wikilinks (basename-only targets resolve)
- [ ] `concern` equals parent folder (maps: theme/family leaf)
- [ ] Stem ≈ H1
- [ ] No empty responsibility folders
- [ ] No `status: deprecated` residue
- [ ] Layer catalogs and theme atlases list current stems
- [ ] Lab entries cite doctrine; indexes updated
- [ ] Doctrine suite + `pytest tests/lab -v` green when lab changed
- [ ] Axis F: [[common-case-coverage]] scores honest; no “seeded = done”

## Conflicts

- If new guidance fights a canonical note, update the canonical note in the same change.
- If a lab exemplar fights a canonical note, **fix or delete the exemplar**.
- User direction overrides after a brief challenge — then update the note.

## Out of band

Git history is enough for last month’s wording. This vault does not mirror that story.
