---
type: foundation
status: draft
id: change-knowledge-base-fnd-scope
description: change-knowledge-base scope — PM/BA/TA methods in/out, quarantine, domain and engineering walls.
updated: 2026-07-17
---

# Scope

change-knowledge-base is a **current-state** **change-methods bible**. The landscape below sets direction of travel. It is **not** automatic elevation to principles or standards. Promote only by editing living notes ([[changing-this-bible]], [[knowledge-ingestion]]).

Coverage instrument: [[common-case-coverage]]. Ambition: [[purpose]].

## In scope (active)

| Area | Why |
| --- | --- |
| Problem framing and scope honesty | Repeated BA/PM failure mode |
| Stakeholder clarity (RACI-as-clarity, not org lore) | Portable engagement method |
| Requirements quality and traceability | Core BA common cases |
| Acceptance criteria and intent coverage | BA ↔ TA handoff |
| Planning, risk cadence, status honesty, change control | Core PM common cases |
| Test conditions from requirements/risks; UAT readiness | Core TA common cases (analysis grain) |
| Governance of decisions and approvals | Shared across profiles |
| Vault / staff-agent projection | How agents stay bound to this bible |
| Public method research | Books/templates pressure living notes — claim cards, not curricula |
| **Common-case matrices** | Majority coverage for PM/BA/TA tracks — G1–G4 |
| **Praxis plane (`lab/`)** | Skeletons / zoo densified to the bar — subordinate to doctrine |
| **Project artefact pack** | Tier-1 documents (ToR, catalogue, models, RAID/RACI, testware…) — [[project-artefact-pack]] |
| **Change artefact policy** | Engagement class → mandatory / recommended / optional — [[change-artefact-policy]] |
| **Small change control** | Micro-fix / enhancement (BAU) process path — same control loop, thinner pack — [[small-change-control]] |

## Out of scope

- Domain systems/process facts — **systems-knowledge-base** (or ask the user). Do not invent or copy lore here
- Code-level test craft, pytest, CI gate implementation — out of change-knowledge-base (host engineering lane)
- Full syllabus trees (BABOK/PMBOK/ISTQB chapter dumps) as vault structure
- Vendor tool encyclopaedias as philosophy (`jira/` as L1 folder — forbidden; use `domain:` facets)
- Org politics, personnel evaluations, or confidential project dumps as doctrine
- Soft status / evidence theatre (“looks green”)
- Declaring a profile “functional” because a skill or persona prompt exists — score [[common-case-coverage]]
- Using `lab/` as sole law when a canonical note exists (or should)

## Tool watchlist (guidance only — never L1 folders)

| Class | Examples |
| --- | --- |
| Work tracking | Jira, Azure DevOps |
| Docs | Confluence, SharePoint (as host, not philosophy) |
| Modelling | BPMN tools, lightweight diagram hosts — method first |

## Changing scope

Edit this note when the house methods landscape truly changes. Don’t sprawl by interest or by pasting another curriculum into the vault.
