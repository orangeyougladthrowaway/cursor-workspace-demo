---
type: foundation
status: draft
id: change-knowledge-base-fnd-methodology
description: Note structure, frontmatter, linking, naming-as-navigation for change-knowledge-base.
updated: 2026-07-16
---

# Methodology

Portable Markdown. Meaning must survive as plain files in Git. Full navigation law: [[navigation]]. Change protocol: [[changing-this-bible]].

## Note shape

```markdown
---
type: …
status: draft | canonical | deprecated
id: change-knowledge-base-…
concern: …                 # matches folder (maps: theme/family leaf)
description: "≤160 chars"
domain: []
aliases: []
derived_from: []
updated: YYYY-MM-DD
---

# Title matching the basename
```

One question per note. Split if it answers two.

## Frontmatter

| Field | Use |
| --- | --- |
| `type` | Required — see [[knowledge-model]] |
| `status` | `draft` \| `canonical` \| `deprecated` (migration only) |
| `description` | Scan-without-open summary |
| `updated` | ISO date |
| `id` | **Required** on doctrine notes — prefix `change-knowledge-base-` |
| `concern` | **Required** on standard/pattern/guidance/workflow/**map** |
| `category` | **Required on principles** |
| `derived_from` | Upward links |
| `domain` | Tool / ecosystem tags (`jira`, `ado`, …) — never a folder |
| `aliases` | Informal **search** tokens only — never a rename substitute |

### `aliases` forbid list

Do **not** put in `aliases:`: old basename after rename; spelling twin of the stem; acronym that hides a mismatched stem.

Retire by **rename + link update** ([[changing-this-bible]]), not by alias shim.

## Writing order

1. Philosophy still holds?
2. Right responsibility folder / category spine? ([[navigation]])
3. Then leaf / standard / pattern / guidance / workflow.
4. New theme body? Add/update atlas under `maps/themes/` and [[catalog-maps]].
5. Agents: open atlas or category before bulk-reading leaves.

## Linking

- Wikilinks use **basename only** — e.g. `[[navigation]]`, never a path-style target.
- Wikilink targets must be **vault notes** (`.md` stems). Cite Cursor rules/skills as backtick paths.
- Prefer `id` in prose when rename-resilience matters.
- Prefer **rename** over aliasing retired titles.
- Do not invent placeholder wikilinks.
- After edits: every new wikilink must resolve (cleanliness gate in [[changing-this-bible]]).

## Naming

| Piece | Rule |
| --- | --- |
| Path | `NN-altitude/{responsibility}/{slug}.md` |
| Responsibility folders | **One idea** — **no `and`** |
| Basename | Globally unique kebab |
| Stem ↔ H1 | H1 is the prose form of the basename |
| Spelling | One canon (**artefact**) |
| Catalogs | `catalog-*.md` only — never `_index.md` |
| Maps | `maps/themes/{theme}/*-atlas.md` (+ `maps/catalog-maps.md`) |
| Lab zoo | `lab/zoo/{facet}/{slug}.md` — `type: example`; must cite doctrine |

## AI retrieval

1. Prefer `status: canonical`
2. Theme → atlas; law → altitude × responsibility; tool → `domain`
3. Exemplars → [[lab-atlas]] after the canon
4. Walk `derived_from` upward
5. Do not invent folders or standards absent from the vault
6. Domain facts → systems-knowledge-base/user; code-level engineering/test craft is out of scope
