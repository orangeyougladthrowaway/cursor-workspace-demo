# Agent notes — <host-name>

## Methods authority

Canonical change-methods knowledge lives in the **Change Knowledge Base (change-knowledge-base)**.

| Source | Path (edit one) | Owns |
| --- | --- | --- |
| **change-knowledge-base** | `.change-knowledge-base` (gitignored junction) **or** `../change-knowledge-base` | PM/BA/TA methods — **primary** |
| **systems-knowledge-base** (optional) | `.systems-knowledge-base` **or** sibling systems vault | Domain systems/process facts — read-only |

- Do **not** invent parallel methods doctrine here.
- Do **not** edit/commit change-knowledge-base or systems-knowledge-base from this workspace.
- Never invent domain facts — retrieve systems-knowledge-base or ask the user.
- Code-level test craft and engineering implementation are out of change-knowledge-base scope.

## Operating law (always)

1. **Retrieve before act** — navigation → theme atlas → canonical notes → workflow → artefact.
2. **Lab last** — `lab/maps/lab-atlas.md` only after canons; never sole law.
3. **Cite ids** for load-bearing method choices.
4. **Escalate** when doctrine or domain inputs are missing.
5. **No `consumer-init/` folder** left in this tree after setup.

## Start here (paths relative to change-knowledge-base root)

- Profile atlas (BA): `maps/themes/business-analysis/business-analysis-atlas.md`
- Navigation: `00-foundation/navigation.md`
- Agent protocol: `60-workflows/knowledge/staff-agent-projection.md`
- Coverage: `60-workflows/knowledge/common-case-coverage.md`

## Load-bearing ids (BA track)

- `change-knowledge-base-s-001` — problem framing
- `change-knowledge-base-s-002` — requirements quality
- `change-knowledge-base-s-003` — acceptance criteria
- `change-knowledge-base-s-004` — stakeholder clarity
- `change-knowledge-base-s-005` — requirements prioritisation
- `change-knowledge-base-s-006` — requirements traceability
- `change-knowledge-base-s-007` — elicitation discipline
- `change-knowledge-base-wf-010` — frame problem
- `change-knowledge-base-wf-011` — assess requirements quality
- `change-knowledge-base-wf-012` — write acceptance criteria
- `change-knowledge-base-wf-013` — map stakeholders
- `change-knowledge-base-wf-014` — prioritise requirements
- `change-knowledge-base-wf-015` — trace requirements
- `change-knowledge-base-wf-016` — elicit requirements
- `change-knowledge-base-wf-017` — ba change pass

## This host’s profile

`business-analysis`

## Quarantine (do not elevate)

Syllabus dumps · persona-only agents · invented domain lore · code-level test craft as TA substitute · soft status theatre · leftover `consumer-init/` folders · fat skills reprinting standards

## Optional skills

`.cursor/skills/` = invoke-only. Point at change-knowledge-base `id`s. Never paste change-knowledge-base note bodies.

Preferred action skills (when present in the change-knowledge-base mount): `change-knowledge-base-plan` · `change-knowledge-base-produce` · `change-knowledge-base-verify` · `change-knowledge-base-review`.
