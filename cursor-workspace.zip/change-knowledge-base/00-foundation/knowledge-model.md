---
type: foundation
status: draft
id: change-knowledge-base-fnd-knowledge-model
description: Taxonomy of knowledge types for change-knowledge-base — includes catalog and map.
updated: 2026-07-16
---

# Knowledge model

Types are kinds of knowledge, not folder bureaucracy.

## Type overview

| Type | Stability | Primary question |
| --- | --- | --- |
| `philosophy` | Very high | What do we believe change work is for? |
| `category` | Very high | What stable theme organises related principles? |
| `principle` | High | What enduring constraint guides decisions in a theme? |
| `standard` | High | What must we normally do / require of artefacts? |
| `pattern` | Medium–high | What recurring method shape do we use? |
| `guidance` | Medium–low | How does a tool/context apply higher knowledge? |
| `workflow` | Medium–low | What sequence does a staff agent follow? |
| `map` | Medium | What body of knowledge should I open first? |
| `catalog` | N/A | Inventory / lens for taxonomic browse |
| `template` | Medium | Starter shape for **writing a vault note** (`00-foundation/templates/` only) |
| `example` | Low | What clarifies a higher concept without becoming law? (`lab/zoo/`) |
| `glossary` | High | What does this term mean here? |
| `foundation` | Highest | How does this bible itself work? |

## Layering

```text
philosophy → category → principle → standard → pattern
                          ↓
                    guidance / workflow / example
                          ↑
              maps (theme / family atlases cite any altitude)
```

## Writing rules

- **Category before leaf** for principles.
- Tool detail belongs in `guidance`, never in philosophy.
- Every standard/pattern/guidance/workflow/**map** declares **`concern`** matching its folder.
- Prefer stable **`id`** with `change-knowledge-base-` prefix.
- **Praxis:** zoo uses `type: example` and must cite doctrine. Copy-out **skeletons** live under `lab/skeletons/` — not `type: template` note stubs. Densify toward [[common-case-coverage]]; seeded ≠ majority done.

## Status

| Status | Meaning |
| --- | --- |
| `draft` | Unfinished — do not treat as doctrine |
| `canonical` | Living doctrine |
| `deprecated` | Brief migration only — then delete |

## Related

- [[navigation]] · [[dependency-rules]] · [[methodology]] · [[changing-this-bible]] · [[common-case-coverage]] · [[praxis-ingestion]]
