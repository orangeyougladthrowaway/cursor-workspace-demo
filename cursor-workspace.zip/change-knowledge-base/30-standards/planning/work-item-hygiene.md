---
type: standard
status: draft
id: change-knowledge-base-s-061
concern: planning
description: Tracked work items carry the right grain, required content, owner, parent link, and an honest state.
derived_from:
  - "[[bound-the-change]]"
  - "[[precision-over-vagueness]]"
  - "[[artefact-has-owner]]"
  - "[[link-across-artefacts]]"
  - "[[status-matches-evidence]]"
  - "[[outcome-over-output]]"
updated: 2026-07-26
---

# Work item hygiene

Applies when delivery is tracked in a backlog/board of typed items rather than a document plan alone. Tracker-agnostic: this standard fixes **grain and content**, not vendor field names.

**This note is the house single home** for what a good work item looks like and what belongs at each level. Tooling how-to (ADO fields, MCP) lives elsewhere; it must express this standard, not replace it.

## Grain ladder — what belongs where

| Level | Answers | Belongs here | Does **not** belong here |
| --- | --- | --- | --- |
| **Initiative / Epic** | Programme-level outcome spanning releases | Outcome + success measure; sponsor | A folder for unrelated Stories; build tickets |
| **Feature** | One coherent capability a stakeholder can name | In/out of scope; may span iterations | A single-demo slice (that is a Story) |
| **Story** | One iteration-sized slice with independent value | Acceptance criteria; DoR; demoable alone | Multi-theme capability; pure tech layer split |
| **Task** | One unit of execution inside a story | How/who for a slice of the Story | Independent stakeholder value |
| **Bug** | Observed defect against agreed behaviour | Repro + expected vs actual + severity | A change request or new wish |

## Normally require

| Level | Item must carry |
| --- | --- |
| **All** | Outcome-shaped title (not "work on X"), single owner, parent link (except the top level), state that matches evidence, and a link to the artefact/requirement it serves ([[requirements-traceability]]) |
| Initiative / Epic | Outcome + how success is measured; sponsor ([[work-needs-mandate]]) |
| Feature | Capability description; in / out of scope ([[bound-the-change]]); parent initiative unless BAU ([[small-change-control]]) |
| Story | Acceptance criteria ([[acceptance-criteria]]); size as a range or band ([[estimate-range-method]]); known dependencies ([[delivery-dependencies]]) and assumptions ([[assumption-log]]); readiness gate met ([[definition-of-ready]]) |
| Task | What will be done and by whom; estimate; parent story |
| Bug | Reproduction steps, expected vs actual, severity ([[defect-severity]]), evidence ([[claim-needs-warrant]]) |

Done evidence is **not** this vault's authority — the host engineering lane owns the completion gate. This standard only requires that a Closed state be backed by that evidence.

## Ownership and claim (parallel delivery)

| Rule | Meaning |
| --- | --- |
| One owner | Shared ownership is no ownership ([[artefact-has-owner]]) |
| Claim grain | When starting delivery: own the **Story + its child Tasks + in-scope Bugs** as one set |
| Multi-item WIP | Allowed — people may own many Active Stories; organisation is hierarchy + ids, not a one-Story cap |
| Do not touch | Items owned by someone else — wait or ask; do not silently take over |
| Blocked | Ownership **retained**; work may reopen when the blocker clears |
| Cancelled / abandoned | Ownership **released**; item returns to unowned backlog or is removed if junk |
| Ready ≠ claimed | [[definition-of-ready]] is understanding; claim is start of delivery |

How-to (tracker mapping, agent steps): [[work-item-hygiene-craft]].

## Framework posture

INVEST as a story-grain test, the "As a … I want … so that …" story shape, and Given/When/Then acceptance are portable and in scope. Vendor process templates, field schemas, board column mechanics, and tracker automation are **out of scope** — they belong with the tooling lane, which should be configured to express this standard rather than replace it.

## How to produce

[[work-item-hygiene-craft]]. Praxis exemplar is a **Gap** until the first tracked change runs end to end.

## Refuse / escalate

- A "story" that is really a feature (multi-iteration, several acceptance themes)
- An initiative used as a folder for unrelated work
- A task with no parent, or an item with no owner
- Acceptance criteria recorded as "TBC" on an item entering delivery ([[precision-over-vagueness]])
- A bug that is actually a change request → route to [[change-control]]
- A state left Active with no movement or evidence ([[status-matches-evidence]])
- Splitting by technical layer ("the backend half of the story") instead of by value
- Implementing an item owned by someone else without an explicit handoff

## Not this standard

Readiness gate ([[definition-of-ready]]); acceptance content ([[acceptance-criteria]]); plan structure ([[plan-honesty]], [[work-breakdown-structure]]); reporting ([[status-reporting-honesty]]); which artefacts are mandatory ([[change-artefact-policy]]); prioritisation order ([[requirements-prioritisation]]); engineering Done evidence (host eng lane); ADO field mechanics (systems tooling notes).
