---
type: standard
status: draft
id: change-knowledge-base-s-001
concern: analysis
description: Problem frames must name the problem, outcome, scope bounds, risks, and unknowns — no invented domain lore.
derived_from:
  - "[[name-the-problem]]"
  - "[[outcome-over-output]]"
  - "[[bound-the-change]]"
  - "[[risk-shapes-attention]]"
  - "[[enough-to-decide]]"
  - "[[claim-needs-warrant]]"
updated: 2026-07-16
---

# Problem framing

## Normally require

A **problem frame** for a change includes:

| Field | Test |
| --- | --- |
| Problem | Named so two readers agree what is wrong or missing ([[name-the-problem]]) |
| Outcome | Who is better off and how if solved ([[outcome-over-output]]) |
| In / out / later | Explicit bounds ([[bound-the-change]]) |
| Material risks | Uncertainties that could invalidate the outcome ([[risk-shapes-attention]]) |
| Warrants | Evidence or stakeholder source for the need — or `unknown` ([[claim-needs-warrant]]) |
| Owner | Who maintains this frame ([[artefact-has-owner]]) |

## How to produce

[[problem-framing-craft]]. Worked: [[problem-frame-worked]].

## Refuse / escalate

- Domain process or system facts are missing → escalate to **systems-knowledge-base** or the **user**. Do not invent.
- Only a solution list exists with no problem → reject as incomplete; ask for the problem.

## Not this standard

Detailed requirements quality ([[requirements-quality]]); acceptance wording ([[acceptance-criteria]]); PM initiation packs (later PM slice).
