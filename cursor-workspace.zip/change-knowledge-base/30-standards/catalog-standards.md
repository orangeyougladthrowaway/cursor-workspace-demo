---
type: catalog
status: draft
id: change-knowledge-base-cat-standards
description: Standards inventory.
updated: 2026-07-18
---

# Catalog -- Standards

| Stem | Concern |
| --- | --- |
| [[gap-analysis]] | analysis |
| [[options-communication]] | analysis |
| [[problem-framing]] | analysis |
| [[process-swimlane]] | analysis |
| [[workshop-facilitation]] | analysis |
| [[closure-confirmation]] | delivery |
| [[communications-plan]] | delivery |
| [[delivery-comms]] | delivery |
| [[post-implementation-review]] | delivery |
| [[status-reporting-honesty]] | delivery |
| [[business-case]] | governance |
| [[change-artefact-policy]] | governance |
| [[change-control]] | governance |
| [[decision-log]] | governance |
| [[initiation-mandate]] | governance |
| [[kickoff-honesty]] | governance |
| [[terms-of-reference]] | governance |
| [[delivery-dependencies]] | planning |
| [[plan-honesty]] | planning |
| [[work-item-hygiene]] | planning |
| [[quality-plan]] | planning |
| [[assumption-log]] | requirements |
| [[business-rules-catalogue]] | requirements |
| [[data-model]] | requirements |
| [[elicitation-discipline]] | requirements |
| [[nfr-schedule]] | requirements |
| [[nonfunctional-framing]] | requirements |
| [[requirements-catalogue]] | requirements |
| [[requirements-conflict]] | requirements |
| [[requirements-prioritisation]] | requirements |
| [[requirements-quality]] | requirements |
| [[definition-of-ready]] | requirements |
| [[requirements-traceability]] | requirements |
| [[use-case]] | requirements |
| [[issue-risk-split]] | risk |
| [[raid-pack]] | risk |
| [[risk-cadence]] | risk |
| [[raci-matrix]] | stakeholders |
| [[stakeholder-clarity]] | stakeholders |
| [[acceptance-criteria]] | verification |
| [[boundary-applied]] | verification |
| [[coverage-honesty-narrative]] | verification |
| [[defect-clarity]] | verification |
| [[defect-severity]] | verification |
| [[intent-coverage]] | verification |
| [[risk-based-test-focus]] | verification |
| [[test-case]] | verification |
| [[test-completion-report]] | verification |
| [[test-conditions]] | verification |
| [[test-plan]] | verification |
| [[test-procedure]] | verification |
| [[uat-intent-scripts]] | verification |
| [[uat-readiness]] | verification |
| [[uat-sign-off]] | verification |

[[navigation]]
