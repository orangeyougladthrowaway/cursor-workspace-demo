---
type: standard
status: draft
id: change-knowledge-base-s-062
concern: requirements
description: Entry gate — what a requirement or story must satisfy before it may be committed to delivery.
derived_from:
  - "[[intent-must-be-testable]]"
  - "[[enough-to-decide]]"
  - "[[bound-the-change]]"
  - "[[estimate-shows-uncertainty]]"
  - "[[elicit-before-invent]]"
updated: 2026-07-25
---

# Definition of ready

The **entry** gate to delivery, mirroring the completion gate at the other end. Ready is about *understanding*, not about *permission*: an item can be approved and still not be ready.

## Normally require

| Gate | Test |
| --- | --- |
| Intent stated | The outcome and its beneficiary are named ([[outcome-over-output]]) |
| Acceptance written | Testable criteria exist on the item ([[acceptance-criteria]], [[intent-must-be-testable]]) |
| Quality bar | Requirement passes the quality tests ([[requirements-quality]]) — unambiguous, singular, verifiable |
| Boundaries | In / out of scope stated ([[bound-the-change]]) |
| Non-functionals considered | Relevant NFRs named or explicitly not applicable ([[nonfunctional-framing]]) |
| Dependencies known | External and internal dependencies identified with owners ([[delivery-dependencies]]) |
| Assumptions logged | Open assumptions recorded and owned ([[assumption-log]]) |
| Conflicts resolved | No unresolved contradiction with another agreed requirement ([[requirements-conflict]]) |
| Sized | An estimate band exists with its assumption ([[estimate-range-method]]) |
| Priority known | Ranked against the rest of the set ([[requirements-prioritisation]]) |
| Domain facts sourced | Facts come from a source of record or a named person — never invented ([[elicit-before-invent]]) |

Ready is a **judgement with a checklist**, not a form. An item may pass with a declared Gap if the Gap is owned and does not block the first slice.

## Framework posture

Definition-of-Ready checklists, the three-Cs conversation view of a story, and readiness-vs-done symmetry are portable practice. Sprint mechanics, ceremony scheduling, and tracker gating features are out of scope.

## How to produce

[[definition-of-ready-craft]]. Praxis exemplar is a **Gap** until the first tracked change runs end to end.

## Refuse / escalate

- Committing an item whose acceptance is "to be discussed in refinement"
- Readiness claimed because a sponsor approved the *funding* rather than the *understanding* ([[work-needs-mandate]] is a different gate)
- Sizing an item whose domain facts are unknown → escalate rather than pad
- A readiness checklist used to block small BAU work that needs no ceremony ([[small-change-control]])
- Ready declared by the delivering party alone when the requirement owner has not seen it

## Not this standard

Completion evidence — the host engineering lane owns that gate. Item grain and required fields ([[work-item-hygiene]]); acceptance content ([[acceptance-criteria]]); UAT entry ([[uat-readiness]]); mandate to spend ([[initiation-mandate]]).
