---
type: standard
status: draft
id: change-knowledge-base-s-017
concern: verification
description: Defects state expected vs actual, reproduction, and impact — evidence, not complaint.
derived_from:
  - "[[defect-carries-evidence]]"
  - "[[claim-needs-warrant]]"
  - "[[risk-shapes-attention]]"
  - "[[status-matches-evidence]]"
updated: 2026-07-16
---

# Defect clarity

## Normally require

A **defect report** includes:

| Field | Test |
| --- | --- |
| Summary | One-line what-is-wrong |
| Expected vs actual | Both stated, tied to intent ([[defect-carries-evidence]]) |
| Reproduction | Steps or conditions to observe it |
| Evidence | Observation reference (log line, screenshot ref, data) — provenance, not a dump |
| Impact / severity | Effect on outcome/users; severity reasoned from risk ([[risk-shapes-attention]]) |
| Trace | Link to the condition/intent it violates |

## Framework posture

Severity/priority scales and defect-report shapes are portable. Bug-tracker workflow states are tool detail, out of scope.

## How to produce

[[defect-clarity-craft]]. Worked: [[defect-clarity-worked]].

## Refuse / escalate

- "It's broken" with no expected/actual or reproduction ([[defect-carries-evidence]])
- Severity asserted with no impact reasoning
- Expected behaviour unknown (ambiguous requirement) → escalate to BA/acceptance

## Not this standard

Deriving conditions ([[test-conditions]]); coverage ([[intent-coverage]]); code-level debugging (out of change-knowledge-base scope).
