---
type: pattern
status: draft
id: change-knowledge-base-pt-008
concern: governance
description: RAID log — Risks, Assumptions, Issues, Dependencies in one governance view.
derived_from:
  - "[[risk-cadence]]"
  - "[[status-matches-evidence]]"
updated: 2026-07-16
---

# Raid log

## Shape

One governance view, four lanes:

| Lane | Captures |
| --- | --- |
| **R**isks | Future uncertain events ([[risk-register-shape]]) |
| **A**ssumptions | Things taken as true — with validation status |
| **I**ssues | Problems happening now — with owner and action |
| **D**ependencies | Things needed from/for others — with dates |

Each row: statement, owner, status, next review.

## When

Governing a change that needs assumptions and dependencies tracked alongside risk.

## When not

As a dumping ground; as a substitute for the scored [[risk-register-shape]] on material risks.

## Related

- [[status-rag-honesty]] · [[run-risk-cadence]] · [[report-status]] · [[raid-pack]] · [[maintain-raid-log]] · [[project-artefact-pack]]
