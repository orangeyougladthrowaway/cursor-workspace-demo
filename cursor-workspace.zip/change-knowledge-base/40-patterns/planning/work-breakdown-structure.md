---
type: pattern
status: draft
id: change-knowledge-base-pt-005
concern: planning
description: Work breakdown structure — decompose outcome into ownable, estimable work items.
derived_from:
  - "[[bound-the-change]]"
  - "[[plan-honesty]]"
updated: 2026-07-16
---

# Work breakdown structure

## Shape

Decompose the change top-down until each leaf is:

- **Ownable** — one accountable owner
- **Estimable** — small enough to range with confidence
- **Verifiable** — a done-state you can check

```text
Outcome
 ├─ Deliverable A
 │   ├─ Work item A1
 │   └─ Work item A2
 └─ Deliverable B
     └─ Work item B1
```

Decompose by **deliverable/outcome**, not by org unit or by tool.

## When

Building a plan that needs estimates and ownership ([[plan-honesty]]).

## When not

As a task diary; decomposing past the point of useful control ([[enough-to-decide]]).

## Related

- [[estimate-range-method]] · [[build-plan]]
