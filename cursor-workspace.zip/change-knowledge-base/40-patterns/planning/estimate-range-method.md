---
type: pattern
status: draft
id: change-knowledge-base-pt-006
concern: planning
description: Range-based estimation — three-point / optimistic-likely-pessimistic with assumptions.
derived_from:
  - "[[estimate-shows-uncertainty]]"
  - "[[plan-honesty]]"
updated: 2026-07-16
---

# Estimate range method

## Shape

For each estimated item capture:

| Point | Meaning |
| --- | --- |
| Optimistic (O) | Everything goes well |
| Likely (M) | Normal conditions |
| Pessimistic (P) | Known things go wrong |

Communicate a **range** (and, if useful, a weighted expectation such as (O + 4M + P) / 6). Always attach the **assumptions** the range depends on.

## When

Any estimate that will drive commitments ([[plan-honesty]]).

## When not

False precision to a single number; ranges with no stated assumptions ([[estimate-shows-uncertainty]]).

## Related

- [[work-breakdown-structure]] · [[build-plan]]
