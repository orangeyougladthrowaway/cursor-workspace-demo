---
type: catalog
status: draft
id: change-knowledge-base-cat-patterns
description: Patterns inventory — portable method shapes (frameworks) for BA/PM/TA.
updated: 2026-07-16
---

# Catalog — Patterns

| Concern | Notes |
| --- | --- |
| stakeholders | [[influence-interest-grid]] |
| requirements | [[moscow-bands]], [[value-risk-matrix]] |
| analysis | [[elicitation-modes]] |
| planning | [[work-breakdown-structure]], [[estimate-range-method]] |
| risk | [[risk-register-shape]] |
| governance | [[raid-log]] |
| delivery | [[status-rag-honesty]] |
| verification | [[test-condition-derivation]], [[coverage-dimensions]], [[boundary-equivalence-thinking]], [[defect-report-shape]] |

[[navigation]]
