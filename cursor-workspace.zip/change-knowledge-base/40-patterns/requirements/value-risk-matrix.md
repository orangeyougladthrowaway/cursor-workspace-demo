---
type: pattern
status: draft
id: change-knowledge-base-pt-003
concern: requirements
description: Value × risk matrix — rank by outcome contribution and risk of delay/wrongness.
derived_from:
  - "[[rank-by-outcome]]"
  - "[[risk-shapes-attention]]"
  - "[[requirements-prioritisation]]"
updated: 2026-07-16
---

# Value risk matrix

## Shape

Score or place each item on:

1. **Value** — contribution to the named outcome ([[outcome-over-output]])
2. **Risk** — harm if delayed, wrong, or uncertain ([[risk-shapes-attention]])

Typical read:

| | Lower risk | Higher risk |
| --- | --- | --- |
| **Higher value** | Do soon | Do soon *and* elicit/verify hard |
| **Lower value** | Later / Could | Challenge — often Won’t or rethink |

Relative scales beat fake precision. Unknown value/risk → escalate, don’t invent numbers.

## When

MoSCoW alone hides *why*; need outcome/risk discrimination ([[requirements-prioritisation]]).

## When not

As a spreadsheet of invented scores; as tool backlog automation theatre.

## Related

- [[moscow-bands]] · [[prioritise-requirements]]
