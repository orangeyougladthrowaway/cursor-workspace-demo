---
type: pattern
status: draft
id: change-knowledge-base-pt-009
concern: delivery
description: RAG status with evidence and defined thresholds — colour follows facts, not comfort.
derived_from:
  - "[[status-matches-evidence]]"
  - "[[tradeoff-visible]]"
updated: 2026-07-16
---

# Status rag honesty

## Shape

Define what each colour **means** before reporting:

| Colour | Trigger |
| --- | --- |
| Green | On track vs plan; no material unmanaged risk |
| Amber | Off track or material risk, with a credible recovery |
| Red | Off track with no credible recovery, or breached tolerance |

Each colour cites **evidence** (milestone, metric, risk movement). Amber/Red name the ask.

## When

Reporting status ([[status-reporting-honesty]]).

## When not

"Watermelon" reporting (green outside, red inside); colour chosen for comfort over evidence ([[status-matches-evidence]]).

## Related

- [[raid-log]] · [[report-status]]
