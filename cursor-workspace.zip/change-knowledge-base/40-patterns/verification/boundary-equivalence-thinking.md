---
type: pattern
status: draft
id: change-knowledge-base-pt-012
concern: verification
description: Equivalence partitioning and boundary analysis — portable test-design thinking at analysis grain.
derived_from:
  - "[[condition-derives-from-intent]]"
  - "[[test-conditions]]"
updated: 2026-07-16
---

# Boundary equivalence thinking

## Shape

Given a rule with inputs/ranges:

1. **Equivalence classes** — group inputs that should behave the same; test one representative per class (valid and invalid).
2. **Boundaries** — test at and just across each edge (min, min−1, max, max+1).

Example (rule "accept 1–100"): classes = {<1 invalid, 1–100 valid, >100 invalid}; boundaries = 0, 1, 100, 101.

## When

A condition involves ranges, limits, or categories ([[test-conditions]]).

## When not

As a substitute for risk focus on non-range logic; as code-level parametrisation (out of change-knowledge-base scope).

## Related

- [[test-condition-derivation]] · [[coverage-dimensions]]
