---
type: pattern
status: draft
id: change-knowledge-base-pt-013
concern: verification
description: Defect report shape — summary, expected vs actual, repro, evidence, impact, trace.
derived_from:
  - "[[defect-carries-evidence]]"
  - "[[defect-clarity]]"
updated: 2026-07-16
---

# Defect report shape

## Shape

| Field | Content |
| --- | --- |
| Summary | One line |
| Expected | What intent said should happen |
| Actual | What happened |
| Reproduction | Steps / conditions |
| Evidence | Observation reference (not a dump) |
| Impact | Effect on outcome/users |
| Severity | Reasoned from impact + risk |
| Trace | Condition / intent id violated |

## When

Reporting a defect ([[defect-clarity]]).

## When not

Bare "broken"; severity with no impact reasoning; expected behaviour invented rather than escalated.

## Related

- [[report-defect]] · [[test-conditions]]
