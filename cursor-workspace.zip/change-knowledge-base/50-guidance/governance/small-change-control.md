---
type: guidance
status: draft
id: change-knowledge-base-g-062
concern: governance
description: Intentional process path for micro-fix and enhancement (BAU/small change) — same control rigor as project, thinner M-set.
derived_from:
  - "[[change-artefact-policy]]"
  - "[[change-artefact-policy-craft]]"
  - "[[plan-change-work]]"
  - "[[precision-over-vagueness]]"
  - "[[enough-to-decide]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-20
---

# Small change control

House how-to for **micro-fix** and **enhancement** engagements. Same control loop as a project (plan → produce → verify → review); **thinner** mandatory documents per [[change-artefact-policy]] — never accidental silence.

**BAU** in house language maps to these classes (not a sixth class): routine product/support increments → usually **micro-fix**; material feature increments on a live mandate → **enhancement**. If unclear → ask; do not default to project or to “no docs.”

## Applies when

- Updating a **live** product or service under an existing mandate
- Hours–days defect/tweak (**micro-fix**) or weeks-scale increment (**enhancement**)
- Agents or staff would otherwise skip classify / M-account / AC

## Does not apply when

- New outcome / new mandate → **project** (or programme)
- Compliance/audit dominates → **regulatory**
- Pure ops runbook with no change intent → out of change-knowledge-base (systems / eng ops)

## Control loop (intentional — all small classes)

```text
1. Mandate check — living charter/product mandate exists (or escalate)
2. plan-change-work — classify + M/R account + cell vs journey choice + precision
3. produce-change-artefact — only named cells (or thinned pass) on the plan
4. verify-change-artefact — field tests + M-set honesty
5. review-change-artefact — no green-wash
6. Eng / ops implement — host lane; methods do not skip AC
```

Skipping a step requires the same honesty as project: **named skip / substitute / exemption** with residual risk — not “it’s BAU.”

## Default process path by class

| Class | Prefer | Typical Produce set (from policy — confirm on plan) | Journey? |
| --- | --- | --- | --- |
| **micro-fix** | **Named cells** | AC (**M**); defect clarity (**M**); RTM/quality lite (**R**); assumptions/RAID lite (**R**); closure lite (**R**); catalogue only if intent moves | Full BA/PM/TA pass **not** default — enter cells that cover M |
| **enhancement** | **Selected cells** or **thinned** profile pass | Problem/stakeholder deltas (**M**); AC (**M**); RTM (**M**); plan/RAID/decisions/change-control/status/conditions as **M** per column; catalogue **R** (include when intent changes) | Thin pass OK if plan names which steps run / skip |
| **project+** | Full profile journey | Policy project/regulatory column | Default journey |

Data/historisation on enhancement (or micro if it touches stores): apply **data override** — [[data-model]] field maps **M**, catalogue/AC precision ([[precision-over-vagueness]]).

## Required docs (where decided)

| Layer | Owns “whether” | Owns “shape / field tests” |
| --- | --- | --- |
| Class → M/R/O | [[change-artefact-policy]] | — |
| How to classify + cell vs journey | [[change-artefact-policy-craft]] · this note | — |
| Plan output | [[plan-change-work]] | — |
| Each artefact | — | Artefact **standard** + craft + skeleton via [[project-artefact-pack]] |

There is **no** separate “BAU pack” competing with policy. Small change uses the **same standards**, selected by class column.

## Maintain existing product artefacts

When the product already has a catalogue / AC / RAID / data model:

1. Prefer **delta** rows (new/changed ids, version bump) over blank parallel packs.
2. Retire or supersede obsolete REQs/AC with status honesty — do not leave dual SoTs.
3. Link the change-task plan to the living artefact paths in the consumer repo.

## Done test

- Class named (micro-fix or enhancement) and cited `change-knowledge-base-s-060`
- Every **M** Produce / Substitute / Exempt (decision id)
- Path chosen: cells vs thinned journey — written on plan
- AC (and other M) meet precision before eng implement
- Verify/review run against that M-set

## Refuse

- “BAU — no docs” without class + M-account
- Full project pack for a label fix (wrong class)
- Journey auto-run of all BA/PM/TA cells for micro-fix
- Adjective-only AC on micro-fix because “small”

## Related

- [[change-artefact-policy]] · [[change-artefact-policy-craft]] · [[change-artefact-policy-worked]]
- [[plan-change-work]] · [[produce-change-artefact]] · [[verify-change-artefact]] · [[review-change-artefact]]
- [[ba-change-pass]] · [[pm-delivery-pass]] · [[ta-analysis-pass]] · [[staff-agent-projection]] · [[project-artefact-pack]]
