---
type: guidance
status: draft
id: change-knowledge-base-g-063
concern: planning
description: How to size, fill, parent, claim, and state tracked work items without board theatre.
derived_from:
  - "[[work-item-hygiene]]"
  - "[[definition-of-ready]]"
  - "[[estimate-range-method]]"
  - "[[outcome-over-output]]"
updated: 2026-07-26
---

# Work item hygiene craft

House how-to for PM12. Field tests: [[work-item-hygiene]].

**Single methods home** for good work items and what belongs where — do not fork this into eng or harness bibles. Eng owns completion evidence; systems/ADO notes own field names and agent wiring.

## Applies when

Delivery is tracked as typed items on a board or backlog and people status against those items.

## House defaults

1. **Title the outcome, not the activity.** "Buyers can resume an abandoned basket" beats "basket work".
2. **Split by value, never by layer.** A slice that only a developer can demo is a task, not a story.
3. **One owner per item.** Shared ownership is no ownership ([[artefact-has-owner]]).
4. **Parent before you start.** An orphan item cannot be prioritised or reported against an outcome.
5. **Acceptance lives on the story**, in the item, not in a side document nobody opens ([[acceptance-criteria]]).
6. **Size as a band with the assumption attached** ([[estimate-range-method]]). A point number with no assumption is false precision.
7. **State reflects evidence, not intention** — an item is Done when its evidence exists, not when the author feels finished.
8. **BAU and micro-fix skip the hierarchy** — a single item is honest; a fabricated epic is theatre ([[small-change-control]]).
9. **Configure the tracker to the standard**, not the standard to the tracker. If a required field is missing, add the field; do not drop the requirement.
10. **Claim the delivery set** — Story + child Tasks + in-scope Bugs — before parallel implement; release on cancel/abandon; keep owner when blocked.

## What good looks like (checklist)

| Check | Pass |
| --- | --- |
| Right level | Matches the grain ladder in [[work-item-hygiene]] |
| Title | Outcome-shaped; stakeholder can understand it |
| Parent | Linked up (except top); Tasks under Stories |
| Owner | Exactly one named owner when in delivery |
| Story AC | Testable; no "TBC" in the committed set |
| DoR | [[definition-of-ready]] before committed delivery |
| Bug body | Repro + expected vs actual + severity |
| State | Matches evidence ([[status-matches-evidence]]) |

## Tracker mapping (Azure DevOps Agile — lived house)

| This standard | ADO expression |
| --- | --- |
| Owner | `System.AssignedTo` |
| Story | Work item type **User Story** |
| Claim set | Assign Story + child Tasks + in-scope Bugs to the same person; state **Active** |
| Blocked | Keep AssignedTo; stay Active; comment the blocker |
| Cancelled / abandoned | Clear AssignedTo; **Removed** if junk, else return to unassigned New |
| Closed / Done | Requires host eng evidence (not invented here) |

Agent/control-plane steps live in sibling agent-harness (`claim-ado-work`, MCP docs) — thin pointers only.

## Decision rules

| Situation | Do |
| --- | --- |
| Story spans more than one iteration | Promote to feature; split into value slices |
| Two teams must both deliver for value | Feature with a story each; record the dependency ([[delivery-dependencies]]) |
| Acceptance unknown at creation | Item stays out of the committed set until [[definition-of-ready]] passes |
| Defect found mid-delivery of the same story | Fix in the story; raise a bug only if it escaped the gate |
| Requested behaviour change after agreement | Bug is wrong — use [[change-control]] |
| Domain fact needed to size | Escalate; widen the band; do not guess |
| Item has drifted from its original intent | Close and re-raise rather than silently mutating scope ([[control-the-delta]]) |
| Item AssignedTo someone else | Do not implement; ask for handoff |
| Many Active Stories per person | Allowed — keep each Story coherent |
| Platform artefact (shared lib/image) released for consumers to adopt | Feature = "release <artefact> <version>"; one **adopt** Story per downstream consumer, each with its own owner and acceptance (pin bumped + integration green). Downstream list = repos whose pin files currently name that artefact — read pins at release time; no separate register |
| Consumer must not adopt until proven | Adopt Story stays out of the committed set until the version is published and the consumer's env can integration-test it — mirrors [[definition-of-ready]] |

## Done test

| Check | Pass means |
| --- | --- |
| Grain | Each level matches the ladder in [[work-item-hygiene]] |
| Content | Required fields present for that level — no "TBC" acceptance |
| Parenting | Every item traceable up to an outcome, or explicitly BAU |
| Ownership | One named owner in delivery; claim set coherent |
| State honesty | Every state backed by evidence someone else could check |

## Related

- [[work-item-hygiene]] · [[definition-of-ready]] · [[acceptance-criteria]] · [[plan-honesty]] · [[status-reporting-honesty]] · [[small-change-control]] · [[requirements-traceability]]
