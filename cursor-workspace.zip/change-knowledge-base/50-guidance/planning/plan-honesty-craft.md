---
type: guidance
status: draft
id: change-knowledge-base-g-007
concern: planning
description: How to build an honest plan — ranges, dependencies, milestones, anti false certainty.
derived_from:
  - "[[plan-honesty]]"
  - "[[estimate-range-method]]"
  - "[[estimate-shows-uncertainty]]"
updated: 2026-07-18
---

# Plan honesty craft

House how-to for PM02. Field tests: [[plan-honesty]].

## Applies when

Turning initiation/scope into a delivery plan others will status against.

## House defaults

1. **Decompose until items have owners.** Wishlist epics are not a plan.
2. **Sequence with dependencies first**, dates second. A Gantt of hopes without deps fails.
3. **Estimates are ranges with assumptions** (best / likely / worst or T-shirt + conditions). Single-point certainty is a lie unless history proves it.
4. **Milestones are decision or delivery checkpoints**, not “status meeting Friday.”
5. **Assumptions owned.** “Vendor will answer in 2 days” needs an owner and a slip path.
6. **Cross-link key risks** to the risk register — plan and risk are one system.
7. **Re-baseline visibly** when scope/capacity changes; silent date edits are theatre.

## Decision rules

| Situation | Do |
| --- | --- |
| Domain effort unknown | Escalate; widen range; do not fake precision |
| External dependency | Explicit lag + owner on other side; escalate if unnamed |
| Fixed date + soft scope | State which gives first; document tradeoff |
| Rolling wave | Near-term detailed; far-term bands — label the horizon |

## Done test

| Check | Pass means |
| --- | --- |
| Breakdown | Ownable/estimable items |
| Sequence | Dependencies visible |
| Uncertainty | Ranges + assumptions |
| Milestones | Checkpoints tied to outcome |
| Risk link | Material risks referenced |

## Related

- [[plan-honesty]] · [[build-plan]] · [[estimate-range-method]] · [[risk-cadence]] · [[plan-honesty-worked]]
