---
type: guidance
status: draft
id: change-knowledge-base-g-003
concern: requirements
description: How to run elicitation — mode choice, prompts, conflict, warrants, anti-invention.
derived_from:
  - "[[elicitation-discipline]]"
  - "[[elicitation-modes]]"
  - "[[elicit-before-invent]]"
  - "[[influence-shapes-engagement]]"
updated: 2026-07-18
---

# Elicitation craft

House how-to for BA07. Field tests live on [[elicitation-discipline]]; this note is how to *run* discovery without inventing answers.

## Applies when

Material unknowns block framing, requirements, acceptance, or prioritisation.

## Does not apply when

- The fact is already warranted in systems-knowledge-base / confirmed docs
- The “unknown” is engineering design — wrong lane

## House defaults

1. **Name the unknown and the decision it unlocks** before booking time. Sessions without a decision question produce folklore.
2. **Choose mode deliberately** ([[elicitation-modes]]): interview for depth/sensitivity; workshop for conflict and shared bounds; observation for as-is vs stated; document study for written rules; prototype review to make abstract intent concrete.
3. **Match engagement to influence** ([[influence-shapes-engagement]]). High-influence dissenters need earlier airtime than low-influence cheerleaders.
4. **Prompts over solutions.** Leading with “we’ll do X, right?” contaminates the warrant.
5. **Record conflicts as first-class output.** Do not average opposing claims into a fake consensus.
6. **Separate hearing from deciding.** Elicitation gathers warrants; prioritisation/governance decides.
7. **Never invent interviewee answers** to keep a pack green ([[elicit-before-invent]]).

## Decision rules

| Situation | Do |
| --- | --- |
| Two SMEs contradict | Capture both + open conflict; schedule resolution owner — do not pick silently |
| Access denied for observation | Document Gap; use alternate mode or escalate |
| Docs look authoritative but stale | Mark warrant weak; confirm with owner |
| Workshop turns political | Park decisions; record unresolved; do not force MoSCoW in the room |

## Communication (session)

| Beat | Intent |
| --- | --- |
| Open | Restate decision question and timebox |
| Explore | Prompts; examples; “what would break?” |
| Reflect | Playback claims; confirm wording |
| Close | List warrants, conflicts, remaining unknowns, next owner |

## Done test

| Check | Pass means |
| --- | --- |
| Unknown named | Decision gap clear |
| Mode fitted | Mode matches influence and unknown type |
| Warrant bound | Output states what claims the session may support |
| Honest remainder | Conflicts and unknowns listed — or explicitly none |

## Related

- [[elicitation-discipline]] · [[elicit-requirements]] · [[elicitation-modes]] · [[stakeholder-clarity]] · BA12 requirements-conflict (Open on [[common-case-coverage]])
