---
type: guidance
status: draft
id: change-knowledge-base-g-064
concern: requirements
description: How to run the readiness gate — what to check, what to defer, what to refuse.
derived_from:
  - "[[definition-of-ready]]"
  - "[[requirements-quality]]"
  - "[[acceptance-criteria]]"
  - "[[enough-to-decide]]"
updated: 2026-07-25
---

# Definition of ready craft

House how-to for BA13. Field tests: [[definition-of-ready]].

## Applies when

Deciding whether a requirement or story may enter a committed delivery set.

## House defaults

1. **Check readiness before the commitment conversation**, not during it. Refinement is where gaps are closed; commitment is where they are proven closed.
2. **Read the acceptance out loud.** If two people picture different behaviour, it is not testable yet ([[intent-must-be-testable]]).
3. **Name the beneficiary.** "The business wants it" fails; a named role with a reason passes.
4. **Ask what would make this impossible** — that question surfaces dependencies faster than a dependency field.
5. **Log the assumption instead of resolving everything.** Ready means *enough to decide*, not fully specified ([[enough-to-decide]]).
6. **Size last.** Sizing before understanding produces a number that anchors everyone wrongly.
7. **The requirement owner confirms readiness**, not only the delivery team. Ready ≠ claimed for delivery — claim is start of implement ([[work-item-hygiene]]).
8. **Scale the gate to the change class** — BAU items pass on intent + acceptance alone ([[small-change-control]]).

## Decision rules

| Situation | Do |
| --- | --- |
| Acceptance vague but intent clear | Not ready — write acceptance first ([[acceptance-criteria]]) |
| Domain fact missing | Escalate to the source of record or the owner; do not invent |
| Dependency owned by a third party | Ready only with a named owner and a slip path ([[delivery-dependencies]]) |
| NFR unknown but likely material | Not ready — frame it ([[nonfunctional-framing]]) |
| Two requirements disagree | Not ready — resolve ([[requirements-conflict]]) |
| Big item, first slice well understood | Split; take the ready slice, leave the rest |
| Pressure to commit an unready item | State what is unknown and what it puts at risk; let the decision be visible ([[tradeoff-visible]]) |

## Done test

| Check | Pass means |
| --- | --- |
| Testable | Acceptance criteria someone else could verify |
| Bounded | In / out of scope stated |
| Sourced | Domain facts traced to a record or a person |
| Dependencies | Identified with owners |
| Sized | Band + assumption |
| Owned | Requirement owner has confirmed |

## Related

- [[definition-of-ready]] · [[work-item-hygiene]] · [[acceptance-criteria]] · [[requirements-quality]] · [[assumption-log]] · [[requirements-prioritisation]]
