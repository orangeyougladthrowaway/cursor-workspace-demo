---
type: guidance
status: draft
id: change-knowledge-base-g-006
concern: requirements
description: How to prioritise — one framework, real tradeoffs, no all-Must theatre.
derived_from:
  - "[[requirements-prioritisation]]"
  - "[[moscow-bands]]"
  - "[[value-risk-matrix]]"
  - "[[tradeoff-visible]]"
updated: 2026-07-18
---

# Requirements prioritisation craft

House how-to for BA05. Field tests: [[requirements-prioritisation]].

## Applies when

In-scope requirements need an order or band for a release/slice.

## House defaults

1. **Pick one primary framework** (MoSCoW, Now-Next-Later, value×risk) and stick to it. Dual labels without a mapping confuse readers.
2. **Rank against outcome and risk**, not loudness. “CEO asked” is a warrant to *consider*, not automatic Must.
3. **Must means release fails without it.** If everything is Must, the framework failed — force tradeoffs.
4. **Show deferred/rejected explicitly.** Invisible cuts become zombie scope.
5. **Trace every ranked row to a quality pack id.** Prioritising unclear items invents value.
6. **Revisit when frame or risks change** — prioritisation is living, not a one-off workshop artefact.

## Decision rules

| Situation | Do |
| --- | --- |
| All Must demanded | Return tradeoff list; escalate to sponsor with capacity constraint |
| Value unknown | Escalate; do not invent ROI |
| Risk-driven item | Prefer [[value-risk-matrix]] or risk rationale in MoSCoW Should/Could |
| Conflict between SMEs | Park as unresolved; do not silent-pick |

## Done test

| Check | Pass means |
| --- | --- |
| Framework named | One primary method applied |
| Ordered | Bands or rank present |
| Rationale | Outcome/risk why visible |
| Tradeoffs | Deferred/rejected named |
| Honesty | Not all top priority without capacity story |

## Related

- [[requirements-prioritisation]] · [[prioritise-requirements]] · [[moscow-bands]] · [[value-risk-matrix]] · [[requirements-prioritisation-worked]]
