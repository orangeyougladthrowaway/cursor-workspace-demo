---
type: guidance
status: draft
id: change-knowledge-base-g-002
concern: delivery
description: How to write honest status — evidence-backed RAG, asks, anti theatre.
derived_from:
  - "[[status-reporting-honesty]]"
  - "[[status-rag-honesty]]"
  - "[[status-matches-evidence]]"
  - "[[tradeoff-visible]]"
updated: 2026-07-18
---

# Status reporting craft

House how-to for PM04. Field tests live on [[status-reporting-honesty]]; this note is how to *communicate* status without green-wash.

## Applies when

Periodic or event-driven status to sponsors, steering, or delivery partners.

## Does not apply when

- Closing the initiative ([[closure-confirmation]])
- Replacing a plan baseline ([[plan-honesty]]) with vibes

## House defaults

1. **Lead with state + warrant.** RAG (or equivalent) in the first lines, with one sentence of evidence — not mood.
2. **Progress vs plan**, not activity theatre. “Meetings held” is not progress unless the plan measured meetings.
3. **Name slips and descopes** as tradeoffs ([[tradeoff-visible]]). Hiding them to keep Green fails the standard.
4. **Risks/issues with movement** since last report — new, worse, stable, closed. Static wallpaper lists fail.
5. **Asks are mandatory when blocked.** Who must decide what by when. Status without an ask when Red/Amber on a dependency is incomplete.
6. **Audience fit.** Executives get outcomes and decisions; delivery partners get milestone and dependency grain. Do not paste the same wall of text to both without purpose.
7. **Separate fact from forecast.** Mark estimates as ranges; do not present hopes as dates.

## Decision rules

| Situation | Do |
| --- | --- |
| Green but open material risk | Cannot be Green — recolour or close the risk with warrant |
| Slip with no new date | State unknown + ask for planning re-baseline; do not invent a date |
| Domain outcome unverified | Escalate / mark unverified — do not report as delivered |
| Too much detail | Move evidence to appendix; keep the front page decidable |

## Done test

| Check | Pass means |
| --- | --- |
| Evidence | RAG colour matches cited facts |
| Plan link | Progress judged against baseline/milestones |
| Tradeoffs | Slips/descopes/overspend named when present |
| Asks | Blockers have owners and decision asks |
| Owner/date | Reporter and as-of date present |

## Related

- [[status-reporting-honesty]] · [[report-status]] · [[status-rag-honesty]] · [[risk-cadence]] · [[plan-honesty]]
