---
type: catalog
status: draft
id: change-knowledge-base-cat-guidance
description: Guidance inventory -- craft how-to notes.
updated: 2026-07-18
---

# Catalog -- Guidance

| Stem | Concern |
| --- | --- |
| [[gap-analysis-craft]] | analysis |
| [[options-communication-craft]] | analysis |
| [[problem-framing-craft]] | analysis |
| [[process-swimlane-craft]] | analysis |
| [[workshop-facilitation-craft]] | analysis |
| [[closure-confirmation-craft]] | delivery |
| [[communications-plan-craft]] | delivery |
| [[delivery-comms-craft]] | delivery |
| [[post-implementation-review-craft]] | delivery |
| [[status-reporting-craft]] | delivery |
| [[business-case-craft]] | governance |
| [[change-artefact-policy-craft]] | governance |
| [[change-control-craft]] | governance |
| [[decision-log-craft]] | governance |
| [[initiation-mandate-craft]] | governance |
| [[kickoff-honesty-craft]] | governance |
| [[project-artefact-pack]] | governance |
| [[small-change-control]] | governance |
| [[terms-of-reference-craft]] | governance |
| [[delivery-dependencies-craft]] | planning |
| [[plan-honesty-craft]] | planning |
| [[work-item-hygiene-craft]] | planning |
| [[quality-plan-craft]] | planning |
| [[assumption-log-craft]] | requirements |
| [[business-rules-catalogue-craft]] | requirements |
| [[data-model-craft]] | requirements |
| [[elicitation-craft]] | requirements |
| [[nfr-schedule-craft]] | requirements |
| [[nonfunctional-framing-craft]] | requirements |
| [[requirements-catalogue-craft]] | requirements |
| [[requirements-conflict-craft]] | requirements |
| [[requirements-prioritisation-craft]] | requirements |
| [[requirements-quality-craft]] | requirements |
| [[definition-of-ready-craft]] | requirements |
| [[requirements-traceability-craft]] | requirements |
| [[use-case-craft]] | requirements |
| [[issue-risk-split-craft]] | risk |
| [[raid-pack-craft]] | risk |
| [[risk-cadence-craft]] | risk |
| [[raci-matrix-craft]] | stakeholders |
| [[stakeholder-clarity-craft]] | stakeholders |
| [[acceptance-criteria-craft]] | verification |
| [[boundary-applied-craft]] | verification |
| [[coverage-honesty-narrative-craft]] | verification |
| [[defect-clarity-craft]] | verification |
| [[defect-severity-craft]] | verification |
| [[intent-coverage-craft]] | verification |
| [[risk-based-test-focus-craft]] | verification |
| [[test-case-craft]] | verification |
| [[test-completion-report-craft]] | verification |
| [[test-conditions-craft]] | verification |
| [[test-plan-craft]] | verification |
| [[test-procedure-craft]] | verification |
| [[uat-intent-scripts-craft]] | verification |
| [[uat-readiness-craft]] | verification |
| [[uat-sign-off-craft]] | verification |

[[navigation]]
