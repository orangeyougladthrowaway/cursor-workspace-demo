---
type: foundation
status: draft
id: change-knowledge-base-lab-praxis-plane
description: Praxis plane contract — lab cites doctrine; never redefines law.
updated: 2026-07-16
---

# Praxis plane

`lab/` holds exemplars and copy-out skeletons subordinate to doctrine (`00`–`60` + `maps/`).

| Artefact | Role |
| --- | --- |
| `zoo/{facet}/` | Thin `type: example` notes — choice-changing only |
| `skeletons/{name}/` | Copy-out artefact shapes with README citing canons |
| `stubs/{facet}/` | Tiny fragments (optional) |
| [[lab-atlas]] / [[catalog-lab]] | Indexes — not curricula |

Ingestion: [[praxis-ingestion]]. Coverage: [[common-case-coverage]].
