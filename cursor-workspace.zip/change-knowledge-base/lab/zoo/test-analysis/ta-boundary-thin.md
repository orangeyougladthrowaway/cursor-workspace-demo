---
type: example
status: draft
id: change-knowledge-base-ex-022
description: Thin exemplar — TA stays at analysis grain; code-level test craft is out of change-knowledge-base scope.
derived_from:
  - "[[ta-analysis-pass]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Ta boundary thin

## When

Asked to "just write the automated tests" — reaching into framework/fixture/code craft.

## When not

The task is intent/coverage analysis: conditions, focus, coverage, defects, readiness.

## Choice

Do the analysis here; hand implementation to the host engineering lane. TA owns intent/coverage; code-level test craft is out of this vault.
