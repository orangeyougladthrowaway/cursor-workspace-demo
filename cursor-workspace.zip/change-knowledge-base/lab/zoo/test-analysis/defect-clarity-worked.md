---
type: example
status: draft
id: change-knowledge-base-ex-027
description: Worked exemplar — clear defect vs complaint without expected/actual.
derived_from:
  - "[[defect-clarity]]"
  - "[[defect-clarity-craft]]"
updated: 2026-07-18
---

# Defect clarity worked

Fictional grain. Quality bar for TA04 G4.

## Bad

| Field | Content | Why it fails |
| --- | --- | --- |
| Summary | Dashboard broken | Vague |
| Expected/actual | (missing) | No oracle |
| Severity | Critical!!! | No impact reasoning |

## Good

| Field | Content |
| --- | --- |
| Summary | Export CSV includes invoices outside selected age filter |
| Expected | Per AC-R2-happy / TC01 — CSV rows match on-screen filtered set only |
| Actual | CSV includes 4 invoices aged <30 days when filter is “30+” |
| Repro | Finance role; filter 30+; Export CSV; compare ids to UI (build 2026.7.12-rc2) |
| Evidence | Screenshot `export-mismatch-12jul.png`; sample ids INV-19, INV-22 |
| Impact / severity | **High** — finance would pay/chase wrong set; month-end trust broken |
| Trace | TC01 · AC-R2-happy · R2 |

## Related

- [[defect-clarity-thin]] · [[defect-clarity-craft]] · skeleton `defect-report/`
