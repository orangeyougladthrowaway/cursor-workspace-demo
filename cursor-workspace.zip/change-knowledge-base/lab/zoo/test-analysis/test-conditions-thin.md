---
type: example
status: draft
id: change-knowledge-base-ex-017
description: Thin exemplar — refuse test conditions invented with no upstream intent.
derived_from:
  - "[[test-conditions]]"
  - "[[derive-test-conditions]]"
updated: 2026-07-16
---

# Test conditions thin

## When

Conditions written from imagination ("test the login looks nice") with no requirement or acceptance source.

## When not

Each condition cites a requirement/acceptance/risk id.

## Choice

Fail [[condition-derives-from-intent]]. Derive from intent via [[test-condition-derivation]]; escalate missing/untestable intent to BA.
