---
type: example
status: draft
id: change-knowledge-base-ex-026
description: Worked exemplar — traced test conditions vs orphan test ideas.
derived_from:
  - "[[test-conditions]]"
  - "[[test-conditions-craft]]"
updated: 2026-07-18
---

# Test conditions worked

Fictional grain. Quality bar for TA01 G4. Analysis only.

## Shared intent

| Id | Intent |
| --- | --- |
| R1 / AC-R1-happy | Finance sees aged unpaid matching filter |
| R2 / AC-R2-unauth | Export refused without permission |

## Bad

| Condition | Why it fails |
| --- | --- |
| “Test the dashboard” | No intent trace; not testable |
| “Check security” | Invented; no AC |

## Good

| Id | Condition | Source | Type | Priority |
| --- | --- | --- | --- | --- |
| TC01 | Filtered aged list count and invoice ids match source unpaid set for selected band | AC-R1-happy | Positive | Must |
| TC02 | Band boundary at exactly 30 days classifies per agreed rule | AC-R1-happy | Boundary | Must |
| TC03 | User without export permission cannot obtain CSV | AC-R2-unauth | Negative | Must |
| — | **Gap:** predictive cashflow (R4) — out of release; no conditions | — | — | — |

## Related

- [[test-conditions-thin]] · [[test-conditions-craft]] · skeleton `test-conditions/`
