---
type: example
status: draft
id: change-knowledge-base-ex-018
description: Thin exemplar — refuse claims of exhaustive/uniform testing with no risk basis.
derived_from:
  - "[[risk-based-test-focus]]"
  - "[[focus-by-risk]]"
updated: 2026-07-16
---

# Risk focus thin

## When

"We'll test everything equally" or "fully tested" with no likelihood/impact rationale.

## When not

Depth mapped to risk; light/skipped areas stated as tradeoffs.

## Choice

Fail [[risk-based-test-focus]]. Rate by risk via [[focus-by-risk]]; escalate unknown domain likelihoods.
