---
type: example
status: draft
id: change-knowledge-base-ex-019
description: Thin exemplar — refuse test counts / line coverage reported as intent coverage.
derived_from:
  - "[[intent-coverage]]"
  - "[[assess-intent-coverage]]"
updated: 2026-07-16
---

# Intent coverage thin

## When

"200 tests pass, 90% line coverage — fully covered" with no map to requirements or risks.

## When not

Intents mapped to conditions; covered/gap/untestable named per dimension.

## Choice

Fail [[coverage-measures-intent]]. Assess against intent via [[coverage-dimensions]]; name gaps; line coverage is out of change-knowledge-base scope.
