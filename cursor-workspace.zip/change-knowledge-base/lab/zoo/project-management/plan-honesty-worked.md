---
type: example
status: draft
id: change-knowledge-base-ex-025
description: Worked exemplar — estimate ranges with assumptions vs false single point.
derived_from:
  - "[[plan-honesty]]"
  - "[[plan-honesty-craft]]"
  - "[[estimate-range-method]]"
updated: 2026-07-18
---

# Plan honesty worked

Fictional grain. Quality bar for PM02 G4.

## Bad

| Item | Estimate | Why it fails |
| --- | --- | --- |
| Whole project | 6 weeks | Single point; no breakdown; no deps; no assumptions |

## Good (excerpt)

| Id | Work | Depends on | Range | Assumptions |
| --- | --- | --- | --- | --- |
| W1 | Aged list UI (R1) | Role matrix warranted | 5–8 days | Design tokens exist; one FE |
| W2 | CSV export (R2) | W1; vendor API for status field | 3–10 days | Vendor field docs accurate; mock if RISK-04 fires |
| W3 | Prod role wiring | BA role warrant | 2–4 days | IdP groups already exist — **unconfirmed → escalate** |

**Milestones:** M1 UI demo; M2 vendor integrate; M3 finance UAT.

**Key risks:** RISK-04, RISK-07 linked.

## Related

- [[estimate-range-thin]] · [[plan-honesty-craft]] · skeleton `delivery-plan/`
