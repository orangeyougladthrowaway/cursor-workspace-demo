---
type: example
status: draft
id: change-knowledge-base-ex-023
description: Worked exemplar — honest vs watermelon status report.
derived_from:
  - "[[status-reporting-honesty]]"
  - "[[status-reporting-craft]]"
  - "[[status-rag-honesty]]"
updated: 2026-07-18
---

# Status reporting worked

Fictional grain. Quality bar for PM04 G4.

## Bad (watermelon)

| Field | Content | Why it fails |
| --- | --- | --- |
| RAG | Green | Vendor API still blocked 10 days; milestone slipped |
| Progress | “Lots of meetings; team busy” | Activity ≠ progress vs plan |
| Asks | (none) | Blocker with no decision ask |

## Good

| Field | Content |
| --- | --- |
| RAG | **Amber** — integration milestone slipped; build path clear |
| Progress vs plan | Milestone M2 (vendor invoice API) due 10 Jul — **missed**; re-plan proposed 24 Jul. UI slice M1 **done** (demo 8 Jul) |
| Risks/issues | RISK-04 vendor latency — P high / I high; issue ISS-02 waiting on vendor ticket #441 |
| Tradeoffs | Descope colour themes (R3) to protect M2 buffer |
| Asks | Sponsor approve 24 Jul M2 date **or** cut export (R2) from release — decide by 15 Jul |
| Owner / date | PM P. Example · as-of 12 Jul |

## Related

- [[status-rag-thin]] · [[status-reporting-craft]] · skeleton `status-report/`
