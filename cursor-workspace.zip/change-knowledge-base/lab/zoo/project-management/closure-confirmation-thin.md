---
type: example
status: draft
id: change-knowledge-base-ex-016
description: Thin exemplar — refuse closing a change without confirming the outcome.
derived_from:
  - "[[closure-confirmation]]"
  - "[[close-delivery]]"
updated: 2026-07-16
---

# Closure confirmation thin

## When

"We're done — the tasks are finished" with no check against the benefit or open residuals.

## When not

Outcome confirmed vs mandate; residuals owned; handoff recorded.

## Choice

Fail [[close-confirms-benefit]]. Run [[close-delivery]]; escalate unknown benefit realisation rather than claiming success.
