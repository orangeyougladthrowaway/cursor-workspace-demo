---
type: example
status: draft
id: change-knowledge-base-ex-012
description: Thin exemplar — refuse single-point estimates presented as certainty.
derived_from:
  - "[[plan-honesty]]"
  - "[[estimate-range-method]]"
updated: 2026-07-16
---

# Estimate range thin

## When

Plan states "12 weeks" with no range and no assumptions.

## When not

Ranges with assumptions, or a justified confidence band.

## Choice

Fail [[estimate-shows-uncertainty]]. Give O/M/P range + assumptions via [[estimate-range-method]]; escalate unknown domain effort.
