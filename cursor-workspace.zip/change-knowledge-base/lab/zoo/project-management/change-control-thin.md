---
type: example
status: draft
id: change-knowledge-base-ex-015
description: Thin exemplar — refuse silent scope absorption without a change record.
derived_from:
  - "[[change-control]]"
  - "[[control-change]]"
updated: 2026-07-16
---

# Change control thin

## When

Stakeholder adds a "small" requirement mid-delivery; team just absorbs it.

## When not

Delta, impact, and decision are recorded with an approver.

## Choice

Fail [[control-the-delta]]. Raise a change record via [[control-change]]; escalate impact if domain effort is unknown.
