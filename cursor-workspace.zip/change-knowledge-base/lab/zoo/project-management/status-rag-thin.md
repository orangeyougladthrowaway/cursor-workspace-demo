---
type: example
status: draft
id: change-knowledge-base-ex-014
description: Thin exemplar — refuse green status hiding material slips (watermelon reporting).
derived_from:
  - "[[status-reporting-honesty]]"
  - "[[status-rag-honesty]]"
updated: 2026-07-16
---

# Status rag thin

## When

Report is green while a critical milestone slipped and a top risk is unmitigated.

## When not

RAG follows defined thresholds with evidence; amber/red name the ask.

## Choice

Fail [[status-matches-evidence]]. Set colour by evidence via [[status-rag-honesty]]; state the tradeoff and ask.
