---
type: example
status: draft
id: change-knowledge-base-ex-011
description: Thin exemplar — refuse mobilising work with no authorising mandate.
derived_from:
  - "[[initiation-mandate]]"
  - "[[initiate-project]]"
updated: 2026-07-16
---

# Initiation mandate thin

## When

"Just start the project" with no sponsor, budget owner, or agreed outcome.

## When not

Mandate, outcome, and success measure are named and authorised.

## Choice

Fail [[initiation-mandate]] / [[work-needs-mandate]]. Escalate for authorisation; do not self-authorise scope.
