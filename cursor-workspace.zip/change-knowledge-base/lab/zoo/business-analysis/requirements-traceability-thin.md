---
type: example
status: draft
id: change-knowledge-base-ex-006
description: Thin exemplar — refuse fully-traced claims when acceptance links are missing.
derived_from:
  - "[[requirements-traceability]]"
  - "[[trace-requirements]]"
updated: 2026-07-16
---

# Requirements traceability thin

## When

Pack says “100% traced” but several requirement ids have no acceptance criteria.

## When not

Forward and backward links exist, or gaps are explicit and accepted.

## Choice

Fail [[requirements-traceability]] / [[status-matches-evidence]]. Mark gaps; do not invent criteria to green-wash.
