---
type: example
status: draft
id: change-knowledge-base-ex-009
description: Thin exemplar — refuse MoSCoW with every item Must and empty Won’t.
derived_from:
  - "[[requirements-prioritisation]]"
  - "[[moscow-bands]]"
  - "[[tradeoff-visible]]"
updated: 2026-07-16
---

# Moscow bands thin

## When

Prioritisation uses MoSCoW but every row is Must and Won’t is empty.

## When not

Bands show real tradeoffs with outcome/risk rationale.

## Choice

Fail [[moscow-bands]] / [[tradeoff-visible]]. Force Could/Won’t or switch to [[value-risk-matrix]] with honest unknowns.
