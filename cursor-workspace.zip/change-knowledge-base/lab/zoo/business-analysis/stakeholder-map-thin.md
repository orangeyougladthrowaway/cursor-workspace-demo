---
type: example
status: draft
id: change-knowledge-base-ex-004
description: Thin exemplar — refuse a directory dump as a stakeholder map.
derived_from:
  - "[[stakeholder-clarity]]"
  - "[[map-stakeholders]]"
updated: 2026-07-16
---

# Stakeholder map thin

## When

Brief attaches an org chart or email list with no interest/impact.

## When not

Parties already named with interest, impact, and engagement need.

## Choice

Fail [[stakeholder-clarity]]. Ask for interest/impact or escalate ownership facts. Do not invent who cares about what.
