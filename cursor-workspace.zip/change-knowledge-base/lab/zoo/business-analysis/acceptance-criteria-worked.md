---
type: example
status: draft
id: change-knowledge-base-ex-020
description: Worked exemplar — good vs bad acceptance criteria for the same requirement.
derived_from:
  - "[[acceptance-criteria]]"
  - "[[acceptance-criteria-craft]]"
  - "[[write-acceptance-criteria]]"
updated: 2026-07-18
---

# Acceptance criteria worked

Fictional initiative grain (not domain SoR). Shows quality bar for BA03 G4 praxis.

## Shared requirement

| Id | Intent |
| --- | --- |
| R12 | Finance user can export the filtered invoice list as CSV for the current month |

## Bad (fails [[acceptance-criteria]] / [[acceptance-criteria-craft]])

| Req id | Scenario | Given | When | Then | Why it fails |
| --- | --- | --- | --- | --- | --- |
| R12 | Export | User is on invoices | They export | It works and is fast / user-friendly | Adjectives; no observable; no actor/data |

## Good (passes field tests)

| Req id | Scenario | Given | When | Then (observable) | Pass/fail notes |
| --- | --- | --- | --- | --- | --- |
| R12 | Happy path CSV | Finance user is signed in; invoice list shows March 2026 rows after filter applied | User chooses Export CSV | Browser downloads a `.csv` whose header row matches the on-screen columns and whose data rows match the filtered March set (same count and invoice ids) | Compare file to UI list |
| R12 | Empty filter | Finance user; filters yield zero invoices | User chooses Export CSV | System offers empty CSV with headers only **or** shows a blocking message that export needs ≥1 row — behaviour named in pack; either is pass if documented | Must not invent silent success |
| R12 | Unauthorised | User lacks Finance export permission | User attempts Export CSV | Export control absent or action refused with non-enumerating error; no file downloaded | AuthZ — do not invent roles; confirm with domain/user |

## Shared data requirement (historisation)

| Id | Intent |
| --- | --- |
| R20 | Contacts snapshot historised to ODS on hash change (fictional) |

## Bad (data)

| Req id | Then | Why fails |
| --- | --- | --- |
| R20 | SCD2 works | No key/hash/table; no change/delete/noop |

## Good (data — sample rows)

| Req id | Scenario | Given | When | Then (observable) |
| --- | --- | --- | --- | --- |
| R20 | Insert | No current ODS row for contact_id C1; staging has C1 | Merge runs | ODS current row for C1 with staging attrs and is_current=true |
| R20 | Change | Current C1 hash H1; staging hash H2≠H1 | Merge runs | Prior row closed (is_current=false, effective_to set); new current with H2 |
| R20 | Noop | Current C1 hash equals staging | Merge runs | No new version; counts may be zero — success |
| R20 | Tombstone | Complete snapshot; C1 absent; prior current exists | Merge runs | Prior closed; tombstone current is_deleted=true (or named refuse if incompleteness) |

## Teaching points

- Same R12: bad pack is theatre; good pack is checkable.
- Empty and auth paths are material — not optional decoration.
- Domain role names must come from inputs; escalate if missing.
- Data intents need insert/change/noop/tombstone (or Gap) — happy-path only fails [[precision-over-vagueness]].

## Related

- [[acceptance-criteria-thin]] (reject adjectives) · [[acceptance-criteria-craft]] · skeleton `acceptance-criteria/`
