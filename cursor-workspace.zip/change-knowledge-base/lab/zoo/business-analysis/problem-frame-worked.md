---
type: example
status: draft
id: change-knowledge-base-ex-021
description: Worked exemplar — good vs bad problem frame for the same ask.
derived_from:
  - "[[problem-framing]]"
  - "[[problem-framing-craft]]"
updated: 2026-07-18
---

# Problem frame worked

Fictional grain. Quality bar for BA01 G4.

## Ask received

“Build a dashboard for invoices.”

## Bad (fails [[problem-framing]])

| Field | Content | Why it fails |
| --- | --- | --- |
| Problem | Need a dashboard | Solution shaped; no wrong/missing named |
| Outcome | Nice UI | No beneficiary / better-off-how |
| Bounds | (missing) | Scope unbounded |
| Warrants | (missing) | Invented need |

## Good (passes)

| Field | Content |
| --- | --- |
| Problem | Finance cannot reconcile unpaid invoices older than 30 days without exporting three spreadsheets and joining by hand |
| Outcome | Finance ops can see aged unpaid invoices in one view and act within the month-end window without spreadsheet joins |
| In | Aged unpaid list, filters by age band, export of filtered set |
| Out | Payment collection workflows; customer portal; predictive cashflow |
| Later | Auto-reminders |
| Risks | Wrong SoR for invoice status; access to finance data without role model |
| Warrants | Ops lead interview 2026-07-01 — “we burn ~4h at month-end joining CSVs”; escalate systems for invoice SoR |
| Owner | BA A. Example |

## Related

- [[problem-frame-thin]] · [[problem-framing-craft]] · skeleton `problem-frame/`
