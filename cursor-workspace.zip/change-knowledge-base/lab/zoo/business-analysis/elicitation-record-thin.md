---
type: example
status: draft
id: change-knowledge-base-ex-007
description: Thin exemplar — refuse writing requirements to avoid elicitation.
derived_from:
  - "[[elicitation-discipline]]"
  - "[[elicit-requirements]]"
updated: 2026-07-16
---

# Elicitation record thin

## When

Material rule is unknown and the brief says “just draft the requirements so we can move.”

## When not

Warrants already exist from a named elicitation mode/source.

## Choice

Fail [[elicitation-discipline]] / [[elicit-before-invent]]. Plan mode+target+prompts; escalate if targets unknown. Do not invent answers.
