---
type: example
status: draft
id: change-knowledge-base-ex-008
description: Thin exemplar — refuse flat inform-everyone engagement when influence differs.
derived_from:
  - "[[stakeholder-clarity]]"
  - "[[influence-interest-grid]]"
updated: 2026-07-16
---

# Influence interest thin

## When

Map lists ten parties all as “inform” though two can block the change.

## When not

Engagement differs by influence × interest with explicit strategy.

## Choice

Fail [[influence-shapes-engagement]]. Re-band via [[influence-interest-grid]]; escalate unknown influence — do not invent politics.
