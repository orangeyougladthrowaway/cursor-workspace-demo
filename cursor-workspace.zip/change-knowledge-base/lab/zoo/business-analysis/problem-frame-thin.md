---
type: example
status: draft
id: change-knowledge-base-ex-001
description: Thin exemplar — refuse a solution list with no named problem.
derived_from:
  - "[[problem-framing]]"
  - "[[frame-problem]]"
updated: 2026-07-16
---

# Problem frame thin

## When

Brief is only a feature wishlist (“add dashboard, add export”).

## When not

Problem and outcome are already named and warranted.

## Choice

Reject as incomplete under [[problem-framing]]. Ask for the problem and outcome; escalate domain facts. Do not invent a process story to justify the wishlist.
