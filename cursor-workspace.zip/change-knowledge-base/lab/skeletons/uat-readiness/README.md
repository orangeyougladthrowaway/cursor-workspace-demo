# UAT readiness skeleton

## Purpose

Copy-out starter for a UAT readiness assessment. Cite [[uat-readiness]] (`change-knowledge-base-s-018`).

## Required canons

- [[uat-readiness]] · [[intent-coverage]]
- Workflow: [[assess-uat-readiness]]

## Copy

1. Copy `readiness.md` into the host work area.
2. Confirm coverage; set observable entry/exit; state residual risk and roles.
3. Cite `change-knowledge-base-s-018`.

## Honesty

Skeleton ≠ doctrine. No "ready" with hidden gaps; escalate unknown env/data facts.
