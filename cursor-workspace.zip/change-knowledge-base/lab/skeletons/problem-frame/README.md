# Problem frame skeleton

## Purpose

Copy-out starter for a BA problem frame artefact. Cite and obey [[problem-framing]] (`change-knowledge-base-s-001`).

## Required canons

- [[problem-framing]]
- Workflow: [[frame-problem]]

## Copy

1. Copy this folder’s `frame.md` into the host work area.
2. Fill every section. Use `unknown — escalate` rather than inventing domain facts.
3. Cite `change-knowledge-base-s-001` in the artefact header.

## Honesty

This skeleton is **not** a second SoT. If it fights the standard, the standard wins — amend the skeleton.
