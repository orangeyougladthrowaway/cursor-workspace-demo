# Problem frame

- **Standard:** `change-knowledge-base-s-001` ([[problem-framing]])
- **Owner:**
- **Change / brief ref:**

## Problem

What is wrong or missing? (two readers must agree)

## Outcome

Who is better off, and how, if this is solved?

## Scope

| In | Out | Later |
| --- | --- | --- |
| | | |

## Material risks

| Risk | Why it matters |
| --- | --- |
| | |

## Warrants / sources

| Claim | Warrant or `unknown — escalate` |
| --- | --- |
| | |

## Open questions

-
