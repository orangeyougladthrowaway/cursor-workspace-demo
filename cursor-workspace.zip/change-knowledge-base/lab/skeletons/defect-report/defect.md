# Defect report

- **Standard:** `change-knowledge-base-s-017` ([[defect-clarity]])
- **Reporter:**

| Field | Content |
| --- | --- |
| Summary | |
| Expected | |
| Actual | |
| Reproduction | |
| Evidence (ref) | |
| Impact | |
| Severity | |
| Trace (condition/intent id) | |

## Escalation (ambiguous expected behaviour)

-
