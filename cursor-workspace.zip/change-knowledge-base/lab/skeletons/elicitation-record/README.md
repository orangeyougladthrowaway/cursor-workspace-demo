# Elicitation record skeleton

## Purpose

Copy-out starter for an elicitation plan/record. Cite [[elicitation-discipline]] (`change-knowledge-base-s-007`).

## Required canons

- [[elicitation-discipline]]
- [[elicitation-modes]]
- Workflow: [[elicit-requirements]]

## Copy

1. Copy `record.md` into the host work area.
2. Name unknowns, mode, target, prompts. Record findings without inventing answers.
3. Cite `change-knowledge-base-s-007`.

## Honesty

Skeleton ≠ doctrine. Empty findings with invented requirements = fail.
