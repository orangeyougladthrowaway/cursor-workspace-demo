# Risk register

- **Standard:** `change-knowledge-base-s-010` ([[risk-cadence]])
- **Owner:**
- **Review cadence:**

| Id | Statement (cause→event→effect) | Prob | Impact | Score | Response | Owner | Next review |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | |

## Issues (now)

| Id | Issue | Owner | Action |
| --- | --- | --- | --- |

## Assumptions / dependencies (RAID)

| Type | Statement | Owner | Status |
| --- | --- | --- | --- |
