# Status report skeleton

## Purpose

Copy-out starter for an evidence-backed status report. Cite [[status-reporting-honesty]] (`change-knowledge-base-s-011`).

## Required canons

- [[status-reporting-honesty]] · [[status-rag-honesty]]
- Workflow: [[report-status]]

## Copy

1. Copy `status.md` into the host work area.
2. Set RAG by threshold + evidence; name tradeoffs and asks.
3. Cite `change-knowledge-base-s-011`.

## Honesty

Skeleton ≠ doctrine. No watermelon green; no evidence-free progress.
