# Status report

- **Standard:** `change-knowledge-base-s-011` ([[status-reporting-honesty]])
- **Owner / date:**
- **Overall RAG:** (with evidence)

## Progress vs plan

| Milestone | Planned | Actual | Note |
| --- | --- | --- | --- |

## Risks / issues (movement)

-

## Tradeoffs (slips / descopes)

-

## Asks / decisions needed

-
