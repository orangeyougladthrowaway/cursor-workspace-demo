# Stakeholder map skeleton

## Purpose

Copy-out starter for a stakeholder map. Cite [[stakeholder-clarity]] (`change-knowledge-base-s-004`).

## Required canons

- [[stakeholder-clarity]]
- Workflow: [[map-stakeholders]]

## Copy

1. Copy `map.md` into the host work area.
2. Fill party · interest · impact · engagement · warrant. Use `unknown — escalate` for missing org facts.
3. Cite `change-knowledge-base-s-004`.

## Honesty

Skeleton ≠ doctrine. Not an org-chart dump.
