# Risk focus

- **Standard:** `change-knowledge-base-s-015` ([[risk-based-test-focus]])
- **Owner:**

| Area | Likelihood | Impact | Risk | Test depth | Tradeoff (lighter/none) |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

## Escalations (unknown domain risk)

-
