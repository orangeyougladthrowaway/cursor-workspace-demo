# BA change pass

- **Workflow:** `change-knowledge-base-wf-017` ([[ba-change-pass]])
- **Owner:**
- **Change / brief ref:**

| Step | Workflow | Standard | Status | Artefact ref | Escalations |
| --- | --- | --- | --- | --- | --- |
| 1 Frame | [[frame-problem]] | `change-knowledge-base-s-001` | | | |
| 2 Stakeholders | [[map-stakeholders]] | `change-knowledge-base-s-004` | | | |
| 3 Elicit | [[elicit-requirements]] | `change-knowledge-base-s-007` | | | |
| 4 Req quality | [[assess-requirements-quality]] | `change-knowledge-base-s-002` | | | |
| 5 Prioritise | [[prioritise-requirements]] | `change-knowledge-base-s-005` | | | |
| 6 Acceptance | [[write-acceptance-criteria]] | `change-knowledge-base-s-003` | | | |
| 7 Trace | [[trace-requirements]] | `change-knowledge-base-s-006` | | | |

## Pass verdict

not ready / ready — evidence:

## Tradeoffs / deferred

-
