# BA change pass skeleton

## Purpose

Checklist for one supervised BA pass across cells. Cite [[ba-change-pass]] (`change-knowledge-base-wf-017`).

## Required canons

- [[ba-change-pass]]
- Cell standards `change-knowledge-base-s-001` … `change-knowledge-base-s-007` as applicable

## Copy

1. Copy `pass.md` into the host work area.
2. Walk steps in order; mark escalate/pause honestly.
3. Do not invent domain facts to keep steps green.

## Honesty

Order is a default dependency, not sacred theatre. Skipping requires an explicit because.
