# TA analysis pass

- **Workflow:** `change-knowledge-base-wf-030` ([[ta-analysis-pass]])
- **Owner:**
- **Change ref:**

| Step | Workflow | Standard | Status | Artefact ref | Escalations |
| --- | --- | --- | --- | --- | --- |
| 1 Conditions | [[derive-test-conditions]] | `change-knowledge-base-s-014` | | | |
| 2 Risk focus | [[focus-by-risk]] | `change-knowledge-base-s-015` | | | |
| 3 Coverage | [[assess-intent-coverage]] | `change-knowledge-base-s-016` | | | |
| 4 Defects | [[report-defect]] | `change-knowledge-base-s-017` | | | |
| 5 UAT readiness | [[assess-uat-readiness]] | `change-knowledge-base-s-018` | | | |

## Pass verdict

not ready / ready — evidence:
