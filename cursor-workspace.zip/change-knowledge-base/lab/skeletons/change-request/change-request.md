# Change request

- **Standard:** `change-knowledge-base-s-012` ([[change-control]])
- **Owner:**
- **Baseline ref:**

## Delta (what changes)

## Reason (warranted)

## Impact

| Area | Effect |
| --- | --- |
| Scope | |
| Plan | |
| Cost | |
| Risk | |

## Options (incl. do-nothing)

-

## Decision

approve / reject / defer — **Approver:** — **Date:**

## Trace (affected items)

-
