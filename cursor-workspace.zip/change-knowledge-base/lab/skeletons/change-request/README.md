# Change request skeleton

## Purpose

Copy-out starter for a change control record. Cite [[change-control]] (`change-knowledge-base-s-012`).

## Required canons

- [[change-control]]
- Workflow: [[control-change]]

## Copy

1. Copy `change-request.md` into the host work area.
2. State delta, impact, options, decision, approver.
3. Cite `change-knowledge-base-s-012`.

## Honesty

Skeleton ≠ doctrine. No silent scope absorption; escalate unknown impact.
