# Project initiation charter

- **Standard:** `change-knowledge-base-s-008` ([[initiation-mandate]])
- **Owner:**
- **Sponsor / mandate:**

## Outcome (benefit sought)

## Scope

| In | Out | Assumptions | Constraints |
| --- | --- | --- | --- |
| | | | |

## Key stakeholders

| Party | Role in decision |
| --- | --- |

## Success measure

## Warrant / justification

`unknown — escalate` if not supplied.

## Open questions

-
