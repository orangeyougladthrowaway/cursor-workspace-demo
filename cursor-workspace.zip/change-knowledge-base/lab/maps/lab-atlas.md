---
type: map
status: draft
id: change-knowledge-base-map-lab
description: Praxis index — open after canons; never sole law.
updated: 2026-07-18
---

# Lab atlas

Index of praxis. **Retrieve canons first.** Mandatoriness: [[change-artefact-policy]]. Small-change path: [[small-change-control]]. Templates: [[project-artefact-pack]].

## BA track

| Cell | Canon | Workflow | Skeleton | Zoo |
| --- | --- | --- | --- | --- |
| BA01 | [[problem-framing]] | [[frame-problem]] | `problem-frame/` | [[problem-frame-thin]] · [[problem-frame-worked]] |
| BA02 | [[requirements-quality]] | [[assess-requirements-quality]] | `requirements-quality-pack/` | [[requirements-quality-thin]] |
| BA03 | [[acceptance-criteria]] | [[write-acceptance-criteria]] | `acceptance-criteria/` | [[acceptance-criteria-thin]] · [[acceptance-criteria-worked]] |
| BA04 | [[stakeholder-clarity]] | [[map-stakeholders]] | `stakeholder-map/` | [[stakeholder-map-thin]] · [[influence-interest-thin]] |
| BA05 | [[requirements-prioritisation]] | [[prioritise-requirements]] | `requirements-prioritisation/` | [[requirements-prioritisation-thin]] · [[moscow-bands-thin]] · [[requirements-prioritisation-worked]] |
| BA06 | [[requirements-traceability]] | [[trace-requirements]] | `requirements-traceability/` | [[requirements-traceability-thin]] |
| BA07 | [[elicitation-discipline]] | [[elicit-requirements]] | `elicitation-record/` | [[elicitation-record-thin]] |
| Journey | — | [[ba-change-pass]] | `ba-change-pass/` | [[ba-change-pass-thin]] |

## PM track

| Cell | Canon | Workflow | Skeleton | Zoo |
| --- | --- | --- | --- | --- |
| PM01 | [[initiation-mandate]] | [[initiate-project]] | `project-initiation/` | [[initiation-mandate-thin]] |
| PM02 | [[plan-honesty]] | [[build-plan]] | `delivery-plan/` | [[estimate-range-thin]] · [[plan-honesty-worked]] |
| PM03 | [[risk-cadence]] | [[run-risk-cadence]] | `risk-register/` | [[risk-cadence-thin]] · [[risk-cadence-worked]] |
| PM04 | [[status-reporting-honesty]] | [[report-status]] | `status-report/` | [[status-rag-thin]] · [[status-reporting-worked]] |
| PM05 | [[change-control]] | [[control-change]] | `change-request/` | [[change-control-thin]] |
| PM06 | [[closure-confirmation]] | [[close-delivery]] | `closure-report/` | [[closure-confirmation-thin]] |
| Journey | — | [[pm-delivery-pass]] | `pm-delivery-pass/` | — |

## TA track

| Cell | Canon | Workflow | Skeleton | Zoo |
| --- | --- | --- | --- | --- |
| TA01 | [[test-conditions]] | [[derive-test-conditions]] | `test-conditions/` | [[test-conditions-thin]] · [[test-conditions-worked]] |
| TA02 | [[risk-based-test-focus]] | [[focus-by-risk]] | `risk-focus/` | [[risk-focus-thin]] |
| TA03 | [[intent-coverage]] | [[assess-intent-coverage]] | `intent-coverage/` | [[intent-coverage-thin]] |
| TA04 | [[defect-clarity]] | [[report-defect]] | `defect-report/` | [[defect-clarity-thin]] · [[defect-clarity-worked]] |
| TA05 | [[uat-readiness]] | [[assess-uat-readiness]] | `uat-readiness/` | [[uat-readiness-thin]] |
| Journey | — | [[ta-analysis-pass]] | `ta-analysis-pass/` | [[ta-boundary-thin]] |

## Artefact pack (Tier-1 documents)

Full matrix on [[common-case-coverage]] (AR01–AR21). Approach index: [[project-artefact-pack]].

| Pack | Skeleton folder | Workflow |
| --- | --- | --- |
| ToR / business case / gap | `terms-of-reference/` · `business-case/` · `gap-analysis/` | [[write-terms-of-reference]] · [[write-business-case]] · [[write-gap-analysis]] |
| Requirements models | `requirements-catalogue/` · `use-case/` · `process-swimlane/` · `data-model/` · `nfr-schedule/` · `business-rules-catalogue/` | [[maintain-requirements-catalogue]] · [[write-use-case]] · [[model-process-swimlane]] · [[model-data]] · [[write-nfr-schedule]] · [[maintain-business-rules]] |
| Governance | `raid-pack/` · `raci-matrix/` · `communications-plan/` · `quality-plan/` · `decision-log/` · `assumption-log/` | [[maintain-raid-log]] · [[write-raci-matrix]] · [[write-communications-plan]] · [[write-quality-plan]] · [[log-decision]] · [[maintain-assumption-log]] |
| Testware | `test-plan/` · `test-case/` · `test-procedure/` · `test-completion-report/` · `uat-sign-off/` | [[write-test-plan]] · [[write-test-case]] · [[write-test-procedure]] · [[write-test-completion-report]] · [[record-uat-sign-off]] |
| Close | `post-implementation-review/` | [[write-post-implementation-review]] |

## Related

- [[praxis-ingestion]] · [[catalog-lab]] · [[common-case-coverage]] · [[project-artefact-pack]]
