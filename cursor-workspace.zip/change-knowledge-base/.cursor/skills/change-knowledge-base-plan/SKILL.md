---
name: change-knowledge-base-plan
description: Plans PM/BA/TA change work under change-knowledge-base authority. Use when asked to plan, scope, or sequence change-methods work.
disable-model-invocation: true
---

Follow `60-workflows/planning/plan-change-work.md` (`change-knowledge-base-wf-031`).

Retrieve before act. Escalate domain Gaps to systems-knowledge-base or the user. Do not edit files
unless asked to produce a plan artefact via a named cell workflow.
