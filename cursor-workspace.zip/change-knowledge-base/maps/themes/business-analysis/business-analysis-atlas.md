---
type: map
status: draft
id: change-knowledge-base-map-ba
concern: business-analysis
description: Theme atlas — business analysis methods body (indexes doctrine; not a BA curriculum).
updated: 2026-07-18
---

# Business analysis atlas

Index of BA methods knowledge in this vault. **Not** a task playbook.

## Living law

| Concern | Notes |
| --- | --- |
| analysis | [[problem-framing]] · [[frame-problem]] · [[gap-analysis]] · [[process-swimlane]] · end-to-end [[ba-change-pass]] |
| stakeholders | [[stakeholder-clarity]] · [[map-stakeholders]] · pattern [[influence-interest-grid]] |
| verification | [[acceptance-criteria]] · [[acceptance-criteria-craft]] · [[write-acceptance-criteria]] |
| requirements | [[elicitation-discipline]] · [[elicitation-craft]] · [[elicit-requirements]] · [[requirements-quality]] · [[assess-requirements-quality]] · [[definition-of-ready]] · [[definition-of-ready-craft]] · [[requirements-prioritisation]] · [[prioritise-requirements]] · [[requirements-traceability]] · [[trace-requirements]] · [[requirements-catalogue]] · [[use-case]] · [[data-model]] · [[nfr-schedule]] · [[business-rules-catalogue]] · patterns [[moscow-bands]], [[value-risk-matrix]], [[elicitation-modes]] |
| artefacts | [[change-artefact-policy]] · [[small-change-control]] · [[project-artefact-pack]] (Tier-1 templates + craft) |

## Praxis (after canon)

| Cell | Skeleton | Zoo |
| --- | --- | --- |
| BA01 | `problem-frame/` | [[problem-frame-thin]] |
| BA02 | `requirements-quality-pack/` | [[requirements-quality-thin]] |
| BA03 | `acceptance-criteria/` | [[acceptance-criteria-thin]] · [[acceptance-criteria-worked]] |
| BA04 | `stakeholder-map/` | [[stakeholder-map-thin]] · [[influence-interest-thin]] |
| BA05 | `requirements-prioritisation/` | [[requirements-prioritisation-thin]] · [[moscow-bands-thin]] |
| BA06 | `requirements-traceability/` | [[requirements-traceability-thin]] |
| BA07 | `elicitation-record/` | [[elicitation-record-thin]] |
| Journey | `ba-change-pass/` | [[ba-change-pass-thin]] |
| Pack | see [[lab-atlas]] Artefact pack | AR matrix on [[common-case-coverage]] |

Index: [[lab-atlas]]

## Untapped (honest)

- Dry-runs (Axis U4) before `canonical` promotion — see [[roadmap]]
- Deep primary-source harvest — deferred ([[ingest-coverage]])
- Tool/system specialisations — out of scope while abstract

## Related

- [[catalog-maps]] · [[common-case-coverage]] · [[staff-agent-projection]] · [[project-artefact-pack]]
