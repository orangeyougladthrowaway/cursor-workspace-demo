---
type: category
status: draft
id: change-knowledge-base-cat-honesty
description: Spine for honesty — status and quality claims match evidence.
updated: 2026-07-16
---

# Honesty

## Theme

Green-washed status and inflated quality destroy trust in change artefacts.

## Leaves

- [[status-matches-evidence]]
- [[tradeoff-visible]]
- [[estimate-shows-uncertainty]]
