---
type: principle
status: draft
id: change-knowledge-base-p-016
category: honesty
description: Prioritisation and coverage claims must show what was traded away.
derived_from:
  - "[[honesty]]"
updated: 2026-07-16
---

# Tradeoff visible

When ranking or declaring coverage, name what is **deferred, reduced, or rejected**. Invisible tradeoffs are status theatre.
