---
type: principle
status: draft
id: change-knowledge-base-p-008
category: authority
description: Each living change artefact names an owner and its role as source of truth.
derived_from:
  - "[[authority]]"
updated: 2026-07-16
---

# Artefact has owner

Requirement packs, frames, and acceptance sets name **who maintains them** and that they are the lived SoT for that question — not a shadow copy in chat.
