---
type: principle
status: draft
id: change-knowledge-base-p-013
category: authority
description: Material intents stay linked across frame, requirement, and acceptance artefacts.
derived_from:
  - "[[authority]]"
updated: 2026-07-16
---

# Link across artefacts

When a requirement, acceptance criterion, or scope bound changes, the **links** that keep intent coherent must be updated or explicitly broken with a recorded delta. Orphan rows are method failure.
