---
type: principle
status: draft
id: change-knowledge-base-p-012
category: value
description: Rank work by outcome and risk of delay — not by who shouted last.
derived_from:
  - "[[value]]"
updated: 2026-07-16
---

# Rank by outcome

Prioritisation states **why this before that** in terms of outcome and material risk. Popularity, tool defaults, or silent FIFO are not house method.
