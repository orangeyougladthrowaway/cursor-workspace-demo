---
type: category
status: draft
id: change-knowledge-base-cat-value
description: Spine for value — prefer outcomes that matter over output volume.
updated: 2026-07-16
---

# Value

## Theme

Output without outcome is busywork. Frame and prioritise toward valued change.

## Leaves

- [[outcome-over-output]]
- [[rank-by-outcome]]
- [[close-confirms-benefit]]
