---
type: principle
status: draft
id: change-knowledge-base-p-015
category: clarity
description: Engagement intensity follows influence and interest — not alphabetical contact lists.
derived_from:
  - "[[clarity]]"
updated: 2026-07-16
---

# Influence shapes engagement

Treat stakeholders differently by **influence** (can they enable or block?) and **interest** (do they care about this change?). Uniform “keep everyone informed” is not clarity.
