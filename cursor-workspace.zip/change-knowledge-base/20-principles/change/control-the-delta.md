---
type: principle
status: draft
id: change-knowledge-base-p-009
category: change
description: Material changes to agreed scope or intent go through an explicit control step.
derived_from:
  - "[[change]]"
updated: 2026-07-16
---

# Control the delta

When the problem, scope, or acceptance intent shifts materially, record the delta and who approved it. Silent absorption is not house method.
