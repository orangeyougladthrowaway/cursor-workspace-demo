---
type: principle
status: draft
id: change-knowledge-base-p-014
category: evidence
description: Gather warrants from people and artefacts before writing requirements as if known.
derived_from:
  - "[[evidence]]"
updated: 2026-07-16
---

# Elicit before invent

Requirements and rules that lack an elicitation warrant are invention. Prefer a named elicitation mode and source over filling fields to look complete.
