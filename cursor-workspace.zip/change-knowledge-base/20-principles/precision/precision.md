---
type: category
status: draft
id: change-knowledge-base-cat-precision
description: Spine for precision — artefacts must name grain fine enough to implement and verify without re-eliciting.
updated: 2026-07-20
---

# Precision

## Theme

Vague methods artefacts create silent rework. High-quality documentation **demands** named grain — not adjective fog, not blank theatre.

## Belongs here

Principles about how fine artefacts must be (fields, measures, transforms, observables) once a topic is in scope.

## Does not belong here

Whether a claim is warranted ([[evidence]]); whether to invent missing domain facts ([[restraint]] / [[enough-to-decide]]); engineering DDL as methods substitute.

## Leaves

- [[precision-over-vagueness]]
