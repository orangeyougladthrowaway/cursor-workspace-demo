---
type: principle
status: draft
id: change-knowledge-base-p-014
category: precision
description: Once a topic is in scope, name it at the grain needed to build and verify — refuse adjective-only and table-name-only theatre.
derived_from:
  - "[[precision]]"
  - "[[clarity]]"
updated: 2026-07-20
---

# Precision over vagueness

When an artefact covers a topic, state it at **actionable grain**. Prefer one precise row over a paragraph that cannot be implemented or tested.

## Grain examples (not exhaustive)

| Domain of change | Insufficient | Sufficient grain |
| --- | --- | --- |
| Requirements | “System shall historise customers” | Source module/API + target store + business key + historised attributes + change/delete rule |
| Acceptance | “SCD2 works” | Observable close/open/tombstone/noop behaviours on named keys/hashes |
| Data | Entity names only | Logical model **plus**, for data/integration work, source→target field map (db.schema.table.column or explicit eng DDL link) and transforms |
| NFR | “Secure / scalable” | Named measure or check |
| Test conditions | AC paraphrase only | Distinct positive / negative / boundary claims where intent implies them |
| Plan / status | “Build done” | Exit tied to AC ids and evidence type |

## Relationship to [[enough-to-decide]]

**Enough** forbids inventing missing facts. It does **not** license vague artefacts for in-scope topics. If grain cannot be named → Gap / blocked — not Ready.

## Refuse

- Adjective-only intent
- Catalogue rows that hide grain in chat
- Logical-only data packs for material store/API work when physical mapping is needed and unwarranted
