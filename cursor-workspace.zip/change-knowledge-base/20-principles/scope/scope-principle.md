---
type: category
status: draft
id: change-knowledge-base-cat-scope-principle
description: Spine for scope — bound what is in and out of the change.
updated: 2026-07-16
---

# Scope principle

## Theme

Unbounded change absorbs infinite work. Bound what is in, out, and deferred.

Stem `scope-principle` avoids collision with foundation [[scope]].

## Leaves

- [[bound-the-change]]
