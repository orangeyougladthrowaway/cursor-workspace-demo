---
type: category
status: draft
id: change-knowledge-base-cat-verification
description: Spine for verification — intent must be checkable without inventing domain lore.
updated: 2026-07-16
---

# Verification

## Theme

Unverifiable acceptance language postpones disagreement until build or UAT pain.

## Leaves

- [[intent-must-be-testable]]
- [[condition-derives-from-intent]]
- [[coverage-measures-intent]]
