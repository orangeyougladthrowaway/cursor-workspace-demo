---
type: principle
status: draft
id: change-knowledge-base-p-021
category: verification
description: Test conditions derive from stated intent (requirements, acceptance, risk) — not from imagination.
derived_from:
  - "[[verification]]"
updated: 2026-07-16
---

# Condition derives from intent

Every test condition traces back to a **stated intent**: a requirement, acceptance criterion, or named risk. Conditions with no upstream intent are invented scope.
