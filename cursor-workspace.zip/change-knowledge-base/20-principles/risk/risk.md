---
type: category
status: draft
id: change-knowledge-base-cat-risk
description: Spine for risk — uncertainty that matters shapes attention and verification.
updated: 2026-07-16
---

# Risk

## Theme

Not all uncertainty is equal. Attention and verification follow what can hurt the change.

## Leaves

- [[risk-shapes-attention]]
- [[risk-managed-continuously]]
