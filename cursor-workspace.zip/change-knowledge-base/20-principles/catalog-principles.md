---
type: catalog
status: draft
id: change-knowledge-base-cat-principles
description: Principles — open a concept folder, then the leaf.
updated: 2026-07-16
---

# Catalog — Principles

Drill: `20-principles/{concept}/` → spine → leaf.

| Concept | Spine | Leaves |
| --- | --- | --- |
| clarity | [[clarity]] | [[name-the-problem]], [[name-who-matters]], [[influence-shapes-engagement]] |
| precision | [[precision]] | [[precision-over-vagueness]] |
| evidence | [[evidence]] | [[claim-needs-warrant]], [[elicit-before-invent]], [[defect-carries-evidence]] |
| risk | [[risk]] | [[risk-shapes-attention]], [[risk-managed-continuously]] |
| scope | [[scope-principle]] | [[bound-the-change]] |
| value | [[value]] | [[outcome-over-output]], [[rank-by-outcome]], [[close-confirms-benefit]] |
| verification | [[verification]] | [[intent-must-be-testable]], [[condition-derives-from-intent]], [[coverage-measures-intent]] |
| honesty | [[honesty]] | [[status-matches-evidence]], [[tradeoff-visible]], [[estimate-shows-uncertainty]] |
| authority | [[authority]] | [[artefact-has-owner]], [[link-across-artefacts]], [[work-needs-mandate]] |
| change | [[change]] | [[control-the-delta]] |
| restraint | [[restraint]] | [[enough-to-decide]] |

[[navigation]]
