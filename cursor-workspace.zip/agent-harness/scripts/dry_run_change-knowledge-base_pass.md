# Human dry-run checklist — change-knowledge-base passes

Use after change-knowledge-base skills exist. Score against named standards; do not invent domain facts.

1. Open change-knowledge-base `staff-agent-projection` and the relevant theme atlas.
2. Invoke `change-knowledge-base-plan` for a small change brief.
3. Invoke `change-knowledge-base-produce` naming a cell workflow (e.g. `frame-problem`) — write deliverables in the **consumer/product** workspace, not into this vault or harness dumps.
4. Invoke `change-knowledge-base-verify` against the standard field tests.
5. Invoke `change-knowledge-base-review` — findings first; no green-wash.
6. Record Gaps / escalations in the chat or PR — not in vault doctrine, not in harness `artefacts/` / audit logs.

Optional journeys: `ba-change-pass`, `pm-delivery-pass`, `ta-analysis-pass`.
