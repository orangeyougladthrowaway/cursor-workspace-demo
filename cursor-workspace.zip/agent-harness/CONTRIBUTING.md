# Contributing — agent-harness

## Branches

| Branch | Use |
| --- | --- |
| `main` | Protected — PR required; **`pytest`** must pass |
| `feature/<id>-<short-name>` | Default work (`<id>` = Boards id when tracked) |
| `bug/<id>-<short-name>` | Fixes |
| `chore/<id>-<short-name>` | Tooling / meta |

Omit `<id>` only for vault-style harness amends with no tracker item. Claim before implement when Boards-tracked — `docs/workflows/claim-ado-work.md`.

No long-lived `dev` / `uat` / `prod`.

## Pull requests

1. Branch from latest `main` (or your team’s agreed integration branch).
2. Keep the PR focused.
3. Ensure CI job **`pytest`** is green.
4. Merge only via PR into `main`.

House detail: [`docs/source-control.md`](docs/source-control.md).  
New user setup: [`docs/setup.md`](docs/setup.md).  
New vault: skill `harness-create-knowledge-base`.

## Local checks

```bash
python -m pip install -e ".[dev]"
pytest tests/ -v
```
