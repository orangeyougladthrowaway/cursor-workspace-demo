"""Profile → cwd / write-wall / skill hints (runtime binding of vault projection)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ProfileBinding:
    profile: str
    cwd_env: str
    default_skill: str
    default_workflow: str
    write_mode: str
    allowed_vaults: tuple[str, ...]


PROFILES: dict[str, ProfileBinding] = {
    "eng": ProfileBinding(
        profile="eng",
        cwd_env="ENGINEERING_KNOWLEDGE_BASE_OR_PRODUCT",
        default_skill="engineering-knowledge-base-plan",
        default_workflow="plan-engineering-change",
        write_mode="implement",
        allowed_vaults=("engineering-knowledge-base", "harness"),
    ),
    "pm": ProfileBinding(
        profile="pm",
        cwd_env="CHANGE_KNOWLEDGE_BASE",
        default_skill="change-knowledge-base-plan",
        default_workflow="plan-change-work",
        write_mode="produce_artefact",
        allowed_vaults=("change-knowledge-base", "systems-knowledge-base", "harness"),
    ),
    "ba": ProfileBinding(
        profile="ba",
        cwd_env="CHANGE_KNOWLEDGE_BASE",
        default_skill="change-knowledge-base-produce",
        default_workflow="produce-change-artefact",
        write_mode="produce_artefact",
        allowed_vaults=("change-knowledge-base", "systems-knowledge-base", "harness"),
    ),
    "ta": ProfileBinding(
        profile="ta",
        cwd_env="CHANGE_KNOWLEDGE_BASE",
        default_skill="change-knowledge-base-produce",
        default_workflow="produce-change-artefact",
        write_mode="produce_artefact",
        allowed_vaults=("change-knowledge-base", "systems-knowledge-base", "harness"),
    ),
    "domain": ProfileBinding(
        profile="domain",
        cwd_env="SYSTEMS_KNOWLEDGE_BASE",
        default_skill="systems-knowledge-base-lookup",
        default_workflow="lookup-domain-truth",
        write_mode="read_only",
        allowed_vaults=("systems-knowledge-base", "harness"),
    ),
    "harness": ProfileBinding(
        profile="harness",
        cwd_env="HARNESS",
        default_skill="harness-start",
        default_workflow="start-work",
        write_mode="implement",
        allowed_vaults=("harness",),
    ),
}


def get_profile(name: str) -> ProfileBinding:
    try:
        return PROFILES[name]
    except KeyError as exc:
        raise KeyError(f"unknown profile: {name}") from exc
