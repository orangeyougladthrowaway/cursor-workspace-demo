"""Ephemeral local task ledger (gitignored store/) for cross-session resume."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

OPEN_STATUSES = frozenset({"draft", "ready", "running", "blocked"})
COMPLETED_STATUSES = frozenset({"done", "cancelled"})


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _id() -> str:
    return f"task-{uuid4().hex[:12]}"


def default_store_path(repo_root: Path | None = None) -> Path:
    root = repo_root or Path.cwd()
    return root / "store" / "tasks.json"


class EphemeralTaskStore:
    """Single JSON file of tasks keyed by task_id. Never commit this file."""

    def __init__(self, path: Path) -> None:
        self.path = path

    def _read(self) -> dict[str, dict[str, Any]]:
        if not self.path.exists():
            return {}
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        if isinstance(raw, dict) and "tasks" in raw:
            return {k: v for k, v in raw["tasks"].items() if isinstance(v, dict)}
        if isinstance(raw, dict):
            return {k: v for k, v in raw.items() if isinstance(v, dict) and "task_id" in v}
        return {}

    def _write(self, tasks: dict[str, dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"tasks": tasks, "updated_at": _now()}
        self.path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def list_all(self) -> list[dict[str, Any]]:
        return list(self._read().values())

    def list_open(self) -> list[dict[str, Any]]:
        return [t for t in self.list_all() if t.get("status") in OPEN_STATUSES]

    def list_completed(self) -> list[dict[str, Any]]:
        return [t for t in self.list_all() if t.get("status") in COMPLETED_STATUSES]

    def get(self, task_id: str) -> dict[str, Any] | None:
        return self._read().get(task_id)

    def upsert(self, task: dict[str, Any]) -> dict[str, Any]:
        if "task_id" not in task:
            task = {**task, "task_id": _id()}
        if "created_at" not in task:
            task = {**task, "created_at": _now()}
        tasks = self._read()
        tasks[task["task_id"]] = task
        self._write(tasks)
        return task

    def update(self, task_id: str, **fields: Any) -> dict[str, Any]:
        tasks = self._read()
        if task_id not in tasks:
            raise KeyError(f"unknown task_id: {task_id}")
        tasks[task_id] = {**tasks[task_id], **fields}
        self._write(tasks)
        return tasks[task_id]

    def purge(self, task_ids: list[str] | None = None, *, completed_only: bool = False) -> list[str]:
        """Remove tasks. If task_ids is None and completed_only, purge all done/cancelled."""
        tasks = self._read()
        if task_ids is None:
            if completed_only:
                victim_ids = [tid for tid, t in tasks.items() if t.get("status") in COMPLETED_STATUSES]
            else:
                victim_ids = list(tasks.keys())
        else:
            victim_ids = list(task_ids)
        removed: list[str] = []
        for tid in victim_ids:
            if tid in tasks:
                if completed_only and tasks[tid].get("status") not in COMPLETED_STATUSES:
                    continue
                del tasks[tid]
                removed.append(tid)
        self._write(tasks)
        if not tasks and self.path.exists():
            self.path.unlink()
            if self.path.parent.exists() and not any(self.path.parent.iterdir()):
                self.path.parent.rmdir()
        return removed

    def create(
        self,
        goal: str,
        profile: str,
        *,
        acceptance: list[str] | None = None,
        status: str = "ready",
        write_mode: str = "read_only",
        allowed_vaults: list[str] | None = None,
        constraints: list[str] | None = None,
    ) -> dict[str, Any]:
        task = {
            "task_id": _id(),
            "created_at": _now(),
            "goal": goal,
            "profile": profile,
            "status": status,
            "acceptance": acceptance or [],
            "constraints": constraints or [],
            "parent_task_id": None,
            "allowed_vaults": allowed_vaults or ["harness"],
            "write_mode": write_mode,
            "cited_ids": [],
        }
        return self.upsert(task)
