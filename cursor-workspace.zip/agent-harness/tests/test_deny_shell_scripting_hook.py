"""Tests for agent-harness beforeShellExecution shell-shape gate."""

from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

HOOK = Path(__file__).resolve().parents[1] / ".cursor" / "hooks" / "deny_shell_scripting.py"


def _load():
    spec = importlib.util.spec_from_file_location("deny_shell_scripting", HOOK)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture(scope="module")
def gate():
    return _load()


@pytest.mark.parametrize(
    "command",
    [
        "python -m pytest -q",
        'git commit -m "fix: a; b && c"',
        "git status",
        'python -c "print(len(s.list_open()))"',
        "az login",
        "az acr login --name zccontainers",
    ],
)
def test_allow_single_instruction(gate, command: str) -> None:
    assert gate.decide(command)["permission"] == "allow"


@pytest.mark.parametrize(
    "command",
    [
        "pip install -e . -q && pytest -q",
        "pip install -e . -q; pytest -q",
        "cd X:\\repos\\demo && pytest -q",
        "Set-Location X:\\repos\\demo; pytest -q",
        "echo hi | Out-File x.txt",
        "if ($true) { pytest }",
        "Remove-Item -Recurse store",
        "rm -rf store",
        "pytest\npytest",
        "cat <<EOF\nhi\nEOF",
        'python -c "a=1; print(a)"',
        "az repos pr update --id 25 --auto-complete true",
        "az rest --method patch --uri https://dev.azure.com/org/proj/_apis/git/pullrequests/25",
        "az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798",
        "Invoke-RestMethod -Uri https://dev.azure.com/org/_apis/wit/workitems/1",
        "curl https://dev.azure.com/org/proj/_apis/git/repositories/r/pullrequests/25",
        "docker push zccontainers.azurecr.io/platform/gateway:20260726.3",
        "az acr import --name zccontainers --source elsewhere/image:1",
    ],
)
def test_deny_scripting_shape(gate, command: str) -> None:
    decision = gate.decide(command)
    assert decision["permission"] == "deny"
    assert "agent_message" in decision


def test_ado_deny_mentions_mcp(gate) -> None:
    decision = gate.decide("az repos pr list")
    assert decision["permission"] == "deny"
    assert "MCP-only" in decision["agent_message"]


def test_acr_push_deny_mentions_publish(gate) -> None:
    decision = gate.decide(
        "docker push zccontainers.azurecr.io/platform/db-api:20260726.3"
    )
    assert decision["permission"] == "deny"
    assert "containers-publish" in decision["agent_message"]
