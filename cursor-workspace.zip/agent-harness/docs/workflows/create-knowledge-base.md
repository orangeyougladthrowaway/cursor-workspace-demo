---
id: harness-wf-create-knowledge-base
status: draft
description: Create and link a new sibling *-knowledge-base under the harness hub.
updated: 2026-07-18
---

# Create knowledge base

Mint a new vault remote and wire it into the house. Harness **orchestrates**; it does not become a second bible.

## Purpose

Add `{domain}-knowledge-base` as a sibling repo with full-kebab naming, thin projection, and the same source-control / CI rules as existing vaults.

## Preconditions

- User intent and owning role named
- Harness workspace available
- Agreement on vault **token**: `{domain}-knowledge-base` (kebab-case; **no new acronyms**)
- Scope clear vs existing vaults (engineering / change / systems / others)

## Retrieve

1. [`docs/setup.md`](../setup.md) — sibling layout, catalogue, missing-vault Gaps
2. [`docs/source-control.md`](../source-control.md) — branches, PR, pytest gate
3. An existing vault as **structure** reference (not doctrine to copy):
   - Domain-like → `systems-knowledge-base`
   - Methods-like → `change-knowledge-base`
   - Engineering-like → `engineering-knowledge-base`

## Steps

1. **Name and scope** — write one paragraph: owns / does not own; lane(s) it serves.
2. **Remote** — create empty host repo with the same token name; assign owners; plan to protect `main` after first green `pytest`.
3. **Scaffold** — copy **structure** only from the reference vault (foundation folders, authority rule stub, `AGENTS.md` stub, vault-health tests + `.github/workflows/vault-health.yml`, empty maps). **Do not** paste foreign note bodies.
4. **Ids and skills** — note `id:` prefix = `{token}-…`; skills named `{token}-plan` (etc.) pointing at workflows under that vault.
5. **Local sibling** — clone beside `agent-harness`.
6. **Link in hub**
   - Add a row to the catalogue in [`docs/setup.md`](../setup.md)
   - Optional folder in `agent-harness.code-workspace`
   - Optional mount `.{token}` (gitignored)
   - Authority table row in harness `AGENTS.md` if it is a house-standard vault
7. **Source control** — add root `CONTRIBUTING.md` (same branch table; point at harness `docs/source-control.md`).
8. **Verify** — `pytest tests/ -v` in the new vault; open workspace; confirm other vaults can remain missing without breaking harness-only work.
9. **Stop** — do not paste vault doctrine into harness docs or skills.

## Output

- Vault token + remote URL + owner
- Local path
- Catalogue / workspace / AGENTS updates listed
- Confirmation CI workflow present

## Forbidden

- Inventing an opaque acronym (e.g. inventing `mkb` for marketing)
- Scaffolding by dumping another vault’s note bodies
- Putting the new vault inside harness as a subdirectory instead of its own remote
- Declaring the vault “ready” without health tests / CONTRIBUTING / hub link

## Related

- Skill: `harness-create-knowledge-base`
- Setup: [`docs/setup.md`](../setup.md)
- Source control: [`docs/source-control.md`](../source-control.md)
