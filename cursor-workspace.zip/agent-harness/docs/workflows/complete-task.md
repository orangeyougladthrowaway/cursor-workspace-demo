---
id: harness-wf-complete-task
status: draft
description: Close a Task and ask the user whether to purge ephemeral local store records.
updated: 2026-07-26
---

# Complete task

Close in-flight harness work and decide what happens to the **local** resume record under gitignored `store/`.

## Purpose

Tasks exist so a **new agent session** can resume without chat history. Once work is finished, that local record is optional clutter — **ask** before deleting.

## Preconditions

- A `task_id` (from `store/tasks.json` or the user)
- Goal met, cancelled, abandoned, or user wants to sweep completed leftovers

## Pause / leave vocabulary (when Boards linked)

| Intent | Task `status` | ADO claim (`ado_claim_ids`) | Boards |
| --- | --- | --- | --- |
| Blocked (may resume) | `blocked` | **Keep** AssignedTo | Active + blocker comment |
| Cancelled or abandon | `cancelled` | **Unassign** all claim ids | New+unassigned if still valid; Removed if junk |
| Done with evidence | `done` | Keep until Closed | Closed only per eng gates + source-control Close timing |

Follow [`claim-ado-work.md`](claim-ado-work.md) for MCP release steps. Never Close Boards from purge alone.

## Steps

1. **Load** the task via `harness-task` / `EphemeralTaskStore`.
2. If Boards-linked and leaving ownership (cancel/abandon): unassign claim set **before** treating local status as final.
3. If status is not already terminal, set `status` to `done` or `cancelled` (and note why). For blocked mid-flight, leave `blocked` and do **not** unassign.
4. If `done` and `ado_id` set: confirm with user that Boards Closed (or explicitly leave Active with reason).
5. **Ask the user** (required — do not skip):

   | Option | Meaning |
   | --- | --- |
   | **A — Purge** (default offer) | Delete this task from `store/` now |
   | **B — Keep locally** | Leave in `store/` (still gitignored); will ask again on later start-work sweeps |
   | **C — Elevate then purge** | First copy lasting content to product repo / PR / vault ingestion; then purge |

6. Execute the chosen option. For **A** or **C** after elevate: `EphemeralTaskStore.purge([task_id])` (or `completed_only=True` for sweeps).
7. If sweeping **all** completed leftovers: list `list_completed()`, ask once for batch purge vs keep.

## Output

- Task id + final status
- Claim release / keep / Close confirmation (if linked)
- User choice (A/B/C)
- Whether `store/` still contains this task

## Forbidden

- Silent delete without asking
- Committing `store/`
- Writing closure novels under `artefacts/`
- Treating local store as a compliance audit trail
- Unassigning because the Task is merely **blocked**
- Closing Boards without eng evidence

## Related

- Skills: `harness-complete-task`, `harness-task`, `harness-start`, `harness-ado-mcp`
- Resume entry: `docs/workflows/start-work.md` (step 0)
- Claim: [`claim-ado-work.md`](claim-ado-work.md)
