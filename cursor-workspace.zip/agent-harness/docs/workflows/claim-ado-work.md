---
id: harness-wf-claim-ado
status: draft
description: Claim an ADO Story bundle before implement; release on cancel/abandon; keep assign when blocked.
updated: 2026-07-26
---

# Claim ADO work

Parallel-safe ownership for Boards-tracked delivery. **ADO AssignedTo is the team lock**; harness `store/` only mirrors for resume.

Grain, good-item rules, and pause vocabulary → change-knowledge-base `work-item-hygiene` / craft. Platform fields → systems `azure-devops-org`. Done evidence → eng `delivery-gates`. Branch shapes → [`docs/source-control.md`](../source-control.md).

## Purpose

Before implementing tracked product/lib/containers/SQL-product work: claim a coherent set, refuse collision, link the ephemeral Task, then branch with the primary id.

## Preconditions

- User or Task gates MCP writes
- ADO MCP available (`docs/agent-ops/mcp.md`)
- A real work item id (never invent)
- Current user identity from `az login` (same identity MCP uses)

## Claim grain (v1)

| Include | Exclude |
| --- | --- |
| User Story (primary) **or** Bug (when bug-led) | Whole Epic / Feature for eng implement |
| Child Tasks under that Story | Unrelated Stories |
| Bugs in scope for the same change/PR | Items AssignedTo someone else |

Multi-Story WIP is allowed. Organisation comes from hierarchy + branch ids — not a one-Story cap.

## Steps

### 1. Discover

1. Read the candidate item(s) via MCP (get by id or WIQL).
2. Confirm type/grain with change `work-item-hygiene` (Story vs Feature vs Task).
3. For eng implement: Story should meet `definition-of-ready` (or user explicitly accepts Gap).

### 2. Preflight assignees

1. Build the claim set (primary + children + in-scope Bugs).
2. Batch-read assignees.
3. If **any** item has `AssignedTo` set to someone **other than** the current user → **stop**. Report owners. Do not reassign without explicit user ask.
4. If all are unassigned **or** already AssignedTo current user → continue.

### 3. Claim (gated write)

1. Set `System.AssignedTo` = current user on every id in the set.
2. Set Story/Task/Bug state to **Active** where that transition is valid (Bugs: Active; do not invent Removed).
3. Prefer one batch update when the tool allows; otherwise update each id (still one MCP call per item — no shell chaining).

### 4. Mirror locally

Upsert harness Task (`harness-task` → `store/`):

- `ado_id` / `ado_url` = primary Story or Bug
- `ado_claim_ids` = full set
- `ado_claimed_at` = now
- `status` = `running` (or `ready` if not yet coding)
- Copy acceptance from Story AC when present

### 5. Branch

Follow [`docs/source-control.md`](../source-control.md):

- Mainline: `feature/<ado_id>-<slug>` from `main` (or `bug/<id>-…`)
- SQL product: same name pattern from **`prod`**
- Prefer create branch **from** the work item in ADO

### 6. Release / pause (when leaving)

| Intent | Harness | Claim | Boards |
| --- | --- | --- | --- |
| **Blocked** (may resume) | `blocked` | **Keep** AssignedTo | Stay Active; comment blocker |
| **Cancelled** / **abandon** | `cancelled` | **Unassign** whole `ado_claim_ids` | New + unassigned if still backlog-worthy; **Removed** if junk |
| **Done** (evidence) | `done` then complete-task | Keep until Closed | Closed only per eng gates + Close timing table in source-control |

Never Close Boards from Task purge alone. Never implement when AssignedTo ≠ current user.

## Forbidden

- Inventing work-item ids
- Claiming an Epic/Feature as the eng implement unit (decompose first)
- Working items owned by someone else
- Dual-writing Done/Closed from local Task status
- Treating `store/` as the team claim registry

## Related

- Skills: `harness-ado-mcp`, `harness-task`, `harness-start`, `harness-complete-task`
- [`docs/agent-ops/mcp.md`](../agent-ops/mcp.md) · [`start-work.md`](start-work.md) · [`complete-task.md`](complete-task.md)
