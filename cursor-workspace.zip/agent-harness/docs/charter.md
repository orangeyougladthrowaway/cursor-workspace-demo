# Charter — agent-harness

**Status:** draft product charter (not vault doctrine)  
**Updated:** 2026-07-26

## Purpose

Task-triggered control plane and harness so PM/BA/TA/domain/eng agents can be allocated and gated — while engineering-knowledge-base, change-knowledge-base, and systems-knowledge-base (and future sibling vaults) remain the living authorities.

## In scope

- Schemas for Task, Allocation, GateResult, Escalation (handoff shapes)
- Thin control-plane helpers and **ephemeral** local Tasks in gitignored `store/` for cross-session resume
- Thin Cursor consumer projection (`AGENTS.md`, rules)
- Task-agnostic programme entry: skill `harness-start` → `docs/workflows/start-work.md`
- Task close + purge consent: `harness-complete-task` → `docs/workflows/complete-task.md`
- House setup, source-control policy, and create-knowledge-base workflow (hub only)
- Adapters for Cursor IDE / later SDK-CLI

## Out of scope (near term)

- Always-on agent fleet
- Dumping run history into knowledge bases or committed harness dumps (`artefacts/`)
- Append-only compliance audit theatre in this repo
- Fat skills that reprint vault doctrine
- Unattended API orchestration until IDE skills prove out
- Merging harness + vaults into one git monorepo

## Decision catalogue (open)

| Topic | Options / notes | Owner lane |
| --- | --- | --- |
| Language | Python chosen for bootstrap; revisit if TS SDK preferred | product + engineering-knowledge-base |
| Ephemeral Tasks | gitignored `store/`; purge on complete with user consent | product |
| Runtime | Local IDE-first; SDK deferred | product |
| Approvals | Allocate / ship / vault-amend need an explicit gate (chat ask and/or branch policy). Real-org merge: mandatory reviewers. Lab may self-merge until that policy exists. | product + change-knowledge-base |
| Secrets | OS/env; never in vaults or committed store | engineering-knowledge-base trust |
| Budget | Caps TBD before unattended | product |
| Elevation | Stable patterns → engineering-knowledge-base/change-knowledge-base; not run logs | all vaults |

## Success

Schema-valid handoffs (chat/PR + ephemeral store for resume); vault retrieve + cite ids; Gaps escalate; completed local trails purged when the user agrees.
