# Agent ops — Azure DevOps MCP

How agents use the house **ADO MCP** from agent-harness. Systems vault owns what ADO *is*; change owns work-item grain/goodness; eng owns Done evidence. This note is **wiring + agent behaviour only** — not a second bible.

## Preconditions (human / getting-started)

| Need | Where |
| --- | --- |
| Node.js 20+ (`node`, `npx` on PATH) | Machine install |
| Azure CLI + `az login` | Machine; auth for `--authentication azcli` |
| `ADO_ORG=<org-name-only>` | **`agent-harness/.env`** (gitignored) — **never** Windows system/user env for house portability |
| MCP config | `.cursor/mcp.json` → runs `.cursor/run_ado_mcp.py` (loads `.env`, then `npx @azure-devops/mcp`) |

Copy `.env.example` → `.env` and fill `ADO_ORG`. Restart Cursor after changing `.env` or MCP config. **Manually Enable** server **ado** in Cursor **Settings → MCP** (project MCP is not auto-enabled — lived). Then start a **new** Agent chat.

After changing MCP **domains** in `run_ado_mcp.py`: restart Cursor (or reload MCP), re-Enable **ado**, **new** Agent chat — otherwise the session keeps the old tool set.

## Agent protocol (every session)

1. **Discover tools** — MCP discovery for server `ado` (do not web-search Microsoft docs mid-task for basic list/read).
2. If **ado missing** → stop. Tell the user: `.env` `ADO_ORG`, Node on PATH, `az login`, MCP Enabled, new chat after restart. Do not invent org names or PATs.
3. **Read before write** — list/get work items, PRs, or pipeline runs first. Controlled creates/updates only when the Task/workflow allows and the user gated writes.
4. **Domains (house)** — `core` + `work-items` + `repositories` + `pipelines` (wired in `.cursor/run_ado_mcp.py`).
5. **Ids** — never invent work-item ids. Prefer batch-by-id. Link Task `ado_id` / `ado_url` / `ado_claim_ids` when known; **ADO is shared status SoT**.
6. **Secrets** — no PAT in `mcp.json`, `.env.example`, chat dumps, or git.
7. **Authority** — good items / grain / claim → change `work-item-hygiene`. Done evidence → eng `delivery-gates`. PR shape → [`docs/source-control.md`](../source-control.md). Platform → systems `azure-devops-org`. Pipeline create/wire (human once) → [`docs/setup.md`](../setup.md) (ADO CI) · release order → [`docs/release-chain.md`](../release-chain.md).
8. **MCP only for ADO Boards / Repos / Pipelines agent work** — see hard ban below. If MCP fails, errors, or cannot complete the asked action → **stop and report to the user**. Do not switch tools.

## Hard ban — no `az` / REST ADO fallback

Agents must **not** work around ADO MCP with Azure CLI or raw HTTP.

| Forbidden (agent) | Allowed elsewhere |
| --- | --- |
| `az repos` / `az boards` / `az pipelines` / `az artifacts` / `az devops` | Human console if they choose |
| `az rest` (ADO or otherwise as a Boards/PR/pipelines substitute) | — |
| `az account get-access-token` aimed at ADO / `dev.azure.com` to drive REST | — |
| `curl` / `Invoke-RestMethod` / `Invoke-WebRequest` to `dev.azure.com` / `_apis/wit` / `_apis/git` / `_apis/build` / `_apis/pipelines` | — |
| Any other CLI/SDK path that duplicates MCP Boards/PR/pipelines work | — |

| Still OK (not MCP substitutes) | Why |
| --- | --- |
| Human / agent `az login` | MCP auth precondition (`--authentication azcli`) |
| `az acr login` / `docker pull` | Registry identity — not Boards/PR/pipelines |

**On MCP failure:** stop. Report the exact MCP error / missing capability. Ask the user what to do. Do **not** “just use az” or craft an ADO REST call.

## Smoke prompts (after Enabled)

- List projects in the configured org
- List recent work items (do **not** create probe items unless the user asks)
- List repos / open a draft PR only when the user asks
- List recent pipeline runs / get a run for `containers-test` or `containers-publish` (read-only smoke)

## Agent WIT lifecycle (Boards SoT)

Harness ephemeral Tasks may link via `ado_id` / `ado_url` / `ado_claim_ids`. **ADO is shared status SoT**; Task `status` is session-local and must not silently close the work item. **`store/` is not a team lock.**

| Step | Do | Do not |
| --- | --- | --- |
| Discover | MCP list/get; re-read assignees on resume | Invent org, project, or ids |
| Plan | Align title/AC with change `work-item-hygiene` + `definition-of-ready` | Paste vault bodies into the work item |
| Claim | Follow [`docs/workflows/claim-ado-work.md`](../workflows/claim-ado-work.md) — Story + child Tasks + in-scope Bugs → AssignedTo=me, Active | Implement when AssignedTo ≠ me; claim whole Epic for eng |
| Link Task | Set `ado_id`/`ado_url`/`ado_claim_ids`/`ado_claimed_at` | Dual-write conflicting Done/Closed |
| Implement | Branch `feature/<id>-<slug>` (or `bug/…`) per [`docs/source-control.md`](../source-control.md) | Invent `<id>` |
| PR | Follow **PR lifecycle** below (create → poll BV → confirm → approve + autocomplete) | Silent approve/autocomplete; `az repos` / REST |
| CI wait | MCP `pipelines` — poll Build Validation until terminal; publish after merge | Poll with `az pipelines`; invent run status; poll other human approvers |
| Blocked | Keep AssignedTo; Task=`blocked`; comment blocker | Unassign because paused |
| Cancel / abandon | Unassign whole claim set; Task=`cancelled` | Leave ghost Active ownership |
| Evidence | PR `#id` + CI green; eng `delivery-gates` | Close from Task purge alone |
| Close | Boards Closed when Close-timing table says so; then `harness-complete-task` | Auto-complete without green evidence |

**Multi-Story WIP:** allowed.

**Permanent destroy:** not an agent path. Soft-remove = Removed / unassign; Bugs often **Closed** instead of Removed.

## Pull requests (MCP `repositories`)

Full title/body/link conventions: [`docs/source-control.md`](../source-control.md) (Pull requests section).

### PR lifecycle (agent SoT)

Default path for every agent-driven PR. Do **not** skip the confirm step because the user earlier said “open a PR” or “push”.

| Step | Do | Do not |
| --- | --- | --- |
| **1. Create** | `repo_create_pull_request` — source `refs/heads/…`, target `refs/heads/main` (or SQL env target); title/body/link per source-control; work-item ids when required | `az repos` / REST; invent work-item ids |
| **2. Poll CI** | MCP `pipelines` — list/get the PR’s Build Validation (`*-test`) until **terminal** (succeeded / failed / cancelled) | Invent status; poll forever without reporting; use `az pipelines` |
| **3. CI failed** | **Stop.** Report failing run + root cause. Discuss with the user, agree a fix, push, return to step 2 | Approve, autocomplete, or “fix forward” without agreement |
| **4. CI passed** | **Stop and ask** explicitly: CI green on PR `#N` — approve + set autocomplete? | Approve or autocomplete on green alone; treat “create PR” / “push” as merge consent |
| **5. On user yes** | `repo_vote_pull_request` **Approved**, then set **autocomplete** (house default: squash + delete source branch unless the user says otherwise) | Silent approve; policy-bypass without an explicit user ask; `az` / REST if MCP fails |
| **6. Other required approvers** | After casting your vote: **no polling loop**. Ad-hoc check only when the user returns or the agent is otherwise continuing; if still waiting, say so and stop | Poll other humans on an interval; block the session spinning on reviewer votes |
| **7. After merge** | For publish repos: poll `*-publish` per release-chain (still MCP `pipelines`) | Assume Artifacts/ACR updated without a green publish run |

**Draft / labels:** draft (`isDraft: true`) when WIP; labels only if the repo already uses them — default none.

**MCP failure / stuck complete:** stop and report — never `az` / REST / invent a complete path. If autocomplete is set, CI is green, and the PR stays Active (e.g. self-approve limits), report and ask the user to Complete in the UI or grant an explicit next step.

**Lab vs real org:** lab may be a single reviewer so step 5 can land the PR once the user confirms after green CI. A real org should set **mandatory reviewers** / no self-approve on `main` — then step 6 applies; branch policy is the hard gate; skills are soft.

**Controlled writes:** create/update only when the user or Task gates writes. Pre-authorisation phrases like “push and merge” / “land it” count as step-4 consent **for that PR** once CI is green — still run steps 1–3 first; still cast Approve + autocomplete only after green.

## Pipelines (MCP `pipelines`)

House CI SoT (which pipelines exist, Build Validation, publish vs test): [`docs/setup.md`](../setup.md) (ADO CI) · artefact order: [`docs/release-chain.md`](../release-chain.md).

| Action | When | Tool / rule |
| --- | --- | --- |
| **List / get runs** | Waiting on Build Validation or `*-publish` after merge | MCP pipelines tools — discover schema first |
| **Queue / cancel / update** | Only when the user explicitly asks | Gated write; prefer human UI for first-time pipeline create |
| **Create pipeline definitions** | Human once in ADO UI | Not an agent day-one path — follow setup.md |

Do **not** use `az pipelines` or pipeline REST as a substitute. If MCP pipelines tools are missing after domain enable → stop and report (restart / re-Enable / new chat).

## Related

- `.cursor/mcp.example.json` · `.cursor/run_ado_mcp.py` · `.env.example`
- `docs/setup.md` · `docs/source-control.md` · `docs/workflows/claim-ado-work.md` · `docs/release-chain.md`
- eng `credential-class-storage` · `code-review-norm` · systems `azure-devops-org` · change `work-item-hygiene`
