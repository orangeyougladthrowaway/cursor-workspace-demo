# Agent ops — commands

Shell, git, and Task-store rules for **agent-harness** sessions. Not vault doctrine.

ADO MCP (Boards + PRs): [`mcp.md`](mcp.md) · skill `harness-ado-mcp` · claim workflow [`../workflows/claim-ado-work.md`](../workflows/claim-ado-work.md).

**ADO Boards/PR/pipelines agent work is MCP-only.** Do not use `az repos` / `az boards` / `az pipelines` / `az devops` / `az rest` / raw ADO HTTP as a substitute. If MCP fails → stop and report. Shell hard-gate also denies those `az` shapes (see Hook coverage). Domains: `core` + `work-items` + `repositories` + `pipelines` (`run_ado_mcp.py`). `az login` (MCP auth) and `az acr login` (pull identity) remain allowed.

**ACR image publish is ADO-only.** Never `docker push` (or equivalent) to the house ACR from a laptop/agent session. Images reach ACR only via merge to `main` → `containers-publish`. Local `docker build` for PR/proof is fine; `az acr login` + Compose **pull** is fine.

On command failure: re-read this page. If the case is **new**, propose a patch here before inventing a workaround.

## Authority split (policy vs gate)

| Layer | Owns | Location |
| --- | --- | --- |
| **Policy (SoT)** | What is allowed / forbidden and why | **this file** |
| **Hard gate** | Deny non-compliant Shell before it runs | `.cursor/hooks.json` → `beforeShellExecution` → `.cursor/hooks/deny_shell_scripting.py` |
| **Thin pointers** | Always-on reminder only — do not fork the recipe | `AGENTS.md` · `.cursor/rules/harness-authority.mdc` · skills |

Prose without the hook is soft. The hook without this doc is opaque. Keep them aligned; extend **both** when adding a new shell anti-pattern.

## Hard rules

| Rule | Do | Do not |
| --- | --- | --- |
| Dependencies | Use the environment the user already has | Local `pip install` / `npm install` / similar unless the user asks |
| Read files | Cursor **Read** / **Grep** / **Glob** | Shell `type` / `Get-Content` / `cat` / `head` |
| Edit files | Cursor **Write** / **StrReplace** | Shell bulk edit unless the user explicitly approves |
| Git | Only when the user explicitly allows | Own-initiative `status` / `commit` / `push` |
| Shell shape | **One single-line instruction per Shell call** (set `working_directory` instead of `cd`) | Multi-statement lines; `;` / `&&` / `\|\|` / `\|` chains; heredocs; `python -c` with loops/ifs/multi-statements; scripts; branching; dynamics |
| Delete / prune files | Cursor **Delete** (one path per call, or a few parallel Deletes) | Shell `Remove-Item` / `rm` / `del` / `rmdir` |
| Task store | File path `store/tasks.json`; short upsert/get/list; purge with `completed_only=True` | Directory `store/` to `EphemeralTaskStore`; `purge()` with no args (wipes **all** tasks including open) |
| ADO Boards / PRs / pipeline runs | MCP tools only (`harness-ado-mcp` / `mcp.md`; domains include `pipelines`) | `az repos` / `az boards` / `az pipelines` / `az artifacts` / `az devops` / `az rest`; ADO REST via curl/IRM; stop + report on MCP fail |
| ACR image publish | Merge → `containers-publish` only | `docker push` / `az acr import` / laptop publish to house ACR |

## Prefer tools over shell

| Intent | Prefer |
| --- | --- |
| Open / skim a file | Read |
| Find a symbol | Grep |
| Find a file by name | Glob |
| Change code/docs | Write / StrReplace |
| Delete a path | Cursor **Delete** |
| Run tests (when asked) | Short `pytest` in the target repo cwd |

## Shell — hard shape

Every Shell call must be **one instruction on one line**. No scripting in the shell.

| Allowed | Forbidden |
| --- | --- |
| `python -m pytest -q` | `cmd1; cmd2` or `cmd1 && cmd2` |
| `python -c "print(len(s.list_open()))"` (tiny, no `;` / control flow) | Heredoc / here-string / multi-line `-c` / `-c` with `;` |
| Set cwd via tool `working_directory` | `Set-Location` / `cd` inside the command |
| One git verb when user asked (`git status`) | Pipelines; `if` / `for` / `while` / `try` |
| | Embedding full Task JSON or multi-upsert scripts |

Need several steps → **several Shell calls** (or Cursor tools). Never pack a workflow into one command.

**On deny:** split into separate Shell calls. Do **not** “fix” a blocked `&&` by rewriting it as `;` — that is the same violation.

```powershell
# Good — cwd via working_directory = X:\repos\demo-cloud-data-warehouse
python -m pytest -q

# Bad (hook denies)
Set-Location X:\repos\demo-cloud-data-warehouse; python -m pytest -q
cd X:\repos\demo-cloud-data-warehouse && python -m pytest -q
pip install -e ".[dev]" -q && pytest -q
```

### Hook coverage (gate)

`deny_shell_scripting.py` denies when the command (outside quotes, unless noted) shows:

- `;` · `&&` · `||` · `|` · newlines · heredoc / here-string markers
- `cd` / `Set-Location` / `Push-Location` / `chdir`
- shell control-flow keywords (`if` / `for` / `while` / `try` / …)
- wipe verbs (`Remove-Item` / `rm` / `del` / `rmdir`)
- `python -c` / `py -c` bodies with `;`, newlines, or control-flow
- ADO MCP workarounds: `az repos` / `az boards` / `az pipelines` / `az artifacts` / `az devops` / `az rest`; `az account get-access-token` aimed at ADO; `curl` / `Invoke-RestMethod` / `Invoke-WebRequest` to `dev.azure.com` / `visualstudio.com` / `_apis/wit` / `_apis/git`
- ACR laptop publish: `docker push` to `*.azurecr.io` (or any `az acr` write that publishes images)

Still allowed: `az login`, `az acr login` (pull), local `docker build` (no push to house ACR).

Operators **inside** quoted commit messages are ignored (e.g. `git commit -m "fix: a; b"`). Residual Gap: exotic PowerShell quoting / escaped operators not listed above — extend the hook + this section together.

## Search-tool path syntax (Windows)

`Grep` / `Glob` run ripgrep. On this Windows host, passing an **absolute** path to
`Grep.path` or `Glob.target_directory` fails hard:

```text
rg: : IO error for operation on : The system cannot find the path specified. (os error 3)
```

| Tool | Absolute path arg | Do |
| --- | --- | --- |
| `Grep` / `Glob` | **Breaks** (`os error 3`) | Omit `path` / `target_directory` (searches all workspace roots) **or** pass a **workspace-relative** path (e.g. `maps/families/zoho/*.md`); scope by reading the per-root results |
| `Read` / `Write` / `StrReplace` / `Delete` | Fine | Absolute `X:/repos/...` (forward or back slash) |
| `Shell` | Fine | Set cwd via tool `working_directory` only — one instruction; gate enforces shape |

This is a **call-technique** fault, not an environment outage — do not "wait it out". Fix the path arg and retry.

## Transient workspace reload (the real outage case)

The opposite of the fault above: when the **workspace folder set changes** mid-session (a repo added/removed — system reminder "Workspace folders changed…"), the tool backend reindexes and briefly drops calls. Tell: **all** surfaces fail at once (`Write` / `StrReplace` / `Shell` spawn) with "Tool failed; this may be temporary", alongside a workspace-change notice — not one tool with a syntax error.

Proper approach: pause a few seconds and **retry the same call** once or twice unchanged (do not rewrite content or switch technique). Confirm recovery with a trivial `Write-Output "ok"`, then **re-verify which writes actually persisted** before resuming — partial batches are normal. If it persists past ~2 retries, stop and tell the user rather than looping.

## Git publish (when user asks)

Three **separate** Shell calls (cwd = target repo via `working_directory`):

```powershell
git add -A
```

```powershell
git commit -m "short why-focused message"
```

```powershell
git push
```

| Rule | Detail |
| --- | --- |
| Allow | Only when the user asks to add / commit / push |
| `git add -A` | Default stage for these repos |
| Message | One `-m` string; prefer why — `git commit -m "message"` only |
| Attribution | Do **not** add `Co-authored-by` / `Made-with` trailers. **Human must** turn off **Cursor Settings → Agents → Attribution → Commit Attribution** and **PR Attribution** (otherwise Cursor injects `--trailer`). See [`docs/setup.md`](../setup.md) |
| `git push` | Current branch upstream (`-u` on first push of a new branch only) |
| Never | Commit `store/`; force-push `main`; `--no-verify` unless asked |
| Multi-repo | One cwd + sequence per repo |

Branch / PR rules: [`docs/source-control.md`](../source-control.md).

## Task store

Prefer Cursor **Read** / **Write** / **StrReplace** on `store/tasks.json` for create/update/restore.

Do **not** use multi-statement `python -c` for Task CRUD — the shell gate denies `;` inside `-c`. Prefer editing `store/tasks.json` with Write / StrReplace, or a future `python -m agent_harness…` one-liner if added.

- `list_open()` returns **dicts** — keys `task_id` / `goal` / `status` (not `t.id`).
- Constructor: `default_store_path(Path('.'))` → `store/tasks.json` (file, not directory).
- Never commit `store/`. On `done` / `cancelled`: ask before purge (`harness-complete-task`).
- Do not combine multi-repo git sweeps with Task Python in one command.
- **Purge:** always `s.purge(completed_only=True)` (or pass explicit `task_ids=[…]`). Bare `s.purge()` deletes every task.
- **Upsert / restore:** edit `store/tasks.json` via Write / StrReplace. Do not embed Task bodies in shell.
- If a `python -c` needs loops, branches, or more than one statement → stop; use Write / StrReplace instead.

## Patterns

| Pattern | Why |
| --- | --- |
| `EphemeralTaskStore(default_store_path(repo_root))` | Correct JSON path |
| Cursor Read / Grep / Glob / patches | Correct I/O surface |
| One Shell instruction; cwd via `working_directory`; hook deny on scripting | Enforceable, reviewable |
| User-approved `pytest` in repo cwd | Small honest gate |
| User-asked git: separate calls `git add -A` then `git commit -m "…"` then `git push` | House publish sequence |
| Cite vault ids; write only in the allowed wall | Authority split |

## Anti-patterns

| Anti-pattern | Symptom / risk |
| --- | --- |
| `EphemeralTaskStore(Path("…/store"))` | Often `PermissionError` on Windows — wrong path |
| Task row as object (`t.id`) | `AttributeError: 'dict' object has no attribute 'id'` |
| `;` / `&&` / `\|` chaining, heredocs, loops, `if` in Shell | Hook deny; wipe / review risk |
| Rewriting denied `&&` as `;` | Same violation; still denied |
| Multi-repo / huge pasted blocks | Timeouts, quoting breakage |
| `python -c @"…"` / multi-statement Task CRUD | Bypasses shell shape; easy to wipe store |
| `s.purge()` without `completed_only=True` | Deletes open Tasks; resume trail gone |
| Dep installs without ask | Pollutes machine |
| Shell file-read / bulk rewrite / bulk `Remove-Item` | Bypasses tools; prune must use **Delete** |
| Absolute path to `Grep.path` / `Glob.target_directory` | `rg … os error 3`; omit or use workspace-relative path |
| Treating a fixable tool error as an outage and waiting | Burns cycles; check syntax/call technique first |
| Git without user allow | History / push surprises |
| Alternate publish ritual when standard was asked | Drift |
| Commit `store/` or write `artefacts/` | Forbidden |

## Related

- `AGENTS.md` · skill `harness-task`
- `.cursor/hooks.json` · `.cursor/hooks/deny_shell_scripting.py`
- `docs/workflows/start-work.md` · `docs/workflows/complete-task.md`
