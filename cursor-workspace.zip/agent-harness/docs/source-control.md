# Source control — house rules

Applies to **agent-harness** and every `*-knowledge-base` repo. Keep local copies thin (`CONTRIBUTING.md` in each repo); this note is the hub summary.

Product / library / containers remotes follow the same branch and PR shape, with the hosting and work-item rules below.

## Publish (agent-ops)

When the user asks to commit/push current work, use the sequence in [`docs/agent-ops/commands.md`](agent-ops/commands.md): `git add -A` → `git commit -m "…"` → `git push` (one repo cwd at a time). Do not invent a different default ritual.

## Hosting

| Repo class | Primary | Backup | Notes |
| --- | --- | --- | --- |
| Vaults (`agent-harness`, `*-knowledge-base`) | **ADO Repos** | GitHub remote `github` (history backup) | Doctrine; `pytest` is the gate — work-item linking is **not** required |
| Product code (`python-lib`, `containers`, products) | **ADO Repos** | GitHub remote `github` (history backup) | Work-item linking **is** required once branch policy is enabled |
| SQL Server **product** repos | **ADO Repos** (typical) | As configured | Long-lived `dev`/`uat`/`prod` — eng `sql-server-env-branches`; still use work-item id in feature names |

**Lived cutover (2026-07-26):** six house remotes use ADO as `origin` / day-to-day push target; GitHub keeps full prior history as backup only. Do not force-push over the GitHub backup. Turn on ADO build validation and (for product/lib/containers) **Check for linked work items** once pipelines have a green run.

## Branches

### Mainline (harness, vaults, lib, containers, normal products)

| Branch | Use |
| --- | --- |
| `main` | Protected integration line — **PR required** |
| `feature/<id>-<short-name>` | Default work. `<id>` = primary work-item id when tracked |
| `bug/<id>-<short-name>` | Fixes |
| `chore/<id>-<short-name>` | Tooling / meta when tracked |

No long-lived `dev` / `uat` / `prod` on these repos. Merge to `main` is the release line for docs and vault health.

Omit `<id>` only for **vault-only** amends with no tracker item.

### SQL Server product carve-out (unchanged topology)

Doctrine: engineering-knowledge-base `sql-env-release-assembly` · `sql-server-env-branches`.

| Branch | Role |
| --- | --- |
| `feature/<id>-<short-name>` | Selectable unit — cut from **`prod`**; optional early PR → `dev` |
| `dev` / `uat` / `prod` | Persistent env lines (PR-gated) |
| `release/<name>` | Assembly from `prod` + selected feature tips |
| `hotfix/<id>-<short-name>` | From `prod` for production fixes |

**Same claim + id naming as mainline.** Do not change env/release structure — only require `<id>` in feature/hotfix names when Boards tracks the work.

### Consumer app repos (pin promotion)

App repos that consume house wheels/images across DEV/UAT/PROD promote **immutable** artefacts rather than rebuilding per env (eng `environment-promotion`). `dev`/`uat` may track the newest published tag; `prod` pins an exact tag and is bumped only by a reviewed PR carrying a tag already proven in UAT. Downstream for a platform change = read each consumer repo's pin files at the time — those pins are the SoT.

## Work items ↔ code ↔ claim

| Concern | ADO Repos (primary) | GitHub backup (legacy) |
| --- | --- | --- |
| Link syntax | `#123`; create the branch **from** the work item to auto-link | `AB#123` only if a PR still targets GitHub |
| Enforcement | Branch policy **“Check for linked work items” = Required** (product/lib/containers) | Not required on backup host |
| Claim | AssignedTo = you before implement — [`docs/workflows/claim-ado-work.md`](workflows/claim-ado-work.md) | n/a |
| State transition | Prefer complete linked items after merge when policy allows | Manual |
| Build evidence | ADO Pipelines on PR / integration line | GHA optional / unused for publish |

House rules regardless of host:

1. The **PR** is the authoritative link point — squash merges discard per-commit links.
2. An agent **never invents a work-item id**. No id for product/lib/containers/SQL-product work → stop and ask.
3. Vault repos are exempt from work-item linking; `pytest` remains their gate.
4. Harness Tasks may carry `ado_id` / `ado_url` / `ado_claim_ids` (`schemas/task.schema.json`). Boards is shared status SoT; Task `status` is session-local.
5. Do not implement when AssignedTo ≠ current user (claim workflow).
6. Good item grain/content → change-knowledge-base `work-item-hygiene`. Done evidence → eng `delivery-gates`.

### Close timing (honest Done)

| Topology | Close Story/Bug when |
| --- | --- |
| Mainline → `main` | PR merged + hard gates green (`delivery-gates`) |
| SQL product | Feature tip **shipped** (prod promote + publish evidence). Merge to `dev` alone is **not** Done |

## Pull requests

### Shape

- One concern per PR; prefer small PRs.
- Target `main` (mainline) or the env/release target named in eng SQL doctrine.
- **Required check:** the repo’s `pytest` (or product CI) job must pass before merge.
- Vault content amends still follow that vault’s ingestion / changing-this-bible — branching ≠ doctrine process.
- Ownership is **per remote**: reviewers/CODEOWNERS on that repo; harness does not merge foreign vault PRs.

### Title

- Short **imperative** summary that stands alone in history (same bar as eng `code-review-norm` CL first line).
- Outcome-shaped: what the PR delivers, not “WIP” / “updates” / “Phase 1”.
- Optional conventional prefix when it helps scan history: `feat:`, `fix:`, `docs:`, `chore:` — keep the rest human-readable.
- When a work item exists, you may include the id: `feat: #42 publish python-lib wheels from main CI`.

### Description

| Section | Content |
| --- | --- |
| **Summary** | What changed and why (1–3 bullets) |
| **Work items** | `#123` (and child ids if useful) — omit only when vault-exempt or no tracker yet |
| **Test plan** | What CI / local checks prove; for release-chain PRs: “PR = Test only; Publish on merge to main” |
| **Notes** | Risks, follow-ups, pin/order constraints (`lib` before `containers`) |

Bad: empty body, “see commits”, or a paste of the whole diff.

### Work-item link

1. Prefer create branch **from** the work item (auto-link).
2. On the PR: include `#<id>` in the description (and title if useful).
3. MCP create may also pass work-item ids when the tool supports it.
4. Product/lib/containers: once branch policy “Check for linked work items” is **Required**, no id → stop and ask.
5. Vaults: linking optional; `pytest` remains the gate.

### Labels (tags)

Optional. Do not invent a taxonomy. Use only labels the project already maintains. Default: **no labels**.

### Agent create / merge (ADO MCP)

- **MCP only** for create / vote / autocomplete / complete / merge (`repo_create_pull_request`, …). **Never** `az repos`, `az rest`, or raw ADO HTTP as a fallback.
- **Lifecycle SoT:** create → poll Build Validation → on fail discuss/fix → on green **ask** → approve + autocomplete → other approvers ad-hoc (no poll). Full table: [`docs/agent-ops/mcp.md`](agent-ops/mcp.md) (PR lifecycle).
- If MCP fails or cannot finish the asked merge → **stop and report** to the user (do not invent a CLI/API path).
- **CI status while waiting:** MCP `pipelines` domain (list/get runs) — not `az pipelines`.
- **Real org:** set mandatory reviewers / no self-approve on `main` so agents cannot land code unchecked — policy is the hard gate.

## CI — pytest on PR

**Every** house repo has an ADO `<repo>-test` pipeline that runs pytest on pull requests into `main`. Azure Repos ignores YAML `pr:` triggers, so each one is queued by a **Build Validation** branch policy on `main` — attach it once per repo and mark it **Required**. The YAML sets `trigger: none` so the test pipeline never runs on merge; publishing repos have a separate `*-publish` pipeline for that.

| Repo | ADO test pipeline | YAML | Publishes? |
| --- | --- | --- | --- |
| agent-harness | `agent-harness-test` | `agent-harness-test.yml` | no |
| engineering-knowledge-base | `engineering-knowledge-base-test` | `engineering-knowledge-base-test.yml` | no |
| change-knowledge-base | `change-knowledge-base-test` | `change-knowledge-base-test.yml` | no |
| systems-knowledge-base | `systems-knowledge-base-test` | `systems-knowledge-base-test.yml` | no |
| python-lib | `python-lib-test` | `python-lib-test.yml` | `python-lib-publish` → Artifacts |
| containers | `containers-test` | `containers-test.yml` | `containers-publish` → ACR |

Never attach a `*-publish` pipeline to a branch policy — releasing must not run pre-merge. Full create/wire checklist (all eight pipelines + Build Validation + first green): [`docs/setup.md`](setup.md) (ADO CI). What the publish pipelines produce, and the order to run them in: [`docs/release-chain.md`](release-chain.md).

GitHub Actions mirrors (`.github/workflows/`) may still run where a repo is also mirrored to GitHub; ADO is primary and the mirror must not diverge.

### Enable branch protection (human)

**ADO (primary)** — per repo, once the `<repo>-test` pipeline exists:

1. Repos → **Branches** → `main` → **⋯** → **Branch policies**
2. **Build Validation** → **+** → build pipeline = that repo's **`<repo>-test`** (never `*-publish`)
3. Trigger **Automatic** · requirement **Required** · path filter blank · expire when `main` updates
4. (Optional) Minimum reviewers; product/lib/containers: **Check for linked work items** once CI is green

**GitHub mirror (if used)** — Settings → Branches → rule for `main` → require a PR → require status check **`pytest`**.

Tune review count to taste.

## Related

- [`docs/agent-ops/mcp.md`](agent-ops/mcp.md) · [`docs/workflows/claim-ado-work.md`](workflows/claim-ado-work.md) · [`docs/release-chain.md`](release-chain.md)
- eng `credential-class-storage` · `sql-server-env-branches` · `environment-promotion` · change `work-item-hygiene` · systems `azure-devops-org`
