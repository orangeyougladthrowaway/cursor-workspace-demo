# Setup — agent-harness (step by step)

Build the local Cursor workspace and Azure DevOps / Azure wiring so you can PR, publish wheels and images, and smoke-test sandbox.

Doctrine stays in the knowledge-base repos. `agent-harness` holds setup, MCP wiring, and control-plane docs. Remotes: Azure DevOps Repos = **`origin`**. Optional GitHub remotes are history backup only ([`source-control.md`](source-control.md)).

## Assumptions (out of scope here)

You already have:

- An **Azure tenant**
- An **Azure DevOps organisation**

This guide does **not** walk creating the tenant or the ADO org. Everything below starts from “org exists; now wire the rest.”

## What you will end up with

| Layer | Outcome |
| --- | --- |
| Local | Sibling clones under one parent; multi-root workspace open in Cursor |
| Azure | **ACR** (Basic or org SKU; Admin user **Disabled**); your identity can `az acr login` (AcrPull) |
| ADO project | Repos for each tree below; Artifacts feed; pipelines; Build Validation on `main` |
| Publish path | `python-lib` wheel on the feed → `containers` images on ACR |
| Laptop smoke | Sandbox Compose pulls ACR + runs orchestrator smoke |
| Agents | ADO MCP Enabled (`core` + `work-items` + `repositories` + `pipelines`) |

---

## Requirements (complete list)

Capture these before or during wiring. Skip nothing that applies to your role (sandbox smoke needs Finnhub; MCP needs Node).

### A — Already assumed

| Requirement | Notes |
| --- | --- |
| Azure tenant | Exists (out of scope to create) |
| Azure DevOps organisation | Exists (out of scope to create) |

### B — Request from IT (before first ACR pull / smoke)

| Requirement | Notes |
| --- | --- |
| **Docker Desktop paid licence** | Business/Pro (or org standard). Free Personal is not the assumed path. Needed for sandbox Compose and local image proof. |
| **Azure subscription access** | Rights to use (or create resources in) `<subscription>` |
| **ACR Basic** (or org-standard SKU) | Registry for `platform/*` images — or rights to create one. **Admin user Disabled**. Laptop pull via AcrPull + `az acr login`. |

### C — Laptop software (must be on PATH)

Install so these commands work in a **new** terminal (Cursor integrated terminal included):

| Requirement | On PATH | Why | Check |
| --- | --- | --- | --- |
| **Git** | `git` | Clone / commit / push | `git --version` |
| **Python 3.12+** | `python` | Harness, lib, sandbox, scripts | `python --version` |
| **pip** | `pip` and/or `python -m pip` | Install `build`, editable harness, deps | `python -m pip --version` |
| **build** (PyPA) | via pip | Local wheels for sandbox / image proof | `python -m pip install build` then `python -m build --help` |
| **Node.js 20+** | `node` | ADO MCP runtime | `node --version` |
| **npm** | `npm` | Ships with Node; keep on PATH | `npm --version` |
| **npx** | `npx` | MCP launches `@azure-devops/mcp` | `npx --version` |
| **Docker Desktop** (paid) | `docker` | Compose + local `docker build` | `docker version` |
| **Azure CLI** | `az` | `az login`, `az account set`, `az acr login` | `az version` |
| **Cursor** | — | Multi-root workspace, Agent, MCP Enable | App installed |

If `python` / `node` / `npm` / `npx` / `docker` / `az` / `git` fail with “not recognized”, fix PATH (and reopen the terminal) before continuing.

Optional later: `python -m pip install -e ".[dev]"` inside `agent-harness` for local pytest.

### D — Accounts, keys, and cloud access

| Requirement | Notes |
| --- | --- |
| ADO user in `<ado-org>` | Can open the project; create/use Repos, Pipelines, Artifacts, Service connections as needed for your role |
| Azure identity | `az login` works against `<subscription>` |
| **AcrPull** on the ACR | Your user (and anyone pulling on a laptop) |
| ADO **Build Service** → Artifacts feed **Contributor** | So publish can upload wheels |
| Docker Registry **service connection** name | For `containers-publish` (`ACR_SERVICE_CONNECTION`) |
| **`ADO_ORG`** | Org name only — in gitignored `agent-harness/.env` (MCP) |
| **`FINNHUB_API_KEY`** | Required for full sandbox orchestrator smoke (local `.env` only) |
| **`ACR_HOST`** / **`IMAGE_TAG`** | Local sandbox `.env` only — never commit lived values |

### E — Cursor configuration

| Requirement | Notes |
| --- | --- |
| **Commit Attribution OFF** | Settings → Agents → Attribution |
| **PR Attribution OFF** | Same panel — do not allow Cursor `Co-authored-by` trailers |
| Restart Cursor after Attribution change | — |
| MCP server **ado** manually Enabled | Settings → MCP (not auto-enabled) |
| New Agent chat after MCP / domain changes | Old chats keep stale tool sets |

### F — Git identity

| Requirement | Notes |
| --- | --- |
| `user.name` / `user.email` | Org identity for commits (global or per-repo) |

---

## Step 0 — Decide names (do not commit lived values)

Write these down locally (password manager / notepad). **Never** commit them into the repos.

| Placeholder | Meaning |
| --- | --- |
| `<ado-org>` | ADO organisation name |
| `<ado-project>` | ADO project that will hold these repos (create in Step 2 if needed) |
| `<subscription>` | Azure subscription id or name |
| `<acr-name>` | ACR resource name (short name for `az acr login --name`) |
| `<acr-login-server>` | Usually `<acr-name>.azurecr.io` → becomes local `ACR_HOST` |
| `<feed-name>` | Artifacts feed name |
| `<ARTIFACTS_FEED>` | `ProjectName/FeedName` if project-scoped (common), or feed name only if org-scoped |
| `<ACR_SERVICE_CONNECTION>` | Exact name of the Docker Registry service connection in ADO |

Clone URL shape:

```text
https://dev.azure.com/<ado-org>/<ado-project>/_git/<repo-name>
```

---

## Step 1 — Confirm laptop requirements

Run every **Check** in [Requirements §C](#c--laptop-software-must-be-on-path). Confirm IT items in §B are approved or already provisioned. Confirm Git identity (§F) and plan Cursor Attribution OFF (§E) before first commit/PR.

Do not continue to Azure/ADO wiring if `python`, `node`, `npm`, `npx`, `docker`, `az`, or `git` are missing from PATH.

---

## Step 2 — Azure identity (subscription)

1. `az login`
2. `az account set --subscription <subscription>`
3. Confirm: `az account show` (correct subscription)

Keep using this subscription for ACR and any role assignments below.

---

## Step 3 — ADO project (if you do not already have one)

In the existing ADO **organisation**:

1. Create a **project** (name = `<ado-project>`), or reuse an existing one.
2. Ensure you can create **Repos**, **Pipelines**, **Artifacts**, and **Service connections** in that project.

Boards process template is your choice; agents expect work items later for product/lib/containers PRs.

---

## Step 4 — Create and wire ACR

1. In the Azure portal (or CLI), **create an Azure Container Registry** `<acr-name>` in `<subscription>` — **Basic** SKU (or org-standard), after IT approval if required ([Requirements §B](#b--request-from-it-before-first-acr-pull--smoke)).
2. Set **Admin user = Disabled**.
3. Note `<acr-login-server>` (Overview → Login server).
4. Grant your user (and anyone who will pull on a laptop) **AcrPull** on that registry.
5. Pipeline push will use an ADO **service connection** (Step 8) — not the admin user.

Laptop pull check (after login):

```bash
az acr login --name <acr-name>
```

**Hard ban:** never `docker push` to this ACR from a laptop/agent session. Only merge → `containers-publish` may publish images ([`release-chain.md`](release-chain.md)).

---

## Step 5 — Create Azure Repos and land code

### 5a — Create empty Git repos in `<ado-project>`

Create one repo per tree you will use (full set):

| Repo name |
| --- |
| `agent-harness` |
| `engineering-knowledge-base` |
| `change-knowledge-base` |
| `systems-knowledge-base` |
| `python-lib` |
| `containers` |
| `sandbox` |

### 5b — Push or clone

**If you already have local trees:** add ADO as `origin` and push `main` (or push the branch you will protect as `main`).

**If starting from this pack / another archive:** create folders, `git init`, commit, add remote, push.

**If repos already have `main`:** clone siblings under one parent:

```bash
cd X:\repos
git clone https://dev.azure.com/<ado-org>/<ado-project>/_git/agent-harness
git clone https://dev.azure.com/<ado-org>/<ado-project>/_git/engineering-knowledge-base
git clone https://dev.azure.com/<ado-org>/<ado-project>/_git/change-knowledge-base
git clone https://dev.azure.com/<ado-org>/<ado-project>/_git/systems-knowledge-base
git clone https://dev.azure.com/<ado-org>/<ado-project>/_git/python-lib
git clone https://dev.azure.com/<ado-org>/<ado-project>/_git/containers
git clone https://dev.azure.com/<ado-org>/<ado-project>/_git/sandbox
```

Target layout:

```text
repos/
  agent-harness/
  engineering-knowledge-base/
  change-knowledge-base/
  systems-knowledge-base/
  python-lib/
  containers/
  sandbox/
```

Ensure each repo has the CI YAML on **`main`** before creating pipelines (Step 9): `*-test.yml` / `*-publish.yml` at repo root as shipped in this pack.

---

## Step 6 — Local Git + Cursor workspace

1. **Git author (org identity):**

   ```bash
   git config --global user.name "<Org Display Name>"
   git config --global user.email "<org-email@example.com>"
   ```

   Use the identity you want on commit history (local config per-repo is fine instead of `--global`).

2. **Cursor Attribution OFF:** **Settings → Agents → Attribution** → **Commit Attribution** OFF · **PR Attribution** OFF → restart Cursor. Do not allow Cursor `Co-authored-by` trailers ([`commands.md`](agent-ops/commands.md)).

3. Open **`agent-harness/agent-harness.code-workspace`** (multi-root: harness + vaults + python-lib + containers + sandbox).  
   Or open `agent-harness.minimal.code-workspace` / harness alone for harness-only work.

4. Read [`AGENTS.md`](../AGENTS.md) and [`docs/charter.md`](charter.md). For day-to-day work later: skill **`harness-start`** → [`start-work.md`](workflows/start-work.md).

5. Optional junctions (single-folder sessions only) — usually skip if using the multi-root workspace:

   ```bat
   mklink /J .engineering-knowledge-base X:\repos\engineering-knowledge-base
   mklink /J .change-knowledge-base X:\repos\change-knowledge-base
   mklink /J .systems-knowledge-base X:\repos\systems-knowledge-base
   ```

---

## Step 7 — Artifacts feed + variable group

1. ADO → **Artifacts** → **Create Feed**.
2. Private; **project** scope preferred; optional public upstreams ON.
3. Feed settings → **Permissions** → project **Build Service** = **Contributor**.
4. Record `<feed-name>` and compute `<ARTIFACTS_FEED>`:
   - Project-scoped: `<ado-project>/<feed-name>` (example shape `dev/python-lib`)
   - Org-scoped: `<feed-name>` only  
   If TwineAuthenticate / PipAuthenticate cannot find the feed, try the other shape. **Do not commit** the lived string.
5. **Pipelines → Library → + Variable group** (recommended name e.g. `artifacts-feed`):
   - Add variable `ARTIFACTS_FEED` = `<ARTIFACTS_FEED>`
   - You will **link** this group to `python-lib-publish`, `containers-test`, and `containers-publish` in Step 9 so PR and release cannot drift ([`release-chain.md`](release-chain.md)).

---

## Step 8 — ACR service connection (ADO → ACR)

1. Project settings → **Pipelines** → **Service connections** → **New service connection**.
2. Type: **Docker Registry** → **Azure Container Registry**.
3. Select the subscription and `<acr-name>`.
4. Save; copy the connection’s **exact name** → `<ACR_SERVICE_CONNECTION>`.
5. “Grant access to all pipelines” may stay **off** — first `containers-publish` run will prompt **Permit**.

Admin user on the registry stays **Disabled**.

---

## Step 9 — Create every pipeline (Save, do not run yet)

Azure Repos **ignores** YAML `pr:` triggers. Test pipelines fire only via **Build Validation** (Step 10). Publish pipelines fire on **`main`** via YAML `trigger: main`.

There is **no** generic `azure-pipelines.yml`. Create from branch **`main`**, YAML already on `main`.

**For each row:**

1. Pipelines → **New pipeline** → **Azure Repos Git** → that repo  
2. **Existing Azure Pipelines YAML file**  
3. Branch **`main`** → path in the table  
4. **Continue** → **Run** dropdown → **Save** (not Save & run)  
5. Pipeline **⋯ → Rename/move** → exact **Pipeline name** from the table  
6. **Edit → Variables** and/or **Variable groups** → link/set as in the table → save without running  

| Pipeline name | Repo | YAML path | Variables / group |
| --- | --- | --- | --- |
| `agent-harness-test` | `agent-harness` | `/agent-harness-test.yml` | none |
| `engineering-knowledge-base-test` | `engineering-knowledge-base` | `/engineering-knowledge-base-test.yml` | none |
| `change-knowledge-base-test` | `change-knowledge-base` | `/change-knowledge-base-test.yml` | none |
| `systems-knowledge-base-test` | `systems-knowledge-base` | `/systems-knowledge-base-test.yml` | none |
| `python-lib-test` | `python-lib` | `/python-lib-test.yml` | none |
| `python-lib-publish` | `python-lib` | `/python-lib-publish.yml` | `ARTIFACTS_FEED` (variable group) |
| `containers-test` | `containers` | `/containers-test.yml` | `ARTIFACTS_FEED` (variable group) |
| `containers-publish` | `containers` | `/containers-publish.yml` | `ARTIFACTS_FEED` (group) + `ACR_SERVICE_CONNECTION` = `<ACR_SERVICE_CONNECTION>` |
| `sandbox-test` | `sandbox` | `/sandbox-test.yml` | `ARTIFACTS_FEED` when the YAML requires it |

Delete or pause any leftover pipeline still pointing at a removed `/azure-pipelines.yml`.

**Agent note:** after MCP is on (Step 12), agents poll runs via MCP **`pipelines`** — never `az pipelines`. Creating definitions stays human (this step).

---

## Step 10 — Branch policies (Build Validation)

For **`main`** in **each** repo that has a `*-test` pipeline:

1. Repos → **Branches** → repo → `main` → **⋯** → **Branch policies**  
2. **Build Validation** → **`+`**  
3. **Build pipeline:** that repo’s **`<repo>-test` only** — **never** a `*-publish` pipeline  
4. Path filter blank · Trigger **Automatic** · Policy **Required** · Expiration when `main` updates · Display name = pipeline name  
5. **Save**

| Repo | Attach when |
| --- | --- |
| harness, three vaults, `python-lib`, `containers` | After Step 9 creates their `*-test` |
| `sandbox` | When you intend the sandbox PR gate (`sandbox-test` on `main`) |

Optional: minimum reviewers. For `python-lib` / `containers` / products: enable **Check for linked work items** once CI is trusted ([`source-control.md`](source-control.md)).

---

## Step 11 — First green publish (order matters)

Pipelines created **after** a merge do not run for that merge retrospectively. Prefer **Run pipeline** on `main` for the first publish.

1. Confirm `containers/lib-pin.txt` names the `python-lib` version you will publish.  
2. **Run** `python-lib-publish` on branch **`main`**.  
3. Confirm Artifacts shows that version.  
4. **Run** `containers-publish` on **`main`** (only after the pin exists on the feed).  
5. Confirm ACR repositories at least:

   - `platform/gateway`
   - `platform/storage-api`
   - `platform/ocr-api`
   - `platform/db-api`
   - `platform/finnhub-bridge`

6. Note the publish **build number / image tag** → you will set local `IMAGE_TAG` to that value.  
7. First run may pause for **Permit** on the feed and/or ACR connection — authorize when prompted.

Changing lib + images in one release later: publish lib first → bump `containers/lib-pin.txt` (+ smoke assert) → merge/run containers ([`release-chain.md`](release-chain.md)).

---

## Step 12 — ADO MCP (Cursor agents)

1. In `agent-harness`, copy [`.env.example`](../.env.example) → `.env` (gitignored).  
2. Set `ADO_ORG=<ado-org>` (org name **only** — not a URL).  
3. Ensure `az login` still works (MCP uses `--authentication azcli`).  
4. MCP config: project [`.cursor/mcp.example.json`](../.cursor/mcp.example.json) → `.cursor/mcp.json` if you maintain a local copy; default runs `.cursor/run_ado_mcp.py` (loads `.env`, then `npx @azure-devops/mcp`). Domains wired in the wrapper: **`core`**, **`work-items`**, **`repositories`**, **`pipelines`**.  
5. Cursor **Settings → MCP** → **manually Enable** server **ado** (project MCP is not auto-enabled).  
6. After changing domains/wrapper: restart Cursor → re-Enable **ado** → start a **new** Agent chat.  
7. Smoke: list projects / my work items / recent builds (read-only). Protocol: [`mcp.md`](agent-ops/mcp.md) · skill `harness-ado-mcp`.  

**Hard ban:** agents must not use `az repos` / `az boards` / `az pipelines` / `az rest` / raw ADO HTTP as a Boards/PR/pipelines substitute. On MCP failure → stop and report.

Claim before implement (product/lib/containers): [`claim-ado-work.md`](workflows/claim-ado-work.md). PR lifecycle: create → poll BV → on green ask → approve + autocomplete ([`mcp.md`](agent-ops/mcp.md)).

---

## Step 13 — Sandbox smoke (laptop)

1. Copy `sandbox/.env.example` → `sandbox/.env`.  
2. Set:

   | Variable | Value |
   | --- | --- |
   | `FINNHUB_API_KEY` | Your Finnhub token |
   | `ACR_HOST` | `<acr-login-server>` (**your** registry — change it; never commit `.env`) |
   | `IMAGE_TAG` | Tag from Step 11 publish |
   | Postgres defaults | OK from example for local smoke |

3. Build a local wheel into the sandbox context:

   ```bash
   cd sandbox
   python -m pip install build
   python -m build -w -o wheels ../python-lib
   ```

4. `az acr login --name <acr-name>`  
5. `python scripts/up_pull.py`  
6. `python scripts/smoke_stack.py`  

Platform images come from ACR; **orchestrator** is sandbox-local (Compose `.local.yml`). Orchestrator calls Finnhub/db **via gateway** only. Details: `sandbox/README.md`.

Compose convention (every consumer): base + `.local.yml` + `.pull.yml` — [`release-chain.md`](release-chain.md) § Consumer Compose.

---

## Step 14 — Verify checklist

**Requirements**

- [ ] IT: Docker Desktop paid licence; subscription access; ACR Basic (or equivalent)  
- [ ] PATH: `git`, `python`, `pip`/`python -m pip`, `node`, `npm`, `npx`, `docker`, `az` all resolve  
- [ ] `python -m build --help` works  
- [ ] Git author is org identity; Cursor Attribution OFF  
- [ ] MCP: `ADO_ORG` in `.env`; **ado** Enabled; new Agent chat after enable  

**Platform**

- [ ] Sibling clones under one parent; `agent-harness.code-workspace` opens cleanly  
- [ ] ACR exists; Admin Disabled; `az acr login` works  
- [ ] Artifacts feed + Build Service Contributor; variable group linked  
- [ ] ACR Docker Registry service connection named and used by `containers-publish`  
- [ ] All catalogue pipelines exist with correct names  
- [ ] Build Validation **Required** on `main` for each wired `*-test`  
- [ ] `python-lib-publish` then `containers-publish` green; five `platform/*` repos present  
- [ ] ADO MCP smoke: agent can list projects / pipelines (read)  
- [ ] Sandbox `.env` has `FINNHUB_API_KEY`, `ACR_HOST`, `IMAGE_TAG`; `up_pull` + `smoke_stack` green  
- [ ] No lived `ADO_ORG` / `ACR_HOST` / keys committed  

---

## Day-two pointers

| Need | Open |
| --- | --- |
| Shell / git / Task-store rules | [`commands.md`](agent-ops/commands.md) · `.cursor/hooks.json` |
| Branches / PRs / Close timing | [`source-control.md`](source-control.md) · `CONTRIBUTING.md` |
| Lib → feed → images → ACR | [`release-chain.md`](release-chain.md) |
| Vague / cross-lane start | Skill `harness-start` → [`start-work.md`](workflows/start-work.md) |
| Missing vault | Gap — do not invent doctrine ([`start-work.md`](workflows/start-work.md)) |
| New vault | Skill `harness-create-knowledge-base` |

## Develop harness (optional local)

```bash
cd agent-harness
python -m pip install -e ".[dev]"
pytest tests/ -v
```

Same suite as ADO `agent-harness-test`.
