# Release chain — lib → Artifacts → images → ACR

How house code becomes a running artefact. Hub wiring only: gate honesty is engineering-knowledge-base `delivery-gates` / `delivery-ci`; what ADO Artifacts and ACR *are* is systems-knowledge-base `azure-devops-org` / ACR notes.

## The chain

```text
python-lib  ──CI──►  Azure Artifacts feed (versioned wheel)
                          │
                          │ lib-pin.txt names the exact version
                          ▼
containers  ──CI──►  service images (gateway, storage-api, ocr-api)  ──►  ACR
                          │
                          ▼
                    Compose on VM pulls ACR by IMAGE_TAG
```

Each repo has **two** pipelines — a PR gate that proves the commit can become an artefact (no publish), and a release pipeline that only fires on `main` to **emit** that artefact. Testing and releasing are separate definitions so a release step can never run pre-merge.

| Repo | Test pipeline (PR gate) | Publish pipeline (`main` only) | Publish produces |
| --- | --- | --- | --- |
| `python-lib` | `python-lib-test` — lint/unit/type **+ wheel build/install smoke** | `python-lib-publish` — re-check, rebuild, **Twine upload** | Versioned wheel → Artifacts feed |
| `containers` | `containers-test` — feed pin + pytest **+ docker build (no push)** | `containers-publish` — re-test, build, **ACR push** | Images built against the **pinned** lib → ACR |
| consumer / host | — | Compose | Pulls `${ACR_HOST}/platform/<service>:${IMAGE_TAG}` |

**Left-shift rule:** anything deterministic and side-effect-free that would otherwise fail only at publish belongs on `*-test` (packaging, Dockerfile build, import of the house pin). Upload/push stay on `*-publish` only. Prefer one **variable group** for `ARTIFACTS_FEED` on both containers pipelines so PR and release cannot drift.

Images never vendor library source and never float on `main`: they install the version named in `containers/lib-pin.txt`.

Work happens on `fork/work-version` (or `feature/<id>-…`). **Publishing** runs only after merge to **`main`**.

## When CI runs

| Event | Runs | Driven by |
| --- | --- | --- |
| **PR targeting `main`** | **Test pipeline only** — no wheel upload, no ACR push; includes packaging / image-*build* proof | Build Validation branch policy on `main` |
| **Merge / push to `main`** | **Publish pipeline** (short re-check, then upload or push) | YAML `trigger: main` on the publish pipeline |
| Work branch alone (`fork/*`) | **No** CI | test pipeline is policy-only; publish triggers on `main` |

**Azure Repos gotcha:** YAML `pr:` triggers are ignored for Azure Repos Git. A pull request runs a pipeline **only** when a **Build Validation** branch policy points at it. That is why the PR gate is a separate `*-test` pipeline attached as a policy — and why the `*-publish` pipeline is never attached to a policy (so releasing cannot happen pre-merge). The YAML sets `trigger: none` / `pr: none` on test pipelines to make this explicit.

**Implication:** once the publish pipeline exists for a repo, merging `fork/work-version` → `main` **will** start a `main` build and **will** publish. Do not merge until you intend the first green publish (or disable/pause the publish pipeline first).

You can create the feed and save all pipelines (variables set, no Run) **before** any merge. Creating a pipeline may select YAML from `fork/work-version` so ADO can find the file; later runs use the YAML on the branch you build (`main` after merge).

## Order matters

**Containers CI cannot build a lib version that was never published.** The pin is resolved from the feed, so an unpublished pin fails the build (loudly) rather than shipping a stale library.

Changing **only** the library:

1. Bump `version` in `python-lib/pyproject.toml`; PR; merge.
2. python-lib CI publishes the wheel to the feed.
3. Nothing else — existing images keep their old pin until someone bumps it.

Changing **only** the containers:

1. PR; merge. Containers CI reuses the already-published pin.

Changing **both in one release** (the case people get wrong):

1. Bump `python-lib/pyproject.toml` version → merge → **wait for python-lib CI to publish**.
2. Bump `containers/lib-pin.txt` to that exact version (and the smoke test's expected version).
3. Merge containers → containers CI builds images against the new wheel and pushes to ACR.
4. Roll the consumer by `IMAGE_TAG`.

Running containers CI before the lib publish is not a partial success — it fails at the pin.

## Promotion across environments

Publishing produces an **immutable** artefact (SemVer wheel, immutable image tag). Consumers **promote** that same artefact across environments — they do not rebuild per env. Doctrine: engineering-knowledge-base `environment-promotion`.

| Consumer env | Resolves | Promotion event |
| --- | --- | --- |
| `dev` / `uat` | Newest published tag (early integration) | — |
| `prod` | An exact **pinned** tag only | Reviewed PR bumping the pin to a tag already proven in UAT |

- No environment pins a moving `:latest`; a `prod` pin bump is the promotion, carried up from a proven lower env.
- Before merging a platform `main` that changes a published contract, find downstream consumers by reading each consumer repo's pin files (`lib-pin.txt`, Compose image pins) and integration-test them. Those pins are the SoT — no separate register. Release/adopt work-item grain: change-knowledge-base `work-item-hygiene`.

## Human ADO setup (once)

Do this before first green. Org/project names and feed names stay out of git — only pipeline variables.

### 1. ACR service connection (if not already)

1. Project settings → **Pipelines** → **Service connections**
2. Confirm a **Docker Registry** connection to the house ACR (Admin user on the registry stays **Disabled**)
3. Copy the connection’s **exact name** for `ACR_SERVICE_CONNECTION`
4. “Grant access to all pipelines” may stay **off** — first run will ask to authorize

### 2. Artifacts feed

1. Left → **Artifacts** → **Create Feed**
2. Private; project scope preferred; optional public upstreams ON
3. Feed settings → **Permissions** → project/collection **Build Service** = **Contributor**
4. Remember the feed name for `ARTIFACTS_FEED`

### 3. `ARTIFACTS_FEED` value shape

| Feed scope | Set variable to | Example shape |
| --- | --- | --- |
| Project-scoped | `ProjectName/FeedName` | `dev/python-lib` |
| Organization-scoped | `FeedName` only | `python-lib` |

Lived house default for a **project** feed is `dev/<FeedName>` (project name + feed name). If TwineAuthenticate / PipAuthenticate cannot find the feed, try the other shape. Do not commit the lived string.

### 4. Create the publish-path pipelines (Save only — no Run until ready)

Two per publishing repo (`python-lib`, `containers`). When ADO asks for the YAML path, pick the specific file — each YAML is named for the pipeline it backs (there is no generic `azure-pipelines.yml`). Harness/vault **test-only** pipelines are listed in [`docs/setup.md`](setup.md) (ADO CI).

| New pipeline name | Repo | YAML path | Variables to set |
| --- | --- | --- | --- |
| `python-lib-test` | `python-lib` | `/python-lib-test.yml` | none |
| `python-lib-publish` | `python-lib` | `/python-lib-publish.yml` | `ARTIFACTS_FEED` |
| `containers-test` | `containers` | `/containers-test.yml` | `ARTIFACTS_FEED` |
| `containers-publish` | `containers` | `/containers-publish.yml` | `ARTIFACTS_FEED`, `ACR_SERVICE_CONNECTION` |

For each: Pipelines → **New pipeline** → Azure Repos Git → repo → **Existing YAML** → branch **`main`** → the path above → set variables → **Save** (not Save & run). Rename the pipeline to the name in the table (default name is the repo name).

### 5. Attach Build Validation policies (the PR gate)

YAML `pr:` does nothing on Azure Repos — the PR test run is a **branch policy**. For **`main`** in **every** house repo (including harness and vaults — full table in [`docs/setup.md`](setup.md)):

1. Repos → **Branches** → `main` row → **⋯** → **Branch policies**
2. **Build Validation** → **`+`**
3. **Build pipeline:** the repo's **`*-test`** pipeline — **never** a `*-publish` one
4. Path filter: blank · Trigger: **Automatic** · Policy requirement: **Required** (blocks merge until green) · Expiration: when `main` updates
5. **Save**

Now a PR into `main` queues the test pipeline automatically; publish stays off until merge.

### 6. When ready for first green

1. Merge `fork/work-version` → `main` for `python-lib` (and `containers` after lib publish, or both only if the pin is already on the feed)
2. The merge **triggers** `python-lib-publish` automatically — or **Run pipeline** on branch `main`
3. Confirm Artifacts shows `python-lib` at the pinned version
4. Then merge **containers** → `containers-publish` runs → confirm ACR repos `platform/gateway`, `platform/storage-api`, `platform/ocr-api`, `platform/db-api`, `platform/finnhub-bridge`

## Credentials

Feed auth happens **in the pipeline** (`PipAuthenticate` / TwineAuthenticate). The pinned wheel is downloaded into the build context before `docker build`. No feed token is passed as a build argument or baked into an image. Credential homes: engineering-knowledge-base `credential-class-storage`.

## Build an image locally

```bash
python -m build -w -o ../containers/wheels ../python-lib
docker build -f deploy/docker/Dockerfile.gateway -t gateway:dev .
```

`wheels/` is gitignored; a missing wheel fails the build rather than silently pulling something else.

## Consumer Compose convention (every product / sandbox / host)

Do **not** put pull/up logic in `python-lib`. Every consumer uses the same files under `deploy/compose/`:

| File | Role |
| --- | --- |
| `docker-compose.yml` | Base wiring (networks, volumes, shared deps) |
| `docker-compose.local.yml` | `build:` — laptop / WIP / not-yet-admitted services |
| `docker-compose.pull.yml` | `image: ${ACR_HOST}/platform/<svc>:${IMAGE_TAG}` — published artefacts |

**Laptop:** base + local (`up --build`). **Laptop + platform proof / hosts:** add pull after `az acr login` (identity `AcrPull`; Admin user Disabled). Env owns `ACR_HOST`, `IMAGE_TAG`, secrets — never commit lived registry identity. Lived example: `sandbox` (orchestrator → gateway only; observer WAL via `db_api`). Template: `containers/deploy/compose/docker-compose.pull.yml`. New-user entry: [`docs/setup.md`](setup.md) item 10.

**Hard ban:** agents must **not** `docker push` (or otherwise publish) images to the house ACR from a laptop. Only merge → `containers-publish` may write to ACR. Local `docker build` proves Dockerfiles; Compose **pull** consumes published tags.

## Related

- [`docs/setup.md`](setup.md) — new-user entry points here
- [`docs/source-control.md`](source-control.md) — branches, PRs, work-item link, Close timing
- [`docs/workflows/claim-ado-work.md`](workflows/claim-ado-work.md) — claim before implement
- eng `delivery-gates` · `delivery-ci` · `environment-promotion` · `credential-class-storage` · `house-shared-python-library` · `prefer-house-platform-image`
- systems `azure-devops-org`
