# Agent notes — agent-harness

## Authority split

| Source | Path (edit one) | Owns | Write from this repo? |
| --- | --- | --- | --- |
| **engineering-knowledge-base** | `.engineering-knowledge-base` **or** `../engineering-knowledge-base` | Engineering craft, coding-agent projection, delivery gates | **No** — elevate in engineering-knowledge-base workspace |
| **change-knowledge-base** | `.change-knowledge-base` **or** `../change-knowledge-base` | PM/BA/TA methods, staff-agent projection | **No** |
| **systems-knowledge-base** | `.systems-knowledge-base` **or** `../systems-knowledge-base` | Domain systems / SoR / process facts | **No** |
| **This repo** | `.` | Schemas, control plane, docs, harness adapters | **Yes** (committed usable content only) |

Do **not** invent parallel doctrine here. Do **not** paste vault note bodies into this tree.

## Operating law (always)

1. **Retrieve before build** — engineering-knowledge-base for engineering; change-knowledge-base for change methods; systems-knowledge-base for domain facts. Missing vault → Gap (see `docs/setup.md`).
2. **Write walls** — agents may write harness code, schemas, docs, and tests. **Ephemeral** Tasks may use gitignored `store/` for resume only — **never commit** `store/`. No `artefacts/` dumps.
3. **Cite ids** for load-bearing house choices (`engineering-knowledge-base-…`, `change-knowledge-base-…`, `systems-knowledge-base-…`).
4. **Hard gates** for quality claims; no soft CI theatre. PRs to `main` require green **`pytest`**.
5. **Skills** — vault skills live in the owning vault. Harness `.cursor/skills/` is invoke-only — never a second bible.
6. **Single entry** — vague or cross-lane work → `harness-start` (`docs/workflows/start-work.md`). Close → `harness-complete-task` (ask before purge).
7. **Agent ops** — before odd shell/Task-store moves, open `docs/agent-ops/commands.md`. Shell shape is also **hard-gated** by `.cursor/hooks.json` (`beforeShellExecution`). On new failure modes, propose a patch to the doc (and the hook when it is shell-shape).

## Start here

| Need | Open |
| --- | --- |
| **New user / clone** | `docs/setup.md` (includes **ADO CI** — all `<repo>-test` / `*-publish` pipelines + Build Validation) |
| **Agent shell / git / Task-store** | `docs/agent-ops/commands.md` · gate: `.cursor/hooks.json` |
| **ADO MCP (Boards + PRs + pipelines)** | Skill `harness-ado-mcp` → `docs/agent-ops/mcp.md` (**MCP only** — no `az repos`/`az pipelines`/`az rest`/ADO HTTP fallback; stop + report on fail) · domains: `core` + `work-items` + `repositories` + `pipelines` · claim: `docs/workflows/claim-ado-work.md` · PR shape: `docs/source-control.md` · `.env` `ADO_ORG` + `az login` (auth only) |
| **Git publish (when asked)** | `commands.md`: `git add -A` → `git commit -m "…"` → `git push` (per repo) |
| **Branches / PRs / Close timing** | `docs/source-control.md` · `CONTRIBUTING.md` |
| **Release chain (lib → Artifacts → images → ACR)** | `docs/release-chain.md` |
| **Programme / vague start** | Skill `harness-start` → `docs/workflows/start-work.md` |
| **Resume / Task CRUD** | `harness-task` (local `store/` only) |
| **Close Task** | `harness-complete-task` → `docs/workflows/complete-task.md` |
| **Good work items** | change-knowledge-base `work-item-hygiene` (+ craft) — single methods home |
| **New knowledge base** | Skill `harness-create-knowledge-base` → `docs/workflows/create-knowledge-base.md` |
| Eng bind | engineering-knowledge-base `coding-agent-projection` · `engineering-knowledge-base-plan` / … |
| Methods bind | change-knowledge-base `staff-agent-projection` · `change-knowledge-base-plan` / … |
| Domain bind | systems-knowledge-base `agent-projection` · `systems-knowledge-base-lookup` / … |
| Coverage | each vault’s `common-case-coverage` |

## Load-bearing ids

- `harness-wf-start-work` — programme entry + resume
- `harness-wf-complete-task` — close + purge consent
- `harness-wf-claim-ado` — Boards claim/release before implement
- `harness-wf-create-knowledge-base` — mint and link a new sibling vault
- `engineering-knowledge-base-wf-002` — coding-agent projection
- `engineering-knowledge-base-wf-009`–`engineering-knowledge-base-wf-012` — plan / build / verify / review engineering change
- `change-knowledge-base-wf-003` — staff-agent projection
- `change-knowledge-base-wf-031`–`change-knowledge-base-wf-034` — plan / produce / verify / review change work
- `systems-knowledge-base-wf-004` — agent projection
- `systems-knowledge-base-wf-006`–`systems-knowledge-base-wf-010` — domain lookup / plan / amend / verify / review

## Quarantine

Fat skills reprinting vault bodies · invented SoR · soft gates · always-on agent fleet as day-one · dumping run logs into vaults · committed `store/` or `artefacts/` · append-only audit theatre · leftover `product-init/` / `consumer-init/` folders · opaque vault acronyms
