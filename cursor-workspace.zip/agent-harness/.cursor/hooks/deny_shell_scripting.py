#!/usr/bin/env python3
"""beforeShellExecution gate — one instruction, no shell scripting.

Policy SoT: docs/agent-ops/commands.md
This hook is the hard gate; prose rules alone are not enough.
"""

from __future__ import annotations

import json
import re
import sys
from typing import Iterable

AGENT_HINT = (
    "Shell shape denied. Use one single-line instruction per Shell call; "
    "set cwd via working_directory. Split steps into separate Shell calls — "
    "never replace && with ;. See docs/agent-ops/commands.md."
)

ADO_MCP_HINT = (
    "ADO Boards/PR agent work is MCP-only. Do not use az repos/boards/devops/rest "
    "or raw ADO HTTP. If MCP fails, stop and report. See docs/agent-ops/mcp.md."
)

ACR_PUBLISH_HINT = (
    "House ACR publish is ADO-only (merge → containers-publish). "
    "Do not docker push / az acr publish from a laptop. "
    "Local docker build + az acr login pull are OK. See docs/release-chain.md."
)

_CD_RE = re.compile(
    r"(?i)(?:^|[\s&|;])(?:cd|set-location|chdir|push-location)\b"
)
_CONTROL_RE = re.compile(
    r"(?i)(?:^|[\s;|&])(?:if|elif|else|fi|for|foreach|while|until|do|done|"
    r"case|esac|try|catch|finally|switch|function)\b"
)
_WIPE_RE = re.compile(
    r"(?i)(?:^|[\s;|&])(?:remove-item|ri\b|rm\b|del\b|rmdir\b|rd\b)\b"
)
_PY_C_RE = re.compile(
    r"(?i)(?:^|[\s])(?:python(?:3)?|py)(?:\.exe)?\s+(?:-\d\s+)?-c\s+"
)
_AZ_ADO_RE = re.compile(
    r"(?i)(?:^|[\s;|&])az(?:\.cmd|\.exe)?\s+"
    r"(?:repos|boards|pipelines|artifacts|devops|rest)\b"
)
_AZ_ADO_TOKEN_RE = re.compile(
    r"(?i)(?:^|[\s;|&])az(?:\.cmd|\.exe)?\s+account\s+get-access-token\b"
    r".*(?:499b84ac-1321-427f-aa17-267ca6975798|visualstudio\.com|dev\.azure\.com)"
)
_ADO_HTTP_RE = re.compile(
    r"(?i)(?:invoke-restmethod|invoke-webrequest|curl(?:\.exe)?|wget(?:\.exe)?)\b"
    r".*(?:dev\.azure\.com|visualstudio\.com|_apis/(?:wit|git)\b)"
)
_DOCKER_PUSH_ACR_RE = re.compile(
    r"(?i)(?:^|[\s;|&])docker(?:\.exe)?\s+push\b.*\.azurecr\.io\b"
)
_AZ_ACR_WRITE_RE = re.compile(
    r"(?i)(?:^|[\s;|&])az(?:\.cmd|\.exe)?\s+acr\s+"
    r"(?:import|build|run|pack|task|helm|repository\s+delete|credential)\b"
)


def strip_quoted_regions(command: str) -> str:
    """Remove single/double-quoted spans so operators inside messages don't trip."""
    out: list[str] = []
    i = 0
    n = len(command)
    while i < n:
        c = command[i]
        if c in "'\"":
            quote = c
            i += 1
            while i < n:
                if command[i] == "\\" and i + 1 < n:
                    i += 2
                    continue
                if command[i] == quote:
                    i += 1
                    break
                i += 1
            out.append(" ")
            continue
        out.append(c)
        i += 1
    return "".join(out)


def first_quoted_span(command: str) -> str | None:
    """Return contents of the first ' or \" span, if any."""
    i = 0
    n = len(command)
    while i < n:
        c = command[i]
        if c in "'\"":
            quote = c
            i += 1
            start = i
            while i < n:
                if command[i] == "\\" and i + 1 < n:
                    i += 2
                    continue
                if command[i] == quote:
                    return command[start:i]
                i += 1
            return command[start:]
        i += 1
    return None


def _scripting_markers(text: str) -> list[str]:
    reasons: list[str] = []
    if "&&" in text or "||" in text:
        reasons.append("&& or || chaining")
    if "|" in text:
        reasons.append("pipeline (|)")
    if ";" in text:
        reasons.append("statement separator (;)")
    if "<<" in text or '@"' in text or '"@' in text:
        reasons.append("heredoc / here-string markers")
    return reasons


def violation_reasons(command: str) -> list[str]:
    """Return human-readable deny reasons; empty means allow."""
    if not command or not command.strip():
        return ["empty command"]

    reasons: list[str] = []
    if "\n" in command or "\r" in command:
        reasons.append("newlines (multi-line / heredoc shape)")

    bare = strip_quoted_regions(command)
    reasons.extend(_scripting_markers(bare))

    if _CD_RE.search(bare):
        reasons.append("cd/Set-Location — use Shell working_directory instead")
    if _CONTROL_RE.search(bare):
        reasons.append("shell control-flow / branching")
    if _WIPE_RE.search(bare):
        reasons.append("shell delete/wipe — use Cursor Delete tool")
    if _AZ_ADO_RE.search(bare):
        reasons.append("az ADO CLI — use ADO MCP only (stop + report on MCP fail)")
    if _AZ_ADO_TOKEN_RE.search(bare):
        reasons.append("az ADO access-token — use ADO MCP only")
    if _ADO_HTTP_RE.search(bare):
        reasons.append("raw ADO HTTP — use ADO MCP only")
    if _DOCKER_PUSH_ACR_RE.search(bare):
        reasons.append("docker push to ACR — publish via containers-publish only")
    if _AZ_ACR_WRITE_RE.search(bare):
        reasons.append("az acr write/publish — use containers-publish only")

    # python -c bodies are policy surface even though quoted for the shell.
    if _PY_C_RE.search(command):
        body = first_quoted_span(command) or ""
        if ";" in body or "\n" in body:
            reasons.append("python -c multi-statement body")
        if _CONTROL_RE.search(body):
            reasons.append("python -c control-flow body")

    seen: set[str] = set()
    ordered: list[str] = []
    for r in reasons:
        if r not in seen:
            seen.add(r)
            ordered.append(r)
    return ordered


def decide(command: str) -> dict:
    reasons = violation_reasons(command)
    if not reasons:
        return {"permission": "allow"}
    detail = "; ".join(reasons)
    if any("ACR" in r or "containers-publish" in r for r in reasons):
        hint = ACR_PUBLISH_HINT
    elif any("ADO MCP" in r or "raw ADO HTTP" in r or "az ADO" in r for r in reasons):
        hint = ADO_MCP_HINT
    else:
        hint = AGENT_HINT
    return {
        "permission": "deny",
        "user_message": f"Blocked by agent-harness shell gate: {detail}",
        "agent_message": f"{hint} Reasons: {detail}",
    }


def _decode_stdin(data: bytes) -> str:
    if not data:
        return ""
    for enc in ("utf-8-sig", "utf-8", "utf-16", "utf-16-le", "cp1252"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _parse_payload(text: str) -> dict:
    text = text.strip()
    if not text:
        return {}
    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            parsed = json.loads(text[start : end + 1])
            return parsed if isinstance(parsed, dict) else {}
        raise


def main(argv: Iterable[str] | None = None) -> int:
    args = list(argv) if argv is not None else sys.argv[1:]
    raw_bytes = sys.stdin.buffer.read()
    text = _decode_stdin(raw_bytes)
    if not text.strip() and args:
        text = args[0]

    try:
        payload = _parse_payload(text)
    except json.JSONDecodeError:
        # Some hosts may pass the bare command string instead of JSON.
        stripped = text.strip()
        if stripped and not stripped.startswith("{"):
            payload = {"command": stripped}
        else:
            print(
                json.dumps(
                    {
                        "permission": "deny",
                        "user_message": "Shell hook: could not parse hook stdin JSON",
                        "agent_message": AGENT_HINT,
                    }
                )
            )
            return 2

    command = (
        payload.get("command")
        or payload.get("cmd")
        or payload.get("shell_command")
        or ""
    )
    if not isinstance(command, str):
        command = str(command)

    result = decide(command)
    # Always exit 0 with a valid JSON body so a parser glitch does not
    # fail-open; permission:"deny" is the block signal (exit 2 also blocks).
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
