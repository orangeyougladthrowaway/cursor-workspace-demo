---
name: harness-task
description: >-
  Creates, updates, lists, or resumes ephemeral harness Tasks in gitignored store/.
  Use for mid-work resume across agent sessions without chat history — never commit store/.
disable-model-invocation: true
---

# harness-task

1. Read `AGENTS.md` and `docs/charter.md`.
2. Shape tasks against `schemas/task.schema.json`.
3. Persist **only** via `agent_harness.task_store.EphemeralTaskStore` → gitignored `store/tasks.json`.
4. Never write programme dumps under `artefacts/`. Never commit `store/`.
5. Do not invent vault doctrine; cite vault ids when the task depends on them.
6. Optional Boards link: `ado_id` / `ado_url` (primary) + `ado_claim_ids` / `ado_claimed_at` (full claim set). When set, the work item is the **shared status SoT**; Task `status` is session-local and must not silently close the work item. Never invent a work-item id — stop and ask. On resume, re-read ADO assignees.
7. `blocked` keeps ADO claim; `cancelled` (abandon) releases claim — see `docs/workflows/claim-ado-work.md` and `docs/workflows/complete-task.md`.
8. On `done` / `cancelled` → follow `docs/workflows/complete-task.md` (`harness-complete-task`) and **ask** before purge.

## Invoke (ops)

- Commands (policy SoT): `docs/agent-ops/commands.md`
- Shell gate: `.cursor/hooks.json` (`beforeShellExecution`) — deny chaining/scripting
- Path: always `default_store_path(repo_root)` or `…/store/tasks.json` — **never** the `store/` directory.
- Shell: one instruction per call; cwd via `working_directory`; prefer Write/StrReplace for Task JSON (no multi-statement `python -c`). No local dep installs, no git, no shell file-read/wipe unless the user explicitly allows.
- On a new command failure: check `commands.md`; if missing, propose a patch there (and extend the hook when it is shell-shape).
