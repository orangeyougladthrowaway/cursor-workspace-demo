---
name: harness-ado-mcp
description: >-
  Use Azure DevOps MCP from agent-harness (Boards claim, PRs, pipeline runs, smoke, gated writes).
  Invoke when listing/creating/updating ADO work items, claiming work, creating PRs, or checking CI/pipeline runs — not for vault doctrine.
disable-model-invocation: false
---

# harness-ado-mcp

1. Open `docs/agent-ops/mcp.md` and follow the agent protocol (discover tools → read before write).
2. Org comes from gitignored `.env` (`ADO_ORG`) via `.cursor/run_ado_mcp.py` — never invent it; never put it in committed files; **do not** use Windows system env for house config.
3. After config changes: user must **manually Enable** server **ado** in Cursor **Settings → MCP** (not auto-enabled), then use a **new** Agent chat.
4. If MCP server `ado` is missing, stop and report preconditions (Node, `az login`, `.env`, **manual Enable**) — do not web-search install guides unless the user asks for troubleshooting.
5. Good items / grain / claim → change-knowledge-base `work-item-hygiene`; Done evidence → eng `delivery-gates`; PR title/body/link → `docs/source-control.md`; platform SoR → systems `azure-devops-org`; CI pipeline inventory → `docs/setup.md` / `docs/release-chain.md`. Do not paste vault bodies here.
6. **Claim before implement** on tracked product/lib/containers/SQL-product work — `docs/workflows/claim-ado-work.md`. Stop if AssignedTo ≠ current user.
7. Mirror `ado_id` / `ado_url` / `ado_claim_ids` / `ado_claimed_at` on the harness Task. ADO is shared status SoT; never Close from Task purge alone.
8. **PRs:** MCP `repositories`. Follow **PR lifecycle** in `docs/agent-ops/mcp.md` (create → poll BV → fail=discuss / pass=ask → approve + autocomplete). Title/body/link: `docs/source-control.md`. Never invent work-item ids. Never `az repos` / REST.
9. **Approve / autocomplete:** only after CI green **and** explicit user yes for that PR (pre-authorisation like “push and merge” counts once green). Never silent approve/autocomplete. Other required approvers: ad-hoc check only — do not poll. MCP fail / stuck Complete → **stop and report**; no `az` / REST.
10. **Pipelines:** MCP `pipelines` — poll Build Validation / publish until terminal. Queue/cancel only when the user asks. Never `az pipelines` / pipeline REST. Pipeline *definition* create stays human (`docs/setup.md`).
11. Blocked → keep assign; cancel/abandon → unassign claim set. Multi-Story WIP allowed.
12. Domains: `core` + `work-items` + `repositories` + `pipelines` (see `run_ado_mcp.py`).
13. **Hard ban:** no agent ADO Boards/PR/pipelines work via Azure CLI or ADO REST — full table in `docs/agent-ops/mcp.md`. `az login` (auth) and `az acr login` (registry) are not substitutes for MCP.
