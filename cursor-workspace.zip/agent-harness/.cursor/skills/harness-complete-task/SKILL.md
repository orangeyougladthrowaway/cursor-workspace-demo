---
name: harness-complete-task
description: >-
  Marks a harness Task done or cancelled and asks whether to purge its ephemeral
  local store record. Releases ADO claim on cancel/abandon; keeps claim when blocked.
disable-model-invocation: true
---

# harness-complete-task

Follow `docs/workflows/complete-task.md` (`harness-wf-complete-task`).

## Rules

1. If Boards-linked and cancelling/abandoning: **unassign** `ado_claim_ids` first (`docs/workflows/claim-ado-work.md`).
2. If **blocked**: keep AssignedTo; do not unassign.
3. Set status to `done` or `cancelled` in gitignored `store/` (if not already). Confirm Boards Closed when `done` and linked.
4. **Ask the user** before deleting local records — do not silently purge.
5. Default offer: purge after close (or after elevating lasting content to product/vault).
6. Never commit `store/`. Never write to `artefacts/`. Never Close Boards from purge alone.
