#!/usr/bin/env python3
"""Load gitignored .env then exec Azure DevOps MCP (npx). No org names in git."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path


def _load_dotenv(path: Path) -> None:
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip("'").strip('"')
        if key and key not in os.environ:
            os.environ[key] = value


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    _load_dotenv(root / ".env")

    org = (os.environ.get("ADO_ORG") or "").strip()
    if not org:
        print(
            "ADO_ORG missing. Set it in agent-harness/.env (gitignored). "
            "See .env.example and docs/agent-ops/mcp.md.",
            file=sys.stderr,
        )
        return 1

    npx = shutil.which("npx")
    if not npx:
        print(
            "npx not found on PATH. Install Node.js 20+ LTS, open a new terminal, restart Cursor.",
            file=sys.stderr,
        )
        return 1

    args = [
        npx,
        "-y",
        "@azure-devops/mcp",
        org,
        "--authentication",
        "azcli",
        "-d",
        "core",
        "work-items",
        "repositories",
        "pipelines",
    ]
    # Inherit stdio so Cursor's MCP transport talks to the npx process.
    # (os.execv breaks on Windows when npx resolves to npx.cmd.)
    raise SystemExit(subprocess.call(args))


if __name__ == "__main__":
    raise SystemExit(main())
