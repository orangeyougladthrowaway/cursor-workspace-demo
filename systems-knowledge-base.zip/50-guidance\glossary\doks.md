---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-001
concern: glossary
description: DOKS — DigitalOcean Kubernetes managed cluster service.
domain: [digital-ocean]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-16
---

# Doks

**DOKS** = DigitalOcean Kubernetes — managed Kubernetes service. System note: [[doks-kubernetes]].
