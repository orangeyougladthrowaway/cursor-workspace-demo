---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-017
concern: glossary
description: Service principal — Azure AD identity for non-interactive ARM access.
domain: [azure-cloud]
updated: 2026-07-20
---

# Service Principal

**Service principal** = Azure AD application identity used for non-interactive access to [[azure-subscription]] (e.g. by [[terraform-azurerm-provider]]). Secrets never stored in this vault.
