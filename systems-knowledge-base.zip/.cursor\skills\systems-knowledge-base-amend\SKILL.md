---
name: systems-knowledge-base-amend
description: Amends systems-knowledge-base living notes via knowledge-ingestion. Use only in a systems-knowledge-base workspace when elevating agreed domain claims.
disable-model-invocation: true
---

Follow `60-workflows/knowledge/amend-domain-truth.md` (`systems-knowledge-base-wf-008`).

Consumers must not write through a read-only mount. Hand-write; no bulk generators.
