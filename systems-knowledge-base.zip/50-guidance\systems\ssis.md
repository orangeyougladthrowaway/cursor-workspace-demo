---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-017
concern: systems
description: SSIS product home — points to catalog, control/data flow, and deployment deep notes.
domain: [sql-server]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Ssis

## Purpose

Provide **SQL Server Integration Services** for enterprise data integration. Deep mechanics: [[ssis-catalog-model]] · [[ssis-control-data-flow]] · [[ssis-deployment-build]].

## Owns

- SSIS packages / projects as deployed
- SSIS Catalog (SSISDB) execution history and environments when used
- Runtime on SQL Server IS / Azure-SSIS IR class (which Untapped)

## Does not own

- Destination business SoR meaning (→ engines / domain systems)
- Full package source-code mirrors in this vault (forbidden encyclopaedia)
- ADF pipeline craft beyond noting Azure-SSIS existence

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Reads/writes | [[sql-server-engine]] / files / other sources | Data movement |
| Administered via | [[ssms]] | Catalog / execution |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Whether a deployed package/execution succeeded in catalog | Informal “the spreadsheet load” as audit trail |
| Package as integration implementation | Source system field SoR |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| Design | Visual designers / programmatic object model |
| Deploy/run | SSIS Catalog; execute via SSMS, SQL Agent, or automation |
| Auth | Proxy/credentials in catalog environments — secrets out of vault |
| Common ops | Deploy project; configure environments; execute; monitor |

### Material config

| Knob | Why it matters |
| --- | --- |
| Catalog vs file deployment | Operability and auditing |
| Package protection level | Credential storage risk |
| Runtime host | Scales and networking to sources |

### Pricing / limits (class)

- Bundled with SQL Server edition features / Azure IR cost — house Untapped.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Hard-coded passwords in packages | Prefer sensitive parameters / catalog |
| Unmonitored failures | Require execution reporting |
| Dumping all packages into vault | Forbidden |

## Deep notes

- [[ssis-catalog-model]] — SSISDB / environments / executions
- [[ssis-control-data-flow]] — control vs data flow component classes
- [[ssis-deployment-build]] — ispac / catalog deploy vs eng CI

## Evidence

- **Lived:** Untapped — which packages are SoR not elevated.
- **Remote:** [SSIS overview](https://learn.microsoft.com/en-us/sql/integration-services/sql-server-integration-services).

## Gaps / Untapped

- Package inventory (names only if needed; no dumps)
- Agent schedules as practiced

## Further detail

- [SSIS overview](https://learn.microsoft.com/en-us/sql/integration-services/sql-server-integration-services)
- [SSIS docs](https://learn.microsoft.com/en-us/sql/integration-services/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[ssis-package]]
