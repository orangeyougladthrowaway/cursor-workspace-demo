---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-006
concern: processes
description: Advance a Zoho CRM Deal through pipeline stages to close.
domain: [zoho]
derived_from:
  - "[[process-note-honesty]]"
  - "[[zoho-crm]]"
updated: 2026-07-20
---

# Advance Crm Deal

## Purpose

Move a **Deal** through pipeline stages until Closed Won / Closed Lost, keeping CRM as opportunity SoR.

## Triggers

- Sales stage change (demo, proposal, negotiation, close)
- Loss reason capture

## Actors / roles

- Deal owner / sales ops

## Inputs / outputs

| In | Out |
| --- | --- |
| Deal + stage evidence class | Updated Deal stage / amount / close date |
| Win/loss | Terminal Deal state in CRM |

## Operable sequence (business grain)

1. **Locate Deal** — UI or API; confirm Account/Contact links.
2. **Update stage** — change stage fields per layout; amount/close date when known.
3. **Record activity class** — notes/calls as practiced (grain Untapped) — Deal remains SoR for outcome.
4. **Close** — Closed Won or Closed Lost with reason fields if required by layout.
5. **Downstream** — fulfilment / onboarding handoffs to other systems are Gaps (including ServiceDesk).

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Deal stage / outcome | [[zoho-crm]] | Yes |
| Ticket for delivery | [[servicedesk-plus]] | Gap — bridge not practiced |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Stage skipped without mandate | Pipeline integrity Untapped |
| Amount only in email | Prefer Deal fields as SoR |

## Owner of this note’s truth

CRM operators (Untapped).
