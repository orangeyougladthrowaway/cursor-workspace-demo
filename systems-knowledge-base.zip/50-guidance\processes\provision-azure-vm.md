---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-031
concern: processes
description: Provision an Azure VM into a VNet with identity and basic controls.
domain: [azure-cloud]
derived_from:
  - "[[process-note-honesty]]"
  - "[[azure-vm-compute]]"
updated: 2026-07-20
---

# Provision Azure Vm

## Purpose

Bring an **Azure VM** into existence in the correct network and identity boundary for business infra.

## Triggers

- New server workload needs IaaS capacity
- Replace/resize host

## Actors / roles

- Cloud operators

## Inputs / outputs

| In | Out |
| --- | --- |
| Size, image, subnet, identity class | Running VM resource |
| Backup/security baseline intent | Disks + controls attached |

## Operable sequence (business grain)

1. **Choose subscription/RG** — [[azure-subscription]] / [[resource-group]].
2. **Network first** — subnet in [[azure-virtual-network]]; NSG posture via [[azure-security-controls]].
3. **Identity** — admin auth + optional MSI ([[azure-entra-id]]).
4. **Provision VM** — portal/CLI/ARM/[[terraform-azurerm-provider]].
5. **Harden** — no open admin ports; patch/backup class Untapped.
6. **Handoff** — workload owners receive host identity (not vault object names).

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| VM existence | [[azure-vm-compute]] | Yes |
| Network path | [[azure-virtual-network]] | Yes |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Public RDP/SSH | Prefer private/JIT |
| Secrets in custom data | Forbidden |

## Owner of this note’s truth

Cloud operators (Untapped).
