---
type: workflow
status: draft
id: systems-knowledge-base-wf-004
concern: knowledge
description: How agents retrieve systems-knowledge-base; consumers read-only via sibling path or .systems-knowledge-base mount.
derived_from:
  - "[[navigation]]"
  - "[[knowledge-ingestion]]"
updated: 2026-07-17
---

# Agent projection

How humans and agents use this vault. Consumer copy-pack: `00-foundation/templates/consumer-init/`.

Cursor skills `systems-knowledge-base-lookup` / `systems-knowledge-base-plan` / `systems-knowledge-base-amend` / `systems-knowledge-base-verify` / `systems-knowledge-base-review` are thin pointers to the operational workflows below.

## Inside systems-knowledge-base workspace

1. Read [[README]] + [[navigation]].
2. Open the relevant **family atlas** (start: [[digital-ocean-atlas]]).
3. Follow links to system / process / glossary guidance.
4. Check [[common-case-coverage]] before claiming completeness.
5. New evidence → [[plan-domain-amend]] → [[amend-domain-truth]] (via [[knowledge-ingestion]]) → [[verify-domain-note]].
6. Keep engineering craft and change-method material out of systems-knowledge-base.

## Operational workflows

| Need | Workflow |
| --- | --- |
| Answer a domain question | [[lookup-domain-truth]] |
| Plan a vault elevate | [[plan-domain-amend]] |
| Amend living notes | [[amend-domain-truth]] |
| Verify notes / coverage / health | [[verify-domain-note]] |
| Independent claim review | [[review-domain-claim]] |

## Consumer workspaces (other repos)

| Mount | Path |
| --- | --- |
| Preferred sibling | `../systems-knowledge-base` |
| Local junction | `.systems-knowledge-base/` → this repo (gitignored) |

Consumers are **read-only**. Elevate domain truth later in a systems-knowledge-base workspace. Engineering craft is out of scope; systems-knowledge-base answers domain facts. Prefer `systems-knowledge-base-lookup` / `systems-knowledge-base-review` from consumers; never `systems-knowledge-base-amend` against a mount.

## Hard rules for agents

- Do not invent SoR/process facts
- Do not paste vault note bodies into product repos
- Do not leave a `consumer-init/` folder in consumer trees after setup
- Cite `systems-knowledge-base-…` ids for load-bearing domain claims when useful
