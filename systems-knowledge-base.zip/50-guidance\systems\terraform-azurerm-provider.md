---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-014
concern: systems
description: Terraform azurerm provider densified to useful — auth/plan/apply grain; modules out.
domain: [azure-cloud]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Terraform Azurerm Provider

## Purpose

Name the **HashiCorp `azurerm` Terraform provider** as the IaC **provider surface** that configures Azure via ARM APIs.

## Owns

- Provider authentication modes and provider-block features as product capabilities
- Mapping of provider resources/data sources to ARM resource types (catalogue existence — not a full mirror here)

## Does not own

- Module layout, state backend craft, or CI apply pipelines (engineering)
- OpenTofu/Terraform **core** language doctrine
- DigitalOcean Terraform provider (separate; DO family)

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Upstream | [[azure-subscription]] | Subscription/tenant the provider acts in |
| Lateral | [[git-vcs]] / [[github-host]] / [[azure-devops-org]] | Where `.tf` lives |
| Lateral | [[azure-devops-org]] | May run plans — pipeline craft out of scope |

## Processes

- [[authenticate-azurerm-provider]] · [[plan-azure-arm-change]] · [[apply-azure-arm-change]]


## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| That `azurerm` is the HashiCorp provider for ARM | Desired-state files as business SoR |
| Documented auth methods for the provider | House module naming conventions |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| Provider | `hashicorp/azurerm` ([registry docs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs)) |
| Auth class | Azure CLI (local); Service Principal (secret or cert); Managed Identity; OpenID Connect — non-interactive prefers SP/MSI/OIDC |
| Config knobs | `features {}` required; optional `resource_provider_registrations` when caller cannot register providers |
| Env class | `ARM_*` subscription/client/tenant variables (names only — never values in vault) |

### Material config

| Knob | Why it matters |
| --- | --- |
| Auth method | Interactive vs CI; secret vs federated |
| Provider version constraint | Behaviour changes across major versions |
| `resource_provider_registrations` | Avoid apply failures when RP registration is denied |
| Subscription selection | Which [[azure-subscription]] is mutated |

### Pricing / limits (class)

- Provider is free/open; Azure resource costs sit on the subscription.
- ARM / Terraform parallelism and rate limits can throttle large plans.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Insufficient RP registration rights | Set registrations to `none` or grant rights — per provider docs |
| Leaked client secret | Rotate SP credentials; never store in notes |
| Treating modules as systems doctrine | Forbidden |

## Owner of truth

Platform/IaC operators when Azure is practiced (Untapped).

## Evidence

- **Lived:** Untapped — no confirmed house azurerm usage elevated (DO/OpenTofu may exist elsewhere — do not conflate without evidence).
- **Remote:** [azurerm provider docs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs) · auth guides (CLI, MSI, SP, OIDC).

## Gaps / Untapped

- Whether house IaC for Azure exists at all
- Chosen auth class for automation
- Relationship to any DO Terraform/OpenTofu stacks

## Further detail

- [azurerm provider docs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[service-principal]] · [[resource-group]]
