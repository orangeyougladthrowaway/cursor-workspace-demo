---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-009
concern: glossary
description: Account — Zoho CRM organisation / company record (house SoR module).
domain: [zoho]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-20
---

# Account

**Account** (Zoho CRM) = organisation / company record in [[zoho-crm]]. House SoR module (lived). Not an Azure cloud subscription account.
