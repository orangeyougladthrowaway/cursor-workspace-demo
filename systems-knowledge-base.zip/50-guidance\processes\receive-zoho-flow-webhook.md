---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-009
concern: processes
description: Receive an inbound webhook into Zoho Flow and run actions — product sequence.
domain: [zoho]
derived_from:
  - "[[process-note-honesty]]"
  - "[[zoho-flow]]"
updated: 2026-07-20
---

# Receive Zoho Flow Webhook

## Purpose

Accept an **inbound webhook** into [[zoho-flow]] and run configured actions (product capability).

## Triggers

- External system emits an HTTP callback to Flow’s webhook URL
- Builder chose Webhook as trigger

## Actors / roles

- Source system operator (configures outbound webhook)
- Flow owner

## Inputs / outputs

| In | Out |
| --- | --- |
| HTTP payload (JSON/form/text) | Action side-effects in target apps |
| Flow webhook URL | Delivery success/failure in Flow history |

## Operable sequence (business grain)

1. **Create webhook trigger** — Flow generates URL.
2. **Configure source** — paste URL into source app webhook settings (no secrets in vault).
3. **Map payload** — bind body fields to variables/actions.
4. **Activate flow** — enable receiving.
5. **Verify** — send test event; confirm actions and history.
6. **Harden** — restrict source if possible; rotate URL on leak (product supports regenerate patterns — confirm at operate time).

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Webhook URL / flow runs | [[zoho-flow]] | Yes when practiced |
| Authoritative business records | Target SoR (e.g. [[zoho-crm]]) | Target systems |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Open webhook spam | Prefer signed/secret query if source supports; else network allowlist Untapped |
| Replay | Idempotency at action side |

## Owner of this note’s truth

Future integration operators (Untapped).
