---
type: principle
status: draft
id: systems-knowledge-base-p-007
category: restraint
description: When wire-level or encyclopaedic detail is out of vault scope, link the authoritative further source — do not leave a dead end.
derived_from:
  - "[[restraint]]"
  - "[[no-encyclopaedia-paste]]"
  - "[[documentation-for-current-truth]]"
updated: 2026-07-20
---

# Link further detail

Do **not** paste vendor manuals, full API response trees, or SOP dumps as doctrine ([[no-encyclopaedia-paste]]).

When house notes **decline** that grain (Does not own / out of scope / Gaps), they **must** still point readers at the further SoT:

| Declined grain | Further link class |
| --- | --- |
| API fields / payloads | Vendor API reference for the module/endpoint |
| Engine internals beyond house Usage | Vendor architecture / Learn hub for that capability |
| Pricing invoices / SKU sheets | Vendor pricing page (class only in vault) |
| Engineering wire / IaC | Pointer that eng lane owns it — optional eng-KB or product DDL path, not fiction |

Prefer stable hub URLs. Re-check before design claims. Lived house facts still beat remote when they conflict on **house** process.
