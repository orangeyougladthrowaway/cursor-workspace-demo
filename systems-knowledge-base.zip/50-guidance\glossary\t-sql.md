---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-020
concern: glossary
description: T-SQL — Transact-SQL dialect for SQL Server.
domain: [sql-server]
updated: 2026-07-20
---

# T Sql

**T-SQL** = Transact-SQL, the SQL dialect and procedural extensions used with [[sql-server-engine]].
