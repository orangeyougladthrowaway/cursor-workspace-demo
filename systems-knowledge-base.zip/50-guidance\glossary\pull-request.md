---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-015
concern: glossary
description: Pull request — GitHub proposed merge with review/checks.
domain: [github]
updated: 2026-07-20
---

# Pull Request

**Pull request (PR)** = proposed merge on [[github-host]] with discussion, checks, and merge gate.
