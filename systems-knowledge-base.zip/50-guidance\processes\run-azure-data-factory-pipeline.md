---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-033
concern: processes
description: Run and monitor an Azure Data Factory pipeline — operable sequence.
domain: [azure-cloud]
derived_from:
  - "[[process-note-honesty]]"
  - "[[azure-data-factory]]"
updated: 2026-07-20
---

# Run Azure Data Factory Pipeline

## Purpose

Execute an **ADF pipeline** and treat run history as the integration execution SoR.

## Triggers

- Scheduled trigger
- On-demand reload / incident replay

## Actors / roles

- Data platform operators

## Inputs / outputs

| In | Out |
| --- | --- |
| Published pipeline + params | Pipeline run id / status |
| Linked service auth | Data side-effects in sinks |

## Operable sequence (business grain)

1. **Confirm factory/pipeline** — correct env.
2. **Check linked services** — Key Vault/MSI preferred ([[azure-security-controls]] / [[azure-entra-id]]).
3. **Trigger run** — debug or trigger.
4. **Monitor** — activity fails → fix source/sink/permissions.
5. **Do not** — dump pipeline JSON into this vault.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Run outcome | [[azure-data-factory]] | Yes |
| Data | Destination engines | Destination SoR |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Silent schedule failure | Alerting Untapped |
| Secrets in activity | Prefer Key Vault |

## Owner of this note’s truth

Data platform operators (Untapped).
