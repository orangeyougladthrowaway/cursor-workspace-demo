---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-012
concern: glossary
description: Flow connection — Zoho Flow credential binding to an app.
domain: [zoho]
updated: 2026-07-20
---

# Flow Connection

**Flow connection** = named credential binding in [[zoho-flow]] that lets triggers/actions call an external app. House Flow not practiced yet.
