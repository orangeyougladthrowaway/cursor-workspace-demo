---
type: foundation
status: draft
id: systems-knowledge-base-fnd-purpose
description: Why systems-knowledge-base exists — current-state systems and process truth, not eng craft or change method.
updated: 2026-07-16
---

# Purpose

## Why this repository exists

Systems and process knowledge becomes tribal memory. This vault makes **current** domain truth explicit so humans and agents stop rediscovering who owns what, which system is source of record, and how material processes actually run here.

## What it is

- A **current-state** bible of **domain systems and business processes**
- Documentation-first: living system/process notes are the bulk product
- Thin principles only to keep documentation honest and navigable
- Organised by altitude × responsibility, browsed primarily via **family atlases**
- Evidence from **lived practice** and **controlled remote research**

## What it is not

- Engineering packaging, CI craft, or code law
- PM / BA / TA methods or staff-agent skills
- A dump of vendor manuals, SOP PDFs, or org charts as architecture
- A history archive or decision-log warehouse

## Success

1. Agents find the right family atlas and answer SoR / process questions from living notes.
2. Coverage cells are scored honestly — seeded ≠ done.
3. Gaps and Untapped stay visible; secrets never enter the vault.
4. Engineering craft and change methods stay out of this vault; facts live here.
