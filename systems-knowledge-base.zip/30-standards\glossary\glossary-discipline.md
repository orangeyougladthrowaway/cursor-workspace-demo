---
type: standard
status: draft
id: systems-knowledge-base-s-003
concern: glossary
description: Glossary notes define house meaning only — no vendor dictionary dumps.
derived_from:
  - "[[no-encyclopaedia-paste]]"
  - "[[gaps-over-fiction]]"
updated: 2026-07-16
---

# Glossary discipline

Glossary notes define **house meaning** for load-bearing terms. One term (or tight cluster) per note when the meaning is contested.

Forbidden: pasting vendor glossaries wholesale; defining widely known English words; parking old basenames as glossary “aliases” for renames.
