---
type: category
status: draft
id: systems-knowledge-base-cat-restraint
category: restraint
description: Category spine — thin principles, no encyclopaedia gravity.
updated: 2026-07-16
---

# Restraint

Principles about keeping the vault small enough to stay true — and pointing outward for declined grain.

## Leaves

- [[no-encyclopaedia-paste]]
- [[link-further-detail]]
