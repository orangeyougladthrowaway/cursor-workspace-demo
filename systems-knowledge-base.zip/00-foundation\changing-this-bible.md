---
type: foundation
status: draft
id: systems-knowledge-base-fnd-changing-this-bible
description: How to change systems-knowledge-base — amend living notes; rename-not-alias; cleanliness gate.
updated: 2026-07-16
---

# Changing this bible

This vault is a **current-state** systems bible. Edit the living notes. Do not maintain a decision log, evidence warehouse, or proposal archive here.

## When changing knowledge

1. Start from [[README]] / [[navigation]] / [[scope]] / [[knowledge-model]] as needed.
2. Place content at the right **altitude** and **responsibility folder**.
3. **Category before leaf** for principles; **one primary concern folder** otherwise.
4. Prefer amending an existing note over adding a parallel one.
5. Put short rationale **in the note**. No separate ADR artefact.
6. Use `status: draft` while sketching; `canonical` when it is doctrine (human promotion).
7. New responsibility enum values require amending [[navigation]].
8. New or widened family knowledge → amend atlas and [[catalog-maps]].
9. Create / rename / delete notes → update the layer `catalog-*.md` in the same change.
10. Naming and linking follow [[methodology]].
11. Ingestion of new evidence follows [[knowledge-ingestion]].

## Retirement (rename, don’t shim)

1. **Rename** the file (stem = correct concept).
2. Update **every** wikilink (and catalog rows) to the new stem.
3. Align `# Title` to the new stem.
4. Do **not** add the old basename to `aliases:`.
5. `status: deprecated` is **migration-only** — then **delete**. Target: zero deprecated doctrine notes.

## Cleanliness accept

- [ ] No broken wikilinks (basename-only targets resolve)
- [ ] `concern` equals parent folder (maps: family leaf)
- [ ] Stem ≈ H1
- [ ] No empty responsibility folders left without orphan proof
- [ ] No `status: deprecated` residue
- [ ] Layer `catalog-*.md` and family atlases list current stems
- [ ] No old basenames parked in `aliases:`
- [ ] Coverage cells updated when family knowledge changed
- [ ] Vault-health tests green ([[vault-health-checks]])

## Conflicts

- If new guidance fights a canonical note, update the canonical note (or retire it) in the same change.
- Lived house facts win over remote generic product docs on local truth.
- User direction overrides after a brief challenge — then update the living note.

## Out of band

Git history is enough for last month’s wording. This vault does not mirror that story.
