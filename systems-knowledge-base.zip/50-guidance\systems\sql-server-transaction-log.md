---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-033
concern: systems
description: SQL Server transaction log — WAL behaviour, VLFs, active log, truncation.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Transaction Log

## Purpose

Describe the **transaction log** as the write-ahead durability mechanism — recoverability of transactions, not a second data file.

## Behaviour

| Concept | Meaning |
| --- | --- |
| Log records | Variable-size records of changes; enable undo/redo |
| Active / tail log | Portion required for recovery — cannot truncate |
| MinLSN | Oldest LSN still required |
| VLF | Virtual log file — internal segmentation of the physical log |
| Truncation | Marks reusable VLFs after checkpoint/backup rules (recovery-model-dependent) |
| Log hardening | Commit waits for log flush (WAL) |

Logged operations include data mods, page/extent alloc, DDL, and rollback reservations.

## Recovery model interaction

Truncation and backup needs differ by model — see [[sql-server-recovery-backup]]. Full/bulk-logged need **log backups** for reuse; simple reclaims on checkpoint class.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Log architecture behaviour | House RPO minutes / backup schedule |

## Failure / controls

| Mode | Posture |
| --- | --- |
| Log full (9002 class) | Open tran, missing log backup, VLF storms, disk full |
| Too many tiny VLFs | Growth pattern smell — resize strategy Untapped |
| Deleting `.ldf` manually | Catastrophic — never |

## Evidence

- **Remote:** [Transaction log](https://learn.microsoft.com/en-us/sql/relational-databases/logs/the-transaction-log-sql-server) · [Log architecture guide](https://learn.microsoft.com/en-us/sql/relational-databases/sql-server-transaction-log-architecture-and-management-guide).

## Further detail

- See Evidence Remote URLs · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-recovery-backup]] · [[sql-server-files-filegroups]] · [[sql-server-concurrency-locking]]
