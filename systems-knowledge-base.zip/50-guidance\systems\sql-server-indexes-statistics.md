---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-032
concern: systems
description: SQL Server indexes and statistics — structures the optimizer uses (not tuning playbook).
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Indexes Statistics

## Purpose

Explain **indexes** and **statistics** as engine structures that shape access paths — capability behaviour, not “when to index” house standards.

## Indexes

| Structure | Behaviour |
| --- | --- |
| Heap | Table without clustered index; RID locates rows |
| Clustered index | Sorts/stores row data at leaf; one per table |
| Nonclustered index | Separate structure pointing to heap RID or clustering key |
| Columnstore / memory-optimized classes | Alternative storage engines/features by edition/host |

Indexes enforce uniqueness when UNIQUE/PK. They are also maintenance and log/write cost surfaces.

## Statistics

Histogram / density info describing column/index data distribution. Optimizer uses stats to choose plans. Auto-create/update class exists; staleness causes poor plans (phenomenon).

Filtered / incremental stats classes exist on modern engines — availability by version/host.

## Owns / not

| Owns | Does not own |
| --- | --- |
| What indexes/stats are and how the engine uses them | Naming standards, covering-index checklists (eng) |

## Failure / controls

| Mode | Posture |
| --- | --- |
| Missing stats / stale stats | Parameter sniffing / bad plans — detect via plan analysis (ops) |
| Over-indexing | Write amplification — craft decision |

## Evidence

- **Remote:** Indexes / statistics Learn docs.

## Further detail

- [Indexes](https://learn.microsoft.com/en-us/sql/relational-databases/indexes/indexes-and-index-performance)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-pages-extents]] · [[sql-server-tables-constraints]] · [[sql-server-concurrency-locking]]
