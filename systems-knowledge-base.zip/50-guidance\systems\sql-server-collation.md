---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-030
concern: systems
description: SQL Server collations — instance/database/column comparison behaviour.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Collation

## Purpose

Explain **collation** as the engine’s rules for character comparison/sort/case/accent — at instance, database, and column grain.

## Behaviour

| Grain | Effect |
| --- | --- |
| Server/instance collation | Defaults for new DBs / temp objects class |
| Database collation | Default for columns when not overridden |
| Column/expression collation | Local override; mismatches cause conflicts |

Collation affects equality of strings, `ORDER BY`, unique indexes on strings, and some expression coercions. Mixing collations without explicit `COLLATE` fails or surprises.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Product collation behaviour | House “which collation we standardize” (Gap until decided — eng/standards later) |

## Azure SQL note

Azure SQL Database default collation chosen at create; changing later is constrained. Instances (MI/box) behave closer to classic.

## Failure / controls

| Mode | Posture |
| --- | --- |
| Cross-DB join collation conflict | Explicit COLLATE or align DB collations |
| Case-insensitive assumptions | Check collation before “unique email” designs |

## Evidence

- **Remote:** Collation and Unicode support Learn docs.
- **Lived:** House standard Untapped.

## Further detail

- [Collation and Unicode support](https://learn.microsoft.com/en-us/sql/relational-databases/collations/collation-and-unicode-support)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-object-model]] · [[sql-server-tables-constraints]]
