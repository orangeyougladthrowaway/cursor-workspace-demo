---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-022
concern: glossary
description: Paginated report — SSRS fixed-layout report definition.
domain: [sql-server]
updated: 2026-07-20
---

# Paginated Report

**Paginated report** = fixed-layout report published to [[ssrs]] (typically RDL).
