---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-023
concern: glossary
description: Postgres cluster — PostgreSQL server instance/cluster.
domain: [postgres]
updated: 2026-07-20
---

# Postgres Cluster

**Postgres cluster** = a running [[postgres-engine]] data directory / server instance hosting databases. Not DigitalOcean’s managed product name (→ [[managed-postgres]]).
