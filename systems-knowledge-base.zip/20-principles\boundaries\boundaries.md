---
type: category
status: draft
id: systems-knowledge-base-cat-boundaries
category: boundaries
description: Category spine — what stays in vs out of this vault and each system.
updated: 2026-07-16
---

# Boundaries

Principles about vault and system boundaries.
