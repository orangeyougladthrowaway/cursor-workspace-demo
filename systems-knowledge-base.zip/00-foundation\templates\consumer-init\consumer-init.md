---
type: template
status: draft
id: systems-knowledge-base-tpl-consumer-init
description: Copy-pack for consumer repos — systems-knowledge-base primary for domain truth; read-only.
domain: [cursor]
updated: 2026-07-16
---

# Consumer init

Copy the **listed sibling files** into a **consumer repo root**, then fill brackets. Do **not** copy the systems-knowledge-base vault into the consumer tree as committed doctrine.

**Hard cleanup:** after copying, the consumer repo must **not** keep a `consumer-init/` folder (or a second copy of this pack). Commit only root `AGENTS.md`, `.cursor/rules/systems-knowledge-base-readonly.mdc`, and the gitignore lines — never the template directory as a parallel tree.

## Agent binding

Consumer control files must encode:

- systems-knowledge-base as **primary** source for domain systems/process truth
- Engineering craft stays out of systems-knowledge-base
- **Read-only** on systems-knowledge-base — elevate later in a systems-knowledge-base workspace
- **Retrieve atlas → notes** before answering process/SoR questions

## Copy checklist (consumer repo)

1. From this folder, copy **only** `AGENTS.md` → consumer repo root; fill `<…>` fields.
2. Copy **only** `systems-knowledge-base-readonly.mdc` → `.cursor/rules/systems-knowledge-base-readonly.mdc`.
3. Append lines from `gitignore-snippet.txt` into the consumer `.gitignore`.
4. Mount systems-knowledge-base locally (pick one):
   - **Preferred:** sibling `../systems-knowledge-base` and set path in `AGENTS.md`.
   - **Junction:** Windows `mklink /J .systems-knowledge-base X:\repos\systems-knowledge-base` (gitignored).
5. Confirm `.systems-knowledge-base/` is ignored and **not** staged.
6. **Delete** any accidental `consumer-init/` pack copy from the consumer tree before commit.
7. Start work; agents read systems-knowledge-base via path in `AGENTS.md` / `.systems-knowledge-base`.

## Files in this folder

| File | Role |
| --- | --- |
| `AGENTS.md` | Consumer agent entry — systems-knowledge-base primary for domain truth |
| `systems-knowledge-base-readonly.mdc` | Always-on: retrieve systems-knowledge-base; read-only; no doctrine fork |
| `gitignore-snippet.txt` | Ignore local `.systems-knowledge-base/` mount |

## Related

- [[agent-projection]] · [[navigation]] · [[scope]]
