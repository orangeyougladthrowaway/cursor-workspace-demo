---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-005
concern: processes
description: Convert a Zoho CRM Lead into Contact / Account / Deal SoR records.
domain: [zoho]
derived_from:
  - "[[process-note-honesty]]"
  - "[[zoho-crm]]"
updated: 2026-07-20
---

# Convert Crm Lead

## Purpose

Advance a qualified **Lead** into lasting relationship SoR — Contact, Account, and optionally Deal — in [[zoho-crm]].

## Triggers

- Lead meets qualification bar (criteria Untapped)
- Manual convert decision by CRM user

## Actors / roles

- CRM users / sales ops

## Inputs / outputs

| In | Out |
| --- | --- |
| Qualified Lead | Contact + Account linkage; optional Deal |
| Layout mapping on convert | Closed/converted Lead state per CRM product rules |

## Operable sequence (business grain)

1. **Open Lead** — confirm fields needed for Contact/Account are complete.
2. **Convert** — use CRM convert action (UI) or supported API path; map Lead → Contact/Account (+ Deal if pipeline starts now).
3. **Verify SoR** — Contact/Account (and Deal if created) hold the authoritative values; Lead no longer worked as open prospect.
4. **Continue pipeline** — Deal advancement → [[advance-crm-deal]].

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Contact / Account / Deal | [[zoho-crm]] | Yes |
| Lead after convert | [[zoho-crm]] | Historic; not open sales SoR |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Convert without Account clarity | Orphan Contact — force Account association policy Untapped |
| Parallel informal CRM (spreadsheet) | Reject — CRM modules are SoR |

## Owner of this note’s truth

CRM operators (Untapped).
