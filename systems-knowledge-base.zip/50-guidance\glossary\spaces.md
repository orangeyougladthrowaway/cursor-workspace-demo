---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-003
concern: glossary
description: Spaces — DigitalOcean S3-compatible object storage.
domain: [digital-ocean]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-16
---

# Spaces

**Spaces** is DigitalOcean’s S3-compatible object storage. System note: [[spaces-object-storage]].
