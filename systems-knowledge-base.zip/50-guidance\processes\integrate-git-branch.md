---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-014
concern: processes
description: Integrate a Git topic branch into the shared base branch.
domain: [git]
derived_from:
  - "[[process-note-honesty]]"
  - "[[git-vcs]]"
updated: 2026-07-20
---

# Integrate Git Branch

## Purpose

Land reviewed commits from a topic branch onto the **shared base branch** via merge/rebase as practiced on the host.

## Triggers

- PR/MR approved
- Direct merge permission (rare; prefer reviewed path)

## Actors / roles

- Reviewer / maintainer
- Author

## Inputs / outputs

| In | Out |
| --- | --- |
| Topic branch + base | Updated base ref |
| Merge strategy class | Linear or merge-commit history per house (Untapped) |

## Operable sequence (business grain)

1. **Ensure CI/checks** — host checks green when required (check config Untapped; YAML craft out of scope).
2. **Merge via host** — complete PR on GitHub and/or ADO equivalent.
3. **Fetch locally** — authors update local base.
4. **Delete topic branch** — optional cleanup on host.
5. **Release tag** — optional later ([[publish-git-tag]]).

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Base branch tip | [[git-vcs]] + host | Yes |
| Review decision | Host PR/MR | Yes for collaboration SoR |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Merge with failing required checks | Blocked by host rules when enabled |
| Divergent dual remotes | Both hosts practiced — sync policy Untapped |

## Owner of this note’s truth

Repo maintainers (Untapped).
