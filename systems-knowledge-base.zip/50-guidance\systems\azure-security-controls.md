---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-024
concern: systems
description: Azure security controls — NSG/Key Vault/Defender class at systems grain.
domain: [azure-cloud]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Azure Security Controls

## Purpose

Name **material Azure security control planes** used with business infra — network controls, secrets, and cloud security posture — without a vendor encyclopaedia.

## Owns

- NSG / Azure Firewall association patterns (as practiced — detail Untapped)
- Key Vault (secrets/keys/certs) as secret store class
- Microsoft Defender for Cloud / security recommendations class when enabled

## Does not own

- SIEM playbook dumps
- Application AuthZ inside apps
- Secrets values

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Protects | [[azure-virtual-network]] / [[azure-vm-compute]] | Network path controls |
| Stores secrets for | [[terraform-azurerm-provider]] / apps | Secret references only |
| Identity | [[azure-entra-id]] | Who may access Key Vault |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Whether a control resource exists and binds | “We use security” without named controls |

## Usage

### Connect / operate

| Surface | Posture |
| --- | --- |
| Key Vault | RBAC or access policies; soft-delete/purge protection class |
| NSG / Firewall | Allow/deny; prefer private |
| Defender | Secure score / recommendations — house enablement Untapped |

### Failure / controls

| Mode | Posture |
| --- | --- |
| Secrets in pipeline logs | Forbidden posture |
| Wide Key Vault get perms | Least privilege |

## Owner of truth

Security / cloud operators (Untapped).

## Evidence

- **Lived:** Security part of significant Azure business infra.
- **Remote:** Key Vault / NSG / Defender Learn docs (claim-card).

## Gaps / Untapped

- Which controls are mandatory house baseline
- Sentinel-as-SIEM vs Defender naming (do not confuse with Aryza)

## Further detail

- [Azure security documentation](https://learn.microsoft.com/en-us/azure/security/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[service-principal]]
