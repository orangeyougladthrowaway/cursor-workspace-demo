---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-002
concern: glossary
description: Droplet — DigitalOcean Linux virtual machine.
domain: [digital-ocean]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-16
---

# Droplet

A **Droplet** is a DigitalOcean Linux virtual machine. System note: [[droplet-compute]].
