---
type: workflow
status: draft
id: systems-knowledge-base-wf-006
concern: systems
description: Answer system/SoR/process questions from systems-knowledge-base; Gaps beat invention; cite bskb ids.
derived_from:
  - "[[agent-projection]]"
  - "[[system-sor-honesty]]"
  - "[[navigation]]"
updated: 2026-07-17
---

# Lookup domain truth

Use when answering “what is true here” about systems, SoR, processes, interfaces, or glossary terms.

## Preconditions

- A clear domain question
- No requirement to invent missing house facts

## Retrieve

1. [[README]] → [[navigation]] → relevant **family atlas** (P0: [[digital-ocean-atlas]]).
2. Follow links to system / process / glossary / interface notes.
3. Open [[system-sor-honesty]] when SoR claims are involved.
4. Check [[common-case-coverage]] before claiming a platform is deep-covered.
5. Prefer `canonical`; treat `draft` as unfinished; `temp/` is harvest only.

## Steps

1. Restate the question at business grain.
2. Answer only from retrieved notes + sourced claims.
3. Mark unknowns as **Gaps** — do not invent SoR or process.
4. Cite `systems-knowledge-base-…` ids for load-bearing claims.
5. If P1 platforms are asked before DO honesty, say so ([[platform-watchlist]] / [[scope]]).

## Output

- Answer or Gap list
- Cited note stems / ids
- Coverage caveat if incomplete

## Handoff

If evidence should land in the vault → [[plan-domain-amend]]. Consumers stay read-only ([[agent-projection]]).

## Forbidden

- Invented SoR / process lore
- Engineering craft or change-method answers (wrong vault)
- Declaring P1 deep-covered without a real deep dive
