---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-029
concern: processes
description: Administer PostgreSQL via pgAdmin — operable client sequence.
domain: [postgres]
derived_from:
  - "[[process-note-honesty]]"
  - "[[pgadmin]]"
  - "[[postgres-engine]]"
updated: 2026-07-20
---

# Administer Via Pgadmin

## Purpose

Use [[pgadmin]] (desktop or server mode) to register a server and perform guided admin tasks against [[postgres-engine]].

## Triggers

- Operator prefers GUI over `psql`
- Shared web pgAdmin for a team (server mode)

## Actors / roles

- DBA / developer with grant

## Inputs / outputs

| In | Out |
| --- | --- |
| Server connection params | Registered server in pgAdmin |
| Dialog actions | DDL/backup/restore side-effects on cluster |

## Operable sequence (business grain)

1. **Deploy client** — desktop install or hardened server mode.
2. **Register server** — host/port/db/user; store password only in approved secret patterns.
3. **Browse** — databases/schemas/tables.
4. **Operate** — Query Tool, grants, backup/restore dialogs as needed.
5. **Audit** — prefer scripted migrations for repeatable prod DDL when material.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| UI session | [[pgadmin]] | Tooling |
| Data/security | [[postgres-engine]] | Yes |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Server mode internet-exposed | Authenticate + TLS + network restrict |
| Shared admin password | Individual roles |

## Owner of this note’s truth

DBAs (Untapped).
