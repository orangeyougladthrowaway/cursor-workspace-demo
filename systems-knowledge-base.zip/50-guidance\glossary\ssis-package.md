---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-021
concern: glossary
description: SSIS package — deployable Integration Services unit of work.
domain: [sql-server]
updated: 2026-07-20
---

# Ssis Package

**SSIS package** = a deployable Integration Services unit (tasks/data flows) executed via [[ssis]].
