---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-039
concern: systems
description: SQL Server integrity and index maintenance — CheckDB/reorg/rebuild as product capabilities.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Maintenance Checks

## Purpose

Name **integrity checks** and **index maintenance operations** the engine exposes — what they do, not weekly runbooks.

## Integrity

| Capability | Behaviour |
| --- | --- |
| DBCC CHECKDB (class) | Consistency validation of DB structures; repair options are last-resort destructive classes |
| Consistency errors | Signal corruption — restore/from backup preferred over casual repair |

## Index maintenance

| Operation | Behaviour |
| --- | --- |
| Reorganize | Online-ish defrag of leaf level; lower impact class |
| Rebuild | Recreate index; offline vs online (edition) classes; heavy log in Full |
| Update statistics | Refresh optimizer stats (auto or manual) |

Fragmentation metrics are inputs; thresholds are **house/eng standards**, not product law.

## Owns / not

| Owns | Does not own |
| --- | --- |
| What CheckDB/rebuild/reorg do | Schedules, Ola-style jobs as mandated craft |

## Azure SQL note

Automated tuning / intelligent insights may exist; CHECKDB still relevant. Maintenance windows by tier.

## Failure / controls

| Mode | Posture |
| --- | --- |
| Repair with data loss without restore plan | Forbidden default |
| Rebuild storms in busy hours | Availability risk |

## Evidence

- **Remote:** DBCC CHECKDB / index maintenance Learn docs.

## Further detail

- [DBCC CHECKDB](https://learn.microsoft.com/en-us/sql/t-sql/database-console-commands/dbcc-checkdb-transact-sql)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-indexes-statistics]] · [[sql-server-pages-extents]] · [[sql-server-agent]]
