---
type: workflow
status: draft
id: systems-knowledge-base-wf-003
concern: knowledge
description: Ingest ledger — sources admitted, claims elevated; lives outside doctrine bodies.
derived_from:
  - "[[knowledge-ingestion]]"
  - "[[common-case-coverage]]"
updated: 2026-07-20
---

# Ingest Coverage

Ledger of sources touched. Not doctrine — tracking only. Pipeline: [[knowledge-ingestion]].

## Bootstrap session — 2026-07-16

### Lived branch

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| Earlier host OpenTofu / packaging pointers | `pointer` | Confirms DO-class host practice | Reinforced watchlist |
| User-relayed systems inventories from DO-touching platform repos (no secret files; no object-name doctrine) | `specialise` | VPC, firewall, DOKS, Droplet, managed Postgres, Spaces, DOCR, edge, inference paths | Yes → system notes + atlas |

### Remote branch

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| https://docs.digitalocean.com/products/kubernetes/ | `specialise` | DOKS managed control plane | Yes → [[doks-kubernetes]] |
| https://docs.digitalocean.com/products/droplets/ | `specialise` | Droplet VMs | Yes → [[droplet-compute]] |
| https://docs.digitalocean.com/products/spaces/ | `specialise` | Spaces object store | Yes → [[spaces-object-storage]] |
| https://docs.digitalocean.com/products/databases/ | `specialise` | Managed databases | Yes → [[managed-postgres]] |

### Deferred / reject

| Source | Admit | Why |
| --- | --- | --- |
| Full DO product catalogue | `reject` | Encyclopaedia |
| P1 platform deep docs | `defer` | After DO systems **and Usage** bar |
| IaC / Helm / CI craft as systems-knowledge-base doctrine | `reject` | Out of scope |
| Account-specific resource names as doctrine | `reject` | Agnostic systems grain |

## Usability wave — 2026-07-18

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| https://docs.digitalocean.com/products/kubernetes/ | `specialise` | Access/ops class | Yes → [[doks-kubernetes]] Usage |
| https://docs.digitalocean.com/products/kubernetes/details/pricing/ | `specialise` | Worker/HA/bandwidth pricing class | Yes → [[doks-kubernetes]] Usage |
| https://docs.digitalocean.com/products/droplets/ | `pointer` | Droplet product home | Reinforced [[droplet-compute]] Usage |
| https://docs.digitalocean.com/products/databases/ | `pointer` | Managed DB product home | Reinforced [[managed-postgres]] Usage |

## Open Untapped

- Ownership (who may change platform resources)
- Live create-vs-existing for registry/Spaces/VPC per environment
- Public edge maturity on host shape
- Trusted-sources / DB firewall coding
- Aryza Sentinel product identity / SKU (lending assumed; confirm)
- Virtual Cabinet public API / integration surface (none clearly public)
- TCS BaNCS marketplace API access for deeper claim cards
- Lived inventory owners per P1 family

## Foundation wave — 2026-07-20 (Wave 0)

Programme admit: expand P1 beyond original five names; unlock wave parallelism after DO useful.

### Lived branch

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| User programme brief (multi-system expansion; DO as depth exemplar; wave parallelism) | `specialise` | Scope + watchlist + coverage sequencing | Yes → [[scope]] · [[platform-watchlist]] · [[common-case-coverage]] · [[catalog-maps]] · [[digital-ocean-atlas]] interfaces |

### Remote branch (source map — pointer / defer only; no family deep dive)

| Source class | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| Zoho CRM / Flow help + CRM API docs | `defer` | Wave 1 densify | No — ledger only |
| ManageEngine ServiceDesk Plus Cloud/on-prem API docs | `defer` | Wave 1 densify | No |
| git-scm.com · GitHub REST/GraphQL docs · Azure DevOps REST | `defer` | Wave 2 densify | No |
| Azure Learn + HashiCorp azurerm provider docs | `defer` | Wave 3 densify (provider grain) | No |
| Aryza marketing / OC4 lending API portal | `pointer` | Identity + API class pressure | No — identity Gap remains |
| TCS BaNCS Marketplace (gated) | `pointer` | API exists but registration-gated | No |
| Tuum developer portal (accounts / overdraft) | `defer` | Wave 4 densify | No |
| Virtual Cabinet marketing / partner integration pages | `pointer` | No clear public API portal found | No |
| Microsoft Learn SQL Server / SSMS / SSIS / SSRS | `defer` | Wave 5 densify | No |

### Deferred / reject this session

| Source | Admit | Why |
| --- | --- | --- |
| Opening P1 family atlas folders | `defer` | Wave 0 foundation only |
| Vendor encyclopaedia paste for any P1 | `reject` | [[knowledge-ingestion]] |
| Terraform module / CI YAML as systems doctrine | `reject` | Out of scope |

## Wave 1 open — 2026-07-20 (`zoho` · `manageengine-servicedesk`)

### Remote branch

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| https://www.zoho.com/crm/developer/docs/api/v7/ | `specialise` | CRM REST v7 surfaces (entity, metadata, bulk, notifications, COQL) | Yes → [[zoho-crm]] |
| https://www.zoho.com/crm/developer/docs/api/v7/oauth-overview.html | `specialise` | OAuth2 access/refresh token class | Yes → [[zoho-crm]] |
| https://www.zoho.com/flow/ | `specialise` | Flow as iPaaS connector home | Yes → [[zoho-flow]] |
| https://www.zoho.com/flow/articles/triggers-in-zoho-flow.html | `specialise` | App / webhook / URL trigger classes | Yes → [[zoho-flow]] |
| https://www.manageengine.com/products/service-desk/sdpod-v3-api/ | `specialise` | SDP Cloud REST v3 | Yes → [[servicedesk-plus]] |
| https://www.manageengine.com/products/service-desk/sdpod-v3-api/getting-started/oauth-2.0.html | `specialise` | Cloud OAuth auth class | Yes → [[servicedesk-plus]] |
| https://www.manageengine.com/products/service-desk/on-premises/faq/api-management.html | `pointer` | On-prem technician API key posture | Reinforced [[servicedesk-plus]] Gaps |

### Lived branch

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| House Zoho / SDP inventories | `defer` | Need operator relay | No — Untapped on notes |

### New notes this session

- [[zoho-atlas]] · [[zoho-crm]] · [[zoho-flow]]
- [[manageengine-servicedesk-atlas]] · [[servicedesk-plus]]

## Wave 1 lived relay — 2026-07-20

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| User relay — SDP edition | `specialise` | Cloud (not on-prem) | Yes → [[servicedesk-plus]] |
| User relay — Zoho CRM SoR modules | `specialise` | Leads, Contacts, Accounts, Deals | Yes → [[zoho-crm]] |
| User relay — Zoho Flow | `specialise` | Not practiced; desired later | Yes → [[zoho-flow]] (aspirational) |
| User relay — CRM↔SDP / Flow bridges | `specialise` | None practiced; desired later | Yes → atlas Gaps / notes Untapped |

## Wave 1 glossary + Waves 2–3 open — 2026-07-20

### Lived / specialised

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| Prior Wave 1 lived modules / Cloud edition | `specialise` | Glossary cards | Yes → [[lead]] · [[contact]] · [[account]] · [[deal]] · [[service-desk-request]] |

### Remote branch

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| https://git-scm.com/docs | `specialise` | Git as VCS SoR | Yes → [[git-vcs]] |
| https://docs.github.com/en/rest | `specialise` | GitHub REST/auth/rate-limit class | Yes → [[github-host]] |
| https://learn.microsoft.com/en-us/rest/api/azure/devops/ | `specialise` | ADO REST instance + api-version + auth class | Yes → [[azure-devops-org]] |
| https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs | `specialise` | azurerm provider + auth modes | Yes → [[terraform-azurerm-provider]] · [[azure-subscription]] |

### New notes this chunk

- Glossaries: [[lead]] · [[contact]] · [[account]] · [[deal]] · [[service-desk-request]]
- [[git-atlas]] · [[git-vcs]]
- [[github-atlas]] · [[github-host]]
- [[azure-devops-atlas]] · [[azure-devops-org]]
- [[azure-cloud-atlas]] · [[azure-subscription]] · [[terraform-azurerm-provider]]

### Deferred

| Source | Admit | Why |
| --- | --- | --- |
| Wave 4 banking deep dives | `defer` | Next significant chunk; identity Gaps remain |
| Wave 5 DMS/SQL | `defer` | After Wave 4 or parallel only with lived owners |
| GitHub Actions / ADO Pipelines YAML | `reject` | Engineering craft |

## Useful densify — 2026-07-20 (Zoho · SDP · Git · GitHub · ADO · azurerm)

### Lived

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| User — primary hosts | `specialise` | Both GitHub and Azure DevOps used | Yes → [[git-vcs]] · [[github-host]] · [[azure-devops-org]] |
| User — Flow depth | `specialise` | Product-useful despite not practiced | Yes → [[zoho-flow]] processes |

### Elevated (processes + glossary)

Process notes proc-004…024; glossaries flow-connection, commit, branch, pull-request, work-item, service-principal, resource-group. Atlases and coverage marked useful (Interfaces partial).

## Admit Postgres / pgAdmin — 2026-07-20

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| User programme brief — add Postgres/pgAdmin at SQL Server suite wave | `specialise` | Wave 5 leaf `postgres` | Yes → [[scope]] · [[platform-watchlist]] · [[common-case-coverage]] · [[catalog-maps]] |

## SQL densify + defer banking/VC — 2026-07-20

### Policy

| Item | Admit | Note |
| --- | --- | --- |
| Aryza / BaNCS / Tuum / Virtual Cabinet | `defer` | User skip for now |
| SQL Server suite + Postgres/pgAdmin | `specialise` | Densify to useful |

### Remote

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| https://learn.microsoft.com/en-us/sql/sql-server/ | `specialise` | Engine | Yes → [[sql-server-engine]] |
| https://learn.microsoft.com/en-us/ssms/ | `specialise` | SSMS | Yes → [[ssms]] |
| https://learn.microsoft.com/en-us/sql/integration-services/ | `specialise` | SSIS | Yes → [[ssis]] |
| https://learn.microsoft.com/en-us/sql/reporting-services/ | `specialise` | SSRS | Yes → [[ssrs]] |
| https://www.postgresql.org/docs/ | `specialise` | Postgres engine | Yes → [[postgres-engine]] |
| https://www.pgadmin.org/docs/pgadmin4/latest/ | `specialise` | pgAdmin | Yes → [[pgadmin]] |

### New notes

- [[sql-server-atlas]] · [[sql-server-engine]] · [[ssms]] · [[ssis]] · [[ssrs]]
- Processes: [[connect-administer-sql-server]] · [[deploy-run-ssis-package]] · [[publish-ssrs-report]]
- [[postgres-atlas]] · [[postgres-engine]] · [[pgadmin]]
- Processes: [[connect-administer-postgres]] · [[administer-via-pgadmin]] · [[backup-restore-postgres]]
- Glossaries: [[sql-instance]] · [[t-sql]] · [[ssis-package]] · [[paginated-report]] · [[postgres-cluster]] · [[psql]]

## Lived harvest + Azure business-infra densify — 2026-07-20

### Lived

| Source | Admit | Focus | Claims elevated? |
| --- | --- | --- | --- |
| User — Postgres topology | `specialise` | DO managed + other Postgres | Yes → [[postgres-engine]] · [[postgres-atlas]] |
| User — SQL topology | `specialise` | On-prem/VM + Azure SQL | Yes → [[sql-server-engine]] · [[sql-server-atlas]] |
| User — Flow | `specialise` | Planned CRM↔SDP; not live | Yes → [[zoho-flow]] |
| User — Azure role | `specialise` | Primary business infra surfaces listed | Yes → [[azure-subscription]] · [[azure-cloud-atlas]] + new systems |
| User — SCM | `specialise` | Dual suite capability; no write-leader / delivery SoR pick | Yes → [[git-vcs]] · [[github-host]] · [[azure-devops-org]] |

### New Azure systems / processes

- [[azure-vm-compute]] · [[azure-virtual-network]] · [[azure-entra-id]] · [[azure-security-controls]] · [[azure-data-factory]] · [[azure-ai-foundry]]
- [[provision-azure-vm]] · [[segment-azure-network]] · [[run-azure-data-factory-pipeline]] · [[deploy-azure-ai-foundry-model]]

### Deferred still

GPO deep densify; Aryza/BaNCS/Tuum/VC; delivery SoR pick; Git write-leader.

## SQL Server engine-deep Waves A–G — 2026-07-20

### Remote (class)

| Source class | Admit | Elevated into |
| --- | --- | --- |
| Pages/extents architecture guide | \specialise\ | [[sql-server-pages-extents]] |
| Transaction log + architecture guides | \specialise\ | [[sql-server-transaction-log]] |
| Recovery models / backup-restore | \specialise\ | [[sql-server-recovery-backup]] · [[backup-restore-sql-server]] |
| Locking/isolation / tempdb / memory / indexes/stats | \specialise\ | Concurrency, tempdb, memory, indexes notes |
| Object model / principals / files / collation | \specialise\ | Wave A notes |
| Programmability / tables-constraints | \specialise\ | Wave D notes |
| SSIS catalog / data flow / deploy | \specialise\ | [[ssis-catalog-model]] · [[ssis-control-data-flow]] · [[ssis-deployment-build]] |
| Azure SQL feature comparison | \specialise\ | [[azure-sql-differences]] |

### Reject

| Source | Admit | Why |
| --- | --- | --- |
| Full BOL / T-SQL textbooks as doctrine | eject\ | Encyclopaedia; eng owns craft |
| House package/schema dumps | eject\ | Inventory without mandate |

### Atlas

[[sql-server-atlas]] indexes engine-deep + SSIS-deep capability maps.

