---
type: map
status: draft
id: systems-knowledge-base-map-me-sdp
concern: manageengine-servicedesk
description: ServiceDesk Plus Cloud atlas — systems, processes, glossary densified to useful.
domain: [manageengine-servicedesk]
updated: 2026-07-20
---

# Manageengine Servicedesk Atlas

Browse for **ManageEngine ServiceDesk Plus Cloud** as ITSM SoR.

## Systems

| Note | Role |
| --- | --- |
| [[servicedesk-plus]] | Incident / service-request lifecycle SoR |

## Processes

| Note | Question |
| --- | --- |
| [[raise-service-desk-request]] | How a request enters the desk |
| [[resolve-service-desk-request]] | How a request is worked to close |
| [[integrate-servicedesk-via-api]] | How Cloud OAuth REST integrates |

## Glossary

[[service-desk-request]]

## Interfaces / Gaps

| Counterpart | Status |
| --- | --- |
| [[zoho-crm]] / [[zoho-flow]] | Gap — aspirational bridges |
| [[azure-devops-org]] | Gap — work item ↔ ticket |
| [[digital-ocean-atlas]] | Gap — platform incident routing |

## Evidence posture

- **Lived:** Cloud edition.
- **Remote:** Cloud API v3 + OAuth docs.

## Further detail

Out-of-vault wire/field matrices and deep vendor manuals stay linked, not pasted ([[link-further-detail]] · [[further-detail-hubs]]):

- [SDP On-Demand API](https://www.manageengine.com/products/service-desk/sdp-ondemand/api.html)

## Usability wave

**Useful** on Atlas/Systems/Usage/Processes/Controls/Glossary/Freshness. Interfaces partial.

## Related

- [[scope]] · [[platform-watchlist]] · [[common-case-coverage]] · [[catalog-maps]]
