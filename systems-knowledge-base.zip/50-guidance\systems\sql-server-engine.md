---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-015
concern: systems
description: SQL Server Database Engine — SoR grain plus deep capability map (storage, concurrency, recovery).
domain: [sql-server]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Sql Server Engine

## Purpose

Provide the **Microsoft SQL Server Database Engine** as a relational data SoR grain (on-prem/VM and Azure SQL practiced — which DB where Untapped).

Deep behaviour lives in linked capability notes (object model, pages, log, locking, recovery, …) — not in this card alone.

## Owns

- Databases, schemas, tables, indexes, and engine security principals as configured
- T-SQL execution and transactional integrity of data it stores
- Instance-level configuration (memory, maxdop, etc.) at engine grain

## Does not own

- Admin UI (→ [[ssms]])
- ETL package definitions as product (→ [[ssis]])
- Paginated report definitions (→ [[ssrs]])
- Application business meaning of rows (domain SoR may sit *in* the DB)
- PostgreSQL engines (→ [[postgres-engine]])
- DO managed Postgres (→ [[managed-postgres]])

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Administered via | [[ssms]] | Connect / Object Explorer / queries |
| Lateral | [[ssis]] | Packages read/write engine data |
| Lateral | [[ssrs]] | Datasets query the engine |
| Lateral | App services | Connection strings (secrets out of vault) |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Data as committed in SQL Server databases that are house SoR | Spreadsheet exports of the same entities |
| Instance login/role grants as configured | OS local admin alone |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| Protocols | TDS; tools include SSMS, sqlcmd, drivers |
| Auth class | Windows Auth and/or SQL logins; Azure AD auth on Azure SQL class — house choice Untapped |
| Common ops | Create DB/schema; backup/restore; index/stats; security grants |
| Hosting class | **Lived:** both **on-prem/VM SQL Server** and **Azure SQL** (DB/MI class) are practiced — which DB on which host Untapped |

### Material config

| Knob | Why it matters |
| --- | --- |
| Edition / compatibility level | Feature surface and support |
| Recovery model | Backup/RPO class |
| Network exposure | Attack surface; prefer private connectivity |
| Contained DB / encryption options | Compliance posture Untapped |

### Pricing / limits (class)

- Licensing / Azure meter class — **house contract Untapped**; re-check before capacity claims.
- Resource governor / DTU-vCore limits on cloud SKUs.

### Failure / controls

| Mode | Posture |
| --- | --- |
| sa / overly privileged logins | Prefer least privilege; break-glass Untapped |
| Unencrypted backups with PII | Forbidden to store dumps in vault |
| Silent dual SoR with Postgres | Name which engine is SoR per domain |

## Processes

- [[connect-administer-sql-server]] · [[backup-restore-sql-server]] · [[deploy-run-ssis-package]] · [[publish-ssrs-report]]

## Capability map

Browse [[sql-server-atlas]] — object model, storage engine, concurrency, recovery, Agent, programmability, SSIS deep notes, [[azure-sql-differences]].

## Owner of truth

DBA / data platform owners (Untapped).

## Evidence

- **Lived:** User relay 2026-07-20 — **both** on-prem/VM SQL Server **and** Azure SQL practiced. Instance inventory Untapped.
- **Remote:** [SQL Server docs](https://learn.microsoft.com/en-us/sql/sql-server/) (Microsoft Learn).

## Gaps / Untapped

- Which databases/workloads sit on-prem vs Azure SQL
- Editions, HA/DR per class
- Named operators

## Further detail

Deep engine matrices and T-SQL craft stay linked / eng-lane — not pasted ([[link-further-detail]] · [[further-detail-hubs]]):

- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/)
- [Azure SQL feature comparison](https://learn.microsoft.com/en-us/azure/azure-sql/database/features-comparison)

## Related glossary

- [[sql-instance]] · [[t-sql]]
