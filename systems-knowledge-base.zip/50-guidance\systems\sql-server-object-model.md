---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-027
concern: systems
description: SQL Server object model — instance/database/schema/object kinds (not T-SQL craft).
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Object Model

## Purpose

Describe how SQL Server **names and contains** objects — so agents place artefacts correctly without inventing house schemas.

## Hierarchy (product behaviour)

```text
Instance (sql-instance)
  └── Database
        └── Schema (namespace + optional owner)
              └── Objects (tables, views, procs, functions, synonyms, …)
  └── Server-scoped objects (logins, linked servers, Agent jobs, …)
```

| Grain | What it is |
| --- | --- |
| **Instance** | Engine process/service endpoint; holds server principals & config |
| **Database** | Contained unit of recovery, collation default, file set |
| **Schema** | Namespace for securables; not a “folder” alone — also permission boundary |
| **Object** | Named durable module or structure inside a schema (or server scope) |

## Object kinds (capability class)

| Kind | Role |
| --- | --- |
| Tables | Durable row storage (heap or clustered) |
| Views | Stored queries; may be indexed (restricted class) |
| Stored procedures | Named batches with parameters |
| Functions | Scalar / inline TVF / multi-statement TVF — different engine constraints |
| Triggers | Event-tied code (DML/DDL/logon classes) |
| Synonyms | Alternate names |
| Types / sequences / assemblies | Supporting types (availability varies by edition/host) |

**Not objects:** ad-hoc batches, cached plans, sessions, locks (runtime phenomena).

## Does not own

- How house apps **should** name or layer schemas (→ engineering warehouse craft)
- Syntax textbooks

## Azure SQL note

Azure SQL Database is **per-database** PaaS — many instance-scoped features differ or absent (see [[azure-sql-differences]]). Managed Instance closer to box.

## Failure / controls

| Mode | Posture |
| --- | --- |
| Objects in `dbo` by accident | Schema discipline is house craft — Gap |
| Cross-db ownership chaining | Security complexity — prefer explicit |

## Evidence

- **Remote:** SQL Server databases / schemas architecture (Microsoft Learn).
- **Lived:** on-prem/VM + Azure SQL practiced — which DBs where Untapped.

## Further detail

- [Databases](https://learn.microsoft.com/en-us/sql/relational-databases/databases/databases)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-engine]] · [[sql-server-principals-securables]] · [[sql-instance]]
