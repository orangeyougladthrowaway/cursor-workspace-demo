---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-011
concern: processes
description: Work and resolve a ServiceDesk Plus Cloud request to closure.
domain: [manageengine-servicedesk]
derived_from:
  - "[[process-note-honesty]]"
  - "[[servicedesk-plus]]"
updated: 2026-07-20
---

# Resolve Service Desk Request

## Purpose

Move an open request through diagnosis and resolution to a **closed** state in [[servicedesk-plus]].

## Triggers

- Assigned technician picks up / updates a request
- Resolution ready for requester confirmation (if configured)

## Actors / roles

- Technician
- Requester (confirm/close where portal requires)

## Inputs / outputs

| In | Out |
| --- | --- |
| Open request | Notes, worklogs, resolution text |
| Closure | Closed request; SLA completion class |

## Operable sequence (business grain)

1. **Assign / pickup** — technician ownership clear.
2. **Update** — notes/worklogs; status transitions per template.
3. **Resolve** — set resolution; notify requester as product rules dictate.
4. **Close** — close when done; reopen path if product/SLA allows.
5. **Learn** — problem/known-error links Untapped.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Ticket lifecycle | [[servicedesk-plus]] | Yes |
| Engineering backlog item | [[azure-devops-org]] | Gap — dual-track Untapped |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Close without resolution text | Prefer mandatory resolution fields if configured |
| Duplicate tickets | Link/merge policy Untapped |

## Owner of this note’s truth

Service-desk operators (Untapped).
