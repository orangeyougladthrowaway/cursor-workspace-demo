---
type: catalog
status: draft
id: systems-knowledge-base-cat-maps
description: Index of family and theme atlases — DO useful; Waves 1–3 atlases opened.
updated: 2026-07-20
---

# Catalog Maps

## Families

| Atlas | Family leaf | Status |
| --- | --- | --- |
| [[digital-ocean-atlas]] | `digital-ocean` | P0 — core cells useful |
| [[zoho-atlas]] | `zoho` | Wave 1 — **useful** (CRM lived; Flow product-useful) |
| [[manageengine-servicedesk-atlas]] | `manageengine-servicedesk` | Wave 1 — **useful** (Cloud) |
| [[git-atlas]] | `git` | Wave 2 — **useful** (dual remotes) |
| [[github-atlas]] | `github` | Wave 2 — **useful** |
| [[azure-devops-atlas]] | `azure-devops` | Wave 2 — **useful** |
| [[azure-cloud-atlas]] | `azure-cloud` | Wave 3 — **useful** expanded (business infra + azurerm) |
| [[sql-server-atlas]] | `sql-server` | Wave 5 — **useful / engine-deep** (capability map A–G) |
| [[postgres-atlas]] | `postgres` | Wave 5 — **useful** (engine · pgAdmin) |

## Themes

None yet. Planned when enough notes exist: `integrations`, `controls`, `data-ownership` (see [[platform-watchlist]]).

## Deferred P1 (atlases not opened)

| Family leaf | Wave | Notes |
| --- | --- | --- |
| `aryza-sentinel` | 4 | Skipped for now — identity Gap |
| `tcs-bancs` | 4 | Skipped for now |
| `tuum` | 4 | Skipped for now |
| `virtual-cabinet` | 5 | Skipped for now |
