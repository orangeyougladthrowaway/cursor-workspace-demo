---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-010
concern: systems
description: Git VCS densified to useful — dual remotes (GitHub + Azure Repos) practiced.
domain: [git]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Git Vcs

## Purpose

Provide **distributed version control** — commits, trees, blobs, refs — as the source-history SoR at the Git object grain.

## Owns

- Local and shared Git object databases and refs (branches, tags)
- Commit identity and history topology as Git records them
- Protocol behaviours for fetch/push between remotes

## Does not own

- Hosted collaboration UX (PRs, issues) — → [[github-host]] or Azure DevOps Repos
- CI workflow definitions (engineering lane)
- Application runtime / cloud resources

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Downstream | [[github-host]] | Hosted remote + PR review — **practiced** |
| Downstream | [[azure-devops-org]] | Azure Repos remote — **practiced** |
| Lateral | Engineers / agents | Clone, commit, push |

## Processes

- [[contribute-git-change]] · [[integrate-git-branch]] · [[publish-git-tag]]


## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Whether a change is in the Git history of a repository | Ticket or CRM status of the business change |
| Ref tips as resolved from remotes | Informal zip drops of source |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| CLI | `git` porcelain/plumbing per [git-scm docs](https://git-scm.com/docs) |
| Protocol | HTTPS or SSH to a hosting remote |
| Auth class | Credential / SSH key / token as required by the remote host — never store secrets in this vault |
| Common ops | clone, fetch, pull, commit, merge/rebase, push, tag |

### Material config

| Knob | Why it matters |
| --- | --- |
| Default branch name | Integration baseline |
| Remotes (`origin`, …) | Which host is SoR for shared history |
| Hooks (client/server) | Policy enforcement — house adoption Untapped |

### Pricing / limits (class)

- Git itself is free software; limits come from the **host** (size, LFS, rate limits).

### Failure / controls

| Mode | Posture |
| --- | --- |
| Divergent history | Merge/rebase conflict — human or negotiated resolution |
| Force-push to shared branch | History rewrite risk — protect on host |
| Credential leak | Rotate at host; never paste tokens into notes |

## Owner of truth

Repository owners / platform maintainers (named Untapped).

## Evidence

- **Lived:** User relay 2026-07-20 — **both** GitHub and Azure DevOps used. Write-leader **not** declared — house wants **full suite capability** of both hosts (not a single SoR pick). Sync/write-leader policy still Gap if dual remotes diverge.
- **Remote:** [git documentation](https://git-scm.com/docs).

## Gaps / Untapped

- Write-leader when the same repo exists on both hosts
- Signed commits / verified authors as practiced
- Monorepo vs multi-repo topology

## Further detail

- [git documentation](https://git-scm.com/docs)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[commit]] · [[branch]]
