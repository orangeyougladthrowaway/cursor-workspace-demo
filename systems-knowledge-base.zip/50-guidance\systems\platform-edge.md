---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-010
concern: systems
description: Optional public edge — DO DNS and/or host reverse proxy; usage and LB Gap.
domain: [digital-ocean]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Platform Edge

## Purpose

Describe how **public hostname traffic** reaches platform workloads when a public edge is enabled.

## Owns

- Optional DigitalOcean DNS records pointing at Droplet addresses (A/AAAA), when DO manages DNS
- Recognition that external DNS may be used instead
- Host-shape pattern: reverse proxy on the Droplet terminates public HTTP(S) to internal services
- Cluster-shape practice in current inventories: no DO Load Balancer / DO DNS; public mapping often unspecified (port-forward / Gap)

## Does not own

- Certificate automation craft (out of scope)
- Application routing rules inside the mesh
- Domain business content

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Points at | [[droplet-compute]] | Public IPv4/IPv6 |
| Opens | [[cloud-firewall]] | 80/443 when public edge enabled |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Edge patterns practiced (DO DNS vs external; host reverse proxy) | Live production hostname (Gap) |
| Absence of DO Load Balancer in current inventories | That public edge is always on (optional / often incomplete) |

## Usage

### Connect / operate

| Surface | House posture |
| --- | --- |
| Host shape | DNS (DO or external) → Droplet IP → reverse proxy → services |
| Cluster shape | Public edge often unspecified in inventories — Gap; do not assume DO LB |
| Firewall | Open 80/443 only when edge enabled ([[cloud-firewall]]) |
| Common ops | Create/update DNS record; reload proxy; verify TLS (cert craft = eng) |

### Material config

| Knob | Why it matters |
| --- | --- |
| DO DNS vs external | Who owns the zone |
| Public IPv4/IPv6 on Droplet | Target of records |
| Proxy virtual hosts | Host routing (eng) |
| DO Load Balancer | **Not practiced** — introducing it is a deliberate change |

### Pricing / limits (class)

- DNS is typically low/no incremental cost at house scale.
- DO Load Balancer would add a fixed monthly class if adopted — currently Gap/not practiced.
- Bandwidth egress still billed via Droplet/DOKS allowances.

### Failure / controls

| Mode | Posture |
| --- | --- |
| 80/443 open without need | Excess exposure |
| Assuming DO LB exists | False for current inventories |
| Hostname as doctrine | Forbidden — env Gap |

## Owner of truth

Platform operators (ownership Untapped).

## Evidence

- **Lived:** Host shape may provision DO DNS and/or rely on external DNS; reverse-proxy maturity varies (Gap). Cluster inventories did not define DO DNS/LB.
- **Remote:** DO DNS / Load Balancers product docs — LB unused here.

## Gaps / Untapped

- Live hostnames
- Cluster public ingress pattern
- Whether DO LB will ever be adopted
- Cert automation ownership

## Further detail

- [DigitalOcean docs](https://docs.digitalocean.com/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[droplet]]
