---
type: map
status: draft
id: systems-knowledge-base-map-sql-server
concern: sql-server
description: SQL Server family atlas — product surfaces plus deep engine/SSIS capability notes.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Atlas

Browse the **SQL Server suite** at systems grain: product surfaces **and** deep engine/SSIS behaviour. No schema dumps, no T-SQL craft, no vendor encyclopaedia paste.

## Product systems

| Note | Role |
| --- | --- |
| [[sql-server-engine]] | Database Engine SoR grain |
| [[ssms]] | Admin / query client |
| [[ssis]] | Integration Services product home |
| [[ssrs]] | Paginated report server |
| [[azure-sql-differences]] | Azure SQL vs box feature deltas |

## Engine capabilities (deep)

| Note | Question |
| --- | --- |
| [[sql-server-object-model]] | Instance/DB/schema/object hierarchy |
| [[sql-server-principals-securables]] | Logins, users, roles, securables |
| [[sql-server-files-filegroups]] | Data/log files and filegroups |
| [[sql-server-collation]] | Collation behaviour |
| [[sql-server-pages-extents]] | Pages, extents, fragmentation phenomenon |
| [[sql-server-indexes-statistics]] | Indexes and optimizer statistics |
| [[sql-server-transaction-log]] | WAL, VLFs, truncation |
| [[sql-server-memory]] | Buffer pool, grants, plan cache |
| [[sql-server-concurrency-locking]] | Locks, isolation, deadlocks |
| [[sql-server-tempdb]] | Shared temp/version store database |
| [[sql-server-recovery-backup]] | Recovery models and backup types |
| [[sql-server-agent]] | Jobs, steps, schedules |
| [[sql-server-maintenance-checks]] | CheckDB / index maintain capabilities |
| [[sql-server-tables-constraints]] | Tables and declarative constraints |
| [[sql-server-programmability-objects]] | Views, procs, functions, triggers |

## SSIS capabilities (deep)

| Note | Question |
| --- | --- |
| [[ssis-catalog-model]] | SSISDB projects/environments/executions |
| [[ssis-control-data-flow]] | Control vs data flow component classes |
| [[ssis-deployment-build]] | ispac/catalog deploy vs eng CI |

## Processes

| Note | Question |
| --- | --- |
| [[connect-administer-sql-server]] | Connect and administer |
| [[backup-restore-sql-server]] | Backup/restore sequences |
| [[deploy-run-ssis-package]] | Deploy and run SSIS |
| [[publish-ssrs-report]] | Publish SSRS report |

## Glossary

[[sql-instance]] · [[t-sql]] · [[page]] · [[extent]] · [[vlf]] · [[isolation-level]] · [[recovery-model]] · [[ssis-package]] · [[ssisdb]] · [[paginated-report]]

## Interfaces / Gaps

| Counterpart | Status |
| --- | --- |
| [[azure-data-factory]] | ADF / Azure-SSIS bridge — partial |
| [[postgres-engine]] | Peer engine — SoR split Untapped |
| Engineering warehouse craft | Out of vault — engineering-knowledge-base warehouse atlas / T-SQL craft (env-branch promotion is eng craft, not this atlas) |
| House schedules / RPO / package inventory | Gaps |
| Named persistent Dev / UAT / Prod SQL instances | **Untapped** — elevate lived inventory when known; do not invent hostnames |

## Evidence posture

- **Lived:** on-prem/VM **and** Azure SQL practiced.
- **Remote:** Microsoft Learn architecture guides (pages/extents, log, recovery, SSIS catalog) — claim-card only.

## Further detail

Out-of-vault wire/field matrices and deep vendor manuals stay linked, not pasted ([[link-further-detail]] · [[further-detail-hubs]]):

- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/)
- [SSIS](https://learn.microsoft.com/en-us/sql/integration-services/)
- [SSRS](https://learn.microsoft.com/en-us/sql/reporting-services/)
- [SSMS](https://learn.microsoft.com/en-us/ssms/sql-server-management-studio-ssms)
- [Azure SQL feature comparison](https://learn.microsoft.com/en-us/azure/azure-sql/database/features-comparison)

## Usability wave

- **Travel-guide useful:** met earlier (connect/admin/SSIS/SSRS).
- **Engine-deep useful:** Waves A–G capability notes landed 2026-07-20 — agent can answer object model, storage, concurrency, recovery, programmability kinds, SSIS catalog/flow/deploy **without inventing craft**.
- Interfaces still **partial**.

## Related

- [[scope]] · [[platform-watchlist]] · [[common-case-coverage]] · [[postgres-atlas]] · [[catalog-maps]]
