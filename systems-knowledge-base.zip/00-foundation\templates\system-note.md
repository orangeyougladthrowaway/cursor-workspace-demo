---
type: template
status: draft
id: systems-knowledge-base-tpl-system
description: Minimum fields for a living system note.
updated: 2026-07-16
---

# System note

Copy into `50-guidance/systems/{slug}.md`. Fill every field. One system question per note.

```markdown
---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-…
concern: systems
description: "…"
domain: []
derived_from:
  - "[[system-sor-honesty]]"
updated: YYYY-MM-DD
---

# {Title matching basename}

## Purpose

One sentence.

## Owns (facts / capabilities)

-

## Does not own

-

## Upstream / downstream (business interfaces)

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Upstream | | |
| Downstream | | |

## Authoritative for / not authoritative for

| Authoritative | Not authoritative |
| --- | --- |
| | |

## Owner of truth

-

## Further detail

- (https links to vendor/docs hubs for any Declined / out-of-scope grain — [[link-further-detail]]; do not paste payloads)

## Related glossary

- (link real glossary stems — do not invent placeholders)
```
