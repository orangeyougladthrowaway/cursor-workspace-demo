---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-009
concern: systems
description: ServiceDesk Plus Cloud — ITSM SoR densified to useful (lived Cloud; processes; API).
domain: [manageengine-servicedesk]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Servicedesk Plus

## Purpose

Provide **IT service management** — incident and service-request lifecycle — on **ServiceDesk Plus Cloud**.

## Owns

- Requests (and related notes, worklogs, resolutions) as desk records
- Technician / role-gated access to those records
- Product modules enabled in the **Cloud** edition (Asset, Change, etc. beyond core requests — **module set Untapped**)

## Does not own

- CRM relationship SoR (→ [[zoho-crm]])
- Engineering backlog / delivery work items (→ Azure DevOps family — not this note)
- Infrastructure hosting of the desk product itself (platform family)
- Full ManageEngine suite encyclopaedia

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Lateral | [[zoho-crm]] / [[zoho-flow]] | Gap — create/update ticket from CRM or Flow (aspirational) |
| Lateral | [[azure-devops-org]] | Gap — dual-track work Untapped |
| Downstream | Requesters / technicians | Human ticket lifecycle |

## Processes

- [[raise-service-desk-request]] · [[resolve-service-desk-request]] · [[integrate-servicedesk-via-api]]


## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Ticket state and desk fields **in ServiceDesk Plus** when it is house ITSM SoR | Informal chat as ticket record |
| API-visible request operations for the deployed edition | Modules never licensed |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| UI | ServiceDesk Plus Cloud web client |
| API | REST **v3** (Cloud) — operations aligned with web client modules; DC-specific base URL |
| Auth | **OAuth 2.0** (Zoho API console / scopes class per ManageEngine Cloud docs) — house token inventory Untapped |
| Common ops | Create/view/update/close requests; notes; worklogs; admin metadata imports (module-dependent) |

### Material config

| Knob | Why it matters |
| --- | --- |
| Edition | **Cloud** (lived) — do not assume on-prem key auth |
| Categories / templates / SLAs | Operational SoR for routing and clocks |
| Technician roles + OAuth apps | Integration privilege ceiling |
| Mail / portal intake | Bypass API creators if misconfigured |

### Pricing / limits (class)

- Cloud edition license count drives module access and scale — **house contract Untapped**.
- Confirm Cloud API rate limits before bulk sync.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Invalid/expired OAuth token | Calls fail; treat as control not silent skip |
| Dual SoR with chat/email | Prefer desk record as authoritative when practiced |

## Owner of truth

Service-desk operators (Untapped).

## Evidence

- **Lived:** User relay 2026-07-20 — **Cloud** edition. No practiced CRM/Flow bridges yet (desired later).
- **Remote:** [ServiceDesk Plus Cloud API v3](https://www.manageengine.com/products/service-desk/sdpod-v3-api/) · [OAuth 2.0](https://www.manageengine.com/products/service-desk/sdpod-v3-api/getting-started/oauth-2.0.html).

## Gaps / Untapped

- Category / SLA / approval model as practiced
- Named operators and OAuth app owners
- Modules beyond core request (Asset, Change, …)
- CRM / Flow bridges (aspirational — not practiced)
- Dual-track with Azure DevOps (Untapped)

## Further detail

- [ServiceDesk Plus Cloud API v3](https://www.manageengine.com/products/service-desk/sdpod-v3-api/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[service-desk-request]]
