---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-021
concern: systems
description: Azure VM compute — IaaS VM grain for business infra (lived significant Azure).
domain: [azure-cloud]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Azure Vm Compute

## Purpose

Provide **Azure Virtual Machines** (and related compute capacity) as IaaS hosts for business workloads.

## Owns

- VM existence, size/SKU class, disks, extensions at ARM grain
- Guest OS identity at host grain (not app SoR inside the guest)

## Does not own

- DigitalOcean Droplets (→ DO family)
- App/domain data SoR inside VMs
- Terraform module craft (→ [[terraform-azurerm-provider]] as provider only)

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Network | [[azure-virtual-network]] | NIC / subnet attachment |
| Identity | [[azure-entra-id]] | Login / managed identity |
| Data | [[sql-server-engine]] / [[postgres-engine]] | May host or connect to DB |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Whether a VM resource exists in the subscription | Files inside the guest as vault doctrine |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| Portal / CLI / ARM / azurerm | Create/start/stop/resize; extensions |
| Auth | RBAC on resource; guest admin separate |
| Common ops | Image choice; disk SKU; availability set/zone; backup |

### Material config

| Knob | Why it matters |
| --- | --- |
| Size / disk | Cost and performance |
| Public IP vs private only | Exposure |
| Identity (system/user MSI) | Secretless Azure API access |

### Pricing / limits (class)

- Per-second/minute compute + disk + bandwidth — house contract Untapped.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Open RDP/SSH to internet | Prefer JIT / private access |
| Orphan disks | Cost leak |

## Owner of truth

Cloud / infra operators (Untapped).

## Evidence

- **Lived:** User relay — VMs part of significant Azure business infra.
- **Remote:** Azure VM Learn docs (claim-card).

## Gaps / Untapped

- Workload placement standards
- Named resource groups (no object-name doctrine)

## Further detail

- [Azure Virtual Machines](https://learn.microsoft.com/en-us/azure/virtual-machines/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[resource-group]]
