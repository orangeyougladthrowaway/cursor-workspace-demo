---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-009
concern: systems
description: Self-hosted inference on DOKS GPU pools or GPU Droplet — SoR plus usage.
domain: [digital-ocean]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Self Hosted Inference Compute

## Purpose

Run **inference runtimes on platform compute we operate** — DOKS GPU node pools and/or a dedicated GPU Droplet — rather than calling DO Serverless Inference.

## Owns

- Placement of inference listeners on GPU capacity (in-cluster pools or external GPU Droplet)
- Network exposure patterns at the firewall grain (ports allowed from VPC / workers)

## Does not own

- DO Serverless Inference product (→ [[serverless-inference]])
- Model catalogue / training pipelines
- Domain application logic that calls inference

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Upstream | [[doks-kubernetes]] | GPU pools when topology is in-cluster |
| Upstream | [[droplet-compute]] | GPU Droplet when topology is external host |
| Upstream | [[cloud-firewall]] | Ingress rules to inference ports |
| Downstream | In-cluster API services | Call local/private inference URLs |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Where self-hosted inference compute lives (pool vs Droplet) | Which topology is live in a given account (Gap) |
| Self-hosted vs serverless as distinct system choices | Specific model names or sizes as doctrine |

## Usage

### Connect / operate

| Surface | House posture |
| --- | --- |
| Topologies | (A) GPU node pool on DOKS (B) GPU Droplet beside cluster — pick one primary per env |
| Access | Private URLs inside VPC; firewall-gated ports; not public by default |
| Lifecycle | GPU pool/Droplet provisioned with platform capacity ([[provision-platform-host]]); runtime packaging is eng |
| Common ops | Scale GPU pool; restart inference runtime; verify firewall membership after scale |

### Material config

| Knob | Why it matters |
| --- | --- |
| GPU SKU / pool size | Dominant cost; availability varies |
| In-cluster vs external Droplet | Networking and blast radius differ |
| Inference ports | Must match [[cloud-firewall]] rules |
| Model weights location | Often [[spaces-object-storage]] or image layers — eng detail |

### Pricing / limits (class)

- GPU workers/Droplets are **high price class** vs CPU — billed like GPU Droplet rates (see DOKS/Droplet pricing).
- Idle GPU still costs — scale to zero policies are eng/ops choice (Untapped).
- Some H100-class SKUs may need DO sales/reservation — house contract Untapped.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Open inference port to world | Control failure |
| Confusing with serverless | Wrong dependency model |
| GPU node NotReady | Workloads schedule fail — product readiness features exist; house policy Untapped |

## Owner of truth

Platform operators (ownership Untapped).

## Evidence

- **Lived:** Cluster-shaped inventories support CPU pools, GPU pools, or external GPU Droplet topologies. Host-shaped current set uses serverless instead.

## Gaps / Untapped

- Which topology is live per account
- Idle scale policy
- Named operators / GPU reservations

## Further detail

- [Droplets](https://docs.digitalocean.com/products/droplets/) (GPU/host topologies; DOKS worker pricing class on product pages)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[doks]] · [[droplet]]
