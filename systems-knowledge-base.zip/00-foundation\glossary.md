---
type: foundation
status: draft
id: systems-knowledge-base-fnd-glossary
description: Cross-cutting systems-knowledge-base terms — SoR, family, coverage cell, admit labels.
updated: 2026-07-16
---

# Glossary

House meanings for vault-wide terms. Platform-specific terms live under `50-guidance/glossary/` and are indexed from family atlases.

| Term | Meaning here |
| --- | --- |
| **SoR** | Source of record — the system authoritative for a named class of facts |
| **Family** | A domain / platform cluster with an atlas under `maps/families/` |
| **Coverage cell** | A completeness facet on [[common-case-coverage]] (atlas, systems, processes, …) |
| **Lived** | Evidence from our projects / operator practice |
| **Remote** | Evidence from official docs / trusted external sources |
| **Admit** | Decision to let a source into the claim pipeline (`pressure`, `specialise`, `pointer`, `defer`, `reject`) |
| **Gap** | Known missing truth — explicit, not invented |
| **Untapped** | Evidence exists (repo/doc) but no elevated note yet |
| **Guidance** | Living domain detail — bulk product of this vault |
| **Principle** | Portable constraint — thin here; domain facts are not principles |

Platform glossary stems (DigitalOcean): see [[digital-ocean-atlas]] and linked glossary notes.
