# Agent notes — Systems Knowledge Base

## Authority split

| Source | Path | Owns | Write? |
| --- | --- | --- | --- |
| **systems-knowledge-base** (this repo) | `X:\repos\systems-knowledge-base` | Domain systems + process facts | **Yes** |

## Operating law

1. **Retrieve before write** — `README` → [[navigation]] → family atlas → notes.
2. **DigitalOcean first, then waves** — DO P0 useful is met; densify P1 per [[platform-watchlist]] waves (do not skip coverage honesty).
3. **Lived + remote** — both evidence branches required over time ([[knowledge-ingestion]]).
4. **No invented SoR** — Gaps beat fiction.
5. **Hand-write** — no bulk note generators.
6. Keep engineering craft and change-method material out of this vault.
7. Skills: `systems-knowledge-base-lookup` · `systems-knowledge-base-plan` · `systems-knowledge-base-amend` · `systems-knowledge-base-verify` · `systems-knowledge-base-review` → operational workflows under [[agent-projection]].

## Start here

- [[navigation]] · [[scope]] · [[platform-watchlist]]
- [[digital-ocean-atlas]] (P0 family)
- [[common-case-coverage]] · [[ingest-coverage]]
- [[knowledge-ingestion]] · [[agent-projection]]
- [[lookup-domain-truth]] · [[plan-domain-amend]] · [[amend-domain-truth]] · [[verify-domain-note]] · [[review-domain-claim]]
- Branching / PRs: root `CONTRIBUTING.md` (house detail: sibling `agent-harness` → `docs/source-control.md`)

## Quarantine

Org-chart folders · SOP dumps · engineering craft bodies · change-method bodies · secrets · `_index.md` · `and`-joined names · alias rename shims
