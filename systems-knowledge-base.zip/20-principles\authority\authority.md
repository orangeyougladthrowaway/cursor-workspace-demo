---
type: category
status: draft
id: systems-knowledge-base-cat-authority
category: authority
description: Category spine — which source wins when notes and research conflict.
updated: 2026-07-16
---

# Authority

Principles about authority stacks for domain truth.
