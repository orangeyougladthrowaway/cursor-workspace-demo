---
type: principle
status: draft
id: systems-knowledge-base-p-002
category: boundaries
description: Keep engineering craft and change method out of domain-fact notes.
derived_from:
  - "[[boundaries]]"
  - "[[documentation-for-current-truth]]"
updated: 2026-07-16
---

# Sibling vault boundaries

Domain facts live here. Engineering craft and change methods stay out of systems-knowledge-base. Do not fork those bodies into systems-knowledge-base notes.
