---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-028
concern: glossary
description: Isolation level — session concurrency anomaly controls in SQL Server.
domain: [sql-server]
updated: 2026-07-20
---

# Isolation Level

**Isolation level** = engine setting controlling which concurrency anomalies are prevented ([[sql-server-concurrency-locking]]).
