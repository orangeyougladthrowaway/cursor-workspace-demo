---
name: systems-knowledge-base-lookup
description: Answers domain system/SoR/process questions from systems-knowledge-base. Use when asking what a system owns, how a process runs, or whether a fact is known.
disable-model-invocation: true
---

Follow `60-workflows/systems/lookup-domain-truth.md` (`systems-knowledge-base-wf-006`).

Gaps beat invention. Cite `systems-knowledge-base-…` ids. Do not invent SoR.
