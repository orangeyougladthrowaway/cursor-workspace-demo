---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-026
concern: processes
description: Deploy and run an SSIS package via catalog — operable sequence.
domain: [sql-server]
derived_from:
  - "[[process-note-honesty]]"
  - "[[ssis]]"
updated: 2026-07-20
---

# Deploy Run Ssis Package

## Purpose

Deploy an Integration Services project to the **SSIS Catalog** and execute it with monitored outcome.

## Triggers

- New/changed ETL must run in an environment
- Scheduled or on-demand load

## Actors / roles

- ETL developer / operator

## Inputs / outputs

| In | Out |
| --- | --- |
| Built IS project; environment params | Deployed catalog project |
| Execution request | Success/fail in catalog history; data side-effects |

## Operable sequence (business grain)

1. **Build** — package/project validated in design tooling (craft detail eng).
2. **Deploy** — to SSISDB folder/project.
3. **Configure** — map environment variables / sensitive params (secrets not in vault).
4. **Execute** — SSMS, Agent job, or automation.
5. **Monitor** — catalog reports; on failure, remediate source/dest/permissions.
6. **Do not** — paste package XML into this vault.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Execution outcome | [[ssis]] | Yes for integration run audit |
| Loaded data | Destination engines | Destination SoR |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Embedded passwords | Prefer sensitive parameters |
| Unowned schedules | Name operator for Agent jobs |

## Owner of this note’s truth

ETL owners (Untapped).
