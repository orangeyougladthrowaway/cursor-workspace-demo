---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-035
concern: systems
description: SQL Server concurrency — locks, latches, isolation levels, deadlocks as engine behaviour.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Concurrency Locking

## Purpose

Describe how the engine **coordinates concurrent sessions** — locks, isolation, versions, deadlocks — as product behaviour (not app transaction design guides).

## Mechanisms

| Mechanism | Behaviour |
| --- | --- |
| Locks | Protect rows/keys/pages/tables; modes (S/U/X/IS/IX/… class) |
| Lock escalation | Many fine locks → coarser grain under pressure |
| Latches / spinlocks | Short-term internal structure protection |
| Deadlock | Cycle of waits; engine chooses a victim |
| Blocking | Session waits on another’s lock — expected under contention |

## Isolation levels (engine options)

Read uncommitted / read committed (default class) / repeatable read / serializable / snapshot & RCSI (row-versioning class). Versioning uses **tempdb** (→ [[sql-server-tempdb]]). Isolation changes what anomalies are prevented vs allowed.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Isolation/lock phenomena | When apps should pick SNAPSHOT (eng) |

## Failure / controls

| Mode | Posture |
| --- | --- |
| Deadlock storms | Capture graphs; fix access order (eng) |
| Long open transactions | Blocks truncation & increases blocking |
| NOLOCK as default | Dirty reads — conscious tradeoff |

## Evidence

- **Remote:** Transaction locking / isolation Learn docs.

## Further detail

- [Transaction locking guide](https://learn.microsoft.com/en-us/sql/relational-databases/sql-server-transaction-locking-and-row-versioning-guide)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-tempdb]] · [[sql-server-transaction-log]] · [[sql-server-memory]]
