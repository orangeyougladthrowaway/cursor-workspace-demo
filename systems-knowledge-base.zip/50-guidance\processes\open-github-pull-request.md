---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-016
concern: processes
description: Open a GitHub pull request for review — house host practiced.
domain: [github]
derived_from:
  - "[[process-note-honesty]]"
  - "[[github-host]]"
  - "[[git-vcs]]"
updated: 2026-07-20
---

# Open Github Pull Request

## Purpose

Propose merging a branch via a **GitHub pull request** so review and checks gate integration.

## Triggers

- Topic branch pushed to GitHub
- Author ready for review

## Actors / roles

- Author
- Reviewers

## Inputs / outputs

| In | Out |
| --- | --- |
| Branch + base | Open PR with id/URL |
| Description / linked work | Reviewable change set |

## Operable sequence (business grain)

1. **Push branch** — to [[github-host]] ([[contribute-git-change]]).
2. **Open PR** — UI or API; set base branch, title, body.
3. **Request review** — assignees/teams Untapped.
4. **Checks run** — required status checks when configured (workflow craft out of scope).
5. **Await** — [[review-merge-github-pull-request]].

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| PR state | [[github-host]] | Yes |
| Commits | [[git-vcs]] | Yes |
| Work item | [[azure-devops-org]] | May dual-track — link policy Untapped |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| PR to unprotected trunk without review | Prefer required reviewers |
| Secrets in PR diff | Block merge; rotate |

## Owner of this note’s truth

Repo admins (Untapped).
