"""Wikilink resolution — basename-only targets must exist."""

from __future__ import annotations

import re

from tests.vault import extract_wikilinks, iter_notes, note_stems, read_text, rel_posix


def test_wikilinks_resolve_to_existing_notes() -> None:
    stems = note_stems()
    broken: list[str] = []
    for path in iter_notes():
        for target in extract_wikilinks(read_text(path)):
            if "/" in target or "\\" in target:
                broken.append(f"{rel_posix(path)} -> path-style [[{target}]]")
            elif target.endswith((".md", ".mdc")):
                broken.append(f"{rel_posix(path)} -> extension [[{target}]]")
            elif target not in stems:
                broken.append(f"{rel_posix(path)} -> missing [[{target}]]")
    assert not broken, "Broken wikilinks:\n" + "\n".join(broken[:50])


def test_no_path_style_wikilink_targets() -> None:
    offenders: list[str] = []
    for path in iter_notes():
        for target in extract_wikilinks(read_text(path)):
            if re.search(r"[/\\]", target):
                offenders.append(f"{rel_posix(path)}: [[{target}]]")
    assert not offenders, "\n".join(offenders)
