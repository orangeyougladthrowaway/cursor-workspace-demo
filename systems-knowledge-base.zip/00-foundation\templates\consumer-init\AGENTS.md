# Agent notes — <product-or-ops-name>

## Domain authority

Canonical **systems and business-process** knowledge lives in the **Systems Knowledge Base (systems-knowledge-base)**.

- **systems-knowledge-base path (edit one):** `.systems-knowledge-base` (gitignored junction) **or** `../systems-knowledge-base`
- systems-knowledge-base is the **primary source** for SoR, system roles, and process truth.
- Engineering craft and change methods are out of scope for this consumer pack.
- Do **not** invent parallel domain doctrine here. Do **not** edit/commit systems-knowledge-base from this workspace.

## Operating law (always)

1. **Retrieve before answer** — systems-knowledge-base `README` → `navigation` → **family atlas** → system/process notes.
2. Prefer `status: canonical`. Treat `draft` as unfinished.
3. Lived house facts in systems-knowledge-base win over generic vendor blogs for “what is true here.”
4. **No secrets** in this repo’s notes copied from systems-knowledge-base examples.
5. **No `consumer-init/` folder** left in this tree after setup.

## Start here (paths relative to systems-knowledge-base root)

- Family atlas (P0): `maps/families/digital-ocean/digital-ocean-atlas.md`
- Navigation: `00-foundation/navigation.md`
- Coverage: `60-workflows/knowledge/common-case-coverage.md`
- Agent protocol: `60-workflows/knowledge/agent-projection.md`

## This repo’s domain facets

<!-- e.g. digital-ocean, zoho — only platforms you actually touch -->

## Optional skills

`.cursor/skills/` = invoke-only. Point at systems-knowledge-base workflows/`id`s. Never paste note bodies.

Preferred: `systems-knowledge-base-lookup` · `systems-knowledge-base-plan` · `systems-knowledge-base-amend` · `systems-knowledge-base-verify` · `systems-knowledge-base-review`.

## Quarantine (do not elevate)

Invented SoR · vendor encyclopaedia paste · forking systems-knowledge-base note bodies · leftover `consumer-init/` · treating P1 platforms as deep-covered without a systems-knowledge-base deep dive
