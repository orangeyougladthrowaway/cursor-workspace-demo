---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-013
concern: processes
description: Contribute a change via Git commit and push to a shared remote.
domain: [git]
derived_from:
  - "[[process-note-honesty]]"
  - "[[git-vcs]]"
updated: 2026-07-20
---

# Contribute Git Change

## Purpose

Record a change in **Git** history and publish it to a shared remote (GitHub and/or Azure Repos — both practiced).

## Triggers

- Author completed a logical change set
- Ready for review or integration

## Actors / roles

- Author
- Remote host controls (branch protection) on [[github-host]] / [[azure-devops-org]]

## Inputs / outputs

| In | Out |
| --- | --- |
| Working tree diffs | Commit(s) on a branch |
| Remote credentials | Updated remote ref |

## Operable sequence (business grain)

1. **Clone/fetch** — sync from remote on [[github-host]] and/or Azure Repos.
2. **Branch** — create topic branch from agreed base (naming Untapped).
3. **Commit** — atomic commits with message; no secrets in tree.
4. **Push** — publish branch to the chosen remote(s).
5. **Review path** — open PR/MR on host ([[open-github-pull-request]] or host-equivalent on ADO).

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Commit history | [[git-vcs]] | Yes |
| Hosted ref / PR | [[github-host]] and/or [[azure-devops-org]] | Yes for shared collaboration |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Force-push shared branch | Avoid; host protection |
| Secret committed | Rotate + history cleanup eng craft |

## Owner of this note’s truth

Repo maintainers (Untapped).
