---
type: map
status: draft
id: systems-knowledge-base-map-azure-cloud
concern: azure-cloud
description: Azure cloud atlas — business infra surfaces + azurerm; lived primary business cloud.
domain: [azure-cloud]
updated: 2026-07-20
---

# Azure Cloud Atlas

Browse for **Microsoft Azure** as **lived primary business infrastructure**, plus Terraform **azurerm** provider grain. Module/pipeline YAML craft out of scope. DigitalOcean remains a separate family (P0 exemplar for its landscape).

## Systems

| Note | Role |
| --- | --- |
| [[azure-subscription]] | Tenant/subscription ARM ownership |
| [[terraform-azurerm-provider]] | `azurerm` provider surface |
| [[azure-vm-compute]] | IaaS VMs |
| [[azure-virtual-network]] | VNet / segmentation |
| [[azure-entra-id]] | Cloud identity / auth (GPO hybrid Gap) |
| [[azure-security-controls]] | NSG / Key Vault / Defender class |
| [[azure-data-factory]] | Managed data integration |
| [[azure-ai-foundry]] | AI project / model deployment platform |

## Processes

| Note | Question |
| --- | --- |
| [[authenticate-azurerm-provider]] | Provider auth |
| [[plan-azure-arm-change]] | Plan ARM change |
| [[apply-azure-arm-change]] | Apply ARM change |
| [[provision-azure-vm]] | Provision VM |
| [[segment-azure-network]] | Segment networking |
| [[run-azure-data-factory-pipeline]] | Run ADF pipeline |
| [[deploy-azure-ai-foundry-model]] | Deploy Foundry model |

## Glossary

[[service-principal]] · [[resource-group]]

## Interfaces / Gaps

| Counterpart | Status |
| --- | --- |
| [[digital-ocean-atlas]] | Dual cloud — roles differ; business infra lived on Azure |
| [[sql-server-atlas]] | Azure SQL practiced alongside on-prem/VM |
| [[postgres-atlas]] | Non-DO Postgres may sit on Azure VMs/etc. Untapped |
| [[azure-devops-atlas]] | Delivery tooling adjacent |
| Group Policy / on-prem AD | Gap — hybrid detail not densified |

## Evidence posture

- **Lived:** Azure is significant / primary business infra (VMs, network, security, auth, Foundry, ADF, Azure SQL).
- **Remote:** Learn + azurerm docs — claim-card only.

## Further detail

Out-of-vault wire/field matrices and deep vendor manuals stay linked, not pasted ([[link-further-detail]] · [[further-detail-hubs]]):

- [Azure Learn hub](https://learn.microsoft.com/en-us/azure/)
- [Azure Resource Manager](https://learn.microsoft.com/en-us/azure/azure-resource-manager/)
- [Microsoft Entra](https://learn.microsoft.com/en-us/entra/)
- [Azure Data Factory](https://learn.microsoft.com/en-us/azure/data-factory/)
- [Azure AI Foundry](https://learn.microsoft.com/en-us/azure/ai-foundry/)

## Usability wave

**Useful** expanded: Atlas/Systems/Usage/Processes/Controls/Glossary/Freshness for named surfaces. Interfaces partial. GPO not a full system note yet.

## Related

- [[scope]] · [[platform-watchlist]] · [[digital-ocean-atlas]] · [[catalog-maps]]
