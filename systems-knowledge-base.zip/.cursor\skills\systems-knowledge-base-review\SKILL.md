---
name: systems-knowledge-base-review
description: Reviews domain claims for invention, stale atlas, and premature P1 depth. Use when reviewing systems-knowledge-base answers or note changes.
disable-model-invocation: true
---

Follow `60-workflows/knowledge/review-domain-claim.md` (`systems-knowledge-base-wf-010`).

Findings first. No green coverage theatre.
