---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-011
concern: glossary
description: Service desk request — ServiceDesk Plus Cloud ticket grain.
domain: [manageengine-servicedesk]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-20
---

# Service Desk Request

**Service desk request** = incident or service-request ticket in [[servicedesk-plus]] (Cloud). Authoritative desk record when practiced; chat/email alone is not.
