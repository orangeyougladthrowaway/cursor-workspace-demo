---
type: catalog
status: draft
id: systems-knowledge-base-cat-guidance
description: Inventory of guidance notes (systems, processes, glossary).
updated: 2026-07-16
---

# Catalog Guidance

## Systems

| Stem | Domain |
| --- | --- |
| [[platform-vpc]] | digital-ocean |
| [[cloud-firewall]] | digital-ocean |
| [[doks-kubernetes]] | digital-ocean |
| [[droplet-compute]] | digital-ocean |
| [[managed-postgres]] | digital-ocean |
| [[spaces-object-storage]] | digital-ocean |
| [[container-registry]] | digital-ocean |
| [[serverless-inference]] | digital-ocean |
| [[self-hosted-inference-compute]] | digital-ocean |
| [[platform-edge]] | digital-ocean |

## Processes

| Stem | Domain |
| --- | --- |
| [[provision-platform-host]] | digital-ocean |
| [[release-workload-to-platform]] | digital-ocean |
| [[store-retrieve-platform-objects]] | digital-ocean |

## Glossary

| Stem | Domain |
| --- | --- |
| [[doks]] | digital-ocean |
| [[droplet]] | digital-ocean |
| [[spaces]] | digital-ocean |
| [[docr]] | digital-ocean |
| [[vpc]] | digital-ocean |
| [[managed-database]] | digital-ocean |
