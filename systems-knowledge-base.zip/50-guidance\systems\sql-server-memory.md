---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-034
concern: systems
description: SQL Server memory — buffer pool, plan cache, memory grants class.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Memory

## Purpose

Explain major **memory consumers** in the engine — how data and plans stay in RAM — without capacity-planning worksheets.

## Consumers (class)

| Area | Behaviour |
| --- | --- |
| Buffer pool | Caches data/index pages; durable data still on disk + log |
| Plan cache | Stores compiled plans; invalidation/recompile phenomena |
| Memory grants | Query workspace for sort/hash — insufficient grant → spill to tempdb |
| Clerks / caches | Other engine caches (metadata, etc.) |
| max server memory | Cap for buffer pool-centric target (box); PaaS is managed |

Memory is **not** a substitute for correct recovery — crash still uses log+data files.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Memory subsystem behaviour | VM overcommit / Azure SKU sizing tables |

## Azure SQL note

Resource governance / SLA tiers replace many knobs; watch DTU/vCore and `sys.dm_db_resource_stats` class metrics.

## Failure / controls

| Mode | Posture |
| --- | --- |
| Grant timeouts / spills | Query shape + stats (eng/ops) |
| OS memory pressure | Leave headroom on box; prefer max server memory |

## Evidence

- **Remote:** Memory management / buffer pool Learn docs.

## Further detail

- [Memory management architecture](https://learn.microsoft.com/en-us/sql/relational-databases/memory-management-architecture-guide)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-tempdb]] · [[sql-server-indexes-statistics]] · [[sql-server-pages-extents]]
