---
type: workflow
status: draft
id: systems-knowledge-base-wf-008
concern: knowledge
description: Apply knowledge-ingestion to elevate system/process/glossary notes; amend-first.
derived_from:
  - "[[knowledge-ingestion]]"
  - "[[plan-domain-amend]]"
  - "[[agent-projection]]"
updated: 2026-07-17
---

# Amend domain truth

Use inside a **systems-knowledge-base workspace** after [[plan-domain-amend]] (or equivalent agreed claims).

Consumers must not run this against a mounted read-only vault ([[agent-projection]]).

## Preconditions

- Agreed claims / admit path
- Target homes located
- No secrets/PII in the change set

## Retrieve

1. Follow [[knowledge-ingestion]] end-to-end.
2. Open target living notes and atlas indexes.
3. Update [[ingest-coverage]] / [[common-case-coverage]] when cells move.

## Steps

1. Collide each claim with living notes.
2. Amend-first — prefer editing existing notes over parallel lore.
3. Keep engineering craft and change methods out of systems-knowledge-base.
4. Hand-write only — no bulk generators.
5. Index atlases / catalogs in the same change when required.
6. Run [[verify-domain-note]] before calling done.

## Output

- Notes amended (stems + ids)
- Ledger updates
- Residual Gaps

## Handoff

[[verify-domain-note]] → optional [[review-domain-claim]].

## Forbidden

- Inventing SoR to close Gaps
- Elevating from consumer sessions into the mount
- Soft “complete” without coverage honesty
