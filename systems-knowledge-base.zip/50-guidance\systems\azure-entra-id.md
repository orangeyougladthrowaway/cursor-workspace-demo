---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-023
concern: systems
description: Microsoft Entra ID — cloud identity/auth grain; GPO hybrid adjacent Gap.
domain: [azure-cloud]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Azure Entra Id

## Purpose

Provide **Microsoft Entra ID** (Azure AD) as cloud identity and access management for users, apps, and workload identities.

## Owns

- Tenant users/groups/app registrations / enterprise apps
- Auth protocols (OAuth2/OIDC/SAML class) for cloud apps
- Conditional Access / MFA policies as configured (detail Untapped)
- Workload identities (managed identities, service principals)

## Does not own

- Full on-prem AD / **Group Policy** encyclopaedia — hybrid GPO is adjacent Gap (lived mentioned; not densified as Windows-admin bible)
- App business SoR
- Secrets in this vault

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Secures | Azure resources / SaaS | Token/RBAC |
| Lateral | [[azure-devops-org]] / [[github-host]] | Org SSO class Untapped |
| Lateral | [[zoho-crm]] / [[servicedesk-plus]] | Possibly separate IdPs — Gap |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Cloud identity existence and app grants in the tenant | Local SAM accounts on a single VM as enterprise IdP |

## Usage

### Connect / operate

| Surface | Posture |
| --- | --- |
| Entra admin centre / Graph API | Users, apps, CA policies |
| Auth | Interactive, SP, MSI, OIDC federation |
| Common ops | App registration; assign roles; rotate credentials |

### Material config

| Knob | Why it matters |
| --- | --- |
| Tenant boundary | Hard security perimeter |
| CA / MFA | Account-takeover posture |
| Hybrid join / sync | GPO/AD interaction — Untapped detail |

### Pricing / limits (class)

- Entra P1/P2 feature packs — house Untapped.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Over-privileged app SP | Least privilege; certify |
| Credential in git | Forbidden |

## Owner of truth

Identity admins (Untapped).

## Evidence

- **Lived:** Auth part of significant Azure business infra; Group Policy called out as in-landscape (hybrid detail Untapped).
- **Remote:** Microsoft Entra Learn docs.

## Gaps / Untapped

- Hybrid AD ↔ Entra sync topology
- GPO as practiced (defer deep Windows admin notes)
- Which apps federate to Entra vs other IdPs

## Further detail

- [Microsoft Entra](https://learn.microsoft.com/en-us/entra/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[service-principal]]
