---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-032
concern: processes
description: Segment Azure networking — VNet/subnet/NSG operable sequence.
domain: [azure-cloud]
derived_from:
  - "[[process-note-honesty]]"
  - "[[azure-virtual-network]]"
updated: 2026-07-20
---

# Segment Azure Network

## Purpose

Create or adjust **VNet/subnet/NSG** segmentation so workloads only get intended paths.

## Triggers

- New environment/app tier
- Security finding requires tighter rules

## Actors / roles

- Network / security operators

## Inputs / outputs

| In | Out |
| --- | --- |
| Address plan; tier intents | VNet/subnets/NSGs |
| Peering needs | Connected hubs/spokes |

## Operable sequence (business grain)

1. **Plan CIDRs** — avoid overlap.
2. **Create/update VNet/subnets** — [[azure-virtual-network]].
3. **Apply NSG/Firewall** — [[azure-security-controls]]; deny-by-default bias.
4. **Peer / private endpoints** as required.
5. **Validate** — connectivity test from intended sources only.
6. **Document Gaps** — hybrid/VPN detail Untapped.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Network config | [[azure-virtual-network]] | Yes |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Any-any allow | Reject for prod tiers |
| Shadow IT public IPs | Inventory Untapped |

## Owner of this note’s truth

Network operators (Untapped).
