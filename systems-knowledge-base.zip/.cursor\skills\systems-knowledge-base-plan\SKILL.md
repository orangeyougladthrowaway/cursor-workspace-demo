---
name: systems-knowledge-base-plan
description: Plans elevating domain evidence into systems-knowledge-base. Use when planning system/process/glossary note amendments from lived or remote sources.
disable-model-invocation: true
---

Follow `60-workflows/knowledge/plan-domain-amend.md` (`systems-knowledge-base-wf-007`).

Read-only planning. Do not invent SoR to fill Gaps.
