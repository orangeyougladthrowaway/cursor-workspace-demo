---
type: map
status: draft
id: systems-knowledge-base-map-ado
concern: azure-devops
description: Azure DevOps atlas — WIT/repos processes densified; CI YAML out of scope.
domain: [azure-devops]
updated: 2026-07-20
---

# Azure Devops Atlas

Browse for **Azure DevOps** as delivery tracking and Git hosting SoR (peer with GitHub).

## Systems

| Note | Role |
| --- | --- |
| [[azure-devops-org]] | Org/project; work items; Azure Repos |

## Processes

| Note | Question |
| --- | --- |
| [[create-azure-devops-work-item]] | How work items are created |
| [[transition-azure-devops-work-item]] | How board state advances |
| [[host-git-on-azure-repos]] | How Azure Repos hosts Git |

## Glossary

[[work-item]]

## Interfaces / Gaps

| Counterpart | Status |
| --- | --- |
| [[git-vcs]] / [[github-host]] | Dual source hosting practiced |
| [[servicedesk-plus]] | Gap — ticket ↔ WIT |
| [[azure-cloud-atlas]] | Env provisioning handoff Untapped |

## Evidence posture

- **Lived:** Practiced as host alongside GitHub.
- **Remote:** ADO REST API docs.

## Further detail

Out-of-vault wire/field matrices and deep vendor manuals stay linked, not pasted ([[link-further-detail]] · [[further-detail-hubs]]):

- [Azure DevOps docs](https://learn.microsoft.com/en-us/azure/devops/)

## Usability wave

**Useful** on Atlas/Systems/Usage/Processes/Controls/Glossary/Freshness. Interfaces partial.

## Related

- [[git-atlas]] · [[github-atlas]] · [[catalog-maps]]
