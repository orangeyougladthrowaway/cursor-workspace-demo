---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-044
concern: systems
description: SSIS deployment and build — project/ispac/catalog vs legacy; vs eng CI.
domain: [sql-server]
updated: 2026-07-20
---

# Ssis Deployment Build

## Purpose

Describe how SSIS **projects are built and deployed** as product mechanics — distinct from house CI YAML.

## Project deployment model (current)

1. **Build** produces deployment artefact (`.ispac` class) from IS project.
2. **Deploy** to SSIS Catalog folder (or validate).
3. **Configure** via parameters/environments.
4. **Execute** via catalog / Agent / API.

Versions retained in catalog until maintenance purges.

## Legacy package deployment

File-system / MSDB package store class — still appears in older estates; prefer catalog understanding for modern box.

## Build vs eng CI

| Systems | Engineering |
| --- | --- |
| What ispac/catalog deploy *is* | Whether Azure DevOps/GitHub builds ispac; SqlPackage-like gates |

## Owns / not

| Owns | Does not own |
| --- | --- |
| Deploy/build product model | Pipeline YAML |

## Failure / controls

| Mode | Posture |
| --- | --- |
| Deploy without environment refs | Wrong connection at run |
| Skipping validation | Runtime surprise |

## Evidence

- **Remote:** Deploy Integration Services projects Learn docs.

## Further detail

- [Deploy SSIS projects](https://learn.microsoft.com/en-us/sql/integration-services/packages/deploy-integration-services-ssis-projects-and-packages)
- [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[ssis-catalog-model]] · [[deploy-run-ssis-package]] · [[ssis]]
