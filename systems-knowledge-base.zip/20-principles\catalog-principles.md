---
type: catalog
status: draft
id: systems-knowledge-base-cat-principles
description: Inventory of principle categories and leaves.
updated: 2026-07-16
---

# Catalog principles

| Category | Leaves |
| --- | --- |
| [[ownership]] | [[named-source-of-record]] |
| [[boundaries]] | [[sibling-vault-boundaries]] |
| [[honesty]] | [[gaps-over-fiction]] |
| [[authority]] | [[lived-beats-remote]] |
| [[change]] | [[amend-on-business-change]] |
| [[restraint]] | [[no-encyclopaedia-paste]], [[link-further-detail]] |
