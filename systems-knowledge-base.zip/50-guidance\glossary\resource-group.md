---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-018
concern: glossary
description: Resource group — Azure ARM grouping scope inside a subscription.
domain: [azure-cloud]
updated: 2026-07-20
---

# Resource Group

**Resource group** = ARM deployment/grouping scope inside an [[azure-subscription]].
