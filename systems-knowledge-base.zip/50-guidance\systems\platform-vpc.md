---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-004
concern: systems
description: VPC — private network scope attaching DOKS, Droplets, managed DB.
domain: [digital-ocean]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Platform Vpc

## Purpose

Provide the **private network (VPC)** that scopes platform resources to one another.

## Owns

- VPC identity and CIDR scope as provisioned (or attached when using an existing VPC)
- Attachment point for compute and managed data plane resources

## Does not own

- Host firewall policy detail (→ [[cloud-firewall]])
- Public DNS / edge addressing (→ [[platform-edge]])
- Application traffic semantics inside the VPC

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Downstream | [[doks-kubernetes]] | Cluster `vpc` attachment |
| Downstream | [[droplet-compute]] | Droplet `vpc` attachment |
| Downstream | [[managed-postgres]] | Private network attachment |
| Lateral | [[cloud-firewall]] | Rules often allow VPC CIDR east-west |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Which platform resources share a private network | Domain SoR |
| Create-new vs attach-existing VPC choice as configured | Live account inventory (Gap unless evidenced) |

## Usage

### Connect / operate

| Surface | House posture |
| --- | --- |
| Management | DigitalOcean API / `doctl` / Terraform for VPC create or attach |
| Runtime | Resources join by `vpc_uuid` (or equivalent) at provision — not a VPN client for apps |
| Common ops | Create VPC in region; attach DOKS/Droplet/DB; list members; rarely peer (peering Untapped) |

### Material config

| Knob | Why it matters |
| --- | --- |
| Region | VPC is regional; cross-region private is not the default house pattern |
| CIDR | Must not overlap other networks you peer/VPN later; size for expected hosts |
| Create vs attach | Account may already have a VPC — consume-vs-create Gap per environment |
| Default VPC | DO default VPC may exist — prefer explicit platform VPC for house resources |

### Pricing / limits (class)

- VPC itself is not a major bill line; cost shows up on attached resources.
- Limits: VPCs/region and members per VPC are account-scoped — re-check DO networking limits before large fleets.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Resource outside VPC | Breaks private DB/registry patterns — treat as mis-provision |
| Overlapping CIDR | Blocks future peering/VPN — plan CIDR deliberately |
| Assuming “VPC = encrypted app auth” | False; still need [[cloud-firewall]] + app AuthZ |

## Owner of truth

Platform operators (ownership Untapped).

## Evidence

- **Lived:** Both runtime shapes provision or attach a VPC; managed DB and compute join it.
- **Remote:** [VPC](https://docs.digitalocean.com/products/networking/vpc/).

## Gaps / Untapped

- Create-new vs attach-existing per environment
- Peering / VPN to non-DO networks
- Named operators
- Account-specific VPC ids (never doctrine)

## Further detail

- [VPC](https://docs.digitalocean.com/products/networking/vpc/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[vpc]]
