"""Naming — no and-joins; stem ↔ H1 for doctrine altitudes."""

from __future__ import annotations

import re

from tests.vault import h1_title, iter_notes, norm_slug, parse_frontmatter, read_text, rel_posix


def test_no_and_in_folder_or_stem() -> None:
    offenders: list[str] = []
    for path in iter_notes():
        if re.search(r"\band\b", path.stem):
            offenders.append(f"stem: {rel_posix(path)}")
        if re.search(r"\band\b", path.parent.name):
            offenders.append(f"folder: {rel_posix(path)}")
    assert not offenders, "\n".join(offenders)


def test_stem_matches_h1_for_doctrine_notes() -> None:
    mismatches: list[str] = []
    for path in iter_notes():
        if path.stem.startswith("catalog-"):
            continue
        if "templates" in path.parts:
            continue
        top = rel_posix(path).split("/")[0]
        if not top.startswith(("10-", "20-", "30-", "40-", "50-", "60-")) and top != "maps":
            continue
        _, body = parse_frontmatter(read_text(path))
        title = h1_title(body)
        if not title:
            mismatches.append(f"{rel_posix(path)}: missing H1")
            continue
        ns, nh = norm_slug(path.stem), norm_slug(title)
        if ns != nh and ns.replace("-", "") != nh.replace("-", ""):
            mismatches.append(f"{rel_posix(path)}: stem={path.stem!r} h1={title!r}")
    assert not mismatches, "\n".join(mismatches[:40])
