---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-020
concern: systems
description: pgAdmin — graphical admin client for PostgreSQL; desktop or server mode.
domain: [postgres]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Pgadmin

## Purpose

Provide **pgAdmin 4** as the leading open-source graphical management tool for Postgres.

## Owns

- Saved server connections and UI sessions in desktop or **server (web)** mode
- Client-side query/backup/restore dialogs that drive cluster operations

## Does not own

- Cluster data SoR (→ [[postgres-engine]])
- DO console for managed Postgres (different product)

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Connects to | [[postgres-engine]] | Admin/query/backup UI |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Nothing as data SoR — client only | Treating pgAdmin “query history” as audit SoR |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| Modes | Desktop runtime; **server mode** behind reverse proxy/WSGI |
| Config | `config_local.py` / `config_system.py` overrides — no secrets in vault |
| Common ops | Register server; browse objects; Query Tool; backup/restore dialogs; grant wizard |

### Material config

| Knob | Why it matters |
| --- | --- |
| Desktop vs server mode | Multi-user exposure |
| External DB for pgAdmin settings | HA of the tool itself |
| Authentication to pgAdmin (server mode) | Who may admin through the UI |

### Pricing / limits (class)

- Open source; hosting cost only for server mode.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Server mode on public internet without auth hardening | High risk — protect |
| Stored DB passwords | Prefer OS/secret patterns; never vault them |

## Owner of truth

DBA workstation / web-app owners (Untapped).

## Evidence

- **Lived:** Untapped.
- **Remote:** [pgAdmin 4 docs](https://www.pgadmin.org/docs/pgadmin4/latest/index.html) · [Server deployment](https://www.pgadmin.org/docs/pgadmin4/latest/server_deployment.html).

## Gaps / Untapped

- Desktop vs server mode in house
- Who may connect to which clusters via pgAdmin

## Further detail

- [pgAdmin 4 docs](https://www.pgadmin.org/docs/pgadmin4/latest/index.html)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[postgres-cluster]]
