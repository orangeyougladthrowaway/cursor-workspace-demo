---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-008
concern: glossary
description: Contact — Zoho CRM person record (house SoR module).
domain: [zoho]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-20
---

# Contact

**Contact** = person record in [[zoho-crm]]. House SoR module (lived). Distinct from Account (organisation).
