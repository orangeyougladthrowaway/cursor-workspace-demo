---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-027
concern: glossary
description: VLF — virtual log file inside the SQL Server transaction log.
domain: [sql-server]
updated: 2026-07-20
---

# Vlf

**VLF** (virtual log file) = internal segment of the transaction log used for truncation/reuse bookkeeping ([[sql-server-transaction-log]]).
