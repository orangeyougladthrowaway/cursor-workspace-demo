---
type: foundation
status: draft
id: systems-knowledge-base-fnd-knowledge-model
description: Knowledge types for systems-knowledge-base — guidance and maps carry bulk; principles stay thin.
updated: 2026-07-16
---

# Knowledge model

Types are kinds of knowledge, not folder bureaucracy.

## Type overview

| Type | Stability | Primary question |
| --- | --- | --- |
| `philosophy` | Very high | What do we believe documentation is for? |
| `category` | Very high | What theme organises related principles? |
| `principle` | High | What portable constraint keeps docs honest? |
| `standard` | High | What must notes normally include? |
| `pattern` | Medium–high | What recurring cross-domain shape? (sparse) |
| `guidance` | Medium–low | What is true of this system/process **here**? |
| `workflow` | Medium–low | What sequence maintains this bible? |
| `map` | Medium | What body of knowledge should I open first? |
| `catalog` | N/A | Inventory / lens for taxonomic browse |
| `template` | Medium | Starter shape for writing a vault note |
| `glossary` | High | What does this term mean **here**? |
| `foundation` | Highest | How does this bible itself work? |
| `index` | N/A | Entry / hub note (e.g. README) |

## Layering

```text
philosophy → category → principle → standard → pattern
                          ↓
                    guidance / workflow
                          ↑
              maps (family / theme atlases cite any altitude)
```

## Writing rules

- **Category before leaf** for principles.
- Domain/system detail belongs in `guidance`, never in philosophy.
- **Domain fact is not a principle** — if it is not portable across domains, it is guidance.
- Every standard/pattern/guidance/workflow/**map** declares **`concern`** matching its folder.
- Prefer stable **`id`** with `systems-knowledge-base-` prefix.
- Catalogs and maps have **unique** filenames — never `_index.md`.
- Process and system notes follow templates under `00-foundation/templates/`.

## Status

| Status | Meaning |
| --- | --- |
| `draft` | Unfinished — do not treat as doctrine |
| `canonical` | Living doctrine |
| `deprecated` | Brief migration only — then delete |

## Related

- [[navigation]] · [[dependency-rules]] · [[methodology]] · [[changing-this-bible]]
