---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-025
concern: processes
description: Connect and administer a SQL Server instance — operable sequence.
domain: [sql-server]
derived_from:
  - "[[process-note-honesty]]"
  - "[[sql-server-engine]]"
  - "[[ssms]]"
updated: 2026-07-20
---

# Connect Administer Sql Server

## Purpose

Establish a controlled connection to [[sql-server-engine]] and perform routine administration (prefer [[ssms]] or reviewed scripts).

## Triggers

- New instance access needed
- Schema/security/backup change

## Actors / roles

- DBA / delegated data owner

## Inputs / outputs

| In | Out |
| --- | --- |
| Host, auth material (not in vault), target DB | Live session; applied DDL/DCL/backup |
| Change intent | Scripted or UI change with evidence |

## Operable sequence (business grain)

1. **Identify target** — instance/DB that is SoR for the change (Inventory Untapped).
2. **Authenticate** — Windows/SQL/Entra as configured; least privilege login.
3. **Connect** — [[ssms]] Object Explorer or `sqlcmd`.
4. **Change** — apply reviewed T-SQL or SSMS action; avoid unreviewed prod clicks for material DDL.
5. **Verify** — query catalog views; confirm backup if destructive risk.
6. **Exit** — close session; no credentials left in scripts committed to public repos.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Data / security state | [[sql-server-engine]] | Yes |
| Client | [[ssms]] | Tooling |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Wrong instance | Confirm environment class before apply |
| sa everyday use | Prefer named least-privilege |

## Owner of this note’s truth

DBAs (Untapped).
