---
type: principle
status: draft
id: systems-knowledge-base-p-005
category: change
description: Amend the living note when the business changes — do not stack archives.
derived_from:
  - "[[change]]"
  - "[[documentation-for-current-truth]]"
updated: 2026-07-16
---

# Amend on business change

When a process or SoR changes in the real world, **amend the living note** in the same change of understanding. Do not create parallel “v2” notes or decision-log archives in this vault.
