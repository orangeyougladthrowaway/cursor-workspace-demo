---
type: principle
status: draft
id: systems-knowledge-base-p-006
category: restraint
description: Do not paste vendor manuals or full SOP dumps as guidance — link further detail instead.
derived_from:
  - "[[restraint]]"
  - "[[documentation-for-current-truth]]"
updated: 2026-07-20
---

# No encyclopaedia paste

Admit remote sources as claim cards. Elevate only claims that change a decision. Reject curriculum mirrors, full product catalogues, and SOP PDF dumps as doctrine.

**Companion duty:** when detail is out of scope, [[link-further-detail]] — add the vendor (or other) URL so agents are not forced to invent wire shape.
