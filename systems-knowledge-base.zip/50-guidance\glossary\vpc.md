---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-005
concern: glossary
description: VPC — DigitalOcean private network scope.
domain: [digital-ocean]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-16
---

# Vpc

**VPC** = private network that scopes platform resources (compute, managed DB, firewall CIDR trust). System note: [[platform-vpc]].
