---
type: guidance
status: draft
id: systems-knowledge-base-g-further-detail-hubs
concern: knowledge
description: Stable vendor/docs hub URLs to link when vault grain declines encyclopaedia detail.
derived_from:
  - "[[link-further-detail]]"
  - "[[no-encyclopaedia-paste]]"
  - "[[system-sor-honesty]]"
updated: 2026-07-20
---

# Further detail hubs

House **pointer** hubs for [[link-further-detail]]. Prefer these on living notes when wire payloads, full field catalogues, or deep matrices stay out of vault scope. Re-check before design claims. Lived house facts still win on house process.

| Family / surface | Hub |
| --- | --- |
| SQL Server | https://learn.microsoft.com/en-us/sql/sql-server/ |
| Azure SQL feature comparison | https://learn.microsoft.com/en-us/azure/azure-sql/database/features-comparison |
| SSMS | https://learn.microsoft.com/en-us/ssms/sql-server-management-studio-ssms |
| SSIS | https://learn.microsoft.com/en-us/sql/integration-services/ |
| SSRS | https://learn.microsoft.com/en-us/sql/reporting-services/ |
| PostgreSQL | https://www.postgresql.org/docs/current/ |
| pgAdmin | https://www.pgadmin.org/docs/ |
| DigitalOcean docs | https://docs.digitalocean.com/ |
| DigitalOcean API | https://docs.digitalocean.com/reference/api/ |
| Azure (platform) | https://learn.microsoft.com/en-us/azure/ |
| Azure Resource Manager | https://learn.microsoft.com/en-us/azure/azure-resource-manager/ |
| Microsoft Entra | https://learn.microsoft.com/en-us/entra/ |
| Azure Data Factory | https://learn.microsoft.com/en-us/azure/data-factory/ |
| Azure AI Foundry | https://learn.microsoft.com/en-us/azure/ai-foundry/ |
| Git | https://git-scm.com/doc |
| GitHub Docs | https://docs.github.com/ |
| Azure DevOps | https://learn.microsoft.com/en-us/azure/devops/ |
| Zoho CRM API v7 | https://www.zoho.com/crm/developer/docs/api/v7/ |
| Zoho CRM OAuth | https://www.zoho.com/crm/developer/docs/api/v7/oauth-overview.html |
| Zoho Flow | https://www.zoho.com/flow/ |
| ManageEngine SDP On-Demand API | https://www.manageengine.com/products/service-desk/sdp-ondemand/api.html |

Capability-specific SQL Learn pages may be linked in addition to the SQL Server hub (pages/extents, recovery, tempdb, etc.).

## Related

- [[link-further-detail]] · [[system-sor-honesty]] · [[knowledge-ingestion]] · [[ingest-coverage]]
