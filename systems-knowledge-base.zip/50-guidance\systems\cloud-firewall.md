---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-005
concern: systems
description: Cloud firewall — DO network allow/deny for Droplets and/or DOKS workers.
domain: [digital-ocean]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Cloud Firewall

## Purpose

Enforce **network allow/deny** at DigitalOcean’s cloud-firewall grain for platform compute.

## Owns

- Firewall rule sets attached to Droplet IDs and/or membership tags (e.g. DOKS workers)
- Typical patterns: admin SSH from a whitelist; broad allow within VPC CIDR; optional public 80/443 when edge is enabled; separate tighter rules for GPU hosts exposing inference ports

## Does not own

- Application AuthN/AuthZ
- Managed-database firewall product (often **absent** — DB privacy via VPC only; Gap if trusted-sources needed)
- Secrets / credentials

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Protects | [[droplet-compute]] | Droplet ID membership |
| Protects | [[doks-kubernetes]] | Tag membership when configured |
| Lateral | [[platform-vpc]] | VPC CIDR as trusted source |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| What network paths are allowed at the cloud-firewall layer | Domain access policy |
| Firewall as practiced for compute | DO database firewall (not coded in current inventories) |

## Usage

### Connect / operate

| Surface | House posture |
| --- | --- |
| Management | DigitalOcean API / `doctl` / Terraform `digitalocean_firewall` |
| Membership | Host shape: Droplet ids; cluster shape: tags on workers; GPU host: often separate firewall |
| Common ops | Create rule set; attach members; open admin SSH from allowlist; allow VPC CIDR east-west; optional 80/443 for edge |

### Material config

| Knob | Why it matters |
| --- | --- |
| Inbound SSH sources | Should be allowlisted — not 0.0.0.0/0 in house posture |
| VPC CIDR allow | Enables private app↔app / app↔DB paths when combined with VPC |
| Public 80/443 | Only when [[platform-edge]] exposes HTTP(S) |
| Inference ports on GPU | Tighter separate rules — do not copy app-host firewall blindly |
| Tags vs ids | Tag drift drops new workers outside protection — verify membership after scale |

### Pricing / limits (class)

- Cloud firewalls are not a primary cost driver; rule/member limits are account-scoped — re-check DO firewall limits for large tag sets.

### Failure / controls

| Mode | Posture |
| --- | --- |
| SSH open to world | Control failure |
| New DOKS node missing tag | Worker unprotected or over-exposed — membership Gap risk |
| Expecting DB firewall here | Wrong product — [[managed-postgres]] trusted-sources still Gap |
| Firewall = AuthZ | False; app identity still required |

## Owner of truth

Platform operators (ownership Untapped).

## Evidence

- **Lived:** Both shapes use `digitalocean_firewall` on compute. Host shape attaches to Droplets; cluster shape uses tags for workers; optional extra firewall for external GPU hosts.
- **Remote:** [Cloud Firewalls](https://docs.digitalocean.com/products/networking/firewalls/).

## Gaps / Untapped

- Exact allowlist CIDRs (environment config — not doctrine)
- DB trusted-sources product use
- Named operators

## Further detail

- [Cloud Firewalls](https://docs.digitalocean.com/products/networking/firewalls/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[vpc]] · [[droplet]] · [[doks]]
