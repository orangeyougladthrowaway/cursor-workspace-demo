---
type: category
status: draft
id: systems-knowledge-base-cat-ownership
category: ownership
description: Category spine — who owns truth and facts.
updated: 2026-07-16
---

# Ownership

Principles about who owns process/system truth and which system owns which facts.
