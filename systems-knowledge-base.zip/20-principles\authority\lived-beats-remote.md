---
type: principle
status: draft
id: systems-knowledge-base-p-004
category: authority
description: Lived house practice beats remote generic product guidance on local facts.
derived_from:
  - "[[authority]]"
  - "[[documentation-for-current-truth]]"
updated: 2026-07-16
---

# Lived Beats Remote

When official vendor docs describe a generic capability and our practice differs, **house practice wins** for “what is true here.” Remote pressure may still create aspirational drafts — never silent overwrite.
