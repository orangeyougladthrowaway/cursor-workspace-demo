---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-002
concern: systems
description: Droplet — VM compute for host runtime shape; SoR plus usage (API, size class, pricing class).
domain: [digital-ocean]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Droplet Compute

## Purpose

Provide **Linux virtual machines (Droplets)** as the **host** platform shape (Compose-style runtime), and optionally as **GPU hosts** beside a cluster.

## Owns

- VM instance existence, size class, image class, and network attachment
- Host-level home for Compose-deployed services when that shape is active
- Optional reserved public IPv6 assignment when edge needs it

## Does not own

- Kubernetes control plane (→ [[doks-kubernetes]])
- Object store / registry / managed DB products
- Domain business facts
- Reverse-proxy product choice on the host (edge pattern → [[platform-edge]]; engineering detail is out of scope)

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Upstream | [[platform-vpc]] | Droplet in VPC |
| Upstream | [[cloud-firewall]] | Firewall attached to Droplet IDs |
| Downstream | Host-shaped workloads | Services run on the VM |
| Lateral | [[self-hosted-inference-compute]] | GPU Droplet may host inference listeners |
| Lateral | [[platform-edge]] | Public DNS may point at Droplet addresses |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Droplet identity and role (app host vs GPU host) as provisioned | DOKS cluster API |
| “Workloads run on this VM” for host-shaped environments | Domain SoR |

## Usage

### Connect / operate

| Surface | House posture |
| --- | --- |
| Access | SSH to public or VPC address as provisioned; DigitalOcean API / `doctl` / Terraform for lifecycle |
| Auth class | DO API tokens for management; SSH keys / user auth on the VM — never store private keys in this vault |
| Console | DO web console for break-glass — house runbook Untapped |
| Common ops | Create/resize/destroy; attach to VPC; tag for firewalls; enable backups/monitoring features when practiced |

### Material config

| Knob | Why it matters |
| --- | --- |
| Size slug (vCPU/RAM/disk) | Capacity and monthly price class |
| Image / base OS | Compatibility with host runtime packaging (packaging = eng lane) |
| Region + VPC | Private reachability to [[managed-postgres]] / [[spaces-object-storage]] patterns |
| Public IPv4/IPv6 | Edge exposure vs private-only |
| GPU vs CPU Droplet | Inference host vs app host roles ([[self-hosted-inference-compute]]) |
| Backups / snapshots | Recovery posture — house default Untapped |

### Pricing / limits (class)

- Droplets are the **reference price class** for DOKS worker nodes (same underlying charge model).
- Billed by size slug and runtime; bandwidth quotas attach to size class (exact tables on DO Droplet pricing — re-check before commits).
- GPU Droplets are a separate, higher price class; reservation/contract paths exist for some GPU SKUs via DO sales — house contract Untapped.
- Do not treat “always-on” and “autoscaled DOKS workers” as the same monthly shape.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Single-VM blast radius | Host shape concentrates failure on one Droplet — accept or dual-home explicitly |
| Firewall miss | [[cloud-firewall]] tags/ids must match; open SSH to world is a control failure |
| Disk full / OOM | Operational — eng observability; systems notes ownership Untapped |
| Secrets on disk doctrine | Forbidden in vault; credential ownership Untapped |

## Owner of truth

Platform operators (ownership Untapped).

## Evidence

- **Lived:** Host-shaped repos use a Droplet as the Compose runtime home. Cluster-shaped repos may still provision a GPU Droplet when inference topology is “external host.”
- **Remote:** [Droplets](https://docs.digitalocean.com/products/droplets/).

## Gaps / Untapped

- House default size slugs per environment class
- Backup/snapshot policy
- Named operators
- Account-specific Droplet ids (never doctrine)

## Further detail

- [Droplets](https://docs.digitalocean.com/products/droplets/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[droplet]] · [[vpc]]
