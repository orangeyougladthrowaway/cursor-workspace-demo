---
type: workflow
status: draft
id: systems-knowledge-base-wf-005
concern: knowledge
description: How to run vault health checks — pytest suite, manual fix loop; pyproject.toml is dep SoT.
domain: []
aliases: [vault-health, cleanliness]
derived_from:
  - "[[changing-this-bible]]"
  - "[[methodology]]"
updated: 2026-07-16
---

# Vault Health Checks

Automated checks enforce testable rules from [[changing-this-bible]] and [[methodology]]. **No auto-fix scripts** — failures are fixed manually in the vault, then re-run.

Deps SoT: root `pyproject.toml` (`[project.optional-dependencies].dev`). No `requirements*.txt` for vault health.

## Run locally

```bash
python -m pip install pytest pyyaml
pytest tests/ -v
```

Equivalent fuller form (optional extras; not required):

```bash
python -m pip install -e ".[dev]"
pytest tests/ -v
```

Lab praxis suite is **deferred** in systems-knowledge-base — do not expect `tests/lab/`.

## Run in CI

GitHub Actions workflow `.github/workflows/vault-health.yml` — same short install, then `pytest tests/ -v`.

## What is tested

Doctrine suite under `tests/` (shared helpers in `tests/vault.py`):

| Rule source | Tests |
| --- | --- |
| Broken wikilinks | `test_wikilinks.py` |
| No path-style wikilinks | `test_wikilinks.py` |
| `concern` = folder / map leaf | `test_frontmatter.py` |
| Doctrine `id` present | `test_frontmatter.py` |
| No `deprecated` doctrine | `test_frontmatter.py` |
| Principle `category` present | `test_frontmatter.py` |
| Stem ≈ H1 | `test_naming.py` |
| No `and` in folder/stem | `test_naming.py` |

Walker skips: `.git`, `temp`, `node_modules`, `.cursor`, `.obsidian`.

## When checks fail

1. Read pytest output (file + rule).
2. Fix the vault note(s) manually — rename, link update, catalog row, frontmatter.
3. Re-run until green.
4. Do **not** disable tests to paper over drift.

## Beyond pytest

Shape-green ≠ coverage-honest. After elevate batches, also check [[common-case-coverage]] and [[ingest-coverage]] honesty.

## Related

- [[changing-this-bible]] · [[knowledge-ingestion]] · [[common-case-coverage]] · [[agent-projection]]
