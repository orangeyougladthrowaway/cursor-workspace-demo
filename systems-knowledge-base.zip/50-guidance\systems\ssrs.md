---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-018
concern: systems
description: SSRS — paginated report server grain; report catalogue Untapped.
domain: [sql-server]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Ssrs

## Purpose

Provide **SQL Server Reporting Services** to create, deploy, and manage **paginated reports** on-premises (native web portal).

## Owns

- Report server catalog (definitions, folders, permissions)
- Rendering, subscriptions, and portal access as configured
- Report server database pair (ReportServer / temp) as product stores

## Does not own

- Underlying transactional SoR (→ [[sql-server-engine]] or others)
- Power BI Service as SaaS (different product — Gap if practiced)
- Full report RDL encyclopaedia in vault

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Queries | [[sql-server-engine]] / other data sources | Datasets |
| Administered via | Portal / Report Server Config / [[ssms]] | Server ops |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Published report definition/version on the report server | Email attachment of an old export as “the report” |
| Subscription delivery config | Source data correctness (engine/domain) |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| Portal | Modern web portal for reports/KPIs |
| Config | Report Server Configuration Manager post-install |
| APIs | SSRS SOAP/REST developer surfaces for integration |
| Common ops | Deploy RDL; set data sources; secure folders; subscribe |

### Material config

| Knob | Why it matters |
| --- | --- |
| Native vs SharePoint mode | Access topology (SharePoint mode legacy class) |
| Service account + URLs | Availability and SPN/auth |
| Unattended execution account | Subscriptions/scheduled |

### Pricing / limits (class)

- SQL Server + SSRS licensing — house Untapped.
- Render concurrency/resource limits on host.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Over-broad folder browser rights | Least privilege on catalog |
| Embedded credentials in data sources | Prefer managed/integrated |
| Report dump into vault | Forbidden |

## Owner of truth

BI / report admins (Untapped).

## Evidence

- **Lived:** Untapped.
- **Remote:** [What is SSRS](https://learn.microsoft.com/en-us/sql/reporting-services/create-deploy-and-manage-mobile-and-paginated-reports) · [Install SSRS](https://learn.microsoft.com/en-us/sql/reporting-services/install-windows/install-reporting-services).

## Gaps / Untapped

- Whether SSRS is practiced vs Power BI only
- Report folder SoR inventory (no RDL dumps)

## Further detail

- [SSRS create/deploy/manage](https://learn.microsoft.com/en-us/sql/reporting-services/create-deploy-and-manage-mobile-and-paginated-reports)
- [Install SSRS](https://learn.microsoft.com/en-us/sql/reporting-services/install-windows/install-reporting-services) · [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[paginated-report]]
