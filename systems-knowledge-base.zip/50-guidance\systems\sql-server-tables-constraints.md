---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-040
concern: systems
description: SQL Server tables and constraints — storage shapes and declarative enforcers.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Tables Constraints

## Purpose

Describe **tables** and **constraints** as engine structures that store and enforce data rules — not dimensional modeling craft.

## Tables

| Shape | Behaviour |
| --- | --- |
| Heap | No clustered index |
| Clustered table | Data ordered by CI key |
| Partitioned table | Horizontal partitions on scheme/function (Enterprise/capability by edition) |
| Temporal / memory-optimized / graph classes | Feature tables by version/host |

## Constraints (declarative enforcers)

| Kind | Engine role |
| --- | --- |
| PRIMARY KEY / UNIQUE | Uniqueness (+ CI/NCI as needed) |
| FOREIGN KEY | Referential integrity (with cascade options) |
| CHECK | Row predicate |
| DEFAULT | Insert-time default |
| NOT NULL | Nullability |

Constraints are **SoR for integrity rules at the engine** when enabled/trusted; disabled/nocheck states weaken enforcement.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Table/constraint product behaviour | Kimball keys, SCD design (eng) |

## Failure / controls

| Mode | Posture |
| --- | --- |
| NOCHECK FK in prod | Integrity Gap — conscious |
| Wide tables / LOB misuse | Performance phenomenon |

## Evidence

- **Remote:** Tables / constraints Learn docs.

## Further detail

- [Tables](https://learn.microsoft.com/en-us/sql/relational-databases/tables/tables)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-object-model]] · [[sql-server-indexes-statistics]] · [[sql-server-programmability-objects]]
