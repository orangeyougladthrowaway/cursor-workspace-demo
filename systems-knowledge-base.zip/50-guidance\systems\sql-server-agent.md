---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-038
concern: systems
description: SQL Server Agent — jobs, steps, schedules, operators as automation objects.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Agent

## Purpose

Describe **SQL Server Agent** as the instance job scheduler/automation host for T-SQL, SSIS, PowerShell, and subsystem steps.

## Objects

| Object | Behaviour |
| --- | --- |
| Job | Named automation unit |
| Job step | Ordered action (T-SQL, CmdExec, SSIS, …) |
| Schedule | When jobs fire |
| Operator / alert | Notification targets & conditions |
| Proxy | Credential mapping for non-sysadmin step contexts |

Agent service is distinct from the Database Engine service; service account rights matter for filesystem/SSIS.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Agent object model & capability | What jobs house must run (lived/eng) |

## Azure SQL note

**Not available** on Azure SQL Database. Present on Managed Instance / box. PaaS elastic jobs / ADF / Agent alternatives fill gaps differently.

## Failure / controls

| Mode | Posture |
| --- | --- |
| Agent stopped | Schedules silent-fail |
| Steps as sysadmin | Prefer proxies/least privilege |
| Secrets in step text | Prefer Credential/Proxy/Key Vault patterns |

## Evidence

- **Remote:** SQL Server Agent Learn docs.
- **Lived:** Whether Agent used on house box/MI Untapped.

## Further detail

- [SQL Server Agent](https://learn.microsoft.com/en-us/sql/ssms/agent/sql-server-agent)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-engine]] · [[ssis]] · [[sql-server-maintenance-checks]] · [[azure-sql-differences]]
