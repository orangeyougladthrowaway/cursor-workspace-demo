---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-031
concern: systems
description: SQL Server pages and extents — storage allocation units and fragmentation phenomenon.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Pages Extents

## Purpose

Describe the engine’s **physical storage units** — pages and extents — and how fragmentation arises as behaviour (not a reindex recipe book).

## Concepts

| Unit | Behaviour |
| --- | --- |
| **Page** (~8 KB) | Basic I/O unit for data/index rows and system pages |
| **Extent** (8 pages / 64 KB) | Allocation unit; uniform vs mixed |
| Allocation maps (GAM/SGAM/PFS/IAM class) | Track free/used space and object extents |
| DCM / BCM | Track extents for differential / bulk-logged backup efficiency |

**Log files do not store data pages** — they store log records of variable size ([[sql-server-transaction-log]]).

## Fragmentation (phenomenon)

Logical fragmentation / free space density change as rows insert/update/delete. It is a **storage/index health signal**, not a moral failing — maintenance response is ops/eng schedule ([[sql-server-maintenance-checks]]).

## Owns / not

| Owns | Does not own |
| --- | --- |
| Page/extent architecture facts | Per-table fillfactor standards (eng) |

## Failure / controls

| Mode | Posture |
| --- | --- |
| Treating log as paged data | Wrong model |
| Ignoring PFS/autogrowth interaction | Growth + allocation stress |

## Evidence

- **Remote:** [Pages and extents architecture guide](https://learn.microsoft.com/en-us/sql/relational-databases/pages-and-extents-architecture-guide).

## Further detail

- See Evidence Remote URL · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-files-filegroups]] · [[sql-server-indexes-statistics]]
