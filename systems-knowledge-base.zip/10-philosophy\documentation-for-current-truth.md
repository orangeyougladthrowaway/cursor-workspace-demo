---
type: philosophy
status: draft
id: systems-knowledge-base-phil-001
description: Documentation exists to make current systems truth shareable — not to archive history or dump SOPs.
updated: 2026-07-16
---

# Documentation for current truth

This bible exists so humans and agents share **what is true now** about systems and processes — ownership, SoR, handoffs, controls — without rediscovering tribal memory.

It is not a history archive, not a procedure library, and not a place to paste vendor manuals. When the business changes, **amend the living note**.
