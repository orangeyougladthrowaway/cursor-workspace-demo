---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-010
concern: glossary
description: Deal — Zoho CRM opportunity record (house SoR module).
domain: [zoho]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-20
---

# Deal

**Deal** = opportunity / pipeline record in [[zoho-crm]]. House SoR module (lived).
