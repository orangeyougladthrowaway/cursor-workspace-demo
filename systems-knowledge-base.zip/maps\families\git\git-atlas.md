---
type: map
status: draft
id: systems-knowledge-base-map-git
concern: git
description: Git atlas — VCS SoR with contribute/integrate/tag processes; dual remotes practiced.
domain: [git]
updated: 2026-07-20
---

# Git Atlas

Browse for **Git** as distributed source-history SoR.

## Systems

| Note | Role |
| --- | --- |
| [[git-vcs]] | Commit/object/ref SoR |

## Processes

| Note | Question |
| --- | --- |
| [[contribute-git-change]] | How changes are committed and pushed |
| [[integrate-git-branch]] | How topic branches land on shared base |
| [[publish-git-tag]] | How release points are tagged |

## Glossary

[[commit]] · [[branch]]

## Interfaces / Gaps

| Counterpart | Status |
| --- | --- |
| [[github-host]] | Practiced remote/host |
| [[azure-devops-org]] | Practiced remote/host (Azure Repos) |
| Dual-remote sync leadership | Gap — writable leader policy Untapped |

## Evidence posture

- **Lived:** Both GitHub and Azure DevOps used as hosts (2026-07-20).
- **Remote:** git-scm docs.

## Further detail

Out-of-vault wire/field matrices and deep vendor manuals stay linked, not pasted ([[link-further-detail]] · [[further-detail-hubs]]):

- [Git documentation](https://git-scm.com/doc)

## Usability wave

**Useful** on Atlas/Systems/Usage/Processes/Controls/Glossary/Freshness. Interfaces partial (sync policy).

## Related

- [[github-atlas]] · [[azure-devops-atlas]] · [[catalog-maps]]
