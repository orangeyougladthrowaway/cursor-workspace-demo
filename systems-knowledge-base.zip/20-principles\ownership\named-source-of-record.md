---
type: principle
status: draft
id: systems-knowledge-base-p-001
category: ownership
description: Every critical business fact has exactly one named source of record.
derived_from:
  - "[[ownership]]"
  - "[[documentation-for-current-truth]]"
updated: 2026-07-16
---

# Named source of record

For each critical class of business facts, name **one** source of record. If two systems appear to own the same fact, that is a Gap or a conflict — not silent dual truth.
