---
type: standard
status: draft
id: systems-knowledge-base-s-001
concern: processes
description: Process notes must include triggers, actors, SoR per critical fact, controls, and truth owner.
derived_from:
  - "[[named-source-of-record]]"
  - "[[gaps-over-fiction]]"
  - "[[honesty]]"
updated: 2026-07-16
---

# Process note honesty

Every living process note must include, at minimum:

- Purpose (one sentence)
- Trigger(s)
- Actors / roles (business grain)
- Inputs / outputs
- Systems touched + **SoR per critical fact**
- Controls / failure modes (business grain)
- Owner of this note’s truth
- Related glossary stems
- `status`, `id`, `concern`, `updated`

Do not paste work-instruction theatre. One process question per note. If a field is unknown, write **Gap** — do not invent.
