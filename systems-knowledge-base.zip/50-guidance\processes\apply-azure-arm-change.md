---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-024
concern: processes
description: Apply a reviewed Terraform azurerm plan to Azure Resource Manager.
domain: [azure-cloud]
derived_from:
  - "[[process-note-honesty]]"
  - "[[terraform-azurerm-provider]]"
  - "[[azure-subscription]]"
updated: 2026-07-20
---

# Apply Azure Arm Change

## Purpose

**Apply** a reviewed plan so ARM resources match the intended configuration via `azurerm`.

## Triggers

- Approved plan for an environment
- Emergency fix with accelerated review (still authenticate + plan first)

## Actors / roles

- IaC operator with apply rights
- Approver when change control applies (methods lane)

## Inputs / outputs

| In | Out |
| --- | --- |
| Saved/approved plan | Applied resources in subscription |
| State lock | Updated Terraform state |

## Operable sequence (business grain)

1. **Confirm target** — subscription/RG/environment class.
2. **Re-plan if stale** — do not apply ancient plans blindly.
3. **Apply** — `terraform apply` with reviewed plan; watch errors.
4. **Verify** — portal/CLI spot-check critical resources.
5. **Record** — link apply to Git commit / work item; secrets untouched in vault.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Live resources | [[azure-subscription]] | Yes |
| Provider execution | [[terraform-azurerm-provider]] | Tooling |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Apply without lock | State race — eng control |
| Partial apply failure | Remediate; do not leave secrets in error logs in vault |
| Wrong cloud vs DO platform | Azure apply does not replace DO P0 runtime without intent |

## Owner of this note’s truth

Cloud / IaC operators (Untapped).
