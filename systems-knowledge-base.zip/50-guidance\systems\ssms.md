---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-016
concern: systems
description: SSMS — admin/query client for SQL Server family surfaces.
domain: [sql-server]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Ssms

## Purpose

Provide **SQL Server Management Studio** as the primary graphical client to administer and query SQL infrastructure.

## Owns

- Client connections, Object Explorer, query editor sessions on the workstation/server where SSMS runs
- Server-level admin views into SSIS/SSRS/Agent when connected

Maps to engine hierarchy via Object Explorer ([[sql-server-object-model]]).

## Does not own

- Engine data SoR (→ [[sql-server-engine]])
- Package/report design surfaces as primary authoring SoR (SSDT/Report Builder class — note Gap)
- Credentials vaulting

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Connects to | [[sql-server-engine]] | Admin/query |
| May administer | [[ssis]] / [[ssrs]] | Server-level ops |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Nothing as data SoR — client only | Treating SSMS local scripts as production SoR |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| Product | SSMS (current channels via Microsoft Learn) |
| Targets | SQL Server, Azure SQL DB/MI, SQL on Azure VM, Fabric SQL, related |
| Auth | Same as target engine auth class |
| Common ops | Connect; browse objects; run T-SQL; backup/restore UI; view agent/jobs when present |

### Material config

| Knob | Why it matters |
| --- | --- |
| SSMS version/channel | Feature parity with engine |
| Registered servers | Operator convenience — not doctrine object names |
| Shared vs personal install | Who may administer |

### Pricing / limits (class)

- SSMS client is free; limits are on target engines.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Saved passwords in client | Prefer OS credential hygiene; no secrets in vault |
| Prod change via ad-hoc SSMS | Prefer reviewed scripts/change control when material |

## Owner of truth

DBA workstation owners (Untapped).

## Evidence

- **Lived:** Untapped.
- **Remote:** [What is SSMS](https://learn.microsoft.com/en-us/ssms/sql-server-management-studio-ssms) · [SSMS docs hub](https://learn.microsoft.com/en-us/ssms/).

## Gaps / Untapped

- Required SSMS version in house
- Who may connect to which instances

## Further detail

- [What is SSMS](https://learn.microsoft.com/en-us/ssms/sql-server-management-studio-ssms)
- [SSMS docs hub](https://learn.microsoft.com/en-us/ssms/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[sql-instance]]
