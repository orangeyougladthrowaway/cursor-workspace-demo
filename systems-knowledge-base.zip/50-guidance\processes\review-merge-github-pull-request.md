---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-017
concern: processes
description: Review and merge a GitHub pull request into the base branch.
domain: [github]
derived_from:
  - "[[process-note-honesty]]"
  - "[[github-host]]"
updated: 2026-07-20
---

# Review Merge Github Pull Request

## Purpose

Complete code review and **merge** (or close) a GitHub PR so the base branch advances safely.

## Triggers

- PR open and checks progressing
- Reviewer assigned / requested

## Actors / roles

- Reviewer
- Author (responds to feedback)
- Merge actor (may be author if policy allows)

## Inputs / outputs

| In | Out |
| --- | --- |
| PR + review comments | Approved / changes-requested |
| Merge | Updated base branch; closed PR |

## Operable sequence (business grain)

1. **Review diff** — comment; request changes or approve.
2. **Author iterates** — push new commits; re-request review.
3. **Confirm gates** — required checks + reviews satisfied.
4. **Merge** — method class (merge/squash/rebase) per repo Untapped.
5. **Cleanup** — delete head branch optional; sync other remote if dual-host ([[integrate-git-branch]]).

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Review decision / merge | [[github-host]] | Yes |
| Resulting history | [[git-vcs]] | Yes |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Admin bypass of protections | Exception only; audit Untapped |
| Merged on GitHub but not Azure Repos mirror | Dual-host drift — sync Untapped |

## Owner of this note’s truth

Repo admins (Untapped).
