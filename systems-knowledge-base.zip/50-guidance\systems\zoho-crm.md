---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-007
concern: systems
description: Zoho CRM — relationship SoR densified to useful (modules lived; processes; controls).
domain: [zoho]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Zoho Crm

## Purpose

Hold **customer and relationship records** as the Zoho CRM product grain for house SoR modules.

## Owns

- House relationship SoR modules (lived): **Leads**, **Contacts**, **Accounts**, **Deals**
- Layouts, fields, and related lists for those modules at product grain
- API/notification surfaces that expose those entities
- Custom modules — **Untapped** (not named as SoR this session)

## Does not own

- Cross-app orchestration logic (→ [[zoho-flow]])
- ITSM ticket lifecycle (→ [[servicedesk-plus]])
- Banking / lending / deposit SoR (domain cores)
- Engineering SDK wrappers or sync job craft

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Lateral | [[zoho-flow]] | Triggers/actions when Flow adopted |
| Lateral | [[servicedesk-plus]] | Gap — ticket ↔ CRM linkage aspirational |

## Processes

- [[capture-crm-lead]] · [[convert-crm-lead]] · [[advance-crm-deal]]


## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Leads, Contacts, Accounts, Deals values **as held in Zoho CRM** | Generic CRM textbook field models |
| API visibility of those modules | Custom / other modules until named as SoR |
| Informal spreadsheets or chat as relationship SoR when CRM holds the record | — |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| UI | Zoho CRM web client (org URL / DC still Untapped) |
| API | REST **v7** entity CRUD, metadata, bulk, composite, notifications, COQL query APIs |
| Auth class | **OAuth 2.0** — access tokens short-lived (~1h class per Zoho docs); refresh tokens until revoked; scopes bound to operations |
| Common ops | Read/write module records; fetch module/field metadata; subscribe to change notifications; bulk import/export async |

### Material config

| Knob | Why it matters |
| --- | --- |
| Module + layout design | Determines SoR shape and API field set |
| OAuth client + scopes | Integration blast radius; revoke/rotate Untapped |
| Data centre / accounts domain | API base host depends on org region |
| Notification / webhook consumers | Dupes and ordering if multiple integrators |

### Pricing / limits (class)

- API call quotas and concurrency are **edition/plan dependent** — live numbers Untapped; re-check Zoho CRM API limits before volume integrations.
- Bulk APIs are asynchronous — treat completion as eventual, not chatty sync.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Token leak | Access/refresh tokens are credentials — do not put in vault notes |
| Wrong module as SoR | Confirm house module ownership before integrations write |
| Notification storms | Multiple subscribers / wide triggers Untapped |

## Owner of truth

Business CRM operators (named owners Untapped). Integration app owners Untapped.

## Evidence

- **Lived:** User relay 2026-07-20 — SoR modules = Leads, Contacts, Accounts, Deals. No practiced CRM↔ServiceDesk / Flow bridges yet (desired later).
- **Remote:** [Zoho CRM API v7](https://www.zoho.com/crm/developer/docs/api/v7/) · [OAuth overview](https://www.zoho.com/crm/developer/docs/api/v7/oauth-overview.html).

## Gaps / Untapped

- Field-level SoR and custom fields of record within the four modules
- Org DC and connected-app inventory
- Named CRM operators
- Pricing/quota as contracted
- CRM ↔ ServiceDesk / Flow bridges (aspirational — not practiced)

## Further detail

Field catalogues and full API response trees stay out of vault — link, do not paste ([[link-further-detail]] · [[further-detail-hubs]]):

- [Zoho CRM API v7](https://www.zoho.com/crm/developer/docs/api/v7/)
- [OAuth overview](https://www.zoho.com/crm/developer/docs/api/v7/oauth-overview.html)
- [Get records (Contacts example)](https://www.zoho.com/crm/developer/docs/api/v7/get-records.html)

## Related glossary

- [[lead]] · [[contact]] · [[account]] · [[deal]]
