---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-029
concern: glossary
description: Recovery model — database property controlling log backup/PITR behaviour.
domain: [sql-server]
updated: 2026-07-20
---

# Recovery Model

**Recovery model** = database property (Full / Bulk-logged / Simple) controlling log maintenance and restore options ([[sql-server-recovery-backup]]).
