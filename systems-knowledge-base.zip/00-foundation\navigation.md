---
type: foundation
status: draft
id: systems-knowledge-base-fnd-navigation
description: Navigation — altitude × responsibility; families are domain/system clusters.
updated: 2026-07-16
---

# Navigation

How this vault is browsed. **Folders and names are architecture.**

## Purpose of structure

systems-knowledge-base stores **current domain systems and process truth**. It is **not** a task centre and **not** an engineering craft bible. Maps **atlas** a body of knowledge; they do not answer with a procedure for a job.

## Hard naming rule

**No `and` as a compounding join** in folder or concept basenames. One folder = one responsibility.

## Three modes (+ praxis deferred)

| Mode | Question | Mechanism |
| --- | --- | --- |
| **Taxonomic** | What responsibility am I under? | Altitude → responsibility folder → note |
| **Atlas** | What body of knowledge? | `maps/families/` or `maps/themes/` |
| **Facet** | Which domain/platform token? | Frontmatter `domain:` / `aliases:` |
| **Praxis** | Exemplars of well-formed notes? | `lab/` — **deferred** |

## Axis 1 — altitude

```text
00-foundation → 10-philosophy → 20-principles → 30-standards
  → 40-patterns → 50-guidance / 60-workflows
```

Depend upward; specialise downward. See [[dependency-rules]].

**Guidance** holds the bulk of living system/process detail. Principles stay thin.

## Axis 2 — responsibility folders

### Principle concepts (thin)

`ownership` · `boundaries` · `honesty` · `authority` · `change` · `restraint`

### Shared responsibilities (30 / 40 / 50 / 60)

Extend this list by amending **this** note before inventing folders:

| Folder | Responsibility |
| --- | --- |
| `ownership` | Who owns process/system truth |
| `systems` | System roles, SoR, capabilities at business grain |
| `processes` | End-to-end / subprocess living descriptions |
| `interfaces` | Business handoffs between systems/org units |
| `controls` | Checks, approvals, audit expectations as practiced |
| `data` | Business data meaning, retention, lineage at process grain |
| `glossary` | Domain terms (house meaning) |
| `knowledge` | Vault / agent projection |
| `change` | How domain truth is updated when the business changes |

**Primary folder only** per note. Prefer a new sibling folder over stuffing unrelated sections.

**Forbidden at altitude L1:** product lore, org-chart folders. Lived **families** belong under `maps/families/` only.

## Axis 3 — maps (atlases)

```text
maps/
  catalog-maps.md
  families/{family}/…-atlas.md
  themes/{theme}/…-atlas.md
```

| Kind | Folder | Role |
| --- | --- | --- |
| **Family** | `maps/families/{family}/` | Domain / platform cluster (e.g. `digital-ocean`) |
| **Theme** | `maps/themes/{theme}/` | Cross-cutting indexes (`integrations`, `controls`, `data-ownership`) |

Atlas `concern` = the **leaf folder** (e.g. `digital-ocean`) — not `families` or `themes`.

**Seeded families:** `digital-ocean` (P0). P1 platforms from [[platform-watchlist]] are **not** family folders until scheduled after DO.

Banned: `_index.md`; `and`-joined names; curriculum playbooks.

## Axis 4 — facets

```yaml
id: systems-knowledge-base-{type}-{nnn}
concern: <responsibility or family leaf>
domain: []          # business/platform tags (digital-ocean, zoho, …)
aliases: []         # informal search only — never rename substitute
status: draft | canonical | deprecated
```

## Protocols

**Human:** open family atlas · or responsibility folder · or `domain` search.

**AI:**

1. Read [[README]] + this note.
2. Prefer `maps/families/` atlases, then linked system/process notes.
3. For coverage honesty open [[common-case-coverage]].
4. Do not invent task journeys or `and`-joined folders.
5. Prefer `canonical`; treat `draft` as unfinished; treat `temp/` as harvest only.
6. Domain facts need lived evidence, sourced claims, or explicit user input.
7. Engineering craft and change methods are out of scope.

## Related

- [[layout]] · [[methodology]] · [[changing-this-bible]] · [[catalog-maps]] · [[scope]]
