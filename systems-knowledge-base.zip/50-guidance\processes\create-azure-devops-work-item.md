---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-019
concern: processes
description: Create an Azure DevOps work item as delivery SoR record.
domain: [azure-devops]
derived_from:
  - "[[process-note-honesty]]"
  - "[[azure-devops-org]]"
updated: 2026-07-20
---

# Create Azure Devops Work Item

## Purpose

Create a **work item** in [[azure-devops-org]] so delivery intent/status has a tracked record.

## Triggers

- New piece of planned/committed work
- Intake from triage (possibly from GitHub Issues)

## Actors / roles

- Analyst / developer / PM role class (RACI out of this vault)
- API automation via PAT/OAuth

## Inputs / outputs

| In | Out |
| --- | --- |
| Title, type, area/iteration class | Work item id |
| Description / acceptance class | Board presence |

## Operable sequence (business grain)

1. **Choose project + type** — Bug/User Story/Task/etc. per process template Untapped.
2. **Create** — UI or WIT REST.
3. **Set fields** — assignment, iteration, tags as practiced.
4. **Link** — PR/commit/issue URLs when dual-hosting with GitHub.
5. **Visible on board** — confirm column.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Work item state | [[azure-devops-org]] | Yes when Boards are SoR for that class |
| Code change | [[git-vcs]] / hosts | Separate |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Work only in chat | Prefer WIT when ADO is tracker |
| Duplicate of GitHub Issue | Link; pick authoritative tracker per class |

## Owner of this note’s truth

Project admins (Untapped).
