---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-007
concern: systems
description: DOCR — container image registry identity; consume always, create optional.
domain: [digital-ocean]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Container Registry

## Purpose

Hold **container image identity** (registry + repository + tags) for deploy to DO-backed runtimes.

## Owns

- Registry as the platform image store (DigitalOcean Container Registry / DOCR)
- Image tags pulled by DOKS or Droplet hosts and pushed by CI

## Does not own

- Image *build* craft and CI matrix (out of scope)
- Runtime scheduling (→ [[doks-kubernetes]] / [[droplet-compute]])
- Domain facts

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Upstream | CI / release pipelines | Push images |
| Downstream | Cluster or host runtimes | Pull images (pull-secret / login mechanics are out of scope) |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Image tag identity in the registry | Whether TF created the registry vs pre-existing (Gap) |
| Registry as image SoR at platform grain | Domain SoR |

## Usage

### Connect / operate

| Surface | House posture |
| --- | --- |
| Registry | DigitalOcean Container Registry (DOCR) — `registry.digitalocean.com/…` class endpoints |
| Auth class | DO API token / `doctl registry login` / integrated DOKS pull — **never** store tokens here |
| Common ops | Push from CI; pull on DOKS or Droplet; tag immutability policy as practiced; garbage-collect unused tags when enabled |

On **Droplet / Compose** hosts that run pulled images, the running workload tracks **registry identity** — a host recreate without a new push does not change application bytes ([[release-workload-to-platform]]).

### Material config

| Knob | Why it matters |
| --- | --- |
| Subscription tier | Storage and repo limits — plan class |
| Region | Pull latency from DOKS/Droplet |
| Create vs consume | Account may already have a registry — Gap per environment |
| DOKS integration | Native pull integration reduces custom pull-secret choreography (mechanics = eng) |
| Tag mutability | Retagging `latest` risks surprise rollbacks — prefer immutable digests in release (eng) |

### Pricing / limits (class)

- DOCR billed by **tier** (included storage/repos) + overage — separate from compute.
- Large image sprawl hits tier limits — prune unused tags.
- Re-check [Container Registry](https://docs.digitalocean.com/products/container-registry/) for current tiers.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Public image with secrets baked in | Control failure — rebuild; rotate |
| Pull from wrong registry/tag | Deploy wrong artefact — treat tag as SoR carefully |
| Tokens in notes | Forbidden ([[confidentiality-redaction]]) |
| Assuming TF always creates registry | Consume-vs-create Gap |
| Host recreate without new tag | App code change not applied — see [[release-workload-to-platform]] |

## Owner of truth

Platform operators (ownership Untapped).

## Evidence

- **Lived:** Both shapes **consume** DOCR for push/pull. Terraform **create** is often optional — account may already have a registry.
- **Remote:** [Container Registry](https://docs.digitalocean.com/products/container-registry/).

## Gaps / Untapped

- Create vs pre-existing registry per environment
- House tier default
- GC / retention policy
- Named operators

## Further detail

- [Container Registry](https://docs.digitalocean.com/products/container-registry/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[docr]]
