---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-019
concern: glossary
description: SQL instance — SQL Server Database Engine instance.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Instance

**SQL instance** = a running [[sql-server-engine]] Database Engine instance (named or default) hosting databases.
