---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-013
concern: systems
description: Azure subscription densified to useful — ARM ownership boundary for azurerm.
domain: [azure-cloud]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Azure Subscription

## Purpose

Provide the **Azure AD tenant + subscription** boundary where Azure Resource Manager (ARM) resources are owned and billed.

## Owns

- Subscription existence and association to a tenant
- ARM resource groups and resources **inside** that subscription (when Azure is used)
- RBAC assignments at subscription / RG / resource scope (identifiers, not secret material)

## Does not own

- DigitalOcean platform runtime (→ [[digital-ocean-atlas]])
- Terraform module design (engineering)
- Azure DevOps project/work-item SoR (→ [[azure-devops-org]])

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Downstream | [[terraform-azurerm-provider]] | Provider targets subscription for plan/apply |
| Lateral | [[azure-devops-org]] | May authenticate to change ARM — pipeline craft out |

## Processes

- [[authenticate-azurerm-provider]] · [[plan-azure-arm-change]] · [[apply-azure-arm-change]]


## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Whether an ARM resource exists in the subscription | DO Droplet/DOKS inventory |
| Subscription-level IAM as configured | Local admin on a VM alone |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| Portal / CLI | Azure Portal; `az` CLI |
| API | ARM REST under management.azure.com class |
| Auth class | User, service principal, managed identity — house choice Untapped |
| Common ops | Create RGs; assign RBAC; register resource providers |

### Material config

| Knob | Why it matters |
| --- | --- |
| Tenant ID + Subscription ID | Hard boundary for automation targets |
| Resource providers registered | Which resource types can be created |
| Management groups (if any) | Policy inheritance — Untapped |

### Pricing / limits (class)

- Pay-as-you-go / EA / CSP class — **house contract Untapped**.
- Quotas/skus per region — re-check before capacity claims.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Wrong subscription targeted | Cross-env blast radius — pin IDs in automation, not in doctrine notes |
| Over-privileged SP | Prefer least privilege; secrets never in vault |

## Owner of truth

Cloud subscription owners (Untapped).

## Evidence

- **Lived:** User relay 2026-07-20 — **Azure is primary business infrastructure** (VMs, networking, security, identity/auth, AI Foundry, Data Factory, Azure SQL, Group Policy hybrid class). Subscriptions/objects not named here.
- **Remote:** Azure Resource Manager / identity model as pressured via azurerm + Learn docs.

## Gaps / Untapped

- Named subscriptions (avoid object-name doctrine until needed)
- How DO platforms relate when both exist (DO remains vault P0 exemplar for its family; Azure is lived business infra)
- Exact Entra/GPO hybrid topology

## Further detail

- [Azure Resource Manager](https://learn.microsoft.com/en-us/azure/azure-resource-manager/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[service-principal]] · [[resource-group]]
