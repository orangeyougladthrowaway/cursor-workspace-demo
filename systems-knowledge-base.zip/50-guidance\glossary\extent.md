---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-026
concern: glossary
description: Extent — eight pages (64 KB) allocation unit in SQL Server.
domain: [sql-server]
updated: 2026-07-20
---

# Extent

**Extent** = eight contiguous pages (~64 KB) used for allocation in [[sql-server-pages-extents]].
