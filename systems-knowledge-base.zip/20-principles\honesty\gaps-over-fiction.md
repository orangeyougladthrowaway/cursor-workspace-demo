---
type: principle
status: draft
id: systems-knowledge-base-p-003
category: honesty
description: Prefer an explicit Gap over an invented process or SoR claim.
derived_from:
  - "[[honesty]]"
  - "[[documentation-for-current-truth]]"
updated: 2026-07-16
---

# Gaps over fiction

If neither lived evidence nor a sourced claim supports a fact, leave a **Gap**. Do not invent process steps, owners, or SoR to look complete.
