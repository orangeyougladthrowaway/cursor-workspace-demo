---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-010
concern: processes
description: Raise a ServiceDesk Plus Cloud request — operable ITSM intake sequence.
domain: [manageengine-servicedesk]
derived_from:
  - "[[process-note-honesty]]"
  - "[[servicedesk-plus]]"
updated: 2026-07-20
---

# Raise Service Desk Request

## Purpose

Create a **service desk request** in [[servicedesk-plus]] (Cloud) so ITSM work has an authoritative ticket.

## Triggers

- User/portal/email intake needs a tracked ticket
- Integrator creates a request via API

## Actors / roles

- Requester
- Technicians / desk agents (named Untapped)
- API apps (OAuth Untapped)

## Inputs / outputs

| In | Out |
| --- | --- |
| Subject, description, category/template class | Open request with id |
| Requester identity | Assignment / SLA clock per configured rules (rules Untapped) |

## Operable sequence (business grain)

1. **Authenticate** — portal/UI or Cloud OAuth token.
2. **Choose template/category** — as configured (house catalogue Untapped).
3. **Create request** — UI or REST v3; capture mandatory fields.
4. **Confirm** — requester receives request id; ticket is SoR over chat alone.
5. **Handoff** — queue/technician works it ([[resolve-service-desk-request]]).

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Request state / notes | [[servicedesk-plus]] | Yes |
| CRM relationship | [[zoho-crm]] | Separate SoR; bridge Gap |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Work only in chat | Prefer ticket as SoR |
| Wrong category | Mis-routed SLA — correct via reclassify |

## Owner of this note’s truth

Service-desk operators (Untapped).
