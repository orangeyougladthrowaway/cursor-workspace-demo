---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-029
concern: systems
description: SQL Server files and filegroups — data/log layout and growth behaviour.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Files Filegroups

## Purpose

Describe **how a database is stored on files** — data vs log, filegroups, growth — without house path doctrine.

## Concepts

| Artefact | Behaviour |
| --- | --- |
| Primary data file (`.mdf` class) | Starts the database; holds system objects |
| Secondary data files (`.ndf` class) | Optional; place objects via filegroups |
| Log file (`.ldf` class) | Transaction log stream — **not** page-organized like data |
| Filegroup | Named set of data files; objects allocated to a filegroup |
| Autogrowth | Engine expands file when full — size/instant-file-init class matters |

Multiple filegroups enable placement (read-only FG, partitioning class) — house use Untapped.

## Owns / not

| Owns | Does not own |
| --- | --- |
| File/FG model behaviour | Volume letters / Azure disk SKUs as secrets of naming |
| Interaction with backup (files are backup units) | OS storage crafting |

## Azure SQL note

PaaS abstracts files; you reason in **storage/size limits**, not `.mdf` paths. MI exposes more file concepts than Azure SQL DB.

## Failure / controls

| Mode | Posture |
| --- | --- |
| Autogrowth storms | Pre-size files; monitor growth events |
| Log full | Recovery model + log backup / open tran (→ [[sql-server-transaction-log]]) |
| Single huge data file | Operability risk — FG strategy Untapped |

## Evidence

- **Remote:** Files and filegroups Learn docs.
- **Lived:** Untapped file layout standards.

## Further detail

- [Database files and filegroups](https://learn.microsoft.com/en-us/sql/relational-databases/databases/database-files-and-filegroups)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-pages-extents]] · [[sql-server-transaction-log]] · [[sql-server-recovery-backup]]
