---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-021
concern: processes
description: Host or mirror a Git remote on Azure Repos — both hosts practiced.
domain: [azure-devops]
derived_from:
  - "[[process-note-honesty]]"
  - "[[azure-devops-org]]"
  - "[[git-vcs]]"
updated: 2026-07-20
---

# Host Git On Azure Repos

## Purpose

Use **Azure Repos** as a Git remote (primary or peer to GitHub — both practiced) for shared history.

## Triggers

- New repository needed under ADO project
- Mirror/sync from GitHub required

## Actors / roles

- Repo admin
- Authors pushing via Git

## Inputs / outputs

| In | Out |
| --- | --- |
| Project + repo name class | Clone URL (HTTPS/SSH) |
| Permissions | Who may push/create PR |

## Operable sequence (business grain)

1. **Create repo** — in ADO project (or adopt existing).
2. **Set default branch + policies** — reviewers/checks Untapped.
3. **Grant access** — teams/users.
4. **Clone/push** — [[contribute-git-change]].
5. **Dual-host** — if GitHub also holds the repo, define which is writable SoR (policy Untapped).

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Remote refs in ADO | [[azure-devops-org]] + [[git-vcs]] | Yes for that remote |
| GitHub remote | [[github-host]] | Yes when also used |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Two writable remotes diverge | Prefer single write leader; sync Untapped |
| PAT in plaintext notes | Forbidden |

## Owner of this note’s truth

ADO project admins (Untapped).
