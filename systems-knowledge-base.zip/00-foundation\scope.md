---
type: foundation
status: draft
id: systems-knowledge-base-fnd-scope
description: systems-knowledge-base in/out — DigitalOcean P0 useful; P1 families admitted in waves; dual evidence posture.
updated: 2026-07-20
---

# Scope

Companion detail: [[platform-watchlist]]. Coverage: [[common-case-coverage]].

## What this vault owns

Current-state **systems and business-process truth** for platforms and processes we run or must understand:

- What each system is for
- What it owns / does not own (source of record)
- Business interfaces and handoffs
- Controls, operators, and failure modes at business grain
- Domain glossary as practiced here

## What this vault does not own

- Engineering packaging, CI, code craft, infra-as-code **patterns** / module design
- PM / BA / TA methods, policies, staff-agent skills
- Vendor manual mirrors, course trees, or credential/secret material
- Org-chart folders or marketing product lore as architecture

Azure / Terraform content here is limited to **platform and provider facts** (resource classes, auth identity, ownership boundaries) — not Terraform style or pipeline craft.

## Evidence posture (required)

| Branch | Role |
| --- | --- |
| **Lived** | Infer from existing projects, configs, runbooks, operator practice — primary for *house* facts |
| **Remote research** | Official docs and trusted product references — **required**; pressure documentation quality and fill gaps |

Rules:

1. Lived house facts win when remote generic guidance conflicts with how we actually run a system.
2. Absence of a local project is **not** permission to skip research — research the platform; mark house practice Untapped/Gaps.
3. Research uses the controlled pipeline ([[knowledge-ingestion]]). Do not paste vendor encyclopaedias.
4. Do not invent process or SoR facts. If neither lived evidence nor a sourced claim supports it, leave a Gap.

## Platform watchlist

| Platform | Role | Priority |
| --- | --- | --- |
| **DigitalOcean** | Core cloud / platform home | **P0 — useful on core cells** |
| Zoho (CRM, Flow) | Business / SaaS suite surfaces | P1 Wave 1 |
| ManageEngine ServiceDesk Plus | ITSM / service-desk processes | P1 Wave 1 |
| Git | Source-history SoR | P1 Wave 2 |
| GitHub | Hosted collaboration SoR | P1 Wave 2 |
| Azure DevOps | Delivery / work-tracking SoR (not CI craft) | P1 Wave 2 |
| Azure cloud (Terraform provider grain) | Cloud platform ownership at provider grain | P1 Wave 3 |
| **Azure business infra (expanded)** | VMs, networking, identity/auth, security controls, Data Factory, AI Foundry, Azure SQL — **lived primary business infra** | Wave 3+ densify (active) |
| Aryza Sentinel | Lending platform — **confirm product identity** | P1 Wave 4 |
| TCS BaNCS | Banking core / deposit SoR cluster | P1 Wave 4 |
| Tuum (overdraft) | Overdraft module within Tuum as practiced | P1 Wave 4 |
| Virtual Cabinet | Document management SoR | P1 Wave 5 |
| SQL Server suite (SSMS, SSIS, SSRS) | Relational engine + tool surfaces | P1 Wave 5 |
| PostgreSQL / pgAdmin | Relational engine + admin tool surfaces (not DO managed SKU) | P1 Wave 5 |

**Sequencing:** DigitalOcean P0 useful gate is **met**. P1 proceeds in **waves of 2–3 families** per [[platform-watchlist]]. Amend this note + watchlist **before** opening a new family atlas.

## First family

`digital-ocean` under `maps/families/digital-ocean/`. New families open under `maps/families/{leaf}/` only after admit on this note and [[platform-watchlist]], scored on [[common-case-coverage]].

## Quarantine

Org-chart as L1 · full SOP dumps as guidance · change-method bodies · engineering craft bodies · secrets/PII · bulk third-party skill packs as a second bible · `_index.md` / `and`-joined names · alias shims for renames · declaring P1 platforms deep-covered while only named · treating Azure Terraform **style** as systems doctrine

## Changing scope

Edit this note when the landscape truly changes. Do not sprawl by interest.
