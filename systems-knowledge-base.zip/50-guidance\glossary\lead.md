---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-007
concern: glossary
description: Lead — Zoho CRM early-stage relationship record (house SoR module).
domain: [zoho]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-20
---

# Lead

**Lead** = early-stage relationship / prospect record in [[zoho-crm]]. House SoR module (lived).
