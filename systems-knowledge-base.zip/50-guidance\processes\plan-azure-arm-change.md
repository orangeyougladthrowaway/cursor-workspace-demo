---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-023
concern: processes
description: Plan an Azure Resource Manager change via Terraform azurerm.
domain: [azure-cloud]
derived_from:
  - "[[process-note-honesty]]"
  - "[[terraform-azurerm-provider]]"
updated: 2026-07-20
---

# Plan Azure Arm Change

## Purpose

Produce a **Terraform plan** for ARM changes using `azurerm` without applying yet.

## Triggers

- Proposed infrastructure change
- PR validation in CI (pipeline craft out of scope)

## Actors / roles

- IaC author / reviewer

## Inputs / outputs

| In | Out |
| --- | --- |
| Authenticated provider; config in Git | Plan file / human-readable plan |
| State access | Diff of create/update/destroy |

## Operable sequence (business grain)

1. **Authenticate** — [[authenticate-azurerm-provider]].
2. **Init** — provider/plugins resolved; backend state accessible (backend craft eng).
3. **Plan** — review creates/updates/destroys; reject surprise destroys.
4. **Review** — second pair of eyes for blast radius.
5. **Decide** — proceed to [[apply-azure-arm-change]] or revise.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Desired config in Git | [[git-vcs]] (+ hosts) | Eng desired-state |
| Live ARM resources | [[azure-subscription]] | Live cloud SoR |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Plan against wrong subscription | Pin subscription id |
| Unreadable plan in automation | Fail closed |

## Owner of this note’s truth

IaC operators (Untapped).
