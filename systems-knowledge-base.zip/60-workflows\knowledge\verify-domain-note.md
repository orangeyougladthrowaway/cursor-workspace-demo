---
type: workflow
status: draft
id: systems-knowledge-base-wf-009
concern: knowledge
description: Verify domain notes — SoR honesty, coverage cells, vault-health cleanliness.
derived_from:
  - "[[vault-health-checks]]"
  - "[[common-case-coverage]]"
  - "[[system-sor-honesty]]"
  - "[[amend-domain-truth]]"
updated: 2026-07-17
---

# Verify domain note

Use after [[amend-domain-truth]] or when checking domain note quality.

## Preconditions

- Notes or claims under check
- Awareness of family coverage cells

## Retrieve

1. [[system-sor-honesty]] for SoR/capability claims.
2. [[common-case-coverage]] for family × cell honesty.
3. [[vault-health-checks]] — run pytest when the vault changed.
4. Family atlas for index honesty.

## Steps

1. Map claims to evidence (lived / sourced / Gap).
2. Confirm SoR statements are not invented.
3. Confirm coverage scores match reality (seeded ≠ useful).
4. Run vault health if files changed; fix manually; re-run.
5. Verdict: pass, fail, or blocked.

## Output

- Check results
- Coverage caveats
- Commands/results for health suite
- Verdict

## Handoff

Failures → [[amend-domain-truth]]. Pass → [[review-domain-claim]] when independent review is required.

## Forbidden

- Declaring useful/deep without evidence
- Skipping health after structural vault edits
