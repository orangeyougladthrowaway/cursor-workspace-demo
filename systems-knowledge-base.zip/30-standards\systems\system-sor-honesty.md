---
type: standard
status: draft
id: systems-knowledge-base-s-002
concern: systems
description: System notes must state owns / does not own and authoritative boundaries explicitly.
derived_from:
  - "[[named-source-of-record]]"
  - "[[sibling-vault-boundaries]]"
  - "[[gaps-over-fiction]]"
  - "[[no-encyclopaedia-paste]]"
  - "[[link-further-detail]]"
updated: 2026-07-20
---

# System SoR honesty

Every living system note must include:

- Purpose
- Owns (facts / capabilities)
- Does not own (explicit)
- Upstream / downstream business interfaces
- Authoritative for … / not authoritative for …
- Owner of truth
- `status`, `id`, `concern`, `updated`

## Platform-product notes (DigitalOcean and later families)

Also require a **Usage** section sufficient for the [[common-case-coverage]] `useful` bar:

| Subsection | Content |
| --- | --- |
| Connect / operate | API/CLI/control-plane access class; auth posture (tokens, SSO, keys — never store secrets here) |
| Material config | Knobs that change house behaviour (HA, pools, networking, retention class) — not vendor encyclopaedia |
| Pricing / limits | Pricing *class* and quotas/limits that affect tier choice; link remote pricing pages; no invoices |
| Failure / controls | Material fail modes and controls as practiced |
| Gaps | Untapped ownership, unpracticed products, consume-vs-provision, account binding |

## Further detail (required when grain is declined)

When **Does not own**, Gaps, or Usage deliberately omit wire payloads, field catalogues, or deep vendor matrices, include a **Further detail** (or Evidence Remote) block with **https** links to the authoritative vendor/docs hub for that surface ([[link-further-detail]]). Do not remove existing house detail — add links beside it.

Engineering wire shapes and IaC module design are out of scope here. Business/semantic handoffs and **platform-use truth** only.
