---
type: map
status: draft
id: systems-knowledge-base-map-postgres
concern: postgres
description: PostgreSQL family atlas — engine + pgAdmin densified; distinct from DO managed-postgres.
domain: [postgres]
updated: 2026-07-20
---

# Postgres Atlas

Browse for **PostgreSQL** and **pgAdmin** at systems grain. Distinct from DigitalOcean [[managed-postgres]].

## Systems

| Note | Role |
| --- | --- |
| [[postgres-engine]] | PostgreSQL engine SoR grain |
| [[pgadmin]] | Graphical admin client (desktop/server mode) |

## Processes

| Note | Question |
| --- | --- |
| [[connect-administer-postgres]] | How operators connect and administer |
| [[administer-via-pgadmin]] | How pgAdmin is used for admin |
| [[backup-restore-postgres]] | How backup/restore is performed |

## Glossary

[[postgres-cluster]] · [[psql]]

## Interfaces / Gaps

| Counterpart | Status |
| --- | --- |
| [[managed-postgres]] | DO managed product — link only when that is the house cluster |
| [[sql-server-engine]] | Peer engine — SoR split Untapped |
| Apps / ETL | Gap — which DBs are domain SoR |

## Evidence posture

- **Lived:** User relay — **both** DO [[managed-postgres]] and other [[postgres-engine]] paths exist.
- **Remote:** postgresql.org docs · pgAdmin 4 docs.

## Further detail

Out-of-vault wire/field matrices and deep vendor manuals stay linked, not pasted ([[link-further-detail]] · [[further-detail-hubs]]):

- [PostgreSQL current docs](https://www.postgresql.org/docs/current/)
- [pgAdmin docs](https://www.pgadmin.org/docs/)

## Usability wave

**Useful** on Atlas/Systems/Usage/Processes/Controls/Glossary/Freshness. Interfaces partial.

## Related

- [[scope]] · [[platform-watchlist]] · [[sql-server-atlas]] · [[digital-ocean-atlas]] · [[catalog-maps]]
