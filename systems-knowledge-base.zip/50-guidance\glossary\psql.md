---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-024
concern: glossary
description: psql — PostgreSQL interactive terminal client.
domain: [postgres]
updated: 2026-07-20
---

# Psql

**psql** = official interactive terminal client for [[postgres-engine]].
