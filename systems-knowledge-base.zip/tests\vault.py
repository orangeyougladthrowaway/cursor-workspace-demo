"""Shared helpers for systems-knowledge-base vault health tests."""

from __future__ import annotations

import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
SKIP_PARTS = {".git", "temp", "node_modules", ".cursor", ".obsidian"}


def iter_notes() -> list[Path]:
    notes: list[Path] = []
    for path in ROOT.rglob("*.md"):
        if any(part in SKIP_PARTS for part in path.parts):
            continue
        notes.append(path)
    return notes


def note_stems() -> set[str]:
    return {p.stem for p in iter_notes()}


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def parse_frontmatter(text: str) -> tuple[dict, str]:
    if not text.startswith("---"):
        return {}, text
    end = text.find("---", 3)
    if end < 0:
        return {}, text
    block = text[3:end]
    body = text[end + 3 :]
    try:
        data = yaml.safe_load(block) or {}
    except yaml.YAMLError:
        data = {}
    if not isinstance(data, dict):
        data = {}
    return data, body


def rel_posix(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def extract_wikilinks(text: str) -> list[str]:
    return [m.group(1).strip().split("|")[0].strip() for m in re.finditer(r"\[\[([^\]|#]+)", text)]


def norm_slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def responsibility_folder(path: Path) -> str | None:
    parts = Path(rel_posix(path)).parts
    if len(parts) >= 3 and re.match(r"^(30|40|50|60)-", parts[0]):
        if path.stem.startswith("catalog-"):
            return None
        return parts[1]
    return None


def map_leaf_folder(path: Path) -> str | None:
    parts = Path(rel_posix(path)).parts
    if (
        len(parts) >= 4
        and parts[0] == "maps"
        and parts[1] in ("families", "themes")
        and not path.stem.startswith("catalog-")
    ):
        return parts[2]
    return None


def h1_title(body: str) -> str | None:
    for line in body.splitlines():
        if line.startswith("# "):
            return line[2:].strip()
    return None
