---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-006
concern: glossary
description: Managed database — DigitalOcean managed DB product (Postgres practiced).
domain: [digital-ocean]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-16
---

# Managed Database

DigitalOcean **Managed Databases** product. House practice uses **PostgreSQL** in the VPC. System note: [[managed-postgres]].
