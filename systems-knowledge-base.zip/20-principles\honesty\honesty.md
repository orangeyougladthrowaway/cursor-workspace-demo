---
type: category
status: draft
id: systems-knowledge-base-cat-honesty
category: honesty
description: Category spine — honest Gaps, coverage, and note completeness.
updated: 2026-07-16
---

# Honesty

Principles about refusing invented truth and coverage theatre.
