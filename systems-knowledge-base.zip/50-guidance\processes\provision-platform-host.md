---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-001
concern: processes
description: Bring DigitalOcean platform capacity into existence — operable sequence, SoR, Gaps.
domain: [digital-ocean]
derived_from:
  - "[[process-note-honesty]]"
  - "[[named-source-of-record]]"
  - "[[doks-kubernetes]]"
  - "[[droplet-compute]]"
updated: 2026-07-18
---

# Provision Platform Host

## Purpose

Bring DigitalOcean-backed **platform capacity** into existence so workloads have somewhere to run.

## Triggers

- New environment needs platform capacity
- Capacity change requiring new cluster and/or Droplet and related platform resources

## Actors / roles

- Platform operators (apply / approve capacity)
- Requesting team (intent + acceptance of shape) — ticket handoff Gap until P1 ITSM deep-dived

## Inputs / outputs

| In | Out |
| --- | --- |
| Intent: environment name class, **runtime shape** (cluster vs host), region, capacity class | Running DOKS and/or Droplet capacity |
| Whether DB / Spaces / registry in scope | Attached [[platform-vpc]], [[cloud-firewall]], optional [[managed-postgres]] / [[spaces-object-storage]] / [[container-registry]] |
| Platform credentials (not stored in vault) | Resource identities in eng state / operator runbook — **not** as doctrine object names here |

## Operable sequence (business grain)

Order is dependency-shaped; eng owns how apply is automated.

1. **Choose shape** — cluster → [[doks-kubernetes]]; host → [[droplet-compute]]; optional GPU host lateral to either ([[self-hosted-inference-compute]]).
2. **Network first** — ensure [[platform-vpc]] in region (create or attach — Gap per env).
3. **Compute** — provision DOKS pools and/or Droplet(s) attached to that VPC.
4. **Firewall** — attach [[cloud-firewall]] (Droplet ids and/or worker tags; separate rules for GPU if needed).
5. **Data plane (if in scope)** — [[managed-postgres]] private in VPC; confirm trusted-sources Gap.
6. **Object / image stores (if in scope)** — bind or create [[spaces-object-storage]] / [[container-registry]] (consume-vs-create Gap).
7. **Edge (optional)** — [[platform-edge]] only if public HTTP(S) required; DO LB still not practiced (Gap).
8. **Handoff** — requesting team gets “capacity ready” with shape + region + connectivity class; secrets stay in secret store.

## Systems touched + SoR

| Fact / artefact | System | SoR? |
| --- | --- | --- |
| Cluster existence | [[doks-kubernetes]] | Yes |
| VM host existence | [[droplet-compute]] | Yes |
| Network scope | [[platform-vpc]] | Yes |
| Firewall rules | [[cloud-firewall]] | Yes |
| Managed DB cluster | [[managed-postgres]] | Yes when in scope |
| Object bucket | [[spaces-object-storage]] | Yes when in scope |
| Image registry | [[container-registry]] | Yes when in scope |
| Desired infra config in Git | Product repo engineering craft | Eng desired-state — not domain SoR |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Apply without shared state locking | Drift risk — eng control; note as failure mode |
| Secrets in vault notes | Forbidden ([[confidentiality-redaction]]) |
| Compute before VPC | Breaks private DB pattern |
| Firewall membership missed after scale | Unprotected workers — verify tags/ids |
| Wrong shape chosen | Compose on DOKS or k8s on single Droplet without intent — re-frame |
| Ticket path unclear | Actor Gap — escalate user until P1 ITSM covered |

## Owner of this note’s truth

Platform operators (ownership Untapped).

## Related glossary

- [[doks]] · [[droplet]] · [[vpc]] · [[spaces]] · [[docr]]
