---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-001
concern: systems
description: DOKS — managed Kubernetes runtime shape; SoR plus usage (API, HA, pricing class).
domain: [digital-ocean]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Doks Kubernetes

## Purpose

Provide the **managed Kubernetes** runtime (DOKS) for the **cluster** platform shape.

## Owns

- Cluster existence and managed control-plane lifecycle
- Worker node pools (general and specialised capacity classes, including GPU pools when enabled)
- Cluster endpoint / operational identity at the platform grain

## Does not own

- Application / domain business facts
- Image build pipelines (out of scope); image *identity* at registry grain → [[container-registry]]
- Object bytes → [[spaces-object-storage]]
- Relational data → [[managed-postgres]]
- Public DNS / DO Load Balancer (not practiced here — see [[platform-edge]])

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Upstream | [[platform-vpc]] | Cluster attached to VPC |
| Upstream | [[cloud-firewall]] | Worker membership via firewall tags when configured |
| Upstream | [[container-registry]] | Image pull at deploy |
| Downstream | Workloads on the cluster | Consume node capacity |
| Lateral | [[self-hosted-inference-compute]] | Optional GPU pools host inference runtimes |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Whether a DOKS cluster exists and its pool layout as provisioned | Domain SoR |
| Cluster as the runtime home for cluster-shaped environments | Host-shaped Compose runtimes (→ [[droplet-compute]]) |

## Usage

### Connect / operate

| Surface | House posture |
| --- | --- |
| Control plane | Managed by DigitalOcean; included with the cluster (no separate control-plane VM to run) |
| Access | `kubectl` via cluster kubeconfig; DigitalOcean API / `doctl` / Terraform providers for cluster lifecycle |
| Auth class | DO account API tokens for management API; kubeconfig credentials for cluster API. SSO/OIDC to the Kubernetes API is a DO product capability — **house adoption Untapped** (confirm before assuming) |
| Common ops | Create/update node pools; upgrade cluster version; scale pools (manual or autoscaler); fetch kubeconfig; apply workloads (workload packaging is engineering lane) |

### Material config

| Knob | Why it matters |
| --- | --- |
| Region + VPC | Cluster must land in the platform VPC for private DB/registry patterns |
| Node pool size/slug | Cost and capacity; workers billed as Droplet-class nodes |
| HA control plane | Optional paid HA for control plane (~$40/month class per DO pricing docs) |
| Autoscaling | Pool min/max changes monthly cost shape |
| GPU pools | Separate pool class; priced like GPU Droplets when used |
| Version | Upgrade cadence; surge upgrades available without extra DO charge for the surge mechanism |

### Pricing / limits (class)

- **Workers:** billed per second at the same price class as the underlying Droplet/GPU size; billing starts when the node is ready (including unhealthy). Minimum short-usage floors apply (see DO Kubernetes pricing).
- **Control plane:** managed control plane at no extra charge; **HA control plane** is a fixed monthly add-on (prorated hourly).
- **Cap:** node-pool billing capped at 28 days (672h) of highest usage in longer months — do not assume 31× full charge.
- **Bandwidth:** free outbound allowance accrues from worker pool size class (Droplet bandwidth quotas).
- **Integrations:** DO Load Balancers and volumes charged at their own product rates when used (LB **not** practiced in current house inventories — Gap).
- Live numbers: [Kubernetes pricing](https://docs.digitalocean.com/products/kubernetes/details/pricing/) — do not paste full tables here; re-check before capacity commits.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Node unhealthy | DO offers node remediation / readiness controls as product features — house policy Untapped |
| Wrong shape | Do not treat DOKS as host for Compose-shaped environments ([[droplet-compute]]) |
| Secrets in notes | Forbidden ([[confidentiality-redaction]]) |
| Open API token sprawl | Tokens are credentials — ownership/rotation Untapped |

## Owner of truth

Platform operators (ownership Untapped). Engineering packaging is out of scope.

## Evidence

- **Lived:** Cluster-shaped platform repos provision DOKS as default compute home; optional CPU/GPU node pools; no DO DNS/LB resources in those inventories.
- **Remote:** [DigitalOcean Kubernetes](https://docs.digitalocean.com/products/kubernetes/) · [pricing](https://docs.digitalocean.com/products/kubernetes/details/pricing/).

## Gaps / Untapped

- House SSO/OIDC adoption for cluster API
- Whether DO LB is ever introduced (currently not practiced)
- Named operators / who may resize pools
- Account-specific cluster ids (never doctrine)

## Further detail

- [DigitalOcean Kubernetes](https://docs.digitalocean.com/products/kubernetes/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[doks]] · [[docr]] · [[vpc]]
