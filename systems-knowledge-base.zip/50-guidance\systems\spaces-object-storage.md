---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-003
concern: systems
description: Spaces — object storage SoR for blobs; not relational domain SoR.
domain: [digital-ocean]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Spaces Object Storage

## Purpose

Provide **S3-compatible object storage** for application blobs/artefacts.

## Owns

- Object bytes and bucket identity at the platform grain
- Product capability for access keys / optional CDN (credential handling is out of scope; never store secrets here)

## Does not own

- Relational / domain entities
- Cluster or VM lifecycle
- Which service may hold Spaces credentials (engineering ownership is out of scope)
- Application key-prefix conventions (product/eng) beyond the platform fact that prefixes are **not** nested buckets

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Upstream | Storage-facing app capability | Put/get objects |
| Lateral | [[doks-kubernetes]] / [[droplet-compute]] | Runtimes that call Spaces |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Object presence in Spaces | Domain database records |
| Bucket as object SoR | Whether TF created the bucket vs pre-existing (Gap) |

## Usage

### Connect / operate

| Surface | House posture |
| --- | --- |
| API class | S3-compatible endpoint (region-specific Spaces endpoint) |
| Auth class | Spaces access key + secret (or DO API-managed keys) — **never** store in this vault |
| Clients | Any S3 SDK / CLI aimed at Spaces endpoint; apps on DOKS or Droplet |
| Common ops | Create bucket (or bind existing); put/get/list/delete objects; set ACL/CORS as practiced; optional CDN |

### Object identity (bucket vs key)

| Concept | Meaning |
| --- | --- |
| **Bucket** | One bucket identity (name) at the platform grain — environment binding Gap (do not freeze ephemeral names as house law) |
| **Object key** | Full object path **inside** that bucket |
| **Key prefix** | Convention on the key (e.g. an inbox segment under a single bucket) — **not** a nested/second bucket |

Operators must not treat `bucket/prefix/...` as nested bucket hierarchy. List/put/get target **one** bucket plus a key (optional prefix filter). App “inbox” folders are prefix conventions. Client `endpoint_url` construction is engineering grain (not documented here).

### Material config

| Knob | Why it matters |
| --- | --- |
| Region | Latency and endpoint URL; match compute region when possible |
| Bucket name | Global DNS-ish uniqueness; environment binding Gap (no names as doctrine) |
| Key / prefix | App layout inside the bucket; prefixes are not separate Spaces products |
| CDN | Edge cache for public objects — house use Untapped |
| File Listing / ACL | Public vs private objects — default private unless edge needs public |
| Create vs consume | TF may or may not create the bucket — Gap per environment |

### Pricing / limits (class)

- Billed by **storage volume + bandwidth egress** (and CDN if enabled) — separate from Droplet/DOKS compute.
- Watch egress when apps pull large artefacts repeatedly; prefer same-region compute.
- Re-check [Spaces](https://docs.digitalocean.com/products/spaces/) pricing before large retention policies.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Keys in git/vault notes | Forbidden ([[confidentiality-redaction]]) |
| Public bucket by mistake | Control failure for non-public blobs |
| Treating Spaces as DB | Wrong SoR — relational → [[managed-postgres]] |
| Nested-bucket confusion | Mis-aiming put/list at a “bucket” that is only a key prefix — wrong object identity |
| Cross-region chatty pulls | Cost/latency foot-gun |

## Owner of truth

Platform operators (ownership Untapped).

## Evidence

- **Lived:** Both runtime shapes **consume** Spaces from apps. Provision via Terraform is often **optional** — consume vs create is a Gap per environment. Apps commonly use one bucket with key prefixes for inbox/layout (prefix names are environment config, not doctrine).
- **Remote:** [Spaces](https://docs.digitalocean.com/products/spaces/).

## Gaps / Untapped

- Create vs pre-existing bucket per environment
- CDN adoption
- Retention / lifecycle policies
- Named credential owners (eng lane adjacency)

## Further detail

- [Spaces](https://docs.digitalocean.com/products/spaces/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[spaces]]
