---
type: standard
status: draft
id: systems-knowledge-base-s-004
concern: controls
description: Never commit secrets, credentials, or unrestricted personal data into vault notes.
derived_from:
  - "[[sibling-vault-boundaries]]"
  - "[[gaps-over-fiction]]"
  - "[[restraint]]"
updated: 2026-07-16
---

# Confidentiality redaction

Vault notes may name **roles**, **control types**, and **classes of data**. They must never contain:

- Secrets, tokens, passwords, private keys
- Unrestricted personal data dumps
- Live account numbers or customer identifiers beyond what is needed for process clarity (prefer redacted examples)

If evidence requires sensitive detail, keep it out of Git — record a Gap or point to a controlled store outside the vault.
