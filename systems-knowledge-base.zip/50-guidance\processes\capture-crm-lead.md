---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-004
concern: processes
description: Capture or update a Lead in Zoho CRM — operable house SoR sequence.
domain: [zoho]
derived_from:
  - "[[process-note-honesty]]"
  - "[[zoho-crm]]"
updated: 2026-07-20
---

# Capture Crm Lead

## Purpose

Create or update a **Lead** in [[zoho-crm]] so early-stage relationship truth has a system of record.

## Triggers

- New prospect / enquiry arrives (web, email, partner, manual)
- Existing Lead needs correction before conversion

## Actors / roles

- CRM users / sales ops (named owners Untapped)
- Integrators via API (OAuth apps Untapped)

## Inputs / outputs

| In | Out |
| --- | --- |
| Person/org identity class, source, interest | Lead record in CRM |
| Optional Campaign / source metadata | Audit of create/update in CRM history |

## Operable sequence (business grain)

1. **Authenticate** — UI session or OAuth token scoped for Leads.
2. **Search** — look for existing Lead/Contact/Account to avoid duplicates (match rules Untapped).
3. **Create or update Lead** — UI or REST v7 entity API; required layout fields must pass CRM validation.
4. **Assign owner** — house assignment rules Untapped; record must have an owner.
5. **Handoff** — owner works Lead; conversion to Contact/Account/Deal is a separate process ([[convert-crm-lead]]).

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Lead field values | [[zoho-crm]] | Yes |
| Orchestration from other apps | [[zoho-flow]] | Not practiced — Gap / aspirational |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Duplicate Leads | Search-before-create; merge policy Untapped |
| API token over-scope | Prefer module-minimal OAuth scopes |
| Secrets in notes | Forbidden |

## Owner of this note’s truth

CRM operators (Untapped).
