---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-012
concern: processes
description: Integrate with ServiceDesk Plus Cloud via OAuth REST — operable API path.
domain: [manageengine-servicedesk]
derived_from:
  - "[[process-note-honesty]]"
  - "[[servicedesk-plus]]"
updated: 2026-07-20
---

# Integrate Servicedesk Via Api

## Purpose

Call **ServiceDesk Plus Cloud REST v3** under OAuth so automations can create/read/update requests without UI.

## Triggers

- New integrator needs ticket CRUD
- Token rotation / re-consent

## Actors / roles

- Integration owner
- Desk admin (scopes / roles)

## Inputs / outputs

| In | Out |
| --- | --- |
| OAuth client + scopes; DC base URL | Access (+ refresh) tokens — not stored in vault |
| API operation | Request JSON success/error |

## Operable sequence (business grain)

1. **Register OAuth client** — Zoho API console class per ManageEngine Cloud docs.
2. **Obtain tokens** — authorization code / refresh flow; store secrets in secret store only.
3. **Call API** — `Authorization` bearer; DC-correct host; versioned `/api/v3/...` paths.
4. **Handle errors** — 401 → refresh; validation errors → fix payload; rate limits → back off.
5. **Operate** — rotate client secrets; revoke on leaver.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Ticket data | [[servicedesk-plus]] | Yes |
| Flow orchestration | [[zoho-flow]] | Aspirational Gap |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Over-scoped OAuth | Minimal scopes for request ops |
| Token in git/vault notes | Forbidden |

## Owner of this note’s truth

Integration + desk admins (Untapped).
