---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-027
concern: processes
description: Publish and secure an SSRS paginated report — operable sequence.
domain: [sql-server]
derived_from:
  - "[[process-note-honesty]]"
  - "[[ssrs]]"
updated: 2026-07-20
---

# Publish Ssrs Report

## Purpose

Publish a **paginated report** to [[ssrs]] so consumers use the server catalogue as the report SoR.

## Triggers

- New/changed report definition ready
- Security model change on folders

## Actors / roles

- Report author / BI admin
- Consumers (read)

## Inputs / outputs

| In | Out |
| --- | --- |
| RDL + shared/embedded data source config | Published report in portal folder |
| Role assignments | Who may browse/view/manage |

## Operable sequence (business grain)

1. **Author** — report definition against approved data source (tooling eng).
2. **Publish** — to report server folder via portal/designer.
3. **Bind data source** — credentials class (integrated/managed — not in vault).
4. **Secure** — folder/item roles least privilege.
5. **Validate** — render in portal; optional subscription.
6. **Retire** — replace/hide obsolete versions; don’t leave dual “truth” exports.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Report definition version | [[ssrs]] | Yes for published report |
| Underlying data | [[sql-server-engine]] / other | Data SoR |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Public folder accidental | Review browser role |
| Credential in RDL checked into git | Forbidden pattern |

## Owner of this note’s truth

BI admins (Untapped).
