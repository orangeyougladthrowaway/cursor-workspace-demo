---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-014
concern: glossary
description: Branch — movable Git ref naming a line of development.
domain: [git]
updated: 2026-07-20
---

# Branch

**Branch** = movable ref in [[git-vcs]] pointing at a commit tip (e.g. topic or shared base).
