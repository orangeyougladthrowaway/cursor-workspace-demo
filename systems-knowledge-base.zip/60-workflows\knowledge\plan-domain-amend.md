---
type: workflow
status: draft
id: systems-knowledge-base-wf-007
concern: knowledge
description: Plan elevating lived/remote domain evidence into systems-knowledge-base (claims, homes, coverage honesty).
derived_from:
  - "[[knowledge-ingestion]]"
  - "[[agent-projection]]"
  - "[[common-case-coverage]]"
updated: 2026-07-17
---

# Plan domain amend

Use before writing system/process/glossary notes. Read-only planning.

## Preconditions

- Evidence branch known (lived and/or remote) or explicit Gap
- Target family/concern guess

## Retrieve

1. [[knowledge-ingestion]] — admit labels, claim cards, conflict protocol.
2. [[navigation]] — confirm responsibility folder before inventing folders.
3. Family atlas + [[common-case-coverage]] / [[ingest-coverage]].
4. [[scope]] / [[platform-watchlist]] — DO first; no premature P1 deep dive.

## Steps

1. Admit source (`pressure` / `specialise` / `pointer` / `defer` / `reject`).
2. Draft ≤20 claim cards that would change a decision.
3. Locate collide homes (atlas → notes); propose new folder only via [[navigation]] amend.
4. List conflict risks (lived vs remote; user override).
5. Name coverage cells that would move.
6. Stop if secrets/PII or engineering/change-method material.

## Output

- Admit label + source refs
- Claim list
- Target notes / Gaps
- Coverage impact
- Open questions

## Handoff

Accepted plan → [[amend-domain-truth]].

## Forbidden

- Planning a curriculum tree or vendor encyclopaedia paste
- Silent overwrite of house process by generic vendor docs
