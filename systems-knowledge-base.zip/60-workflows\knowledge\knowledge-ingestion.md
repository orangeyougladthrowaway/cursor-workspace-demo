---
type: workflow
status: draft
id: systems-knowledge-base-wf-001
concern: knowledge
description: Lived harvest and remote research enter via claims → collide → amend-first; ledger outside doctrine.
derived_from:
  - "[[navigation]]"
  - "[[changing-this-bible]]"
  - "[[methodology]]"
  - "[[scope]]"
updated: 2026-07-16
---

# Knowledge ingestion

How knowledge enters this bible. Sources are pressure; **claims** are the unit of work; **living notes** remain doctrine.

## Paths (two branches, one vault)

```text
Lived:  repo / operator practice / temp harvest → distill claims → collide → amend
Remote: official docs / trusted refs → admit → claims → collide → amend
                                         └ pointer | defer | reject (often)
```

| Branch | Default | Authority |
| --- | --- | --- |
| **Lived** | Primary for domain facts | Org reality wins over generic vendor docs |
| **Remote** | Pressure on documentation quality and portable shapes | Must not silently overwrite house process truth |

## Pipeline

```text
Admit → Claim cards (≤20/source) → Locate/collide → Conflict resolve → Elevate → Cleanliness
```

### Admit labels

| Admit | Meaning | Claims? |
| --- | --- | --- |
| `pressure` | Challenges doctrine we care about, or on watchlist | Yes |
| `specialise` | On watchlist and maps to an existing concern | Yes |
| `pointer` | Research aid only — **keep the URL** on the living note as Further detail when grain stays out of vault | **No** claim cards required |
| `defer` | Good source, wrong season | No |
| `reject` | Out of scope or noise | No |

**Ledger:** [[ingest-coverage]] (and chat). Do not build a curriculum tree in the vault.

### Claim cards

Extract **claims**, not chapter mirrors. Prefer claims that would change a decision.

Banned as claims: tutorial step dumps, vendor encyclopaedias, glossary of widely known terms, full statute mirrors, secrets/PII.

### Conflict protocol (highest wins)

1. User explicit override (then update living note)
2. Canonical systems-knowledge-base note already decided
3. Lived practice for house facts
4. Portable principles (ownership, honesty, …)
5. Stronger remote sources (official product docs) over blogs
6. Drafts — advisory only

**Practiced asymmetry:** if remote contradicts lived house fact, reject remote · aspirational `draft` · or tradeoff with **default = lived**.

### Elevate

| Become | Required |
| --- | --- |
| `draft` | Pass locate/collide; one concern; one question |
| `canonical` | Human promotion; no open contradiction; short rationale |

Amend-first. New note requires explicit “no merge target” check.

### Session budgets (default)

≤30 claim cards · ≤3 note amends · ≤1 new draft per normal ingest session · hand-write only.

## Related

- [[ingest-coverage]] · [[common-case-coverage]] · [[agent-projection]] · [[scope]]
