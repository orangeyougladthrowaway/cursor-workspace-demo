---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-034
concern: processes
description: Deploy or expose an Azure AI Foundry model endpoint — operable sequence.
domain: [azure-cloud]
derived_from:
  - "[[process-note-honesty]]"
  - "[[azure-ai-foundry]]"
updated: 2026-07-20
---

# Deploy Azure Ai Foundry Model

## Purpose

Make a **model deployment** available under Azure AI Foundry with governed identity access.

## Triggers

- New AI capability for an app
- Model/version change

## Actors / roles

- AI platform owners
- Consuming app owners

## Inputs / outputs

| In | Out |
| --- | --- |
| Project; model SKU; region | Deployment/endpoint |
| Access grants | Who/what may call it |

## Operable sequence (business grain)

1. **Select project** — [[azure-ai-foundry]].
2. **Deploy model** — capacity/quota check.
3. **Secure** — Entra/MSI; network private if required ([[azure-virtual-network]]).
4. **Connect app** — endpoint + auth; no keys in git/vault notes.
5. **Monitor** — quota, errors, content safety Untapped.
6. **Retire** — decommission unused deployments.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Deployment inventory | [[azure-ai-foundry]] | Yes |
| Identity | [[azure-entra-id]] | Yes for access |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Public key leakage | Rotate; prefer Entra |
| Ungoverned prod use | Approval Gap |

## Owner of this note’s truth

AI platform owners (Untapped).
