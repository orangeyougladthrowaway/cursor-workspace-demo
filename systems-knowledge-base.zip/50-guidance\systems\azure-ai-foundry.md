---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-026
concern: systems
description: Azure AI Foundry — AI platform/project grain; model-prompt craft out of scope.
domain: [azure-cloud]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Azure Ai Foundry

## Purpose

Provide **Azure AI Foundry** (Azure AI Studio / Foundry class) as the platform for organizing AI projects, model deployments, and governed AI resource access.

## Owns

- AI hubs/projects (product naming evolves — treat as Foundry project grain)
- Model deployments / connections / content safety bindings as configured
- Identity-gated access to AI resources

## Does not own

- Prompt/chain **craft** and app code (engineering)
- Training corpora PII dumps
- Non-Azure AI vendors

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Auth | [[azure-entra-id]] | Who may invoke deployments |
| Network | [[azure-virtual-network]] | Private network to endpoints Untapped |
| Data | Stores via ADF/apps | Grounding data SoR elsewhere |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Whether a deployment/endpoint exists under the project | Chat anecdotes as model inventory |

## Usage

### Connect / operate

| Surface | Posture |
| --- | --- |
| Foundry portal / APIs | Deploy models; manage connections; govern access |
| Auth | Entra + keys/MSI class — prefer MSI/Entra |
| Common ops | Create project; deploy; rotate keys; monitor quota |

### Pricing / limits (class)

- Token/capacity meters per model — house Untapped; re-check before scale.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Open key on internet | Prefer Entra/MSI + network controls |
| Ungoverned prod prompts | Content safety / approval Untapped |

## Owner of truth

AI platform owners (Untapped).

## Evidence

- **Lived:** AI through Foundry part of significant Azure business infra.
- **Remote:** Azure AI Foundry / Azure OpenAI Learn docs (claim-card; product naming drifts).

## Gaps / Untapped

- Exact hub/project topology
- Which models are production SoR for which apps

## Further detail

- [Azure AI Foundry](https://learn.microsoft.com/en-us/azure/ai-foundry/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[service-principal]]
