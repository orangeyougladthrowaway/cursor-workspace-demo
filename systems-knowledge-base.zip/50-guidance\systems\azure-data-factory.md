---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-025
concern: systems
description: Azure Data Factory — managed ETL/ELT orchestration grain; pipeline craft out.
domain: [azure-cloud]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Azure Data Factory

## Purpose

Provide **Azure Data Factory** as managed data integration/orchestration across stores and computes.

## Owns

- Factories, pipelines, datasets, linked services, triggers as product objects
- Execution run history and monitoring at ADF grain

## Does not own

- Pipeline JSON/expression **craft** (engineering)
- Source/destination business SoR (→ SQL/Postgres/files/SaaS)
- SSIS packages (→ [[ssis]]; Azure-SSIS IR is a bridge class Untapped)

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Moves data for | [[sql-server-engine]] / [[postgres-engine]] / Azure SQL | Linked services |
| Auth | [[azure-entra-id]] | MSI / SP |
| Network | [[azure-virtual-network]] | Managed VNet / private endpoints Untapped |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Pipeline run success/fail in ADF | Informal “the overnight load” without run id |

## Usage

### Connect / operate

| Surface | Posture |
| --- | --- |
| Studio / ARM / SDK | Author/monitor (authoring craft eng) |
| Triggers | Schedule / tumbling / event |
| IR | Azure IR vs self-hosted vs SSIS IR — house Untapped |

### Pricing / limits (class)

- Pipeline activity / IR hours — house Untapped.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Plaintext connection strings | Prefer Key Vault + MSI |
| Unowned failing triggers | Name operators |

## Owner of truth

Data platform operators (Untapped).

## Evidence

- **Lived:** Data Factory part of significant Azure business infra.
- **Remote:** ADF Learn docs.

## Gaps / Untapped

- Which pipelines are SoR integrations (names only if needed; no JSON dumps)
- Relationship to SSIS

## Further detail

- [Azure Data Factory](https://learn.microsoft.com/en-us/azure/data-factory/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[resource-group]]
