---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-018
concern: processes
description: Triage a GitHub issue toward accept, defer, or close.
domain: [github]
derived_from:
  - "[[process-note-honesty]]"
  - "[[github-host]]"
updated: 2026-07-20
---

# Triage Github Issue

## Purpose

Triage a **GitHub issue** so collaboration noise becomes accepted work, deferred, or closed.

## Triggers

- New issue opened
- Stale issue needs decision

## Actors / roles

- Triage owner / maintainers

## Inputs / outputs

| In | Out |
| --- | --- |
| Issue body / labels | Labeled, assigned, or closed |
| Decision | Linked PR/work item or wontfix |

## Operable sequence (business grain)

1. **Read & label** — type/priority class (taxonomy Untapped).
2. **Decide SoR** — fix in GitHub Issues vs [[azure-devops-org]] work item (both hosts practiced — which tracker for which work Untapped).
3. **Accept** — assign; optionally open PR later.
4. **Defer/close** — duplicate, wontfix, or moved with link.
5. **Avoid dual silent SoR** — if ADO also tracks it, link explicitly.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Issue conversation | [[github-host]] | Yes when Issues used for that work class |
| Delivery board item | [[azure-devops-org]] | Yes when Boards used for that work class |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Same work in Issue and WIT unlinked | Dual SoR drift |
| Secrets pasted in issue | Redact; rotate |

## Owner of this note’s truth

Maintainers (Untapped).
