---
type: template
status: draft
id: systems-knowledge-base-tpl-process
description: Minimum fields for a living process note.
updated: 2026-07-16
---

# Process note

Copy into `50-guidance/processes/{slug}.md`. Fill every field. One process question per note.

```markdown
---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-…
concern: processes
description: "…"
domain: []
derived_from:
  - "[[process-note-honesty]]"
updated: YYYY-MM-DD
---

# {Title matching basename}

## Purpose

One sentence.

## Triggers

-

## Actors / roles

- (business grain)

## Inputs / outputs

| In | Out |
| --- | --- |
| | |

## Systems touched + SoR

| Fact / artefact | System | SoR? |
| --- | --- | --- |
| | | |

## Controls / failure modes

-

## Owner of this note’s truth

-

## Related glossary

- (link real glossary stems — do not invent placeholders)
```
