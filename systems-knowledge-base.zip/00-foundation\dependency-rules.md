---
type: foundation
status: draft
id: systems-knowledge-base-fnd-dependency-rules
description: Depend upward, specialise downward; domain facts are not principles.
updated: 2026-07-16
---

# Dependency rules

## Core law

> **Depend upward, specialise downward.**

```text
foundation / philosophy
        ↑
     category
        ↑
    principle
        ↑
    standard
        ↑
     pattern
        ↑
    guidance / workflow
```

## Hard rules

1. Philosophy/category/principle must not depend on a concrete vendor product as authority.
2. Every principle declares exactly one `category`.
3. Every standard `derived_from` at least one principle.
4. Guidance specialises; it does not redefine higher notes. If practice conflicts, update the higher note **or** mark the conflict honestly.
5. Same-tier links are narrow and non-cyclic.
6. **Domain fact is not a principle.** “Bancs is SoR for accounts” is guidance. “Name the SoR explicitly” is a standard/principle.
7. Engineering craft and change-method material are not dependency tiers; keep them out of systems-knowledge-base.

## Placement

Standards, patterns, guidance, and workflows sit in a **concern** folder from the closed enum in [[navigation]]. Concern is placement metadata — not a new dependency tier.

## Agent checklist

- [ ] Correct `type` and altitude
- [ ] Correct `concern` folder + frontmatter
- [ ] Principles have `category`
- [ ] Dependencies only upward / same-tier non-cyclic
- [ ] No product-as-philosophy; no org-unit L1 folders
- [ ] `status` is `draft` | `canonical` | `deprecated` (deprecated = brief migration only)
- [ ] Naming / cleanliness pass if structure changed
