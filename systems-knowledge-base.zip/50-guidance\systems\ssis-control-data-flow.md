---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-043
concern: systems
description: SSIS control flow and data flow — component capability classes (not every transform).
domain: [sql-server]
updated: 2026-07-20
---

# Ssis Control Data Flow

## Purpose

Explain **control flow** vs **data flow** and the **kinds** of components SSIS provides — bounded taxonomy, not BOL for every transform.

## Control flow

Orchestrates tasks and containers (sequence, loops, precedence constraints). Tasks include execute SQL, file system, script, execute package, etc. Failures/precedence govern path.

## Data flow

Pipeline of **sources → transformations → destinations** moving buffers of rows. Parallelism and blocking transforms affect memory.

### Component classes (kinds)

| Class | Examples of capability |
| --- | --- |
| Sources | OLE DB/ADO.NET/Flat file/OData class extracts |
| Transformations | Row (derived, lookup*), partial-blocking, blocking (sort/aggregate) classes |
| Destinations | OLE DB/Flat file/SQL destinations |
| Connection managers | Shared connection definitions |

\*Lookup has cache modes — behaviour class that changes performance/correctness tradeoffs.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Flow model & component classes | Exact mapping patterns for house ETL (eng) |

## Failure / controls

| Mode | Posture |
| --- | --- |
| Unbounded blocking transforms | Memory pressure |
| Hard-coded credentials in packages | Prefer parameters/catalog sensitive |

## Evidence

- **Remote:** Integration Services tasks/data flow Learn docs.

## Further detail

- [Control flow](https://learn.microsoft.com/en-us/sql/integration-services/control-flow/control-flow)
- [Data flow](https://learn.microsoft.com/en-us/sql/integration-services/data-flow/data-flow)
- [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[ssis-catalog-model]] · [[ssis-deployment-build]] · [[ssis-package]]
