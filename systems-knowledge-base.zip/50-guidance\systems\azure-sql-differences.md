---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-045
concern: systems
description: Azure SQL vs box — feature differences that change systems behaviour.
domain: [sql-server]
updated: 2026-07-20
---

# Azure Sql Differences

## Purpose

Call out **where Azure SQL offerings diverge from box SQL Server** so agents do not assume Agent/SSIS/file paths everywhere. Lived: Azure SQL **and** on-prem/VM both practiced.

## Offering classes

| Offering | Rough posture |
| --- | --- |
| Azure SQL Database | Per-DB PaaS; many instance features absent |
| Elastic pool | Shared resources across DBs |
| Managed Instance | Near-box compatibility; VNet integration |
| SQL on Azure VM | Closest to box; you own OS/Agent/files |

## Feature deltas (class — verify per service)

| Capability | Typical Azure SQL DB | MI / VM |
| --- | --- | --- |
| SQL Server Agent | No (use elastic jobs/ADF/other) | Yes (MI/VM) |
| SSIS catalog on instance | No native; Azure-SSIS IR | Possible on MI/VM |
| Cross-DB queries | Limited (elastic query class) | Broader on MI/VM |
| File/path control | Abstracted | Visible on VM |
| Backups | Automated + PITR class | Mix of managed vs user on VM |
| Collation change | Constrained after create | Closer to box |
| CLR / certain features | Restricted matrix | Broader on VM/MI |

Exact matrices change — re-check Learn before design.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Delta awareness | SKU price sheets |

## Failure / controls

| Mode | Posture |
| --- | --- |
| Designing Agent jobs for Azure SQL DB | Wrong host assumption |
| Assuming CLR/xp_cmdshell | Likely unavailable |

## Evidence

- **Lived:** Both Azure SQL and on-prem/VM practiced.
- **Remote:** Azure SQL feature comparison Learn docs.

## Further detail

- [Azure SQL feature comparison](https://learn.microsoft.com/en-us/azure/azure-sql/database/features-comparison)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-engine]] · [[sql-server-agent]] · [[azure-subscription]] · [[ssis]]
