---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-022
concern: systems
description: Azure Virtual Network — network isolation/routing grain for business infra.
domain: [azure-cloud]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Azure Virtual Network

## Purpose

Provide **Azure Virtual Network (VNet)** and related networking constructs for private connectivity of business infra.

## Owns

- VNets, subnets, peerings, route tables, NSG association at ARM grain
- Private connectivity patterns for PaaS (Private Link class) when used

## Does not own

- DO VPC (→ [[platform-vpc]])
- Application AuthZ
- Full firewall product catalogues

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Hosts | [[azure-vm-compute]] | NIC / subnet |
| Secures | [[azure-security-controls]] | NSG / policy posture |
| Identity | [[azure-entra-id]] | Conditional access adjacent |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Address space and allowed paths as configured | Internet routing of third parties |

## Usage

### Connect / operate

| Surface | Posture |
| --- | --- |
| Portal / ARM / azurerm | VNet/subnet/NSG/peering |
| Common ops | Segment subnets; peer hubs; private endpoints |

### Material config

| Knob | Why it matters |
| --- | --- |
| Address ranges | Collision/peering |
| NSG rules | Blast radius |
| DNS | Name resolution for private endpoints |

### Pricing / limits (class)

- Peerings, firewalls, private link meters — house Untapped.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Overly permissive NSG | Prefer deny-by-default |
| Overlapping CIDRs | Breaks peering |

## Owner of truth

Network operators (Untapped).

## Evidence

- **Lived:** Networking part of significant Azure business infra.
- **Remote:** Azure VNet Learn docs.

## Gaps / Untapped

- Hub-spoke vs flat topology as practiced
- Hybrid connectivity (VPN/ExpressRoute) detail

## Further detail

- [Azure Virtual Network](https://learn.microsoft.com/en-us/azure/virtual-network/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[resource-group]]
