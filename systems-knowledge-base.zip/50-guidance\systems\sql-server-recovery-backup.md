---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-037
concern: systems
description: SQL Server recovery models and backup/restore types — durability capability.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Recovery Backup

## Purpose

Define **recovery models** and **backup/restore types** as engine capabilities that bound RPO/RTO options.

## Recovery models

| Model | Log behaviour | Point-in-time | Needs log backups |
| --- | --- | --- | --- |
| **Full** | Fully logs | Yes (with log chain) | Yes |
| **Bulk-logged** | Minimal for some bulk ops | Not during bulk-logged spans | Yes |
| **Simple** | Truncates on checkpoint class | No (to last full/diff) | No |

Model is a **database property** and can change; changing breaks or alters restore stories.

## Backup types

| Type | Captures |
| --- | --- |
| Full | Whole DB (data + enough log for consistency) |
| Differential | Extents changed since last full (DCM-aided) |
| Transaction log | Log since prior log backup (Full/Bulk-logged) |
| Copy-only | Special full/log that doesn’t break chains (rules per type) |
| File/filegroup | Subset restore scenarios |

Tail-log backup class matters at disaster time under Full.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Backup/restore product capability | House schedule, offsite vault paths |

## Azure SQL note

Automated backups / PITR are **platform-managed**; timing/retention are service properties. User-initiated export/bacpac is a different artefact class.

## Failure / controls

| Mode | Posture |
| --- | --- |
| Broken log chain | Accidental Simple switch or missing log backup |
| Untested restores | Assume failure until drill |
| Backup files in git/vault | Forbidden |

## Processes

- [[backup-restore-sql-server]]

## Evidence

- **Remote:** [Recovery models](https://learn.microsoft.com/en-us/sql/relational-databases/backup-restore/recovery-models-sql-server) · backup/restore overview.

## Further detail

- [Backup overview](https://learn.microsoft.com/en-us/sql/relational-databases/backup-restore/backup-overview-sql-server)
- [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-transaction-log]] · [[sql-server-files-filegroups]] · [[sql-server-agent]]
