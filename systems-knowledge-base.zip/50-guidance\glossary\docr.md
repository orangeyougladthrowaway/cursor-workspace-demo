---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-004
concern: glossary
description: DOCR — DigitalOcean Container Registry.
domain: [digital-ocean]
derived_from:
  - "[[glossary-discipline]]"
updated: 2026-07-16
---

# Docr

**DOCR** = DigitalOcean Container Registry. Platform **image identity** store. System note: [[container-registry]].
