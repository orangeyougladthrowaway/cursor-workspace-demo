---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-035
concern: processes
description: Backup and restore SQL Server databases — operable Full/Diff/Log sequence.
domain: [sql-server]
derived_from:
  - "[[process-note-honesty]]"
  - "[[sql-server-recovery-backup]]"
updated: 2026-07-20
---

# Backup Restore Sql Server

## Purpose

Perform **backup and restore** consistent with the database recovery model so durability matches intended RPO.

## Triggers

- Scheduled protection
- Pre-change safety
- Disaster recovery

## Actors / roles

- DBA / backup operators

## Inputs / outputs

| In | Out |
| --- | --- |
| DB + recovery model | Backup artefacts in approved store (not this vault) |
| Restore target | Recovered DB; verified connectivity |

## Operable sequence (business grain)

### Backup

1. **Confirm recovery model** — [[sql-server-recovery-backup]].
2. **Full backup** on cadence.
3. **Differential** optional between fulls.
4. **Log backups** if Full/Bulk-logged — maintain chain.
5. **Verify** backup finish / optional VERIFYONLY class.
6. **Store** off-host; encrypt; never commit to git/vault.

### Restore (Full recovery example)

1. **Tail-log backup** if possible at disaster time.
2. **Restore full** WITH NORECOVERY.
3. **Restore latest diff** WITH NORECOVERY (if used).
4. **Restore log chain** in order; STOPAT if point-in-time.
5. **RECOVERY** when done; check consistency ([[sql-server-maintenance-checks]]).
6. **Remap/orphaned users** as needed ([[sql-server-principals-securables]]).

### Azure SQL PaaS

Use platform PITR/LTR portals/APIs — sequence differs; don’t assume `.bak` files.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Backup/restore capability | [[sql-server-recovery-backup]] | Yes |
| Live data | [[sql-server-engine]] | Yes |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Broken log chain | Treat PITR as lost until new full baseline |
| Untested restore | Schedule drills |

## Owner of this note’s truth

DBAs (Untapped).
