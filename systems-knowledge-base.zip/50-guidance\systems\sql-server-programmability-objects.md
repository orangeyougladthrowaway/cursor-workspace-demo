---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-041
concern: systems
description: SQL Server views, procs, functions, triggers — programmability object kinds.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Programmability Objects

## Purpose

Define **programmability objects** as durable engine modules — capability and restriction classes, not T-SQL style guides.

## Views

Stored SELECT definitions. **Indexed views** materialize under schema-binding/restriction classes. Views do not by themselves store base rows (except indexed).

## Stored procedures

Named parameterized batches. Can modify data, return result sets/codes. Plan caching applies. Unlike views, procs are the usual unit for multi-statement side effects.

## Functions

| Kind | Behaviour class |
| --- | --- |
| Scalar | Returns one value; historical performance pitfalls |
| Inline TVF | Expands like a parametrized view |
| Multi-statement TVF | Returns table variable; different optimizer treatment |

Some constructs forbidden in functions (side-effect limits class).

## Triggers

DML (AFTER/INSTEAD OF), DDL, LOGON classes. Fire in transaction of the causing statement — easy to surprise locking/logging. Nested/recursive trigger config exists.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Object kinds & engine limits | How to write set-based merge / SCD2 (engineering-knowledge-base T-SQL / warehouse craft — out of this vault) |

## Failure / controls

| Mode | Posture |
| --- | --- |
| Hidden logic only in triggers | Discoverability Gap |
| Scalar UDF in hot queries | Performance phenomenon |

## Evidence

- **Remote:** Views / procedures / functions / triggers Learn docs.

## Further detail

- [Programmability](https://learn.microsoft.com/en-us/sql/relational-databases/stored-procedures/stored-procedures-database-engine)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-object-model]] · [[sql-server-tables-constraints]] · [[t-sql]]
