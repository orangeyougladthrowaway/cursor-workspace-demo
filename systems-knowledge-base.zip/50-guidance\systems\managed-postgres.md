---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-006
concern: systems
description: Managed PostgreSQL on DigitalOcean — SoR plus usage (connectivity, trusted sources Gap, pricing class).
domain: [digital-ocean]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Managed Postgres

## Purpose

Provide **managed PostgreSQL** as the relational data plane for platform workloads.

## Owns

- Database cluster existence, engine/version class, and private connectivity in the VPC
- Logical databases created for platform use (names are environment config — not doctrine here)

## Does not own

- Application domain meaning of rows (business SoR may sit *in* the DB but the *product* is infrastructure)
- Object blobs (→ [[spaces-object-storage]])
- In-cluster or on-host self-managed Postgres (not the practiced pattern in current inventories)
- Which microservice processes receive connection secrets (engineering ownership — data-access capability only)

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Upstream | [[platform-vpc]] | Private network attachment |
| Downstream | Data-access services on [[doks-kubernetes]] or [[droplet-compute]] | Private host connection |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Managed cluster as the Postgres home for platform apps | Domain entity definitions |
| Private-VPC access pattern as practiced | DO database-firewall / trusted-sources (Gap — not coded in inventories) |

## Usage

### Connect / operate

| Surface | House posture |
| --- | --- |
| Connectivity | Private host inside [[platform-vpc]]; apps on DOKS or Droplet in the **same VPC** reach via private network once networking is correct |
| Access | Connection URI / host+port+db+user from DO control plane or secrets store — **never** paste credentials into this vault |
| Secret consumer | Runtime connection secrets belong to the **data-access** app capability (DWH / db bridge) — not to every microservice on the host |
| Management API | DigitalOcean API / `doctl` / Terraform for cluster lifecycle; engine upgrades via DO managed path |
| Common ops | Create cluster; create logical DBs/users; resize; configure backups/standbys when practiced; rotate app credentials in the secret store (not in notes) |

### Material config

| Knob | Why it matters |
| --- | --- |
| Size / node class | Throughput, storage, price class |
| Engine version | App compatibility |
| VPC attachment | Required for private-only house pattern |
| Standby / HA options | Availability vs cost — house default Untapped |
| Trusted sources / DB firewall | Product supports restricting sources — **house coding Gap** (do not assume open or closed) |
| Connection limits | Pool sizing at app edge (eng) must respect DO plan limits |

### Pricing / limits (class)

- Managed databases are billed by **plan/size class** (compute + storage + standby options), separate from Droplet/DOKS worker bills.
- Expect storage and standby add-ons to dominate surprises — re-check [Managed Databases](https://docs.digitalocean.com/products/databases/) pricing pages before resizing.
- Connection count and storage caps are plan-scoped — treat “unlimited app pools” as a foot-gun.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Public exposure | House pattern is VPC-private; public DB endpoints need explicit exception + control |
| Trusted-sources Gap | Do not invent firewall rules; confirm in inventory or leave Gap |
| Credential leak into vault | Forbidden ([[confidentiality-redaction]]) |
| Secrets on every host process | Wrong — connection secrets are for the data-access capability only (eng enforces scoping) |
| Engine major upgrade | Coordinate with app owners — ownership Untapped |

## Owner of truth

Platform operators (ownership Untapped).

## Evidence

- **Lived:** Both runtime shapes use a VPC-attached managed Postgres cluster. Services reach it over the private host when VPC placement and app secrets are correct.
- **Remote:** [Managed Databases](https://docs.digitalocean.com/products/databases/).

## Gaps / Untapped

- Trusted-sources / DB firewall as coded
- House default plan sizes
- Backup retention policy
- Named operators / who may resize
- Logical DB naming (environment config, not doctrine)
- Self-hosted / non-DO Postgres family → [[postgres-atlas]] (do not conflate)

## Further detail

- [Managed Databases](https://docs.digitalocean.com/products/databases/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[managed-database]] · [[vpc]]
