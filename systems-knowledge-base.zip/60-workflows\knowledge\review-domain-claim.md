---
type: workflow
status: draft
id: systems-knowledge-base-wf-010
concern: knowledge
description: Review domain claims for invention, stale atlas, premature P1 depth, lane walls.
derived_from:
  - "[[agent-projection]]"
  - "[[system-sor-honesty]]"
  - "[[scope]]"
  - "[[verify-domain-note]]"
updated: 2026-07-17
---

# Review domain claim

Use for independent review of agent or human domain answers and note changes.

## Preconditions

- Claim or note set under review
- Verification result, or explicit statement it is absent

## Retrieve

1. [[agent-projection]] · [[system-sor-honesty]] · [[scope]] · [[platform-watchlist]].
2. Family atlas + [[common-case-coverage]].
3. The notes cited by the claim.

## Steps

1. Findings first — invented SoR, missing Gaps, stale `updated`, atlas lies.
2. Check lane walls — no engineering/change-method bodies.
3. Check P0-before-P1 honesty.
4. Check cite honesty for load-bearing claims.
5. Verdict: approve, request changes, or blocked.

## Output

- Ordered findings
- Open Gaps
- Verdict

## Handoff

Corrections → [[amend-domain-truth]] (in systems-knowledge-base workspace) or escalate to user.

## Forbidden

- Approving invented facts
- Treating vendor paste as house SoR
- Green coverage theatre
