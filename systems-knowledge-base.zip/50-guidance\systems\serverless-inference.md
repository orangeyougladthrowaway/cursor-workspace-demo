---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-008
concern: systems
description: DO Serverless Inference — consumed HTTP API; SoR plus usage (auth, pricing class, Gaps).
domain: [digital-ocean]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Serverless Inference

## Purpose

Provide **hosted model inference over HTTP** as a consumed DigitalOcean service (Serverless Inference), without provisioning GPU compute in Terraform.

## Owns

- The external inference endpoint as a platform capability (URL/model selection are environment config — not doctrine here)
- Separation from self-hosted GPU runtimes

## Does not own

- GPU Droplets or DOKS GPU pools (→ [[self-hosted-inference-compute]])
- Application prompts / domain logic
- API keys (never stored in this vault)

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Downstream | Inference-facing services on [[droplet-compute]] (host shape) | HTTPS calls to the inference API |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Inference is a consumed DO API for host-shaped environments that use it | Self-hosted llama-style runtimes on GPU compute |
| Endpoint as an external dependency | Exact model IDs / URLs (env-driven Gap) |

## Usage

### Connect / operate

| Surface | House posture |
| --- | --- |
| API class | HTTPS inference API (product endpoint) — no TF compute resource |
| Auth class | API keys / DO auth for the inference product — never store keys here |
| Common ops | Select model/endpoint in env config; call from inference bridge service; rotate keys in secret store |
| Shape | Practiced on **host** shape; not primary path on cluster inventories |

### Material config

| Knob | Why it matters |
| --- | --- |
| Model / endpoint id | Env-specific — not doctrine |
| Timeouts / retries | App reliability (eng) must respect product limits |
| Region / latency | Prefer same-region callers when product allows |

### Pricing / limits (class)

- Billed as **consumed inference** (tokens/requests/model class) — not Droplet/GPU hourly.
- Spiky traffic can surprise cost — set budgets/alerts in account ops (Untapped).
- Re-check DO Serverless Inference / Gradient-class pricing pages before committing volume.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Keys in vault/git | Forbidden ([[confidentiality-redaction]]) |
| Treating as self-hosted GPU | Wrong system — see [[self-hosted-inference-compute]] |
| No TF resource found | Expected — consume-only |

## Owner of truth

Platform operators (ownership Untapped).

## Evidence

- **Lived:** Host-shaped inventories consume DO Serverless Inference from an inference bridge service. No TF resource creates the endpoint.
- **Not practiced in cluster-shaped inventories** as the primary inference path.

## Gaps / Untapped

- Exact model catalogue as house defaults
- Budget/alert posture
- Account endpoint binding (never doctrine)

## Further detail

- [GradientAI Platform](https://docs.digitalocean.com/products/gradientai-platform/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[droplet]]
