---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-015
concern: processes
description: Publish an immutable Git tag for a release point.
domain: [git]
derived_from:
  - "[[process-note-honesty]]"
  - "[[git-vcs]]"
updated: 2026-07-20
---

# Publish Git Tag

## Purpose

Mark a **release point** with a Git tag and push it to shared remotes.

## Triggers

- Release/cut decision
- Hotfix baseline needs identity

## Actors / roles

- Release owner (Untapped)

## Inputs / outputs

| In | Out |
| --- | --- |
| Commit SHA on base | Annotated/lightweight tag |
| Version name class | Tag on GitHub and/or Azure Repos |

## Operable sequence (business grain)

1. **Identify commit** — usually base branch tip after integrate.
2. **Create tag** — annotated preferred for releases.
3. **Push tag** — to practiced remotes (both hosts when mirroring — sync Untapped).
4. **Announce** — release notes out of this note’s scope.
5. **Protect** — prevent tag overwrite on host when available.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Tag → commit | [[git-vcs]] | Yes |
| Host release UI | Host product | Optional mirror of tag |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Moving tags | Forbidden for released versions |
| Tag only on one of two hosts | Drift — sync policy Untapped |

## Owner of this note’s truth

Release owners (Untapped).
