---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-020
concern: processes
description: Transition an Azure DevOps work item across board states to Done.
domain: [azure-devops]
derived_from:
  - "[[process-note-honesty]]"
  - "[[azure-devops-org]]"
updated: 2026-07-20
---

# Transition Azure Devops Work Item

## Purpose

Move a work item through **board states** until Done/Closed so status matches evidence.

## Triggers

- Work started / blocked / completed
- Sprint ceremonies update state

## Actors / roles

- Assignees
- Board admins (WIP rules Untapped)

## Inputs / outputs

| In | Out |
| --- | --- |
| Current WIT | New state / reason |
| Evidence class | Done when acceptance met (AC live in eng/methods — not invented here) |

## Operable sequence (business grain)

1. **Select item** — board or query.
2. **Transition** — drag/state field; satisfy required fields.
3. **Update remaining work** — if template uses it.
4. **Link PR** — when code lands on [[github-host]] or Azure Repos.
5. **Close/Done** — when complete; don’t mark Done without evidence.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Delivery status | [[azure-devops-org]] | Yes for board-tracked work |
| Ticket ops work | [[servicedesk-plus]] | Separate; bridge Gap |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Done without merge/release | Status dishonesty — challenge |
| Skipped states when rules enforce | Fix fields or policy |

## Owner of this note’s truth

Project admins (Untapped).
