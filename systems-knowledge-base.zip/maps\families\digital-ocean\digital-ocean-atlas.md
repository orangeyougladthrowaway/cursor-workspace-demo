---
type: map
status: draft
id: systems-knowledge-base-map-do
concern: digital-ocean
description: DigitalOcean family atlas — two runtime shapes; system surfaces only; P1 Gaps named.
domain: [digital-ocean]
updated: 2026-07-20
---

# Digital Ocean Atlas

Primary browse for **DigitalOcean** as the core cloud / platform home. This atlas indexes **system surfaces** — not processes, not account-specific object names, not product use-cases.

## Runtime shapes (both practiced)

| Shape | Compute home | Typical stack grain |
| --- | --- | --- |
| **Cluster** | [[doks-kubernetes]] | Workloads on managed Kubernetes |
| **Host** | [[droplet-compute]] | Workloads on a VM (Compose-style runtime) |

A given environment uses one primary shape. Some environments also attach **GPU Droplet** capacity beside a cluster for self-hosted inference compute (see [[self-hosted-inference-compute]]).

## Systems

| Note | Role |
| --- | --- |
| [[platform-vpc]] | Private network scope for platform resources |
| [[cloud-firewall]] | Network allow/deny at the DO cloud-firewall grain |
| [[doks-kubernetes]] | Managed Kubernetes (cluster runtime shape) |
| [[droplet-compute]] | Linux VMs (host runtime shape; optional GPU host) |
| [[managed-postgres]] | Managed PostgreSQL in the VPC |
| [[spaces-object-storage]] | S3-compatible object store |
| [[container-registry]] | Container image registry (DOCR) |
| [[serverless-inference]] | Consumed DO inference HTTP API (no TF resource) |
| [[self-hosted-inference-compute]] | Inference runtimes on GPU pools or GPU Droplet |
| [[platform-edge]] | Optional public DNS / host reverse-proxy edge |

## Processes

Bootstrap process notes exist for vault completeness; **systems densify first**. Process depth is not the current elevation focus.

| Note | Question |
| --- | --- |
| [[provision-platform-host]] | How platform capacity is brought into existence |
| [[release-workload-to-platform]] | How a workload becomes running on DO-backed runtime |
| [[store-retrieve-platform-objects]] | How apps store/retrieve objects via Spaces |

## Glossary

[[doks]] · [[droplet]] · [[spaces]] · [[docr]] · [[vpc]] · [[managed-database]]

## Interfaces / Gaps (watchlist — not deep-covered)

Wave board and leaf names: [[platform-watchlist]]. Counterparts remain Gaps until family densify.

| Counterpart | Leaf | Wave | Status |
| --- | --- | --- | --- |
| Zoho (CRM / Flow) | `zoho` | 1 | Gap interfaces — family atlas **seeded** ([[zoho-atlas]]) |
| ManageEngine ServiceDesk Plus | `manageengine-servicedesk` | 1 | Gap interfaces — family atlas **seeded** ([[manageengine-servicedesk-atlas]]) |
| Git | `git` | 2 | Gap interfaces — family atlas **seeded** ([[git-atlas]]) |
| GitHub | `github` | 2 | Gap interfaces — family atlas **seeded** ([[github-atlas]]) |
| Azure DevOps | `azure-devops` | 2 | Gap interfaces — family atlas **seeded** ([[azure-devops-atlas]]) |
| Azure cloud (provider grain) | `azure-cloud` | 3 | Gap interfaces — family atlas **seeded** ([[azure-cloud-atlas]]); house Azure runtime Untapped |
| Aryza Sentinel (lending) | `aryza-sentinel` | 4 | Gap — P1 (product identity / SKU unconfirmed) |
| TCS BaNCS | `tcs-bancs` | 4 | Gap — P1 |
| Tuum (overdraft) | `tuum` | 4 | Gap — P1 |
| Virtual Cabinet DMS | `virtual-cabinet` | 5 | Gap — **deferred** |
| SQL Server suite | `sql-server` | 5 | Family atlas **useful** ([[sql-server-atlas]]) |
| PostgreSQL / pgAdmin | `postgres` | 5 | Family atlas **useful** ([[postgres-atlas]]); ≠ [[managed-postgres]] |

## Evidence posture

- **Lived:** User-relayed systems inventories from DO-touching platform repos (paths/secrets not ingested into this vault).
- **Remote:** Official DigitalOcean product docs (claim-card only).
- House practice wins on local facts; live account binding (which VPC/bucket/registry is active) stays **Gap** unless evidenced without object-name doctrine.

## Further detail

Out-of-vault wire/field matrices and deep vendor manuals stay linked, not pasted ([[link-further-detail]] · [[further-detail-hubs]]):

- [DigitalOcean docs](https://docs.digitalocean.com/)
- [DigitalOcean API](https://docs.digitalocean.com/reference/api/)

## Usability wave

DO P0 core cells at `useful` on Atlas/Systems/Usage/Processes/Glossary/Controls/Freshness ([[common-case-coverage]]). Interfaces still partial (P1 Gaps). All practiced surfaces carry Usage sections.

## Untapped

- Ownership (who may change platform resources)
- Create vs pre-existing registry/Spaces/VPC per environment
- Cluster public ingress / DO LB adoption
- P1 platform deep dives (DO useful met; proceed by [[platform-watchlist]] waves; Interfaces partial OK)

## Related

- [[scope]] · [[platform-watchlist]] · [[common-case-coverage]] · [[catalog-maps]]
