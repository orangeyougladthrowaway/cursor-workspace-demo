---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-030
concern: processes
description: Backup and restore a PostgreSQL database — operable sequence.
domain: [postgres]
derived_from:
  - "[[process-note-honesty]]"
  - "[[postgres-engine]]"
updated: 2026-07-20
---

# Backup Restore Postgres

## Purpose

Take a **backup** of PostgreSQL data and restore it when needed, preserving recoverability.

## Triggers

- Scheduled protection
- Pre-change safety copy
- Recovery incident

## Actors / roles

- DBA / platform backup owner

## Inputs / outputs

| In | Out |
| --- | --- |
| Target DB/cluster; retention class | Backup artefact in approved store (not this vault) |
| Restore request | Recovered DB; validated connectivity |

## Operable sequence (business grain)

1. **Choose method** — logical (`pg_dump`) vs physical (`pg_basebackup`/PITR) per RPO.
2. **Backup** — run against target; verify exit code and artefact size.
3. **Store** — encrypted backup location; access controlled.
4. **Test restore** — periodic drill on non-prod (cadence Untapped).
5. **Recover** — restore to target; re-apply roles/secrets from secret store; validate app.
6. **Never** — commit backup dumps into git or this vault.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Live data | [[postgres-engine]] | Yes |
| Backup artefact | Backup system (Untapped product) | Recovery SoR |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Untested backups | Assume failure until restore drill |
| PII in vault | Forbidden |

## Owner of this note’s truth

DBAs (Untapped).
