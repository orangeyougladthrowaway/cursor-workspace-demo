---
type: foundation
status: draft
id: systems-knowledge-base-fnd-layout
description: Top-level systems-knowledge-base layout — altitude, maps, temp, tests; lab deferred.
updated: 2026-07-16
---

# Layout

**Primary axis:** altitude of knowledge.  
**Secondary axis:** one responsibility per folder. See [[navigation]].  
**Primary browse:** family atlases under `maps/families/`.  
**Lab:** deferred until process/system standards are useful and DigitalOcean is honest.

```text
systems-knowledge-base/
├── README.md
├── maps/
│   ├── catalog-maps.md
│   ├── families/          # PRIMARY — domain / system-cluster atlases
│   └── themes/            # cross-cutting indexes only
├── 00-foundation/
│   └── templates/         # note-writing templates + consumer-init
├── 10-philosophy/
├── 20-principles/{concept}/
├── 30-standards/{responsibility}/
├── 40-patterns/{responsibility}/   # deferred — create when a portable pattern exists
├── 50-guidance/{responsibility}/   # bulk product
├── 60-workflows/{responsibility}/  # vault maintenance + ingestion
├── temp/                  # harvest staging — not doctrine
├── tests/                 # vault-health
└── .cursor/rules/
```

## Folder contracts

| Folder | Belongs |
| --- | --- |
| `maps/families/{family}/` | Domain / platform atlases — indexes, not task playbooks |
| `maps/themes/{theme}/` | Cross-cutting indexes only |
| `00-foundation/` | Meta, navigation, note templates, glossary |
| `10-philosophy/` | Rare worldview (honesty of documentation) |
| `20-principles/{concept}/` | Thin portable constraints |
| `30-standards/{responsibility}/` | Note-quality norms |
| `40-patterns/{responsibility}/` | Sparse cross-domain shapes — **absent until first pattern**; do not keep an empty catalog |
| `50-guidance/{responsibility}/` | Living system/process/glossary detail |
| `60-workflows/{responsibility}/` | How to maintain this bible |
| `temp/` | Harvest — not user-facing doctrine |

**Banned:** `_index.md`; `and`-joined names; org-chart / product-lore at altitude L1; atlases as job playbooks; long-lived `deprecated` redirects.
