---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-028
concern: processes
description: Connect and administer a PostgreSQL cluster — operable sequence.
domain: [postgres]
derived_from:
  - "[[process-note-honesty]]"
  - "[[postgres-engine]]"
updated: 2026-07-20
---

# Connect Administer Postgres

## Purpose

Authenticate to [[postgres-engine]] and perform routine administration (`psql` or [[pgadmin]]).

## Triggers

- Access / DDL / role / extension change
- Incident on a Postgres cluster

## Actors / roles

- DBA / delegated owner

## Inputs / outputs

| In | Out |
| --- | --- |
| Host, DB, role credentials (not in vault) | Applied SQL; verified state |
| Change intent | Script or UI evidence |

## Operable sequence (business grain)

1. **Identify cluster** — confirm not confusing with DO [[managed-postgres]] unless that is the target.
2. **Authenticate** — role via allowed `pg_hba` method.
3. **Connect** — `psql` or [[pgadmin]].
4. **Change** — reviewed SQL; prefer migrations for app schemas (eng).
5. **Verify** — `\d` / catalog queries; privileges check.
6. **Disconnect** — no lingering superuser sessions.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Cluster state | [[postgres-engine]] | Yes |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Superuser for app runtime | Prefer least privilege app roles |
| Open `0.0.0.0/0` trust | Forbidden posture |

## Owner of this note’s truth

DBAs (Untapped).
