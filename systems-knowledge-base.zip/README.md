---
type: index
status: draft
id: systems-knowledge-base-root
description: Entry point — Systems Knowledge Base (domain systems + process truth).
updated: 2026-07-16
---

# Systems Knowledge Base (systems-knowledge-base)

The current-state bible of domain systems and business-process truth — what exists, what each system owns, how processes run, and which system is source of record. Not engineering craft, not PM/BA/TA method, not a vendor-manual dump.

> **New here? Start from the [agent-harness](../agent-harness/README.md) hub.** It is the single entry point for the workspace: it classifies your task, retrieves the right knowledge, and runs one workflow at a time. Use it before editing this vault directly.

## Scope

systems-knowledge-base owns domain systems and process facts. Engineering craft and change-method material are out of scope.

## Start here

| Note | Role |
| --- | --- |
| [[navigation]] | Navigation constitution |
| [[methodology]] | Note shape, naming, linking |
| [[changing-this-bible]] | Amend / retire / cleanliness |
| [[scope]] | In/out + platform watchlist (DigitalOcean first) |
| [[platform-watchlist]] | Research order companion |
| [[catalog-maps]] | Family / theme atlases |
| [[common-case-coverage]] | Family × completeness cells |
| [[knowledge-ingestion]] | Lived + remote admit pipeline |
| [[purpose]] | Why this exists |
| [[layout]] | Folders |

## Agents

Follow `.cursor/rules/systems-knowledge-base-authority.mdc` and root `AGENTS.md`. Prefer family atlas → linked system/process notes. Invoke `systems-knowledge-base-lookup` / `systems-knowledge-base-plan` / `systems-knowledge-base-amend` / `systems-knowledge-base-verify` / `systems-knowledge-base-review` as thin pointers. Engineering and change-method questions are out of scope. Do not invent SoR or process facts.

Retrieval: [[navigation]] · [[knowledge-ingestion]] · [[common-case-coverage]] · [[agent-projection]] · [[lookup-domain-truth]] · living [[scope]] · [[platform-watchlist]]. P0 atlas: [[digital-ocean-atlas]]. Consumer pack: `00-foundation/templates/consumer-init/`. Vault health: [[vault-health-checks]] (`pytest tests/ -v`).
