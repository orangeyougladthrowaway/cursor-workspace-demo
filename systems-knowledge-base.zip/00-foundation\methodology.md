---
type: foundation
status: draft
id: systems-knowledge-base-fnd-methodology
description: Note structure, frontmatter, linking, naming-as-navigation for systems-knowledge-base.
updated: 2026-07-16
---

# Methodology

Portable Markdown. Meaning must survive as plain files in Git. Navigation law: [[navigation]]. Change protocol: [[changing-this-bible]].

## Note shape

```markdown
---
type: …
status: draft | canonical | deprecated
id: systems-knowledge-base-…
concern: …                 # matches folder (maps: family leaf)
description: "≤160 chars"
domain: []
aliases: []
derived_from: []
updated: YYYY-MM-DD
---

# Title matching the basename
```

One question per note. Split if it answers two.

## Frontmatter

| Field | Use |
| --- | --- |
| `type` | Required — see [[knowledge-model]] |
| `status` | `draft` \| `canonical` \| `deprecated` (migration only) |
| `description` | Scan-without-open summary |
| `updated` | ISO date |
| `id` | Required on doctrine notes — stable key; prefix `systems-knowledge-base-` |
| `concern` | Required on standard/pattern/guidance/workflow/**map** — matches folder |
| `category` | Required on principles |
| `derived_from` | Upward links |
| `domain` | Business / platform tags (`digital-ocean`, `zoho`, …) — never a folder |
| `aliases` | Informal **search** tokens only — never a rename substitute |

### `aliases` forbid list

Do **not** put in `aliases:`: old basename after rename; spelling twin of the stem; acronym that hides a mismatched stem.

## Writing order

1. Philosophy still holds?
2. Right responsibility folder / category spine? ([[navigation]])
3. Then leaf / standard / guidance.
4. New family knowledge? Add/update atlas under `maps/families/` and [[catalog-maps]].
5. Agents: open atlas before bulk-reading leaves.

## Linking

- Wikilinks use **basename only**.
- Wikilink targets must be vault notes — do not wikilink `.mdc` / skills / paths; cite those in backticks.
- Prefer `id` in prose when rename-resilience matters.
- Prefer **rename** over aliasing retired titles.
- Do not invent placeholder wikilinks.
- After edits: every new wikilink must resolve ([[changing-this-bible]]).

## Naming

| Piece | Rule |
| --- | --- |
| Path | `NN-altitude/{responsibility}/{slug}.md` |
| Responsibility folders | One idea — no `and` |
| Basename | Globally unique kebab |
| Stem ↔ H1 | H1 is the prose form of the basename |
| Guidance stems | Concept only — no family/episode suffixes; family via atlas + `domain` |
| Catalogs | `catalog-*.md` only — never `_index.md` |
| Maps | `maps/families/{family}/*-atlas.md`; atlas `concern` = leaf folder |

## Domain fact rule

A **domain fact is not a principle**. Portable honesty/ownership constraints are principles; “DigitalOcean owns X here” is guidance.
