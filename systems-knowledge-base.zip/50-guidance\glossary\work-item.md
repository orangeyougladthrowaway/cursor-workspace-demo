---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-016
concern: glossary
description: Work item — Azure DevOps delivery tracking record.
domain: [azure-devops]
updated: 2026-07-20
---

# Work Item

**Work item** = delivery tracking record in [[azure-devops-org]] (type/state per process template).
