---
type: workflow
status: draft
id: systems-knowledge-base-wf-002
concern: knowledge
description: Family × completeness — Waves 1–3 densified to useful; Waves 4–5 empty.
derived_from:
  - "[[navigation]]"
  - "[[scope]]"
  - "[[platform-watchlist]]"
  - "[[knowledge-ingestion]]"
  - "[[system-sor-honesty]]"
updated: 2026-07-20
---

# Common Case Coverage

systems-knowledge-base Axis F analogue: track **domain families × completeness cells**.

## Cells (score honestly)

| Cell | Meaning |
| --- | --- |
| Atlas | Family atlas exists and indexes honestly |
| Systems | Core systems noted with SoR boundaries ([[system-sor-honesty]]) |
| Usage | Core systems carry usable platform-use depth |
| Processes | Core processes meet process-note standard at operable grain |
| Interfaces | Critical handoffs documented |
| Controls | Material controls named |
| Glossary | Load-bearing terms defined |
| Freshness | `updated` / stale flags honest |

Scores: `empty` · `seeded` · `partial` · `useful`.

## What `useful` means

An agent can answer without inventing: Role · Use (API/auth/config/ops) · Cost/limits class · Failure/controls · Gaps.

## Scoreboard

### `digital-ocean` (P0)

| Cell | Score | Notes |
| --- | --- | --- |
| Atlas | useful | Two shapes; full system index; P1 Gaps named honestly |
| Systems | useful | All practiced DO surfaces have SoR cards |
| Usage | useful | Usage on practiced DO surfaces |
| Processes | useful | Provision, release, store-retrieve |
| Interfaces | partial | P1 counterparts still Gaps / partial |
| Controls | useful | Named with Gaps |
| Glossary | useful | Load-bearing DO set |
| Freshness | useful | Densified 2026-07-18 |

### Densified P1 (2026-07-20) — useful bar met (Interfaces partial OK)

| Family leaf | Atlas | Systems | Usage | Processes | Interfaces | Controls | Glossary | Freshness | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `zoho` | useful | useful | useful | useful | partial | useful | useful | useful | CRM lived; Flow product-useful not practiced |
| `manageengine-servicedesk` | useful | useful | useful | useful | partial | useful | useful | useful | Cloud lived |
| `git` | useful | useful | useful | useful | partial | useful | useful | useful | Dual remotes practiced |
| `github` | useful | useful | useful | useful | partial | useful | useful | useful | Peer host with ADO |
| `azure-devops` | useful | useful | useful | useful | partial | useful | useful | useful | WIT + Repos; no CI craft |
| `azure-cloud` | useful | useful | useful | useful | partial | useful | useful | useful | Expanded: VM, VNet, Entra, security, ADF, Foundry + azurerm |
| `sql-server` | useful | useful | useful | useful | partial | useful | useful | useful | **Engine-deep** capability notes (A–G) + suite surfaces |
| `postgres` | useful | useful | useful | useful | partial | useful | useful | useful | Engine · pgAdmin; ≠ DO managed-postgres |

### Deferred (empty)

| Family leaf | Wave | Status |
| --- | --- | --- |
| `aryza-sentinel` | 4 | empty — skipped for now |
| `tcs-bancs` | 4 | empty — skipped for now |
| `tuum` | 4 | empty — skipped for now |
| `virtual-cabinet` | 5 | empty — skipped for now |
