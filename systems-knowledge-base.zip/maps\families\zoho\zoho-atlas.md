---
type: map
status: draft
id: systems-knowledge-base-map-zoho
concern: zoho
description: Zoho family atlas — CRM lived SoR; Flow product-useful; processes and glossary densified.
domain: [zoho]
updated: 2026-07-20
---

# Zoho Atlas

Browse for **Zoho** products in house use or planned use. Indexes **system surfaces** and operable processes — not marketing catalogues.

## Systems

| Note | Role |
| --- | --- |
| [[zoho-crm]] | Relationship SoR — Leads, Contacts, Accounts, Deals |
| [[zoho-flow]] | iPaaS automation (product-useful; **not practiced** yet) |

## Processes

| Note | Question |
| --- | --- |
| [[capture-crm-lead]] | How a Lead enters CRM SoR |
| [[convert-crm-lead]] | How a Lead becomes Contact/Account/Deal |
| [[advance-crm-deal]] | How a Deal moves to close |
| [[connect-app-to-zoho-flow]] | How an app Connection is established |
| [[build-zoho-flow-automation]] | How a Flow is built and activated |
| [[receive-zoho-flow-webhook]] | How inbound webhooks run actions |

## Glossary

[[lead]] · [[contact]] · [[account]] · [[deal]] · [[flow-connection]]

## Interfaces / Gaps

| Counterpart | Status |
| --- | --- |
| [[servicedesk-plus]] | Gap — ticket ↔ CRM bridge aspirational |
| Banking cores | Gap |
| [[digital-ocean-atlas]] | No practiced platform handoff |

## Evidence posture

- **Lived:** CRM SoR modules named; Flow **planned** (not live) for CRM↔ServiceDesk; bridges not live.
- **Remote:** CRM API v7/OAuth; Flow product/trigger docs.

## Further detail

Out-of-vault wire/field matrices and deep vendor manuals stay linked, not pasted ([[link-further-detail]] · [[further-detail-hubs]]):

- [Zoho CRM API v7](https://www.zoho.com/crm/developer/docs/api/v7/)
- [Zoho CRM OAuth](https://www.zoho.com/crm/developer/docs/api/v7/oauth-overview.html)
- [Zoho Flow](https://www.zoho.com/flow/)

## Usability wave

Wave 1 densified to **useful** on Atlas/Systems/Usage/Processes/Controls/Glossary/Freshness ([[common-case-coverage]]). Interfaces remain partial (desk/banking Gaps). Flow processes are product-operable with honest non-adoption.

## Related

- [[scope]] · [[platform-watchlist]] · [[common-case-coverage]] · [[catalog-maps]]
