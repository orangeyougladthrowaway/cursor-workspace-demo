---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-028
concern: systems
description: SQL Server principals and securables — logins, users, roles, ownership.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Principals Securables

## Purpose

Explain **who** can touch **what** in the engine — identity model, not password runbooks.

## Principals

| Principal | Scope | Behaviour |
| --- | --- | --- |
| Login | Server/instance | Authenticates to the instance (Windows/SQL/Entra classes by host) |
| User | Database | Maps to a login (or contained); principal inside one DB |
| Fixed server roles | Server | Built-in capability bundles (e.g. sysadmin class) |
| Fixed DB roles | Database | Built-in DB capability bundles |
| User-defined roles | Server/DB | Group permissions |
| Application role | Database | Activated by app for elevated DB context |

## Securables

Schemas, objects, and lower grains (column/permission classes) that receive GRANT/DENY/REVOKE. Ownership of a schema/object affects default permissions and chaining behaviour.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Engine security model behaviour | Entra tenant policy (→ [[azure-entra-id]]) |
| Mapping login↔user as product fact | House RACI for who gets sysadmin |

## Azure SQL note

Authentication classes shift toward **Entra** / contained users; classic SQL logins support varies by offering. Always On AG login sync is MI/box concern.

## Failure / controls

| Mode | Posture |
| --- | --- |
| Everyday `sa` / sysadmin | Prefer least privilege |
| Orphaned users | After restore/migrate — expected phenomenon |
| Secrets in connection strings | Store outside vault |

## Evidence

- **Remote:** Principals / permissions Learn docs.
- **Lived:** Untapped inventory of roles.

## Further detail

- [Principals](https://learn.microsoft.com/en-us/sql/relational-databases/security/authentication-access/principals-database-engine)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-object-model]] · [[sql-server-engine]]
