---
type: category
status: draft
id: systems-knowledge-base-cat-change
category: change
description: Category spine — how domain truth is updated.
updated: 2026-07-16
---

# Change

Principles about keeping the bible current when the business changes.
