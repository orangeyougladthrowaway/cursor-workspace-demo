---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-011
concern: systems
description: GitHub host densified to useful — practiced remotes/PRs/issues; dual-host with ADO.
domain: [github]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Github Host

## Purpose

Provide **hosted Git collaboration** — remotes, pull requests, issues, org/identity — as the GitHub product grain (**practiced** alongside Azure DevOps).

## Owns

- Git repositories hosted on GitHub (objects via Git + GitHub Git database APIs)
- Pull requests, issues, discussions as collaboration records when practiced
- Org/user auth, apps, fine-grained PATs / installation tokens for API access
- Actions / Checks / Pages / Wiki / Packages as **product surfaces** (existence, auth, limits class)

## Does not own

- Local Git object model specifics beyond hosting (→ [[git-vcs]])
- Actions workflow **YAML/module craft** (engineering lane)
- Business CRM or ITSM SoR

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Upstream | [[git-vcs]] | Push/fetch of commits |
| Lateral | [[azure-devops-org]] | Dual host practiced; SoR split Untapped |
| Lateral | [[servicedesk-plus]] | Issue ↔ ticket Gap |

## Processes

- [[open-github-pull-request]] · [[review-merge-github-pull-request]] · [[triage-github-issue]]


## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| PR/issue state **on GitHub** when used as house collab SoR | Slack agreement as merge authority |
| Repo contents as published on the host | Unpushed local-only commits |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| UI | github.com (or GHES — house Untapped) |
| API | **REST** (versioned; OpenAPI described) and **GraphQL** |
| Auth class | PAT (classic/fine-grained), GitHub App installation/user tokens, OAuth apps — scopes/permissions bound |
| Common ops | Manage repos, PRs, issues; read checks; manage org teams (role-dependent) |

### Material config

| Knob | Why it matters |
| --- | --- |
| Org / enterprise | Identity boundary and SSO |
| Branch protection / rulesets | Who may land on default branch |
| App vs PAT integrations | Blast radius and rotation |
| API version header | Compatibility |

### Pricing / limits (class)

- REST rate limits scale with auth type and plan; secondary limits apply — re-check [GitHub rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api) before bulk automation.
- Repo/LFS storage and Actions minutes are plan-metered (Actions metering out of systems doctrine depth).

### Failure / controls

| Mode | Posture |
| --- | --- |
| Rate limit exceeded | Back off; do not invent silent retries as doctrine |
| Token leak | Revoke immediately; never store in vault notes |
| Dual SoR with Azure Boards | Name which tracker is authoritative per work type — Gap |

## Owner of truth

Org owners / repo admins (Untapped).

## Evidence

- **Lived:** User relay 2026-07-20 — practiced alongside Azure DevOps; suite-depth (PRs, Actions-as-surface, wiki, etc.) in scope; delivery SoR pick deferred.
- **Remote:** [GitHub REST API](https://docs.github.com/en/rest) · authentication and rate-limit docs.

## Gaps / Untapped

- github.com vs GHES
- Issues vs Azure Boards authority by work class
- Named apps/PATs inventory (no secrets)
- Dual-remote sync leadership

## Further detail

- [GitHub REST API](https://docs.github.com/en/rest)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[pull-request]]
