---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-025
concern: glossary
description: Page — 8 KB SQL Server storage I/O unit.
domain: [sql-server]
updated: 2026-07-20
---

# Page

**Page** ≈ 8 KB storage I/O unit in [[sql-server-pages-extents]] (data/index/system pages). Log files are not page stores.
