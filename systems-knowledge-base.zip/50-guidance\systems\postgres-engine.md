---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-019
concern: systems
description: PostgreSQL engine — relational SoR grain; distinct from DO managed-postgres.
domain: [postgres]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Postgres Engine

## Purpose

Provide **PostgreSQL** as an open-source relational engine SoR grain (self-hosted, cloud VM, or non-DO managed — **house topology Untapped**).

## Owns

- Clusters, databases, schemas, tables, roles, and extensions as configured
- SQL execution and MVCC transactional integrity of data it stores

## Does not own

- Admin UI (→ [[pgadmin]])
- DigitalOcean **managed** Postgres product (→ [[managed-postgres]] on DO family)
- SQL Server engines (→ [[sql-server-engine]])
- Application domain meaning of rows

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Administered via | [[pgadmin]] / `psql` | DDL/DML/admin |
| Lateral | Apps / ETL | Connection strings (secrets out) |
| Lateral | [[managed-postgres]] | Different product — do not conflate without evidence |

## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Data committed in house Postgres databases that are SoR | CSV dumps as live SoR |
| Role grants in the cluster | OS root alone |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| Protocol | PostgreSQL wire protocol; `psql`, drivers, [[pgadmin]] |
| Auth class | Password, peer/ident, cert, SCRAM — house Untapped |
| Common ops | CREATE DATABASE/ROLE; backup (`pg_dump`/`pg_basebackup`); VACUUM/ANALYZE; extensions |
| Hosting class | Self-managed, vendor managed (non-DO), containers — Untapped |

### Material config

| Knob | Why it matters |
| --- | --- |
| Major version | Feature/support window |
| `pg_hba.conf` / listen addresses | Who may connect |
| WAL / backup strategy | RPO/RTO class |
| Extensions | Capability surface |

### Pricing / limits (class)

- Engine is open source; cost is host/managed SKU — house Untapped.
- Connection and storage limits depend on host.

### Failure / controls

| Mode | Posture |
| --- | --- |
| Superuser sprawl | Least privilege roles |
| Public listen + weak auth | Harden `pg_hba` / network |
| Confusing with DO managed Postgres | Separate notes; link only when practiced |

## Processes

- [[connect-administer-postgres]] · [[administer-via-pgadmin]] · [[backup-restore-postgres]]

## Owner of truth

DBA / platform owners (Untapped).

## Evidence

- **Lived:** User relay 2026-07-20 — **both** DigitalOcean [[managed-postgres]] **and** other/self-hosted [[postgres-engine]] exist in the landscape. Exact SoR split by workload Untapped.
- **Remote:** [PostgreSQL documentation](https://www.postgresql.org/docs/).

## Gaps / Untapped

- Which workloads use DO managed vs other Postgres
- House clusters and SoR databases on each path
- Named operators

## Further detail

- [PostgreSQL documentation](https://www.postgresql.org/docs/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[postgres-cluster]] · [[psql]]
