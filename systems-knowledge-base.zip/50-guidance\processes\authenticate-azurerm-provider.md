---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-022
concern: processes
description: Authenticate the Terraform azurerm provider to an Azure subscription.
domain: [azure-cloud]
derived_from:
  - "[[process-note-honesty]]"
  - "[[terraform-azurerm-provider]]"
  - "[[azure-subscription]]"
updated: 2026-07-20
---

# Authenticate Azurerm Provider

## Purpose

Establish credentials so [[terraform-azurerm-provider]] can call ARM against the target [[azure-subscription]].

## Triggers

- First-time Azure IaC setup
- Credential rotation / CI identity change

## Actors / roles

- Cloud / IaC operators (house Azure use may still be light — Untapped depth)

## Inputs / outputs

| In | Out |
| --- | --- |
| Tenant + subscription IDs | Working provider auth |
| Auth method choice | CLI session, SP, MSI, or OIDC federation configured |

## Operable sequence (business grain)

1. **Pick method** — Azure CLI (local); Service Principal / OIDC / Managed Identity (non-interactive).
2. **Grant RBAC** — least privilege on subscription/RG; include RP registration rights or set `resource_provider_registrations = none`.
3. **Configure** — env `ARM_*` or provider arguments; never commit secrets.
4. **Validate** — `terraform plan` against empty/known state succeeds auth.
5. **Rotate** — schedule secret/federated credential rotation.

## Systems touched + SoR

| Fact | System | SoR? |
| --- | --- | --- |
| Subscription existence / IAM | [[azure-subscription]] | Yes |
| Provider auth mode | [[terraform-azurerm-provider]] | Capability SoR |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Broad Owner on SP | Prefer scoped Contributor/custom roles |
| Secrets in repo/vault notes | Forbidden |

## Owner of this note’s truth

Cloud operators (Untapped).
