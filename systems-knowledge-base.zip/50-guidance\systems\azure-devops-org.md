---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-012
concern: systems
description: Azure DevOps densified to useful — WIT + Repos practiced with GitHub dual-host.
domain: [azure-devops]
derived_from:
  - "[[system-sor-honesty]]"
  - "[[named-source-of-record]]"
updated: 2026-07-20
---

# Azure Devops Org

## Purpose

Provide the **Azure DevOps organization/project container** for delivery tracking and **Azure Repos** Git hosting — practiced alongside GitHub.

## Owns

- Organization and team projects
- Work items and boards (delivery tracking **capability** — house SoR pick deferred)
- Azure Repos Git hosting
- Pipelines / Test Plans / Wiki as **product surfaces** (YAML and test-script craft out of scope)
- REST API surface for those resources

## Does not own

- Pipeline YAML / agent pool engineering craft
- Change-methods artefacts (BA/PM pack lives elsewhere)
- Azure cloud resource provisioning (→ Azure cloud family / Wave 3)
- Git object model (→ [[git-vcs]])

## Upstream / downstream

| Direction | Counterpart | Handoff |
| --- | --- | --- |
| Lateral | [[git-vcs]] / [[github-host]] | Dual source hosts **practiced** |
| Lateral | [[servicedesk-plus]] | Work item ↔ ticket Gap |
| Downstream | Engineering delivery | Work item as intent/status record |

## Processes

- [[create-azure-devops-work-item]] · [[transition-azure-devops-work-item]] · [[host-git-on-azure-repos]]


## Authoritative for / not

| Authoritative | Not authoritative |
| --- | --- |
| Work item state **in Azure DevOps** when that is house delivery SoR | Informal chat status |
| Project membership as configured | Cloud subscription RBAC (different product) |

## Usage

### Connect / operate

| Surface | Posture (remote-seeded) |
| --- | --- |
| UI | `dev.azure.com/{organization}` (Services) or on-prem Server URL (Untapped which) |
| API | REST: `https://dev.azure.com/{organization}/_apis/{area}/{resource}?api-version=…` |
| Auth class | PAT (Basic), OAuth, MSAL — prefer short-lived / scoped tokens; never vault secrets |
| Common ops | CRUD work items; list projects; manage repos (if used); queries |

### Material config

| Knob | Why it matters |
| --- | --- |
| Organization + projects | Taxonomy of delivery SoR |
| Process template / work item types | What “Done” means on the board |
| api-version | Compatibility contract |
| Services enabled (Boards, Repos, Pipelines, …) | Scope of this product as practiced |

### Pricing / limits (class)

- Azure DevOps Services billing is seat/parallel-job class — **house plan Untapped**.
- API throttling exists — respect service limits on bulk WIT sync.

### Failure / controls

| Mode | Posture |
| --- | --- |
| PAT expiry / over-scope | Fail closed; rotate |
| Dual tracker with GitHub Issues | SoR pick deferred — document both capabilities |
| Pipeline YAML as systems doctrine | Forbidden — surface notes only |

## Owner of truth

ADO project administrators (Untapped).

## Evidence

- **Lived:** User relay 2026-07-20 — practiced alongside GitHub; suite-depth (Boards, Repos, Pipelines, Test Plans, Wiki) as capabilities; delivery SoR pick deferred.
- **Remote:** [Azure DevOps REST API](https://learn.microsoft.com/en-us/rest/api/azure/devops/).

## Gaps / Untapped

- House org URL and project taxonomy (avoid unnecessary object-name doctrine)
- Boards vs GitHub Issues authority (intentionally deferred)
- Pipeline/test-plan definitions as practiced (surface yes; craft out)
- Dual-remote sync leadership

## Further detail

- [Azure DevOps REST API](https://learn.microsoft.com/en-us/rest/api/azure/devops/)
- Hub index: [[further-detail-hubs]] ([[link-further-detail]])

## Related glossary

- [[work-item]]
