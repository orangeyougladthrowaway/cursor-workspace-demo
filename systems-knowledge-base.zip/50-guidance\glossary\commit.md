---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-013
concern: glossary
description: Commit — Git recorded snapshot in history.
domain: [git]
updated: 2026-07-20
---

# Commit

**Commit** = immutable snapshot node in [[git-vcs]] history (tree + parents + metadata).
