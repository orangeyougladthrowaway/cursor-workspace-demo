---
type: guidance
status: draft
id: systems-knowledge-base-g-proc-002
concern: processes
description: Release built workload onto DOKS or Droplet — operable sequence.
domain: [digital-ocean]
derived_from:
  - "[[process-note-honesty]]"
  - "[[named-source-of-record]]"
  - "[[container-registry]]"
updated: 2026-07-19
---

# Release Workload To Platform

## Purpose

Make a **built workload** become **running** on DigitalOcean-backed runtime (cluster or host shape).

## Triggers

- Release intent for a service
- Hotfix / rollback onto existing capacity

## Actors / roles

- Delivery / release operators
- Platform operators when cluster/host access is required

## Inputs / outputs

| In | Out |
| --- | --- |
| Artefact reference (image tag / compose bundle) | Running workload on [[doks-kubernetes]] or [[droplet-compute]] |
| Target environment identity | Observable service endpoint / health |

## Operable sequence (business grain)

1. **Confirm capacity** exists for the target shape ([[provision-platform-host]] done).
2. **Confirm artefact** in [[container-registry]] (tag/digest) or host bundle reference.
3. **Select target** — correct cluster/namespace or Droplet env (wrong target = incident class).
4. **Apply release** — eng owns Helm/Compose/kubectl mechanics; systems owns where it runs.
5. **Verify** — health/endpoint observable; rollback path known.
6. **Record** — work-item/ticket SoR is P1 Gap (ADO/ServiceDesk) — escalate if status SoR required.

**Host (Droplet + Compose) honesty:** when the workload pulls images from [[container-registry]], the running process follows **registry image identity**. Recreating Compose without a new pushed tag/digest does **not** apply application code fixes — confirm the intended image is present, then pull/recreate. Packaging/build craft stays in the engineering lane.

## Systems touched + SoR

| Fact / artefact | System | SoR? |
| --- | --- | --- |
| Image tags | [[container-registry]] | Yes |
| Running placement | [[doks-kubernetes]] / [[droplet-compute]] | Yes |
| Change/work item status | Azure DevOps (P1) | Gap |
| Ticket | ManageEngine ServiceDesk (P1) | Gap |

## Controls / failure modes

| Mode | Posture |
| --- | --- |
| Image missing in registry | Stop — do not partially invent |
| Recreate without new image | Code change not applied on registry-backed hosts — push then pull |
| Wrong cluster/host | Unintended environment — verify target identity |
| Firewall blocks new exposure | Coordinate [[cloud-firewall]] / [[platform-edge]] |
| No ticket SoR | Status honesty Gap — ask user |

## Owner of this note’s truth

Platform + delivery operators (ownership Untapped). Engineering packaging is out of scope.

## Related glossary

- [[docr]] · [[doks]] · [[droplet]]
