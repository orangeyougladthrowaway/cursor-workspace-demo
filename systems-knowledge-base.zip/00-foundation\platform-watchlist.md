---
type: foundation
status: draft
id: systems-knowledge-base-fnd-platform-watchlist
description: Platform research order — DO P0 useful; P1 families in waves of 2–3 after foundation admit.
updated: 2026-07-20
---

# Platform watchlist

Companion to [[scope]]. Platforms become family atlases / `domain:` tags — not L1 altitude folders. Usability bar: [[common-case-coverage]]. Depth exemplar: [[digital-ocean-atlas]] and system notes with SoR **and Usage**.

## Research order (binding)

```text
0. Foundation — amend scope + this note + coverage before new atlases
1. DigitalOcean — P0 deep dive (Atlas/Systems/Usage/Processes/Glossary useful — met)
2. Then waves of 2–3 P1 families (parallel within a wave; finish wave useful-bar before next wave’s deep densify)
```

Partial coverage is fine; empty theatre is not. Do not mark a family `useful` without real notes.

### Wave board

| Wave | Families | Focus |
| --- | --- | --- |
| **0** | Foundation only | Scope, watchlist, coverage honesty, ingest ledger |
| **1** | `zoho` · `manageengine-servicedesk` | CRM/Flow + ITSM; rich public docs/APIs |
| **2** | `git` · `github` · `azure-devops` | Source + delivery SoR (no CI/YAML craft) |
| **3** | `azure-cloud` | Azure platform at IaC/Terraform **provider** grain |
| **4** | `aryza-sentinel` · `tcs-bancs` · `tuum` | **Deferred** — skip densify for now |
| **5** | `sql-server` · `postgres` | SQL Server suite + PostgreSQL / pgAdmin (**active**) · `virtual-cabinet` **deferred** |

Within a wave, atlases may open in parallel. Do not open Wave *n+1* family atlases until Wave *n* families are scored honestly (at least Atlas + Systems + Usage targeted; `named only` → `seeded` minimum progress before skipping ahead).

## P0 — DigitalOcean

| Field | Guidance |
| --- | --- |
| Family leaf | `digital-ocean` |
| Why first | Core platform for hosting / runtime landscape |
| Lived | DO-touching projects and operator practice — infer, do not invent |
| Remote | Official DigitalOcean docs — admit `pressure` / `specialise`; claim-card only |
| Must produce | Atlas; material system notes with SoR **and Usage** (API/auth class, config knobs, pricing/limits class, fail modes); ≥3 operable process notes; glossary; explicit Gaps |
| Must not | Full DO catalogue; IaC/Helm/Compose engineering doctrine; secrets; account object-name doctrine; claiming `useful` from SoR inventory alone |
| Status | P0 core cells **useful** ([[common-case-coverage]]); Interfaces partial until P1 counterparts densify |

## P1 — admitted families (after DigitalOcean)

| Platform | Suggested leaf | Focus | Out |
| --- | --- | --- | --- |
| Zoho CRM / Zoho Flow | `zoho` | Products in use; CRM vs Flow surfaces; owned facts; handoffs | Marketplace encyclopaedia |
| ManageEngine ServiceDesk Plus | `manageengine-servicedesk` | Ticket lifecycle; SLAs as practiced | Entire ME suite encyclopaedia |
| Git | `git` | Distributed VCS as practiced SoR for source history | Tutorial curricula |
| GitHub | `github` | Hosted collaboration / PR / issue SoR | Actions workflow craft (engineering lane) |
| Azure DevOps | `azure-devops` | Work items / boards / repos as delivery SoR | CI YAML craft; BA method bodies |
| Azure cloud (Terraform provider) | `azure-cloud` | Provider auth/identity **plus** lived business infra surfaces (VM, VNet, Entra, security, ADF, Foundry) | Module design, pipeline YAML, GPO encyclopaedia |
| Aryza Sentinel | `aryza-sentinel` | Lending SoR surfaces as practiced; **confirm product identity / SKU** | Unrelated “Sentinel” products; generic SIEM lore |
| TCS BaNCS | `tcs-bancs` | Deposit / customer / account / txn SoR as practiced | Training curriculum; PII dumps; full product catalogue |
| Tuum (overdraft) | `tuum` | Overdraft module / account-limit SoR | Full Tuum encyclopaedia beyond practiced scope |
| Virtual Cabinet DMS | `virtual-cabinet` | Document store / index / publish handoffs as practiced | Unrelated DMS products; inventing public APIs |
| SQL Server suite | `sql-server` | Engine + SSMS / SSIS / SSRS tool surfaces at systems grain | App schema dumps; BI report catalogue mirrors |
| PostgreSQL / pgAdmin | `postgres` | Engine + pgAdmin tool surface at systems grain; distinct from DO [[managed-postgres]] | App schema dumps; DO-specific managed SKU (stays on DO family) |

## Cross-cutting themes (later)

When enough notes exist, index under `maps/themes/`: `integrations`, `controls`, `data-ownership`.

## Extending

New platforms require amending [[scope]] + this note **before** a new family atlas.
