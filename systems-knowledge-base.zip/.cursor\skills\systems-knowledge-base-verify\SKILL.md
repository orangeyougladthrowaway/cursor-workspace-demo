---
name: systems-knowledge-base-verify
description: Verifies domain notes for SoR honesty, coverage cells, and vault health. Use after systems-knowledge-base amendments or when checking domain note quality.
disable-model-invocation: true
---

Follow `60-workflows/knowledge/verify-domain-note.md` (`systems-knowledge-base-wf-009`).

Seeded ≠ useful. Run vault-health when files changed.
