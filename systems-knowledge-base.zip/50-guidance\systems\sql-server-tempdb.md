---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-036
concern: systems
description: tempdb — shared system database for versions, spills, temps.
domain: [sql-server]
updated: 2026-07-20
---

# Sql Server Tempdb

## Purpose

Explain **tempdb** as the instance-scoped system database for transient objects and version store — critical shared resource.

## Used for (class)

- User temp tables / table variables
- Sorts/hashes spills from memory grants
- Row-versioning stores (RCSI/snapshot/online ops/triggers class)
- Internal worktables / cursors
- Some index rebuild / DBCC workspace classes

Recreated on restart — not for durable business SoR.

## Owns / not

| Owns | Does not own |
| --- | --- |
| tempdb role & contention phenomena | Number of data files house standard (ops Gap) |

## Azure SQL note

Still present; sizing/contention monitoring differs by service tier. Multiple files guidance class still relevant on MI/box.

## Failure / controls

| Mode | Posture |
| --- | --- |
| tempdb full | Version store / spills / runaway temp objects |
| Allocation contention (historic PFS/GAM) | Multiple files of equal size class — ops |
| Durable business tables in tempdb | Wrong SoR |

## Evidence

- **Remote:** tempdb database Learn docs.

## Further detail

- [tempdb database](https://learn.microsoft.com/en-us/sql/relational-databases/databases/tempdb-database)
- [SQL Server docs hub](https://learn.microsoft.com/en-us/sql/sql-server/) · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[sql-server-memory]] · [[sql-server-concurrency-locking]] · [[sql-server-object-model]]
