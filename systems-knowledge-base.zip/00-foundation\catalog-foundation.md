---
type: catalog
status: draft
id: systems-knowledge-base-cat-foundation
description: Inventory of foundation notes.
updated: 2026-07-16
---

# Catalog foundation

| Stem | Role |
| --- | --- |
| [[navigation]] | Navigation constitution |
| [[methodology]] | Note shape / naming / linking |
| [[knowledge-model]] | Types |
| [[dependency-rules]] | Dependency direction |
| [[changing-this-bible]] | Amend / retire / cleanliness |
| [[purpose]] | Why systems-knowledge-base exists |
| [[scope]] | In/out + watchlist summary |
| [[platform-watchlist]] | Research order |
| [[layout]] | Folders |
| [[glossary]] | Vault-wide terms |

## Note-writing templates

| Stem | Role |
| --- | --- |
| [[system-note]] | Starter shape for system guidance |
| [[process-note]] | Starter shape for process guidance |

Consumer copy-pack lives under `00-foundation/templates/consumer-init/` (not individual doctrine stems).
