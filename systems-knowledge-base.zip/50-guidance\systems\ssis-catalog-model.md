---
type: guidance
status: draft
id: systems-knowledge-base-g-sys-042
concern: systems
description: SSIS catalog model — SSISDB, projects, environments, executions, versions.
domain: [sql-server]
updated: 2026-07-20
---

# Ssis Catalog Model

## Purpose

Describe the **SSIS Catalog (SSISDB)** as central storage/admin for projects, parameters, environments, and execution history.

## Concepts

| Artefact | Behaviour |
| --- | --- |
| SSISDB | Catalog database created when IS catalog is configured |
| Folder | Organizational container |
| Project | Deployed unit (contains packages); versioned in catalog |
| Package | Executable unit inside a project |
| Environment / reference | Parameter binding sets per environment |
| Execution | One run instance with status/logging in catalog tables |
| Protection | ServerStorage encryption for sensitive values in catalog |

Catalog maintenance Agent job cleans old operations/versions when configured.

## Owns / not

| Owns | Does not own |
| --- | --- |
| Catalog object model | Package-by-package inventory dumps |

## Azure note

Azure-SSIS Integration Runtime hosts SSIS in Azure Data Factory class — different host, similar project concepts ([[azure-data-factory]]).

## Failure / controls

| Mode | Posture |
| --- | --- |
| Catalog history unbounded | Retention properties / maintenance job |
| Sensitive params in clear | Prefer sensitive + environments |

## Evidence

- **Remote:** [SSIS Catalog](https://learn.microsoft.com/en-us/sql/integration-services/catalog/ssis-catalog).

## Further detail

- See Evidence Remote URL · [[further-detail-hubs]] ([[link-further-detail]])

## Related

- [[ssis]] · [[ssis-control-data-flow]] · [[ssis-deployment-build]] · [[sql-server-agent]]
