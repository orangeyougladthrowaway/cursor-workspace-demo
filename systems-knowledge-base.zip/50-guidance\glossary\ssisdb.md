---
type: glossary
status: draft
id: systems-knowledge-base-g-gloss-030
concern: glossary
description: SSISDB — SSIS Catalog database hosting projects and executions.
domain: [sql-server]
updated: 2026-07-20
---

# Ssisdb

**SSISDB** = Integration Services Catalog database storing projects, environments, and execution history ([[ssis-catalog-model]]).
