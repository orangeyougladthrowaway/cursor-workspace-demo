---
type: map
status: draft
id: systems-knowledge-base-map-github
concern: github
description: GitHub atlas — host systems + PR/issue processes; Actions craft out of scope.
domain: [github]
updated: 2026-07-20
---

# Github Atlas

Browse for **GitHub** as hosted collaboration SoR (peer with Azure Repos).

## Systems

| Note | Role |
| --- | --- |
| [[github-host]] | Remotes, PRs, issues, API auth |

## Processes

| Note | Question |
| --- | --- |
| [[open-github-pull-request]] | How a PR is opened |
| [[review-merge-github-pull-request]] | How a PR is reviewed and merged |
| [[triage-github-issue]] | How issues are triaged |

## Glossary

[[pull-request]]

## Interfaces / Gaps

| Counterpart | Status |
| --- | --- |
| [[git-vcs]] | Object history |
| [[azure-devops-org]] | Dual host + optional Boards ↔ Issues SoR split Untapped |
| [[servicedesk-plus]] | Gap |

## Evidence posture

- **Lived:** Practiced host alongside Azure DevOps.
- **Remote:** GitHub REST auth/rate-limit docs.

## Further detail

Out-of-vault wire/field matrices and deep vendor manuals stay linked, not pasted ([[link-further-detail]] · [[further-detail-hubs]]):

- [GitHub Docs](https://docs.github.com/)

## Usability wave

**Useful** on Atlas/Systems/Usage/Processes/Controls/Glossary/Freshness. Interfaces partial.

## Related

- [[git-atlas]] · [[azure-devops-atlas]] · [[catalog-maps]]
