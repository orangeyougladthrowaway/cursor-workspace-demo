---
type: example
status: draft
id: change-knowledge-base-ex-047
description: Worked exemplar — decision log good vs bad.
derived_from:
  - "[[decision-log]]"
  - "[[decision-log-craft]]"
updated: 2026-07-18
---

# Decision log worked

## Bad

"We decided in the hallway."

## Good

D-14 (13 Jul, CFO): Reject R4 this release; new frame required. Linked CR-03 reject. Plan unchanged.

## Related

- [[decision-log-craft]] · skeleton if present under lab/skeletons/
