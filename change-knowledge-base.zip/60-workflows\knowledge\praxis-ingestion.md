---
type: workflow
status: draft
id: change-knowledge-base-wf-002
concern: knowledge
description: Praxis ingestion — densify lab to common-case matrices; cite doctrine; never redefine law.
derived_from:
  - "[[knowledge-ingestion]]"
  - "[[dependency-rules]]"
  - "[[navigation]]"
  - "[[common-case-coverage]]"
updated: 2026-07-16
---

# Praxis ingestion

Use for `lab/` artifacts. Doctrine remote harvest stays [[knowledge-ingestion]]. Majority bar: [[common-case-coverage]].

## Plane

| Doctrine | Praxis |
| --- | --- |
| `00`–`60` + `maps/` | `lab/zoo` · `lab/skeletons` · `lab/stubs` |
| Sets house law | Illustrates law |
| Depth on [[ingest-coverage]] | Matrix G4 — never doctrine `deep` |

## Admit bar

Add a zoo entry only if it **changes a choice** or **prevents a known failure**, and a living note already answers the normative question — ideally a **matrix cell**.

Reject: uncited tutorials, curriculum sequences, uncited template dumps, soft-theatre as virtue.

**Seed ≠ done:** a non-empty facet does **not** mean the track meets the majority bar.

## Steps

1. **Canon first** — open the living note; confirm question / matrix cell.
2. **Draft** zoo entry with `type: example`, `derived_from` → doctrine stems, When/When-not, thin body.
3. **Collide** quarantine — label anti-patterns explicitly.
4. **Index** — [[lab-atlas]] + [[catalog-lab]] in the same change.
5. **Ledger** — cell G4 on [[common-case-coverage]] only when skeleton + canon truly sufficient.
6. **Health** — `pytest tests/lab -v` (and doctrine suite).

## Skeletons / stubs

- Skeleton = directory under `lab/skeletons/{name}/` + README (Purpose · Required canons · Copy · Honesty).
- Not `00-foundation/templates/` (those are **note** templates).
- Session budgets: ≤10 zoo entries · ≤1 skeleton unless roadmap override.
- Skills (optional): invoke-only; **point at** workflow/`id`s — never reprint bodies.

## Elevate feedback

If an exemplar encodes **new** house law → elevate into guidance/pattern first → shrink zoo to a pointer.

## Related

- [[lab-atlas]] · [[staff-agent-projection]] · [[layout]] · [[scope]] · [[common-case-coverage]]
