---
type: principle
status: draft
id: change-knowledge-base-p-019
category: risk
description: Risk is managed continuously — reviewed on a cadence, not logged once and forgotten.
derived_from:
  - "[[risk]]"
updated: 2026-07-16
---

# Risk managed continuously

Risk work is a **cadence**, not a one-off register. Risks are re-scored, closed, or escalated on a rhythm; a stale log that never changes is not risk management.
