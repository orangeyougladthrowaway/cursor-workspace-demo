---
type: guidance
status: draft
id: change-knowledge-base-g-048
concern: requirements
description: How to produce nfr schedule — what good looks like.
derived_from:
  - "[[nfr-schedule]]"
updated: 2026-07-18
---

# Nfr schedule craft

House how-to for [[nfr-schedule]].

## House defaults

1. Extract NFRs from catalogue or maintain dedicated schedule linked by id.
2. Measures over vibes; open questions explicit.
3. Security NFRs name control intent.
4. Feed [[test-plan]] and conditions.

## What good looks like

TA can write conditions without inventing thresholds.

## Done test

Attribute · measure · context · id · priority.

## Related

- [[nfr-schedule]] · [[nfr-schedule-worked]] · [[write-nfr-schedule]] · skeleton `nfr-schedule/`
