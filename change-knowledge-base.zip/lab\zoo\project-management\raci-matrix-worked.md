---
type: example
status: draft
id: change-knowledge-base-ex-071
description: Worked exemplar — raci matrix good vs bad.
derived_from:
  - "[[raci-matrix]]"
  - "[[raci-matrix-craft]]"
updated: 2026-07-18
---

# Raci matrix worked

## Good

Write catalogue: R=BA, A=Product owner, C=Ops, I=Eng.

## Related

- [[raci-matrix-craft]] · `lab/skeletons/raci-matrix/`
