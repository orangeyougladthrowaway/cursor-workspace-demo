# Acceptance criteria

- **Standard:** `change-knowledge-base-s-003` ([[acceptance-criteria]])
- **Owner:**
- **Requirements pack ref:**
- **Precision:** [[precision-over-vagueness]] — no adjective-only; data intents need change/delete/noop when in scope

| Req id | Scenario | Given | When | Then (observable) | Pass/fail notes |
| --- | --- | --- | --- | --- | --- |
| R1 | | | | | |

## Data / historisation scenarios (when req moves or histories data)

Include material behaviours in scope (not happy-path only):

| Req id | Scenario type (insert / change / noop / tombstone / refuse) | Given (key, hash/state, completeness) | When | Then (named table/state observable) |
| --- | --- | --- | --- | --- |
| | | | | |

## Escalations (domain facts missing)

-

## Not in this artefact

Code-level test design is out of change-knowledge-base scope.
