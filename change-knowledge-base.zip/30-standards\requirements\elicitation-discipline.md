---
type: standard
status: draft
id: change-knowledge-base-s-007
concern: requirements
description: Elicitation declares mode, target, questions, and warrants — frameworks OK; no invented answers.
derived_from:
  - "[[elicit-before-invent]]"
  - "[[claim-needs-warrant]]"
  - "[[enough-to-decide]]"
  - "[[influence-shapes-engagement]]"
  - "[[name-who-matters]]"
updated: 2026-07-16
---

# Elicitation discipline

## Normally require

An **elicitation plan or record** for material unknowns includes:

| Field | Test |
| --- | --- |
| Unknown | What decision or requirement gap is being closed |
| Mode | Named portable mode (interview, workshop, observation, document study, prototype review, …) — see [[elicitation-modes]] |
| Target | Who/what is consulted ([[name-who-matters]]); engagement fits influence ([[influence-shapes-engagement]]) |
| Prompts | Questions or discovery focus — not a leading solution script |
| Output warrant | What claim the session is allowed to support ([[claim-needs-warrant]]) |
| Result | Findings, conflicts, and remaining unknowns — or `not yet run` |

## Framework posture

Technique *families* (structured interview, facilitated workshop, as-is observation) are in scope. Vendor clickpaths and system encyclopaedias are out of scope for this vault.

**How to produce:** [[elicitation-craft]]. Worked: [[elicitation-worked]].

## Refuse / escalate

- Writing requirements to “save a meeting” when the unknown is material ([[elicit-before-invent]])
- Inventing interviewee answers or process facts
- Running the same mode for every gap when influence/interest differ

## Not this standard

Pack field tests ([[requirements-quality]]); stakeholder grid shape ([[influence-interest-grid]]); prioritisation frameworks ([[requirements-prioritisation]]).
