---
type: standard
status: draft
id: change-knowledge-base-s-016
concern: verification
description: Coverage is reported against intent and risk, with explicit gaps — never test counts as proof.
derived_from:
  - "[[coverage-measures-intent]]"
  - "[[status-matches-evidence]]"
  - "[[tradeoff-visible]]"
  - "[[link-across-artefacts]]"
updated: 2026-07-16
---

# Intent coverage

## Normally require

An **intent-coverage view** for a change includes:

| Field | Test |
| --- | --- |
| Coverage basis | Intents (requirements/acceptance/risks) mapped to conditions ([[coverage-measures-intent]], [[coverage-dimensions]]) |
| Covered | Intents with at least one meaningful condition |
| Gaps | Intents with no/weak condition — named, not hidden |
| Untestable | Intents that cannot be verified as written → back to BA/acceptance |
| Honesty | Count of tests or "100%" without intent mapping fails ([[status-matches-evidence]]) |

## Framework posture

Coverage-dimension thinking (requirement, risk, scenario) is portable. Code/line coverage tooling is out of change-knowledge-base scope — not this vault's claim of intent coverage.

## How to produce

[[intent-coverage-craft]]. Worked: [[intent-coverage-worked]].

## Refuse / escalate

- Reporting test counts or line coverage as intent coverage ([[coverage-measures-intent]])
- Hiding uncovered intents
- Untestable intents → escalate to BA/acceptance, don't silently pass

## Not this standard

Condition derivation ([[test-conditions]]); risk focus ([[risk-based-test-focus]]); UAT readiness ([[uat-readiness]]).
