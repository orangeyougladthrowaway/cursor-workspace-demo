---
type: workflow
status: draft
id: change-knowledge-base-wf-049
concern: governance
description: Sequence to produce kickoff honesty for PM11.
derived_from:
  - "[[kickoff-honesty]]"
  - "[[kickoff-honesty-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Run kickoff

Agent-operable sequence for PM11.

## Steps

1. **Retrieve** — theme atlas → [[kickoff-honesty]] → [[kickoff-honesty-craft]] → [[kickoff-honesty-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[kickoff-honesty]]; escalate Gaps.
5. **Cite** — `kickoff-honesty` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
