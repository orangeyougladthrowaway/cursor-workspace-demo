---
type: catalog
status: draft
id: change-knowledge-base-cat-workflows
description: Workflows inventory -- sequences staff agents follow.
updated: 2026-07-18
---

# Catalog -- Workflows

| Concern | Notes |
| --- | --- |
| analysis | [[ba-change-pass]], [[communicate-options]], [[facilitate-workshop]], [[frame-problem]], [[model-process-swimlane]], [[write-gap-analysis]] |
| delivery | [[close-delivery]], [[produce-change-artefact]], [[report-status]], [[run-delivery-comms]], [[write-communications-plan]], [[write-post-implementation-review]] |
| governance | [[control-change]], [[initiate-project]], [[log-decision]], [[pm-delivery-pass]], [[review-change-artefact]], [[run-kickoff]], [[write-business-case]], [[write-terms-of-reference]] |
| knowledge | [[common-case-coverage]], [[ingest-coverage]], [[knowledge-ingestion]], [[praxis-ingestion]], [[roadmap]], [[staff-agent-projection]], [[vault-health-checks]] |
| planning | [[build-plan]], [[manage-delivery-dependencies]], [[plan-change-work]], [[write-quality-plan]] |
| requirements | [[assess-requirements-quality]], [[elicit-requirements]], [[frame-nonfunctionals]], [[maintain-assumption-log]], [[maintain-business-rules]], [[maintain-requirements-catalogue]], [[model-data]], [[prioritise-requirements]], [[resolve-requirements-conflict]], [[trace-requirements]], [[write-nfr-schedule]], [[write-use-case]] |
| risk | [[maintain-raid-log]], [[run-risk-cadence]], [[split-issue-risk]] |
| stakeholders | [[map-stakeholders]], [[write-raci-matrix]] |
| verification | [[apply-boundary]], [[assess-intent-coverage]], [[assess-uat-readiness]], [[derive-test-conditions]], [[focus-by-risk]], [[judge-defect-severity]], [[narrate-coverage-honesty]], [[record-uat-sign-off]], [[report-defect]], [[ta-analysis-pass]], [[verify-change-artefact]], [[write-acceptance-criteria]], [[write-test-case]], [[write-test-completion-report]], [[write-test-plan]], [[write-test-procedure]], [[write-uat-intent-scripts]] |

[[navigation]]
