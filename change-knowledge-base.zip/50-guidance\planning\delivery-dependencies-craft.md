---
type: guidance
status: draft
id: change-knowledge-base-g-025
concern: planning
description: How to perform delivery dependencies — house craft for PM08.
derived_from:
  - "[[delivery-dependencies]]"
updated: 2026-07-18
---

# Delivery dependencies craft

House how-to for PM08. Field tests: [[delivery-dependencies]].

## House defaults

1. List external and cross-team deps explicitly on the plan.
2. Need-by tied to milestones.
3. At-risk deps appear in status asks.
4. Broken dep → replan or change control.

## Done test

Named deps · need-by · status · impact · owners.

## Related

- [[delivery-dependencies]] · [[delivery-dependencies-worked]] · [[common-case-coverage]]
