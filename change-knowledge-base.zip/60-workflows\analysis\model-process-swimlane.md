---
type: workflow
status: draft
id: change-knowledge-base-wf-066
concern: analysis
description: Sequence to produce process swimlane artefact.
derived_from:
  - "[[process-swimlane]]"
  - "[[process-swimlane-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Model process swimlane

Agent-operable sequence for [[process-swimlane]].

## Steps

1. **Retrieve** — theme atlas → [[process-swimlane]] → [[process-swimlane-craft]] → [[process-swimlane-worked]] → skeleton `lab/skeletons/process-swimlane/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[process-swimlane]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
