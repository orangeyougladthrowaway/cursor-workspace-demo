---
type: standard
status: draft
id: change-knowledge-base-s-027
concern: governance
description: Decision log — usable bar for PM09.
derived_from:
  - "[[enough-to-decide]]"
  - "[[control-the-delta]]"
  - "[[artefact-has-owner]]"
updated: 2026-07-18
---

# Decision log

## Normally require

A **decision log** entry includes:

| Field | Test |
| --- | --- |
| Decision | What was decided |
| Date / decider | Who and when |
| Options considered | Brief |
| Consequences | Scope/plan/risk effects |
| Links | Related CR/req/plan |

## Refuse / escalate

- Verbal-only material decisions
- Decider unknown

## How to produce

[[decision-log-craft]]. Worked: [[decision-log-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
