---
type: example
status: draft
id: change-knowledge-base-ex-048
description: Worked exemplar — delivery comms good vs bad.
derived_from:
  - "[[delivery-comms]]"
  - "[[delivery-comms-craft]]"
updated: 2026-07-18
---

# Delivery comms worked

## Bad

Daily 40-line paste to CFO and engineers identically.

## Good

Weekly 1-pager to CFO (RAG+asks); standup notes to eng; vendor escalate thread for ISS-02 only.

## Related

- [[delivery-comms-craft]] · skeleton if present under lab/skeletons/
