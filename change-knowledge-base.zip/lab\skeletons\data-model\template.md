# Data / information model

- **Standard:** [[data-model]] (`change-knowledge-base-s-047`)
- **Owner:**
- **Grain:** logical (+ field map when load/historise/sync)
- **Precision:** [[precision-over-vagueness]]

## Entities

| Entity | Description | Business identifier | SoR / Gap |
| --- | --- | --- | --- |
| | | | |

## Relationships

| From | To | Degree | Optionality | Notes |
| --- | --- | --- | --- | --- |
| | | | | |

## Diagram

(attach)

## Data rules

|

## Source → target field map (required for data/integration work)

BA owns this contract. Eng may author DDL; **linking DDL without rows below is not Ready**.

| Map id | Source system | Source field (API/file) | Target (db.schema.table.column) | Transform | Historised? (Y/N) | Null / PII / delete notes | Further-detail URL (if wire out of vault) | Catalogue / rule refs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | |

## Gaps (unwarranted fields / SoR)

-
