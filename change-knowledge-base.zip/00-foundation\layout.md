---
type: foundation
status: draft
id: change-knowledge-base-fnd-layout
description: Top-level layout — doctrine altitude + theme maps + subordinate lab praxis.
updated: 2026-07-16
---

# Layout

**Primary axis:** altitude of knowledge (doctrine).  
**Secondary axis:** **one responsibility per folder**. See [[navigation]].  
**Praxis plane:** `lab/` — exemplars subordinate to doctrine.

```text
change-knowledge-base/
├── README.md
├── maps/
│   ├── catalog-maps.md
│   ├── themes/              # PRIMARY browse — pm / ba / ta / …
│   └── families/            # optional later — lived programme-shape bodies
├── 00-foundation/
│   └── templates/           # note starters + consumer-init
├── 10-philosophy/
├── 20-principles/{concept}/
├── 30-standards/{responsibility}/
├── 40-patterns/{responsibility}/
├── 50-guidance/{responsibility}/
├── 60-workflows/{responsibility}/
├── lab/
│   ├── praxis-plane.md
│   ├── catalog-lab.md
│   ├── maps/lab-atlas.md
│   ├── zoo/{facet}/
│   ├── skeletons/{name}/
│   └── stubs/{facet}/
├── temp/
├── tests/
└── .cursor/rules/
```

## Folder contracts

| Folder | Belongs |
| --- | --- |
| `maps/themes/{theme}/` | Knowledge atlases for PM/BA/TA (and later risk/governance) — indexes, not job playbooks |
| `maps/families/{family}/` | Optional lived programme-shape bodies — later |
| `00-foundation/` | Meta, [[navigation]], note templates, glossary, [[consumer-init]] |
| `10-philosophy/` | Rare worldview |
| `20-principles/{concept}/` | Category spine + leaves |
| `30-standards/{responsibility}/` | Norms for artefacts and gates |
| `40-patterns/{responsibility}/` | Portable method shapes |
| `50-guidance/{responsibility}/` | Tool/context specialisations (`domain:`) |
| `60-workflows/{responsibility}/` | Sequences staff agents follow |
| `lab/` | Praxis: zoo, skeletons, stubs — cite canons; never redefine law |
| `temp/` | Harvest staging — not doctrine |

**Banned:** `_index.md`; `and`-joined names; role org-chart as L1 altitude trees; atlases as curricula; empty doctrine homes without orphan proof.
