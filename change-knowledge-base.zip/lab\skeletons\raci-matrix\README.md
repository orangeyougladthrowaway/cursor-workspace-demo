# Raci matrix skeleton

## Purpose

Copy-out starter for raci matrix. Cite [[raci-matrix]].

## Required canons

- [[raci-matrix]]
- [[raci-matrix-craft]]
- Workflow: [[write-raci-matrix]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[raci-matrix-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
