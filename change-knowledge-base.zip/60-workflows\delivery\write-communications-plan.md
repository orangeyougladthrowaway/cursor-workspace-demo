---
type: workflow
status: draft
id: change-knowledge-base-wf-072
concern: delivery
description: Sequence to produce communications plan artefact.
derived_from:
  - "[[communications-plan]]"
  - "[[communications-plan-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write communications plan

Agent-operable sequence for [[communications-plan]].

## Steps

1. **Retrieve** — theme atlas → [[communications-plan]] → [[communications-plan-craft]] → [[communications-plan-worked]] → skeleton `lab/skeletons/communications-plan/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[communications-plan]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
