---
type: standard
status: draft
id: change-knowledge-base-s-059
concern: delivery
description: Post implementation review — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[closure-confirmation]]"
  - "[[close-confirms-benefit]]"
  - "[[tradeoff-visible]]"
updated: 2026-07-18
---

# Post implementation review

## Normally require

A **post-implementation review (PIR)** includes:

| Field | Test |
| --- | --- |
| Outcome vs business case / success measure | Honest |
| What worked / what did not | Portable lessons |
| Benefits realised / outstanding | Owners |
| Recommendations | For future changes |

## Refuse / escalate

- PIR that only celebrates with no evidence

## How to produce

[[post-implementation-review-craft]]. Worked: [[post-implementation-review-worked]]. Skeleton: `lab/skeletons/post-implementation-review/`.

## Related

- [[common-case-coverage]] · workflow [[write-post-implementation-review]]
