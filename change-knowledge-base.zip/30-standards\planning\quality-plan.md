---
type: standard
status: draft
id: change-knowledge-base-s-053
concern: planning
description: Quality plan — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[plan-honesty]]"
  - "[[intent-must-be-testable]]"
  - "[[status-matches-evidence]]"
updated: 2026-07-18
---

# Quality plan

## Normally require

A **quality plan** includes:

| Field | Test |
| --- | --- |
| Standards / entry-exit | What "good" means for key products |
| Reviews / tests | What verification happens when |
| Roles | Who assures vs who produces |
| Records | What evidence is kept |

## Refuse / escalate

- Quality = "we'll test at the end" only

## How to produce

[[quality-plan-craft]]. Worked: [[quality-plan-worked]]. Skeleton: `lab/skeletons/quality-plan/`.

## Related

- [[common-case-coverage]] · workflow [[write-quality-plan]]
