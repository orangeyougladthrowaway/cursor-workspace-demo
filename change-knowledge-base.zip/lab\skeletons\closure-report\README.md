# Closure report skeleton

## Purpose

Copy-out starter for a closure record. Cite [[closure-confirmation]] (`change-knowledge-base-s-013`).

## Required canons

- [[closure-confirmation]]
- Workflow: [[close-delivery]]

## Copy

1. Copy `closure.md` into the host work area.
2. Confirm outcome vs mandate; record residuals, handoff, lessons.
3. Cite `change-knowledge-base-s-013`.

## Honesty

Skeleton ≠ doctrine. No success claim while residuals hide; escalate unknown benefit.
