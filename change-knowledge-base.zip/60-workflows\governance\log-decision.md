---
type: workflow
status: draft
id: change-knowledge-base-wf-047
concern: governance
description: Sequence to produce decision log for PM09.
derived_from:
  - "[[decision-log]]"
  - "[[decision-log-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Log decision

Agent-operable sequence for PM09.

## Steps

1. **Retrieve** — theme atlas → [[decision-log]] → [[decision-log-craft]] → [[decision-log-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[decision-log]]; escalate Gaps.
5. **Cite** — `decision-log` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
