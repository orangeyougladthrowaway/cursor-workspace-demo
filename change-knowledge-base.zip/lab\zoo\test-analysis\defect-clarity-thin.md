---
type: example
status: draft
id: change-knowledge-base-ex-020
description: Thin exemplar — refuse a bare "it's broken" defect with no evidence.
derived_from:
  - "[[defect-clarity]]"
  - "[[report-defect]]"
updated: 2026-07-16
---

# Defect clarity thin

## When

Defect logged as "checkout broken" with no expected/actual, reproduction, or impact.

## When not

Expected vs actual, reproduction, evidence, and impact all present with a trace.

## Choice

Fail [[defect-carries-evidence]]. Use [[defect-report-shape]]; escalate if the expected behaviour is genuinely ambiguous.
