---
type: example
status: draft
id: change-knowledge-base-ex-072
description: Worked exemplar — communications plan good vs bad.
derived_from:
  - "[[communications-plan]]"
  - "[[communications-plan-craft]]"
updated: 2026-07-18
---

# Communications plan worked

## Good

CFO: weekly 1-pager RAG+asks. Eng: standup. Vendor: issue thread only.

## Related

- [[communications-plan-craft]] · `lab/skeletons/communications-plan/`
