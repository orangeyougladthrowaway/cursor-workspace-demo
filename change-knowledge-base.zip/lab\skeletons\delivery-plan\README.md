# Delivery plan skeleton

## Purpose

Copy-out starter for a plan with WBS and honest estimates. Cite [[plan-honesty]] (`change-knowledge-base-s-009`).

## Required canons

- [[plan-honesty]] · [[work-breakdown-structure]] · [[estimate-range-method]]
- Workflow: [[build-plan]]

## Copy

1. Copy `plan.md` into the host work area.
2. Decompose, sequence, estimate with ranges + assumptions.
3. Cite `change-knowledge-base-s-009`.

## Honesty

Skeleton ≠ doctrine. No single-point certainty; escalate unknown domain effort.
