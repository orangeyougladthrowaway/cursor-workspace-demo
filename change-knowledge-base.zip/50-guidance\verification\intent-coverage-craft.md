---
type: guidance
status: draft
id: change-knowledge-base-g-017
concern: verification
description: How to report intent coverage — map intents to conditions, gaps named, no count theatre.
derived_from:
  - "[[intent-coverage]]"
  - "[[coverage-measures-intent]]"
  - "[[coverage-dimensions]]"
updated: 2026-07-18
---

# Intent coverage craft

House how-to for TA03. Field tests: [[intent-coverage]].

## House defaults

1. Rows = intents (req/AC/risk), not test case counts.
2. Covered = at least one meaningful condition; Gaps named; Untestable back to BA.
3. Never report line coverage or test counts as intent coverage.
4. Honesty: no 100% while gaps hide.
5. Engineering automation coverage is out of lane.

## Done test

Intent map · covered/gaps/untestable · no count-as-proof · owner.

## Related

- [[intent-coverage]] · [[assess-intent-coverage]] · [[intent-coverage-worked]] · [[test-conditions]]
