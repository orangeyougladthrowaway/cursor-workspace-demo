---
type: principle
status: draft
id: change-knowledge-base-p-022
category: verification
description: Coverage measures how much intent is exercised — not how many tests or lines exist.
derived_from:
  - "[[verification]]"
updated: 2026-07-16
---

# Coverage measures intent

Coverage is answered against **intent and risk**, not test counts. "Many tests" or "lines hit" is not proof that the change's intent is verified.
