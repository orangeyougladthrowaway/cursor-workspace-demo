# Uat sign off skeleton

## Purpose

Copy-out starter for uat sign off. Cite [[uat-sign-off]].

## Required canons

- [[uat-sign-off]]
- [[uat-sign-off-craft]]
- Workflow: [[record-uat-sign-off]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[uat-sign-off-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
