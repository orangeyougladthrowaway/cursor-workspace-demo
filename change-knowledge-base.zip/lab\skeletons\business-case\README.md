# Business case skeleton

## Purpose

Copy-out starter for business case. Cite [[business-case]].

## Required canons

- [[business-case]]
- [[business-case-craft]]
- Workflow: [[write-business-case]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[business-case-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
