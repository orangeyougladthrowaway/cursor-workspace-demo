---
type: workflow
status: draft
id: change-knowledge-base-wf-079
concern: delivery
description: Sequence to produce post implementation review artefact.
derived_from:
  - "[[post-implementation-review]]"
  - "[[post-implementation-review-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write post implementation review

Agent-operable sequence for [[post-implementation-review]].

## Steps

1. **Retrieve** — theme atlas → [[post-implementation-review]] → [[post-implementation-review-craft]] → [[post-implementation-review-worked]] → skeleton `lab/skeletons/post-implementation-review/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[post-implementation-review]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
