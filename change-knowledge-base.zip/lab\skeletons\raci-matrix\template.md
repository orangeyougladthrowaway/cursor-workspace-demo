# RACI matrix

- **Standard:** [[raci-matrix]]
- **Owner:**
- **Phase:**

| Activity / decision | Role A | Role B | Role C | Role D |
| --- | --- | --- | --- | --- |
| | | | | |

**Legend:** R = Responsible · A = Accountable · C = Consulted · I = Informed
