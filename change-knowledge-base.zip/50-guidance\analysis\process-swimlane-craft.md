---
type: guidance
status: draft
id: change-knowledge-base-g-046
concern: analysis
description: How to produce process swimlane — what good looks like.
derived_from:
  - "[[process-swimlane]]"
updated: 2026-07-18
---

# Process swimlane craft

House how-to for [[process-swimlane]].

## House defaults

1. Label as-is vs to-be clearly; same event scope.
2. One task, one swimlane (BCS MBP rule).
3. Notation UML activity or BPMN — pick one per pack.
4. Link tasks to catalogue/use cases where they become system-supported.
5. Do not model system internals as business process.

## What good looks like

Ops recognises the as-is; to-be shows where automation/handoffs change.

## Done test

State labelled · actors · tasks · decisions · outcome · owner.

## Related

- [[process-swimlane]] · [[process-swimlane-worked]] · [[model-process-swimlane]] · skeleton `process-swimlane/`
