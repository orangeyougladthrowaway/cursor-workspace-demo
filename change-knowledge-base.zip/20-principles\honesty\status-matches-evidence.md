---
type: principle
status: draft
id: change-knowledge-base-p-007
category: honesty
description: Reported readiness and quality must match the evidence actually held.
derived_from:
  - "[[honesty]]"
updated: 2026-07-16
---

# Status matches evidence

Do not mark requirements or acceptance packs “ready” when unknowns, open conflicts, or missing warrants remain. Name the gap.
