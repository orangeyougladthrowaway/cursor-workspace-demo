# Risk focus skeleton

## Purpose

Copy-out starter for risk-based test focus. Cite [[risk-based-test-focus]] (`change-knowledge-base-s-015`).

## Required canons

- [[risk-based-test-focus]]
- Workflow: [[focus-by-risk]]

## Copy

1. Copy `focus.md` into the host work area.
2. Rate areas by likelihood × impact; map test depth; state tradeoffs.
3. Cite `change-knowledge-base-s-015`.

## Honesty

Skeleton ≠ doctrine. No exhaustive claims; escalate unknown domain risk.
