---
type: example
status: draft
id: change-knowledge-base-ex-003
description: Thin exemplar — reject vague adjective-only acceptance language.
derived_from:
  - "[[acceptance-criteria]]"
  - "[[write-acceptance-criteria]]"
updated: 2026-07-16
---

# Acceptance criteria thin

## When

Criteria say “the page should be user-friendly and fast.”

## When not

Observable Given/When/Then (or equivalent) with pass/fail tied to a requirement id.

## Choice

Fail [[acceptance-criteria]] / [[intent-must-be-testable]]. Rewrite to observables or escalate for measures. Do not pretend adjectives are done.
