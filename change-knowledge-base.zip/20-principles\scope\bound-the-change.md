---
type: principle
status: draft
id: change-knowledge-base-p-004
category: scope
description: State in-scope, out-of-scope, and deferred items explicitly for the change under analysis.
derived_from:
  - "[[scope-principle]]"
updated: 2026-07-16
---

# Bound the change

A problem frame and requirement pack name **in**, **out**, and **later**. Silent expansion is a method failure, not agility.
