# Decision log skeleton

## Purpose

Copy-out starter for decision log. Cite [[decision-log]].

## Required canons

- [[decision-log]]
- [[decision-log-craft]]
- Workflow: [[log-decision]]

## Copy

1. Copy `template.md` into the host work area.
2. Fill using craft guidance; compare to [[decision-log-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
