---
type: guidance
status: draft
id: change-knowledge-base-g-031
concern: verification
description: How to perform defect severity — house craft for TA08.
derived_from:
  - "[[defect-severity]]"
updated: 2026-07-18
---

# Defect severity craft

House how-to for TA08. Field tests: [[defect-severity]].

## House defaults

1. Severity from outcome impact; priority from release timing/politics separately.
2. Blocker = cannot proceed UAT/release for Must scope.
3. Document band definitions once per programme.
4. Disputes escalate to product owner with impact restated.

## Done test

Impact · band · rationale · priority distinct if needed.

## Related

- [[defect-severity]] · [[defect-severity-worked]] · [[common-case-coverage]]
