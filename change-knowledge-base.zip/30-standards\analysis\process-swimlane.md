---
type: standard
status: draft
id: change-knowledge-base-s-046
concern: analysis
description: Process swimlane — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[bound-the-change]]"
  - "[[name-who-matters]]"
  - "[[enough-to-decide]]"
updated: 2026-07-18
---

# Process swimlane

## Normally require

A **business process model** (swimlane) includes:

| Field | Test |
| --- | --- |
| State | As-is and/or to-be labelled |
| Elements | Event, actors/swimlanes, tasks, decisions, outcomes |
| Integrity | Task in one swimlane; flows make sense |
| Purpose | Supports gap, requirements, or improvement |

## Refuse / escalate

- Swimlanes without actors that exist in stakeholder map
- To-be without warrant

## How to produce

[[process-swimlane-craft]]. Worked: [[process-swimlane-worked]]. Skeleton: `lab/skeletons/process-swimlane/`.

## Related

- [[common-case-coverage]] · workflow [[model-process-swimlane]]
