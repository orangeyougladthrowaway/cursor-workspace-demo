---
type: guidance
status: draft
id: change-knowledge-base-g-011
concern: stakeholders
description: How to map stakeholders — influence, interest, engagement, no invented org lore.
derived_from:
  - "[[stakeholder-clarity]]"
  - "[[influence-interest-grid]]"
  - "[[influence-shapes-engagement]]"
updated: 2026-07-18
---

# Stakeholder clarity craft

House how-to for BA04. Field tests: [[stakeholder-clarity]].

## House defaults

1. List parties that can enable, block, or are materially affected — not the whole org chart.
2. Interest = what they care about for this change; escalate if unknown.
3. Influence = ability to enable/block (H/M/L). Engagement follows influence x interest ([[influence-interest-grid]]).
4. Decision clarity (RACI-style) is about who decides, not HR reporting lines.
5. Warrant each inclusion — role in outcome, not politics gossip.
6. Do not invent process/system owners — systems-knowledge-base / user.

## Decision rules

| Situation | Do |
| --- | --- |
| High influence, low interest | Keep informed lightly; escalate blockers early |
| High influence, high interest | Manage closely; early elicit |
| Unknown influence | Escalate; do not guess power |
| Org dump with no engagement | Fail quality — rewrite |

## Done test

Party named · interest/impact/influence · engagement matched · warrant · owner.

## Related

- [[stakeholder-clarity]] · [[map-stakeholders]] · [[stakeholder-clarity-worked]] · [[elicitation-craft]]
