---
type: workflow
status: draft
id: change-knowledge-base-wf-043
concern: requirements
description: Sequence to produce nonfunctional framing for BA11.
derived_from:
  - "[[nonfunctional-framing]]"
  - "[[nonfunctional-framing-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Frame nonfunctionals

Agent-operable sequence for BA11.

## Steps

1. **Retrieve** — theme atlas → [[nonfunctional-framing]] → [[nonfunctional-framing-craft]] → [[nonfunctional-framing-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[nonfunctional-framing]]; escalate Gaps.
5. **Cite** — `nonfunctional-framing` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
