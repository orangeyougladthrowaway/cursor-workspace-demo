---
type: standard
status: draft
id: change-knowledge-base-s-029
concern: governance
description: Kickoff honesty — usable bar for PM11.
derived_from:
  - "[[work-needs-mandate]]"
  - "[[bound-the-change]]"
  - "[[name-who-matters]]"
updated: 2026-07-18
---

# Kickoff honesty

## Normally require

A **kickoff** confirms before execution:

| Field | Test |
| --- | --- |
| Charter present | [[initiation-mandate]] fields agreed |
| Roles | Who does what this phase |
| Ways of working | Cadence, tools (facets only), escalation |
| Open risks/assumptions | Visible |
| Mandate check | Authoriser acknowledgment |

## Refuse / escalate

- Kickoff without mandate/outcome
- Hidden unknowns presented as settled

## How to produce

[[kickoff-honesty-craft]]. Worked: [[kickoff-honesty-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
