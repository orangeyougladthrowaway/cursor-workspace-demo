---
type: workflow
status: draft
id: change-knowledge-base-wf-041
concern: requirements
description: Sequence to produce assumption log for BA09.
derived_from:
  - "[[assumption-log]]"
  - "[[assumption-log-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Maintain assumption log

Agent-operable sequence for BA09.

## Steps

1. **Retrieve** — theme atlas → [[assumption-log]] → [[assumption-log-craft]] → [[assumption-log-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[assumption-log]]; escalate Gaps.
5. **Cite** — `assumption-log` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
