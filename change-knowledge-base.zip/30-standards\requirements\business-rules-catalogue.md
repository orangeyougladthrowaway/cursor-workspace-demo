---
type: standard
status: draft
id: change-knowledge-base-s-049
concern: requirements
description: Business rules catalogue — atomic warranted rules with precision links.
derived_from:
  - "[[claim-needs-warrant]]"
  - "[[elicit-before-invent]]"
  - "[[bound-the-change]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Business rules catalogue

## Normally require

A **business rules catalogue** includes:

| Field | Test |
| --- | --- |
| Rule id / statement | Clear, atomic |
| Type | Constraint / policy / procedure |
| Source | Warrant |
| Applies to | Process / entity / field named when material |
| Link | Process / catalogue / data map / AC |
| Status | Active / draft / retired |

When data load/historise/sync is in scope, material integrity/delete/hash rules belong here **or** on the field map — not only in chat.

## Refuse / escalate

- Rules invented to fill design
- Vague “data must be correct” without atomic statement

## How to produce

[[business-rules-catalogue-craft]]. Worked: [[business-rules-catalogue-worked]]. Skeleton: `lab/skeletons/business-rules-catalogue/`.

## Related

- [[common-case-coverage]] · workflow [[maintain-business-rules]] · [[data-model]] · [[precision-over-vagueness]]
