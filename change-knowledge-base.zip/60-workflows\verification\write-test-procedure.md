---
type: workflow
status: draft
id: change-knowledge-base-wf-076
concern: verification
description: Sequence to produce test procedure artefact.
derived_from:
  - "[[test-procedure]]"
  - "[[test-procedure-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write test procedure

Agent-operable sequence for [[test-procedure]].

## Steps

1. **Retrieve** — theme atlas → [[test-procedure]] → [[test-procedure-craft]] → [[test-procedure-worked]] → skeleton `lab/skeletons/test-procedure/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[test-procedure]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
