---
type: workflow
status: draft
id: change-knowledge-base-wf-042
concern: analysis
description: Sequence to produce options communication for BA10.
derived_from:
  - "[[options-communication]]"
  - "[[options-communication-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Communicate options

Agent-operable sequence for BA10.

## Steps

1. **Retrieve** — theme atlas → [[options-communication]] → [[options-communication-craft]] → [[options-communication-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[options-communication]]; escalate Gaps.
5. **Cite** — `options-communication` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
