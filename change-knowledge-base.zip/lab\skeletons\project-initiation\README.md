# Project initiation skeleton

## Purpose

Copy-out starter for an initiation brief/charter. Cite [[initiation-mandate]] (`change-knowledge-base-s-008`).

## Required canons

- [[initiation-mandate]]
- Workflow: [[initiate-project]]

## Copy

1. Copy `charter.md` into the host work area.
2. Fill mandate · outcome · scope · stakeholders · success measure. Use `unknown — escalate` for missing authority/justification.
3. Cite `change-knowledge-base-s-008`.

## Honesty

Skeleton ≠ doctrine. No self-authorised scope; no invented justification.
