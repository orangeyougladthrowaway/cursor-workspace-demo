---
type: example
status: draft
id: change-knowledge-base-ex-040
description: Worked exemplar — workshop facilitation good vs bad.
derived_from:
  - "[[workshop-facilitation]]"
  - "[[workshop-facilitation-craft]]"
updated: 2026-07-18
---

# Workshop facilitation worked

## Bad

Two-hour chat; no decision; "we aligned."

## Good

Question: Must vs Should for R1–R4 this release. Outputs: MoSCoW table agreed; R4 Won't; conflict on age rule parked to CFO. Owner notes published same day.

## Related

- [[workshop-facilitation-craft]] · skeleton if present under lab/skeletons/
