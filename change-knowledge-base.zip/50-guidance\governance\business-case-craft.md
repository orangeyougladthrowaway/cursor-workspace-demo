---
type: guidance
status: draft
id: change-knowledge-base-g-042
concern: governance
description: How to produce business case — what good looks like.
derived_from:
  - "[[business-case]]"
updated: 2026-07-18
---

# Business case craft

House how-to for [[business-case]].

## House defaults

1. Scale depth to risk: one-pager OK for small; fuller CBA for large.
2. Options comparable (outcome, cost, time, risk).
3. Recommendation separate from option list.
4. Review at gates; update when scope/cost shifts ([[control-the-delta]]).
5. Link [[terms-of-reference]] / [[initiation-mandate]].

## What good looks like

Sponsor can choose with eyes open; rejected options recorded; benefits not vague adjectives.

## Done test

Options · costs/benefits honesty · recommendation · ask · owner.

## Related

- [[business-case]] · [[business-case-worked]] · [[write-business-case]] · skeleton `business-case/`
