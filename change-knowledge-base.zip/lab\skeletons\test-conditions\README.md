# Test conditions skeleton

## Purpose

Copy-out starter for a traceable test-condition set. Cite [[test-conditions]] (`change-knowledge-base-s-014`).

## Required canons

- [[test-conditions]] · [[test-condition-derivation]] · [[boundary-equivalence-thinking]]
- Workflow: [[derive-test-conditions]]

## Copy

1. Copy `conditions.md` into the host work area.
2. Derive conditions per source id; add boundary/negative variants.
3. Cite `change-knowledge-base-s-014`. Do not write executable tests (out of change-knowledge-base scope).

## Honesty

Skeleton ≠ doctrine. No source-less conditions; escalate untestable intent.
