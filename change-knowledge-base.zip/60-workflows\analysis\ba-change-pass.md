---
type: workflow
status: draft
id: change-knowledge-base-wf-017
concern: analysis
description: End-to-end BA change pass — sequence BA cells without skipping retrieve or escalate.
derived_from:
  - "[[problem-framing]]"
  - "[[stakeholder-clarity]]"
  - "[[elicitation-discipline]]"
  - "[[requirements-quality]]"
  - "[[requirements-prioritisation]]"
  - "[[acceptance-criteria]]"
  - "[[requirements-traceability]]"
  - "[[project-artefact-pack]]"
  - "[[change-artefact-policy]]"
  - "[[small-change-control]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-20
---

# Ba change pass

One supervised pass across the BA cell set. **Not** a curriculum — a dependency order.

## Sequence

1. **Frame** — [[frame-problem]] (`change-knowledge-base-s-001`). Stop if problem/outcome missing.
2. **Stakeholders** — [[map-stakeholders]] (`change-knowledge-base-s-004`) + [[influence-interest-grid]]. Stop if parties/influence unknown and material.
3. **Elicit** — [[elicit-requirements]] (`change-knowledge-base-s-007`) for material unknowns. Do not skip to a “complete” pack.
4. **Requirements quality** — [[assess-requirements-quality]] (`change-knowledge-base-s-002`).
5. **Prioritise** — [[prioritise-requirements]] (`change-knowledge-base-s-005`) with named framework + tradeoffs.
6. **Acceptance** — [[write-acceptance-criteria]] (`change-knowledge-base-s-003`) for in-scope/Must (or agreed band).
7. **Trace** — [[trace-requirements]] (`change-knowledge-base-s-006`). Honesty of coverage.
8. **Document pack (policy-selected)** — only items marked Produce on the plan under [[change-artefact-policy]] / [[project-artefact-pack]] (catalogue, models, NFR, rules, gap, assumption log, …). Do not emit the full menu by default.
9. **Verify pass** — each artefact cites its `id`; open escalations listed; M-set still accounted; no green-wash.

## Branching

- **Class path** ([[change-artefact-policy]] §7 · [[small-change-control]]): **micro-fix** — prefer named cells (often Acceptance + catalogue delta if intent moves); do not auto-run this full pass. **Enhancement** — thinned pass OK when the plan names which steps run/skip. **Project / regulatory** — this sequence is the default.
- Any step may **escalate** and pause the pass.
- Re-enter after new warrants; record deltas ([[control-the-delta]]).
- Skip a step only with explicit “not needed because …” tied to scope — not convenience or “it’s BAU.”

## Skeleton

`lab/skeletons/ba-change-pass/` — checklist citing this workflow.

## Forbidden

- Jumping to AC or prioritisation with no frame/warrants
- Inventing domain facts to keep the pass “green”
- Treating this order as the only forever process — amend change-knowledge-base if practice fights it
