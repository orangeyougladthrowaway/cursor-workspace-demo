"""Wikilink rules — doctrine notes; targets may be doctrine or lab indexes."""

from __future__ import annotations

import re

import pytest

from tests.vault import (
    all_linkable_stems,
    extract_wikilinks,
    iter_notes,
    read_text,
    rel_posix,
)


@pytest.fixture(scope="module")
def stems() -> set[str]:
    return all_linkable_stems()


def test_wikilinks_resolve_to_existing_notes(stems: set[str]) -> None:
    broken: list[str] = []
    for path in iter_notes():
        for target in extract_wikilinks(read_text(path)):
            if "/" in target or "\\" in target:
                broken.append(f"{rel_posix(path)} -> path-style [[{target}]]")
            elif target.endswith((".md", ".mdc")):
                broken.append(f"{rel_posix(path)} -> extension [[{target}]]")
            elif target not in stems:
                broken.append(f"{rel_posix(path)} -> missing [[{target}]]")
    assert not broken, "Broken wikilinks:\n" + "\n".join(broken[:50])


def test_no_path_style_wikilink_targets(stems: set[str]) -> None:
    offenders: list[str] = []
    for path in iter_notes():
        for target in extract_wikilinks(read_text(path)):
            if re.search(r"[/\\]", target):
                offenders.append(f"{rel_posix(path)}: [[{target}]]")
    assert not offenders, "\n".join(offenders)
