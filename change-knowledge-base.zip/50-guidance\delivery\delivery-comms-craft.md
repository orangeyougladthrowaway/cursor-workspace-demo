---
type: guidance
status: draft
id: change-knowledge-base-g-027
concern: delivery
description: How to perform delivery comms — house craft for PM10.
derived_from:
  - "[[delivery-comms]]"
updated: 2026-07-18
---

# Delivery comms craft

House how-to for PM10. Field tests: [[delivery-comms]].

## House defaults

1. Executives: outcomes + decisions; partners: milestones + deps.
2. Rhythm beats ad-hoc panic.
3. Status craft rules apply in every channel.
4. Unblock asks go to the person who can act.

## Done test

Audiences · rhythm · content bar · owner.

## Related

- [[delivery-comms]] · [[delivery-comms-worked]] · [[common-case-coverage]]
