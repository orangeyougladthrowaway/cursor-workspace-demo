---
type: standard
status: draft
id: change-knowledge-base-s-026
concern: planning
description: Delivery dependencies — usable bar for PM08.
derived_from:
  - "[[enough-to-decide]]"
  - "[[bound-the-change]]"
  - "[[estimate-shows-uncertainty]]"
updated: 2026-07-18
---

# Delivery dependencies

## Normally require

A **dependency view** includes:

| Field | Test |
| --- | --- |
| Dependency | What we need from whom |
| Need-by | Date or milestone |
| Status | Met / at risk / broken |
| Impact if late | Plan effect |
| Owner | Internal watcher + external contact |

## Refuse / escalate

- Hidden external deps
- Fake need-by without counterparty acknowledgment — escalate

## How to produce

[[delivery-dependencies-craft]]. Worked: [[delivery-dependencies-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
