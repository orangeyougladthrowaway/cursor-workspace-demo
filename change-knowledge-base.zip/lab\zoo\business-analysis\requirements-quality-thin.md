---
type: example
status: draft
id: change-knowledge-base-ex-002
description: Thin exemplar — mark requirements not-ready when warrants are missing.
derived_from:
  - "[[requirements-quality]]"
  - "[[assess-requirements-quality]]"
updated: 2026-07-16
---

# Requirements quality thin

## When

A pack lists “must support legacy process X” with no systems-knowledge-base cite and no stakeholder warrant.

## When not

Each material requirement has a clear warrant or explicit escalate.

## Choice

Fail the warranted test in [[requirements-quality]]. Status stays not-ready ([[status-matches-evidence]]). Escalate process X to systems-knowledge-base/user — do not invent the rule.
