# Test case skeleton

## Purpose

Copy-out starter for test case. Cite [[test-case]].

## Required canons

- [[test-case]]
- [[test-case-craft]]
- Workflow: [[write-test-case]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[test-case-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
