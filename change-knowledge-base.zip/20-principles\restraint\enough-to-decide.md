---
type: principle
status: draft
id: change-knowledge-base-p-010
category: restraint
description: Produce the minimum artefact that supports the next decision; escalate unknowns instead of inventing — without licensing vague in-scope grain.
derived_from:
  - "[[restraint]]"
updated: 2026-07-20
---

# Enough to decide

Stop when the artefact supports the next decision. Missing domain facts → escalate to systems-knowledge-base/user. Do not invent process lore to fill fields.

**Not a vagueness licence.** For topics already in scope, [[precision-over-vagueness]] still applies: name actionable grain or mark Gap/blocked. “Minimum” means no invented filler and no out-of-scope encyclopaedia — not adjective-only Ready rows.
