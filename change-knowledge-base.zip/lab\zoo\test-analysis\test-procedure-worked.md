---
type: example
status: draft
id: change-knowledge-base-ex-076
description: Worked exemplar — test procedure good vs bad.
derived_from:
  - "[[test-procedure]]"
  - "[[test-procedure-craft]]"
updated: 2026-07-18
---

# Test procedure worked

## Good

Proc-UAT-1: login Finance → filter 30+ → run TC-12 → record pass/fail → logout.

## Related

- [[test-procedure-craft]] · `lab/skeletons/test-procedure/`
