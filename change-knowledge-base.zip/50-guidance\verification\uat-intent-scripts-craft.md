---
type: guidance
status: draft
id: change-knowledge-base-g-032
concern: verification
description: How to perform uat intent scripts — house craft for TA09.
derived_from:
  - "[[uat-intent-scripts]]"
updated: 2026-07-18
---

# Uat intent scripts craft

House how-to for TA09. Field tests: [[uat-intent-scripts]].

## House defaults

1. One script section per Must intent/AC.
2. Language for business testers — not eng jargon.
3. Observe = same oracle as AC Then.
4. Keep out of vault dumps — produce in consumer workspace.

## Done test

Trace · steps · observe · preconditions · analysis-only.

## Related

- [[uat-intent-scripts]] · [[uat-intent-scripts-worked]] · [[common-case-coverage]]
