---
type: example
status: draft
id: change-knowledge-base-ex-005
description: Thin exemplar — refuse all-Must prioritisation without tradeoffs.
derived_from:
  - "[[requirements-prioritisation]]"
  - "[[prioritise-requirements]]"
updated: 2026-07-16
---

# Requirements prioritisation thin

## When

Every requirement is labelled Must / P1 with no deferred set.

## When not

Ordered bands with outcome/risk rationale and named deferrals.

## Choice

Fail [[requirements-prioritisation]] / [[rank-by-outcome]]. Force tradeoffs or escalate value rules — do not invent scores.
