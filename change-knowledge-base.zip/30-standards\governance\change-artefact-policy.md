---
type: standard
status: draft
id: change-knowledge-base-s-060
concern: governance
description: Change artefact policy — engagement class, mandatory vs recommended documents, exemptions, and gates.
derived_from:
  - "[[work-needs-mandate]]"
  - "[[bound-the-change]]"
  - "[[enough-to-decide]]"
  - "[[precision-over-vagueness]]"
  - "[[artefact-has-owner]]"
  - "[[link-across-artefacts]]"
  - "[[tradeoff-visible]]"
  - "[[status-matches-evidence]]"
updated: 2026-07-20
---

# Change artefact policy

House law for **which** project documents are required. Shapes and quality live in [[project-artefact-pack]] and cell standards. This note answers: class → mandatory / recommended / optional; who may exempt; what gates expect.

Agents and staff **do not** invent a parallel mandatory set. Classify → apply the table → tailor only via recorded exemption.

## Normally require

### 1. Engagement class (name one)

| Class | When |
| --- | --- |
| **micro-fix** | Single bounded defect/tweak; clear owner; hours–few days; no new outcome narrative |
| **enhancement** | Increment inside an existing live mandate/product; weeks; limited new stakeholders |
| **project** | Distinct initiative with mandate, outcome, and mobilised delivery |
| **programme** | Multiple related projects; this policy applies **per constituent project** plus programme-level RAID/status (escalate if programme pack undefined) |
| **regulatory** | External/compliance deadline or auditability dominates; treat as **project** minimums **plus** mandatory trace + completion/sign-off |

**BAU / small change:** not separate classes. Routine live-product updates map to **micro-fix** or **enhancement** (see [[small-change-control]]). Do not invent a sixth class in chat.

If class is unclear → ask sponsor/PM; do not default to “full pack” silently or to micro-fix for convenience.

### 2. Obligation codes

| Code | Meaning |
| --- | --- |
| **M** | Mandatory for the class — produce or **exempt** (see below) |
| **R** | Recommended — default include; skip only with explicit “not needed because…” on the plan |
| **O** | Optional — produce when the risk/question needs that shape |
| **—** | Not expected for the class |

### 3. Minimum pack by class

Cell-home artefacts (problem frame, AC, status, etc.) appear where they are the usual SoT. Pack stems are from [[project-artefact-pack]].

| Artefact / cell home | micro | enh | project | regulatory |
| --- | --- | --- | --- | --- |
| Initiation / charter ([[initiation-mandate]]) | R | M | M | M |
| Terms of reference ([[terms-of-reference]]) | — | O | R | R |
| Business case ([[business-case]]) | — | O | R | M |
| Problem frame ([[problem-framing]]) | R | M | M | M |
| Stakeholder clarity ([[stakeholder-clarity]]) | R | M | M | M |
| RACI ([[raci-matrix]]) | O | R | M | M |
| Kickoff honesty ([[kickoff-honesty]]) | — | R | M | M |
| Elicitation record ([[elicitation-discipline]]) | O | R | M | M |
| Requirements catalogue ([[requirements-catalogue]]) | O | R | M | M |
| Requirements quality / prioritisation / RTM | R | M | M | M |
| Acceptance criteria ([[acceptance-criteria]]) | M | M | M | M |
| Gap analysis ([[gap-analysis]]) | — | O | R | R |
| Use case ([[use-case]]) | — | O | R | R |
| Process swimlane ([[process-swimlane]]) | — | O | R | R |
| Data model ([[data-model]]) | — | O | R* | R* |
| NFR schedule ([[nfr-schedule]]) | O | R | M | M |
| Business rules catalogue ([[business-rules-catalogue]]) | — | O | R | R |
| Assumption log ([[assumption-log]]) | R | M | M | M |
| Delivery plan ([[plan-honesty]]) | O | M | M | M |
| Quality plan ([[quality-plan]]) | — | O | R | M |
| Communications plan ([[communications-plan]]) | — | O | R | R |
| RAID pack ([[raid-pack]]) | R | M | M | M |
| Decision log ([[decision-log]]) | R | M | M | M |
| Change control ([[change-control]]) | O | M | M | M |
| Status reporting ([[status-reporting-honesty]]) | O | M | M | M |
| Test conditions / intent coverage | R | M | M | M |
| Test plan ([[test-plan]]) | O | R | M | M |
| Test case / procedure ([[test-case]], [[test-procedure]]) | O | R | R | M |
| Defect clarity ([[defect-clarity]]) | M | M | M | M |
| UAT readiness ([[uat-readiness]]) | O | R | M | M |
| UAT sign-off ([[uat-sign-off]]) | O | R | M | M |
| Test completion report ([[test-completion-report]]) | — | O | R | M |
| Closure ([[closure-confirmation]]) | R | M | M | M |
| Post-implementation review ([[post-implementation-review]]) | — | O | R | R |

**Programme:** apply **project** column to each constituent; add programme-level RAID + status as **M**; escalate for a dedicated programme pack if needed.

\* **Data / integration override:** if the engagement **loads, historises, or syncs** material data (API, file, DB), treat [[data-model]] as **M** for enhancement/project/regulatory **and for micro-fix when stores are touched**, and apply the field-map precision bar on [[data-model]] / [[requirements-catalogue]] / [[acceptance-criteria]]. **Field-map rows on the data-model artefact are mandatory for Ready** — citing eng DDL alone does not satisfy. Prefer [[business-rules-catalogue]] **R→include** for material delete/hash/completeness rules. Name the override on the plan.

### 3b. Precision gate (all classes)

Before eng implement (and before Ready on catalogue/AC/data model/NFR/plan where material): in-scope rows must meet [[precision-over-vagueness]]. Adjective-only, table-name-only data intent, happy-path-only historisation AC, or plan exits without AC/evidence pointers → not Ready; Gap or deepen. Does not override exemptions — exemptions must accept residual imprecision risk explicitly.

### 4. Substitution (allowed collapses)

| Need | May be satisfied by | When |
| --- | --- | --- |
| ToR | Initiation charter | Charter already has BOSCARD-equivalent fields |
| Assumption log | RAID **A** lane | RAID maintained and A rows owned |
| Separate comms plan | Delivery plan + status cadence | Audience/cadence named there |
| Use case + swimlane | Catalogue + AC only | Process/interaction risk is low and stated |
| Test procedure | Test case steps | Cases are runnable without a separate script pack |
| Business case | Mandate warrant + sponsor note | Enhancement/micro only; not regulatory |

Substitutions are **named on the plan** (which artefact covers which M). Silent dual SoTs forbidden ([[link-across-artefacts]]).

### 5. Exemptions

- Who may exempt an **M**: sponsor or named governance owner (PM by default if mandate allows).
- Agent/BA/PM may **propose** exemption; may not self-authorise.
- Every exemption: one [[decision-log]] row (or RAID decision pointer) with rationale, residual risk, and review date.
- Convenience, “we’re agile”, or missing time are **not** valid sole rationales without residual-risk acceptance.

### 6. Gates (honesty)

| Gate | Expect |
| --- | --- |
| Before eng implement | Change-task acceptance + class + M-set listed; AC for in-scope Must (or agreed band); **precision gate** passed (or Gap/exemption logged) |
| Before UAT | UAT readiness (or exempted); intent coverage honesty |
| Before go-live / close | UAT sign-off and/or completion as class requires; closure confirmation |
| Status Red/Amber on missing M | Name the gap; do not green-wash ([[status-matches-evidence]]) |

Gates apply to **micro-fix and enhancement** as well as project — thinner M-set, same honesty.

### 7. Process path (class → cells vs journey)

Document mandatoriness is this standard’s table. **Process path** (which cells or journey to run) is planned in [[plan-change-work]] and operated per [[small-change-control]] / [[change-artefact-policy-craft]]:

| Class | Default path |
| --- | --- |
| micro-fix | **Named cells** covering the M-set (often AC + defect clarity); full BA/PM/TA journey not default |
| enhancement | **Selected cells** or **thinned** profile pass; plan names skips |
| project / regulatory | Profile **journey** default ([[ba-change-pass]] · [[pm-delivery-pass]] · [[ta-analysis-pass]]) |
| programme | Per child project path + programme RAID/status |

## How to apply

[[change-artefact-policy-craft]] · [[small-change-control]]. Plan sequence: [[plan-change-work]]. Menu of shapes: [[project-artefact-pack]].

## Refuse / escalate

- No class named → stop; ask
- Skipping **M** without logged exemption → refuse “done” / Ready claims
- Inventing domain content to fill mandatory shells → escalate Gap
- Treating [[project-artefact-pack]] alone as mandatory law → wrong altitude; this standard wins on *whether*

## Not this standard

Field tests for a single document (each artefact standard); produce sequences (workflows); domain SoR (systems-knowledge-base); harness Task schema.

## Related

- [[project-artefact-pack]] · [[plan-change-work]] · [[small-change-control]] · [[common-case-coverage]] · [[staff-agent-projection]] · [[decision-log]]
