# Business rules catalogue

- **Standard:** [[business-rules-catalogue]] (`change-knowledge-base-s-049`)
- **Owner:**
- **Precision:** atomic, warranted, linked — no invented design fillers ([[precision-over-vagueness]])

| Id | Statement (atomic) | Type | Source / warrant | Applies to (process / entity / field) | Links (catalogue / data map / AC) | Status |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |

## Data / historisation rules (when applicable)

| Id | Rule (e.g. absence≡delete only if complete snapshot) | Linked map / req ids | Status |
| --- | --- | --- | --- |
| | | | |
