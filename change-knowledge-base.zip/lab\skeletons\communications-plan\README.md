# Communications plan skeleton

## Purpose

Copy-out starter for communications plan. Cite [[communications-plan]].

## Required canons

- [[communications-plan]]
- [[communications-plan-craft]]
- Workflow: [[write-communications-plan]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[communications-plan-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
