---
type: category
status: draft
id: change-knowledge-base-cat-restraint
description: Spine for restraint — enough analysis to decide; stop before encyclopaedia.
updated: 2026-07-16
---

# Restraint

## Theme

Over-analysis and template hoards delay decisions without improving them. Restraint forbids **invention** and encyclopaedia — not actionable grain ([[precision]]).

## Leaves

- [[enough-to-decide]]
