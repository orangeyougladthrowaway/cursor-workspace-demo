---
type: principle
status: draft
id: change-knowledge-base-p-018
category: honesty
description: Estimates carry uncertainty — express ranges and assumptions, never false single-point certainty.
derived_from:
  - "[[honesty]]"
updated: 2026-07-16
---

# Estimate shows uncertainty

A plan estimate states its **uncertainty and assumptions**. A single confident number with no range or basis is estimate theatre, not honesty.
