---
type: guidance
status: draft
id: change-knowledge-base-g-054
concern: verification
description: How to produce test plan — what good looks like.
derived_from:
  - "[[test-plan]]"
updated: 2026-07-18
---

# Test plan craft

House how-to for [[test-plan]].

## House defaults

1. One project test plan; thin UAT level plan may nest.
2. Approach follows [[risk-based-test-focus]].
3. Trace to catalogue/AC.
4. Analysis grain: no pytest design here.
5. Environment/data needs listed; unknown → escalate.

## What good looks like

Team knows what "tested enough" means before execution starts.

## Done test

Scope · approach · entry/exit · deliverables · roles · risks.

## Related

- [[test-plan]] · [[test-plan-worked]] · [[write-test-plan]] · skeleton `test-plan/`
