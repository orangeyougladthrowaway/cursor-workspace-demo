---
type: workflow
status: draft
id: change-knowledge-base-wf-033
concern: verification
description: Verify a change artefact against its change-knowledge-base standard field tests; escalate Gaps.
domain: ["cursor"]
derived_from:
  - "[[staff-agent-projection]]"
  - "[[produce-change-artefact]]"
  - "[[change-artefact-policy]]"
  - "[[small-change-control]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Verify change artefact

Use after [[produce-change-artefact]] or when asked to check an existing methods artefact.

## Preconditions

- Artefact under review
- Named standard `id` (or derivable from the producing workflow)
- Field tests available on that standard

If the standard cannot be identified, stop and escalate.

## Retrieve

1. Open the producing cell workflow and its standard (via atlas / `derived_from`).
2. Open [[staff-agent-projection]] for lane walls (systems-knowledge-base vs engineering).
3. If a plan named a class under [[change-artefact-policy]], keep that M/R account and process path ([[small-change-control]]) in view.
4. Open [[precision-over-vagueness]] for requirements / AC / data / conditions artefacts.
5. Open any cited systems-knowledge-base paths only as **read** evidence — do not invent.

## Steps

1. Map each required field / field test to evidence on the artefact.
2. Mark missing, invented, untestable, or **imprecise in-scope grain** as Gaps.
3. Check cite honesty (`id` present where load-bearing).
4. Check status/evidence honesty — no green-wash ([[status-matches-evidence]]).
5. If verifying a **set** or journey close: confirm every **M** is Produce-done, Substitute-named, or Exempt-logged — else fail / block.
6. Verdict: pass, fail, or blocked (escalations open).

## Output

- Field-test results
- Gaps / escalations (including unmet **M** without exemption; imprecise grain)
- Cited `id`s
- Verdict

## Handoff

Passing or explicitly qualified results → [[review-change-artefact]]. Failures return to [[produce-change-artefact]].

## Forbidden

- Soft “looks fine” without field tests
- Inventing domain acceptance to close Gaps
- Treating zoo/skeleton as sole law
- Passing vague Ready rows that fail [[precision-over-vagueness]]
- Passing a journey while mandatory policy items are silently missing
