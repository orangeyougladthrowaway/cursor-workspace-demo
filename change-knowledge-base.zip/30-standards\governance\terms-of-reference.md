---
type: standard
status: draft
id: change-knowledge-base-s-041
concern: governance
description: Terms of reference — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[work-needs-mandate]]"
  - "[[bound-the-change]]"
  - "[[enough-to-decide]]"
  - "[[name-who-matters]]"
updated: 2026-07-18
---

# Terms of reference

## Normally require

A **Terms of Reference** (BOSCARD or equivalent) for a study/project includes:

| Field | Test |
| --- | --- |
| Background | Why this work exists |
| Objectives | Business/project objectives observable enough to judge |
| Scope | In / out / constraints |
| Constraints | Time, cost, regulatory, technical bounds |
| Assumptions | Named; impact if false |
| Reporting / stakeholders | Who commissions, who is informed |
| Deliverables | Named outputs of the engagement |

## Refuse / escalate

- Objectives that are only activity ("do analysis") with no outcome
- Invented mandate — escalate sponsor

## How to produce

[[terms-of-reference-craft]]. Worked: [[terms-of-reference-worked]]. Skeleton: `lab/skeletons/terms-of-reference/`.

## Related

- [[common-case-coverage]] · workflow [[write-terms-of-reference]]
