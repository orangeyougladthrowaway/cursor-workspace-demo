# Requirements catalogue

- **Standard:** [[requirements-catalogue]] (`change-knowledge-base-s-044`)
- **Owner:**
- **Governing frame / ToR:**
- **Precision:** [[precision-over-vagueness]] — Ready only when in-scope grain is named (or Gap)

| Id | Name | Description (actor–action–object + grain) | Type | Source | Owner | Priority | Rationale | Cross-refs | AC refs | Status | Ver |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | | | | |

## Data / store / API requirements (fill when applicable)

For each data-moving Must/Should, complete **or** link a field-map section in [[data-model]] (map artefact required — eng DDL alone is not enough):

| Req id | Source (system/module/endpoint) | Target (db.schema.table or DDL path) | Business key | Attributes / map ref | Transform / historise / delete rule | Completeness (snapshot vs delta) | Vendor / systems further-detail link |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | |

## Notes / open conflicts / Gaps

-
