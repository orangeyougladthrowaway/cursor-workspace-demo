---
type: example
status: draft
id: change-knowledge-base-ex-046
description: Worked exemplar — delivery dependencies good vs bad.
derived_from:
  - "[[delivery-dependencies]]"
  - "[[delivery-dependencies-craft]]"
updated: 2026-07-18
---

# Delivery dependencies worked

## Bad

Plan assumes vendor API; no row; date firm.

## Good

| Dep | Need-by | Status | Impact | Owners |
| --- | --- | --- | --- | --- |
| Vendor invoice API field | M2 10 Jul | Broken | M2 slip | PM / Vendor CSM |

## Related

- [[delivery-dependencies-craft]] · skeleton if present under lab/skeletons/
