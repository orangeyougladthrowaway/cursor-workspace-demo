---
type: example
status: draft
id: change-knowledge-base-ex-067
description: Worked exemplar — data model with field map good vs bad.
derived_from:
  - "[[data-model]]"
  - "[[data-model-craft]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Data model worked

Fictional initiative grain (not domain SoR).

## Bad

Tables copied from DB with no business meaning. Or: entity boxes only while “load to ODS” is Must — no field map.

## Good (logical)

Invoice (1) — unpaid status; Customer (1); Invoice 1..* line. Identifier: invoice number. SoR: finance system Gap confirm.

## Good (data/integration — field map excerpt)

| Map id | Source | Source field | Target | Transform | Historised? | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| FM-C-01 | CRM Contacts | id | ods.contact_history.contact_id | Pass-through | N (key) | Business key |
| FM-C-02 | CRM Contacts | Email | ods.contact_history.email | Lower trim | Y | Hash input |
| FM-C-03 | CRM Contacts | First_Name | ods.contact_history.first_name | Pass-through | Y | Hash input |
| FM-C-04 | CRM Contacts | Last_Name | ods.contact_history.last_name | Pass-through | Y | Hash input |
| FM-C-05 | CRM Contacts | Customer_Ref | ods.contact_history.customer_ref | Pass-through / derive ZOHO-{id} if empty | Y | Hash input |

Further-detail: vendor Contacts API URL on map header. Eng may own DDL file path as supporting SoT; map rows still required for Ready.

## Related

- [[data-model-craft]] · [[precision-over-vagueness]] · `lab/skeletons/data-model/`
