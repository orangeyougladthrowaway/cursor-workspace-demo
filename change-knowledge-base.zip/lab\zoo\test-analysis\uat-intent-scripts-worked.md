---
type: example
status: draft
id: change-knowledge-base-ex-053
description: Worked exemplar — uat intent scripts good vs bad.
derived_from:
  - "[[uat-intent-scripts]]"
  - "[[uat-intent-scripts-craft]]"
updated: 2026-07-18
---

# Uat intent scripts worked

## Bad

"Click around and see if it works."

## Good

Script UAT-R1: As Finance, filter 30+, confirm on-screen ids match known unpaid seed set S1; pass = count and ids match AC-R1-happy.

## Related

- [[uat-intent-scripts-craft]] · skeleton if present under lab/skeletons/
