---
type: guidance
status: draft
id: change-knowledge-base-g-043
concern: analysis
description: How to produce gap analysis — what good looks like.
derived_from:
  - "[[gap-analysis]]"
updated: 2026-07-18
---

# Gap analysis craft

House how-to for [[gap-analysis]].

## House defaults

1. As-is and to-be at same grain (process, capability, or POPIT view).
2. Gaps are differences, not a backlog dump.
3. Actions feed prioritisation and business case options.
4. Attach or link [[process-swimlane]] models when process change.

## What good looks like

Clear journey from evidence of today → target → actions without leaping to "buy X".

## Done test

As-is · to-be · gaps · actions · warrants · owner.

## Related

- [[gap-analysis]] · [[gap-analysis-worked]] · [[write-gap-analysis]] · skeleton `gap-analysis/`
