# Requirements traceability skeleton

## Purpose

Copy-out starter for frame ↔ requirement ↔ acceptance links. Cite [[requirements-traceability]] (`change-knowledge-base-s-006`).

## Required canons

- [[requirements-traceability]]
- [[requirements-quality]] · [[acceptance-criteria]]
- Workflow: [[trace-requirements]]

## Copy

1. Copy `trace.md` into the host work area.
2. Fill forward and backward links; mark gaps explicitly.
3. Cite `change-knowledge-base-s-006`. Do not invent domain rows to close gaps.

## Honesty

“Fully traced” only when gaps are zero or explicitly accepted.
