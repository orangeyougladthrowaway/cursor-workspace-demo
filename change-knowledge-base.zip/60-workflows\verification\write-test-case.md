---
type: workflow
status: draft
id: change-knowledge-base-wf-075
concern: verification
description: Sequence to produce test case artefact.
derived_from:
  - "[[test-case]]"
  - "[[test-case-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write test case

Agent-operable sequence for [[test-case]].

## Steps

1. **Retrieve** — theme atlas → [[test-case]] → [[test-case-craft]] → [[test-case-worked]] → skeleton `lab/skeletons/test-case/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[test-case]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
