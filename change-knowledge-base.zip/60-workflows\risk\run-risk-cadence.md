---
type: workflow
status: draft
id: change-knowledge-base-wf-020
concern: risk
description: Sequence to run the risk cadence against change-knowledge-base-s-010 — capture, score, respond, review.
derived_from:
  - "[[risk-cadence]]"
  - "[[risk-register-shape]]"
  - "[[raid-log]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Run risk cadence

Agent-operable sequence for PM03.

## Steps

1. **Retrieve** — [[project-management-atlas]] → [[risk-cadence]] (`change-knowledge-base-s-010`) → [[risk-register-shape]] · [[raid-log]] → skeleton `lab/skeletons/risk-register/`.
2. **Capture** — cause→event→effect statements; assign owners.
3. **Score** — probability × impact consistently.
4. **Respond** — avoid/reduce/transfer/accept per material risk.
5. **Review** — on a rhythm: re-score, close, escalate. Flag stale/all-green.
6. **Cite** — `change-knowledge-base-s-010`. Escalate domain likelihoods you cannot warrant.

## Forbidden

- Write-once register never reviewed
- Owner-less or response-less risks
- Invented probabilities for domain events
