---
type: guidance
status: draft
id: change-knowledge-base-g-045
concern: requirements
description: How to produce use case — what good looks like.
derived_from:
  - "[[use-case]]"
updated: 2026-07-18
---

# Use case craft

House how-to for [[use-case]].

## House defaults

1. Goal from actor perspective; avoid internal design.
2. Main success scenario first; alternatives/exceptions explicit.
3. One primary actor per use case; secondary actors named.
4. Keep diagram + description in sync with catalogue.
5. Agile teams may use stories for small slices; use cases for richer interactions.

## What good looks like

Stranger can walk the happy path and name failure paths; TA can derive conditions.

## Done test

Goal · actor · flows · postconditions · catalogue trace.

## Related

- [[use-case]] · [[use-case-worked]] · [[write-use-case]] · skeleton `use-case/`
