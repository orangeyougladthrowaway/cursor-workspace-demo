---
type: standard
status: draft
id: change-knowledge-base-s-024
concern: requirements
description: Requirements conflict — usable bar for BA12.
derived_from:
  - "[[status-matches-evidence]]"
  - "[[claim-needs-warrant]]"
  - "[[enough-to-decide]]"
updated: 2026-07-18
---

# Requirements conflict

## Normally require

A **conflict record** when stakeholders disagree on intent includes:

| Field | Test |
| --- | --- |
| Positions | Competing claims named with sources |
| Impact | What cannot proceed until resolved |
| Owner | Who decides |
| Status | Open / resolved with decision ref |
| Honesty | No silent pick of one side |

## Refuse / escalate

- Averaging contradictions into fake consensus
- Inventing a "compromise" that neither party warranted

## How to produce

[[requirements-conflict-craft]]. Worked: [[requirements-conflict-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
