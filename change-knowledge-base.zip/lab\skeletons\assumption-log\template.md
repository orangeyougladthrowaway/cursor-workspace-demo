# Assumption log

- **Standard:** [[assumption-log]]
- **Owner:**

| Id | Statement | Impact if false | Owner | Status | Links |
| --- | --- | --- | --- | --- | --- |
| | | | | | |
