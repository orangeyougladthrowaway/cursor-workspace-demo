# Intent coverage

- **Standard:** `change-knowledge-base-s-016` ([[intent-coverage]])
- **Owner:**

| Intent id | Dimension | Condition id(s) | Covered / Gap / Untestable |
| --- | --- | --- | --- |
| | | | |

## Gaps (named)

-

## Untestable → escalate to BA/acceptance

-
