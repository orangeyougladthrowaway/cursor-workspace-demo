---
type: example
status: draft
id: change-knowledge-base-ex-063
description: Worked exemplar — gap analysis good vs bad.
derived_from:
  - "[[gap-analysis]]"
  - "[[gap-analysis-craft]]"
updated: 2026-07-18
---

# Gap analysis worked

## Bad

"Gap: need AI." No as-is.

## Good

As-is: 4h CSV join at month-end. To-be: one filtered view+export. Gaps: no aged view; no export authz. Actions: R1/R2 Must; defer ML.

## Related

- [[gap-analysis-craft]] · `lab/skeletons/gap-analysis/`
