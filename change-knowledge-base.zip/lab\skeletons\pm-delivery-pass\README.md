# PM delivery pass skeleton

## Purpose

Checklist for one supervised PM pass across cells. Cite [[pm-delivery-pass]] (`change-knowledge-base-wf-024`).

## Required canons

- [[pm-delivery-pass]]
- Cell standards `change-knowledge-base-s-008` … `change-knowledge-base-s-013`

## Copy

1. Copy `pass.md` into the host work area.
2. Walk steps; run risk/status as recurring cadences.
3. Escalate honestly; do not green-wash.

## Honesty

Order is a default dependency, not sacred theatre. Cadences repeat.
