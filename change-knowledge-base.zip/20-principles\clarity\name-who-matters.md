---
type: principle
status: draft
id: change-knowledge-base-p-011
category: clarity
description: Name the people and roles whose interests can make or break the change — not an org chart dump.
derived_from:
  - "[[clarity]]"
updated: 2026-07-16
---

# Name who matters

Stakeholder work starts by naming **who can decide, block, use, or fund** the change. A contact list without interest/impact is not clarity.
