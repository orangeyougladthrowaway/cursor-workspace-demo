---
type: example
status: draft
id: change-knowledge-base-ex-065
description: Worked exemplar — use case good vs bad.
derived_from:
  - "[[use-case]]"
  - "[[use-case-craft]]"
updated: 2026-07-18
---

# Use case worked

## Bad

"Use case: Dashboard" with no flows.

## Good

UC1 Export aged unpaid — Actor Finance; Pre: filtered list; Main: choose Export → CSV matches filter; Alt: no permission → refuse; Post: file downloaded or refused.

## Related

- [[use-case-craft]] · `lab/skeletons/use-case/`
