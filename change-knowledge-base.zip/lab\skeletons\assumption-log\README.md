# Assumption log skeleton

## Purpose

Copy-out starter for assumption / dependency log. Cite [[assumption-log]].

## Required canons

- [[assumption-log]]
- [[assumption-log-craft]]
- Workflow: [[maintain-assumption-log]]

## Copy

1. Copy `template.md` into the host work area.
2. Fill using craft guidance; compare to [[assumption-log-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
