---
type: standard
status: draft
id: change-knowledge-base-s-054
concern: verification
description: Test plan — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[risk-based-test-focus]]"
  - "[[intent-coverage]]"
  - "[[uat-readiness]]"
  - "[[enough-to-decide]]"
updated: 2026-07-18
---

# Test plan

## Normally require

A **test plan** includes:

| Field | Test |
| --- | --- |
| Scope / items | What is tested / not |
| Approach | Levels, types, risk basis |
| Entry / exit | Observable |
| Deliverables | Cases, scripts, reports |
| Roles / schedule class | Who / when |
| Risks | Test risks + product risks link |

## Refuse / escalate

- Plan with no exit criteria
- Claiming exhaustive testing

## How to produce

[[test-plan-craft]]. Worked: [[test-plan-worked]]. Skeleton: `lab/skeletons/test-plan/`.

## Related

- [[common-case-coverage]] · workflow [[write-test-plan]]
