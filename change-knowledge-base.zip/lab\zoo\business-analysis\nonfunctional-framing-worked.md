---
type: example
status: draft
id: change-knowledge-base-ex-043
description: Worked exemplar — nonfunctional framing good vs bad.
derived_from:
  - "[[nonfunctional-framing]]"
  - "[[nonfunctional-framing-craft]]"
updated: 2026-07-18
---

# Nonfunctional framing worked

## Bad

Dashboard must be fast and secure.

## Good

| NFR | Measure | Context |
| --- | --- | --- |
| Perf | Aged list renders < 3s for 10k invoices p95 | Finance role, prod-like data |
| Security | Export denied without Finance-export permission | AC-R2-unauth |

Open: 3s threshold — sponsor confirm.

## Related

- [[nonfunctional-framing-craft]] · skeleton if present under lab/skeletons/
