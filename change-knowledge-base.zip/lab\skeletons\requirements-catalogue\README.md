# Requirements catalogue skeleton

## Purpose

Copy-out starter for requirements catalogue. Cite [[requirements-catalogue]].

## Required canons

- [[requirements-catalogue]]
- [[requirements-catalogue-craft]]
- Workflow: [[maintain-requirements-catalogue]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[requirements-catalogue-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine. Blank rows ≠ Ready. Data/store work needs the data-grain / field-map sections filled or Gap ([[precision-over-vagueness]]).
