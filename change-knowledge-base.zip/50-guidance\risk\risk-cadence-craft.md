---
type: guidance
status: draft
id: change-knowledge-base-g-008
concern: risk
description: How to run risk cadence — cause-event-effect, owners, responses, anti stale green.
derived_from:
  - "[[risk-cadence]]"
  - "[[risk-register-shape]]"
  - "[[risk-managed-continuously]]"
updated: 2026-07-18
---

# Risk cadence craft

House how-to for PM03. Field tests: [[risk-cadence]].

## Applies when

A change needs ongoing risk/issue discipline (not a one-time brainstorm dump).

## House defaults

1. **Write cause → event → effect.** “Cloud risk” is not a risk statement.
2. **Separate risks (may happen) from issues (happening now).** Mixing them muddies response.
3. **Score consistently** (P×I or agreed scale). Recalibrate when new evidence arrives.
4. **Every material risk has owner + response** (avoid / reduce / transfer / accept). Accept without owner is neglect.
5. **Cadence is a calendar commitment** (e.g. weekly with status). A register never opened is theatre.
6. **Close or escalate** — stale open risks with no movement fail honesty.
7. **Do not invent domain likelihoods.** Escalate to SME / systems-knowledge-base for technical probability.

## Decision rules

| Situation | Do |
| --- | --- |
| All risks Green forever | Challenge scoring or close; watermelon register fails |
| Issue misfiled as risk | Move to issues; treat with dates/owners |
| Response “monitor” only | Acceptable for low; material risks need a real control |
| New slip appears | Add/update risk same day; do not wait for ceremony |

## Done test

| Check | Pass means |
| --- | --- |
| Statements | Cause→event→effect clear |
| Owners | Named per material risk |
| Responses | Taxonomy applied |
| Rhythm | Last review date recent vs agreed cadence |
| Honesty | Movement visible; no wallpaper |

## Related

- [[risk-cadence]] · [[run-risk-cadence]] · [[risk-register-shape]] · [[risk-cadence-worked]] · [[status-reporting-craft]]
