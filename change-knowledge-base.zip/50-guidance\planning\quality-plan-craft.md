---
type: guidance
status: draft
id: change-knowledge-base-g-053
concern: planning
description: How to produce quality plan — what good looks like.
derived_from:
  - "[[quality-plan]]"
updated: 2026-07-18
---

# Quality plan craft

House how-to for [[quality-plan]].

## House defaults

1. Tie to artefact pack: catalogue, models, testware, UAT.
2. Entry/exit for major gates.
3. Distinguish QA assurance from QC detection.
4. Link [[test-plan]].

## What good looks like

Defects found early by design; gates have evidence.

## Done test

Standards · gates · roles · records · owner.

## Related

- [[quality-plan]] · [[quality-plan-worked]] · [[write-quality-plan]] · skeleton `quality-plan/`
