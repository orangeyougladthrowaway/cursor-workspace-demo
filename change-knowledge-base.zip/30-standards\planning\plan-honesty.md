---
type: standard
status: draft
id: change-knowledge-base-s-009
concern: planning
description: Plans show decomposed work, sequence, estimate ranges with assumptions, and honest dependencies.
derived_from:
  - "[[estimate-shows-uncertainty]]"
  - "[[bound-the-change]]"
  - "[[risk-shapes-attention]]"
  - "[[status-matches-evidence]]"
  - "[[enough-to-decide]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Plan honesty

## Normally require

A **plan** for a change includes:

| Field | Test |
| --- | --- |
| Work breakdown | Decomposed to items that can be owned/estimated ([[work-breakdown-structure]]) |
| Sequence | Dependencies and order — not a flat wishlist |
| Estimates | Ranges or bands with assumptions, not false single points ([[estimate-shows-uncertainty]], [[estimate-range-method]]) |
| Milestones | Decision or delivery checkpoints tied to outcome |
| Exit / evidence | Material items name **AC ids** (or Gap) and evidence type (unit / compose / live / doc) ([[precision-over-vagueness]]) |
| Assumptions / constraints | Stated and owned ([[bound-the-change]]) |
| Key risks | Cross-linked to the risk cadence ([[risk-cadence]]) |
| Owner | Who maintains the plan |

## Framework posture

WBS, milestone plans, rolling-wave and range-based estimation are portable and in scope. Vendor scheduling tool mechanics are out of scope.

## How to produce

[[plan-honesty-craft]]. Worked: [[plan-honesty-worked]].

## Refuse / escalate

- Single-point estimates presented as certainty ([[estimate-shows-uncertainty]])
- Plan with no dependencies or milestones
- “Build done” exits with no AC/evidence pointer when delivery claims completeness
- Effort/duration that depends on unknown domain facts → escalate

## Not this standard

Initiation mandate ([[initiation-mandate]]); status reporting ([[status-reporting-honesty]]); risk cadence ([[risk-cadence]]).
