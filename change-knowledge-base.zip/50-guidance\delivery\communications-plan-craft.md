---
type: guidance
status: draft
id: change-knowledge-base-g-052
concern: delivery
description: How to produce communications plan — what good looks like.
derived_from:
  - "[[communications-plan]]"
updated: 2026-07-18
---

# Communications plan craft

House how-to for [[communications-plan]].

## House defaults

1. Match audience to grain (exec vs delivery).
2. Rhythm beats ad-hoc panic.
3. Status craft rules apply.
4. Keep one page unless programme-scale.

## What good looks like

Right people get decidable information on time.

## Done test

Audience · rhythm · owner · content bar.

## Related

- [[communications-plan]] · [[communications-plan-worked]] · [[write-communications-plan]] · skeleton `communications-plan/`
