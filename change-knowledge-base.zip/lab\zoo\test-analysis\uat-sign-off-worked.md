---
type: example
status: draft
id: change-knowledge-base-ex-078
description: Worked exemplar — uat sign off good vs bad.
derived_from:
  - "[[uat-sign-off]]"
  - "[[uat-sign-off-craft]]"
updated: 2026-07-18
---

# Uat sign off worked

## Good

Accept Must R1/R2 with DEF-12 workaround; signed Finance ops lead 18 Jul.

## Related

- [[uat-sign-off-craft]] · `lab/skeletons/uat-sign-off/`
