---
type: guidance
status: draft
id: change-knowledge-base-g-024
concern: risk
description: How to perform issue risk split — house craft for PM07.
derived_from:
  - "[[issue-risk-split]]"
updated: 2026-07-18
---

# Issue risk split craft

House how-to for PM07. Field tests: [[issue-risk-split]].

## House defaults

1. If it is happening now → issue.
2. If it might happen → risk.
3. Promote risk to issue when triggered.
4. Status RAG reflects issues, not only risks.

## Done test

Correct bucket · owner · movement · no watermelon hide.

## Related

- [[issue-risk-split]] · [[issue-risk-split-worked]] · [[common-case-coverage]]
