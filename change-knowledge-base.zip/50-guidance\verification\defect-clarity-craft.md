---
type: guidance
status: draft
id: change-knowledge-base-g-010
concern: verification
description: How to write clear defects — expected vs actual, repro, severity reasoning.
derived_from:
  - "[[defect-clarity]]"
  - "[[defect-carries-evidence]]"
  - "[[risk-shapes-attention]]"
updated: 2026-07-18
---

# Defect clarity craft

House how-to for TA04. Field tests: [[defect-clarity]].

## Applies when

Observed behaviour violates a known condition/intent and must be reported for fix triage.

## House defaults

1. **Summary = what is wrong in one line** — not a novel, not “bug.”
2. **Expected vs actual both stated**, tied to intent/AC/condition id.
3. **Reproduction someone else can follow** (data, role, steps, environment class — no secrets).
4. **Evidence with provenance** (log ref, screenshot id, timestamp) — not a paste dump of PII.
5. **Severity from impact on outcome/users**, reasoned — not from reporter frustration.
6. **Trace to the condition/intent violated.** Orphan defects are hard to prioritise.
7. **If expected behaviour is ambiguous**, escalate to BA — do not invent the oracle.

## Decision rules

| Situation | Do |
| --- | --- |
| Cannot reproduce | Report as intermittent with attempts; do not close as “works on my machine” alone |
| Severity dispute | Re-state impact on outcome; escalate product owner — do not inflate |
| Wrong lane (build break) | Still clear defect; eng owns fix craft |
| Enhancement disguised as defect | Reframe; send to change control / backlog |

## Done test

| Check | Pass means |
| --- | --- |
| Expected/actual | Both present and intent-tied |
| Repro | Steps sufficient for another person |
| Evidence | Observation referenced |
| Severity | Impact reasoned |
| Trace | Condition/intent linked |

## Related

- [[defect-clarity]] · [[report-defect]] · [[defect-report-shape]] · [[defect-clarity-worked]] · [[test-conditions]]
