---
type: example
status: draft
id: change-knowledge-base-ex-033
description: Worked exemplar — controlled delta vs silent scope absorb.
derived_from:
  - "[[change-control]]"
  - "[[change-control-craft]]"
updated: 2026-07-18
---

# Change control worked

## Bad

Added predictive ML mid-flight; no record; plan dates unchanged.

## Good

| Field | Content |
| --- | --- |
| Delta | Add R4 predictive cashflow to release scope |
| Reason | Sponsor request 12 Jul — warrant weak (no problem frame) |
| Impact | Scope +; plan +15d; cost +; risk new model SoR |
| Options | (a) new frame+release (b) defer Won't (c) do nothing |
| Decision | **Reject for this release** — defer to new frame. Approver: CFO 13 Jul |
| Trace | R4 Won't; plan unchanged |
