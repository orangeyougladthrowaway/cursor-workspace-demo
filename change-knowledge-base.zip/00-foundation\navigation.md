---
type: foundation
status: draft
id: change-knowledge-base-fnd-navigation
description: Navigation — altitude × responsibility; themes-first atlases for PM/BA/TA.
updated: 2026-07-16
---

# Navigation

How this vault is browsed. **Folders and names are architecture.**

## Purpose of structure

change-knowledge-base stores **accumulated change-methods knowledge** as the base for staff agents and humans.  
It is **not** a task centre (“how do I BA today”). Maps **atlas** a body of knowledge; they do not answer with a job curriculum.  
`lab/` holds subordinate **praxis** — also not a task curriculum ([[layout]], [[praxis-ingestion]]).

## Hard naming rule

**No `and` as a compounding join** in folder or concept basenames. One folder = one responsibility. Split siblings.

## Four modes

| Mode | Question | Mechanism |
| --- | --- | --- |
| **Taxonomic** | What responsibility am I under? | Altitude → **responsibility folder** → note |
| **Atlas** | What body of knowledge? | `maps/themes/` (primary) or `maps/families/` |
| **Facet** | Which tool token? | Frontmatter `domain:` / `aliases:` |
| **Praxis** | What does applying a canon look like? | `lab/zoo/` · `lab/skeletons/` · `lab/stubs/` — indexed by [[lab-atlas]]; **never** a curriculum path |

Normative answers live in doctrine. Lab exemplars **cite** doctrine; they do not replace it.

## Axis 1 — altitude

```text
00-foundation → 10-philosophy → 20-principles → 30-standards
  → 40-patterns → 50-guidance / 60-workflows
```

Depend upward; specialise downward. See [[dependency-rules]].

## Axis 2 — responsibility folders

Principles: `20-principles/{concept}/{note}.md` with spine `{concept}/{concept}.md`.

Standards / patterns / guidance / workflows: `NN-layer/{responsibility}/{note}.md`.

### Principle concepts

`clarity` · `precision` · `evidence` · `risk` · `scope` · `value` · `verification` · `honesty` · `authority` · `change` · `restraint`

Extend by amending **this** note before inventing folders.

### Shared responsibilities (30 / 40 / 50 / 60)

| Folder | Responsibility |
| --- | --- |
| `scope` | Boundaries of work; change control of scope |
| `planning` | Plans, estimate honesty, sequencing |
| `risk` | Risk/issue discipline |
| `stakeholders` | Engagement; RACI-as-clarity (not org lore) |
| `requirements` | Elicitation, quality, traceability |
| `analysis` | BA techniques as portable method |
| `verification` | Test analysis; coverage of intent; acceptance |
| `governance` | Decisions, approvals, status honesty |
| `delivery` | Cadence, reporting, handoffs into build (not CI) |
| `knowledge` | Vault / agent projection |
| `authority` | Docs-as-authority for change artefacts |

**Primary folder only** per note. Prefer a **new sibling folder** over stuffing unrelated sections into one note.

**Forbidden at altitude L1:** org-chart folders (`pm/`, `ba/` as altitude trees). Roles are **themes/facets**, not responsibility trees.

## Axis 3 — maps (atlases)

```text
maps/
  catalog-maps.md
  themes/{theme}/…-atlas.md    # PRIMARY — pm / ba / ta / …
  families/{family}/…-atlas.md # optional lived programme bodies
```

| Kind | Folder | Role |
| --- | --- | --- |
| **Theme** | `maps/themes/{theme}/` | Cross-cutting method bodies — index draft+canonical notes elsewhere |
| **Family** | `maps/families/{family}/` | Lived programme-shape bodies (later) |

Atlas `concern` = the **leaf folder** (`business-analysis`, …) — not `themes` or `families`.

Prefer a new theme atlas over a fat multi-topic atlas. Banned: `_index.md`; `and`-joined names; curriculum playbooks.

## Axis 4 — facets

```yaml
id: change-knowledge-base-{type}-{nnn}
concern: <responsibility or theme leaf>
domain: []          # tool tags — jira, ado, confluence — never philosophy folders
aliases: []         # informal search only — never rename substitute
status: draft | canonical | deprecated
```

## Protocols

**Human:** theme atlas · or responsibility folder · or `domain` search.

**AI:**

1. Read [[README]] + this note.
2. Prefer `maps/themes/` atlases to locate a body of knowledge, then open linked notes.
3. For “show me the shape,” open [[lab-atlas]] after the canon — do **not** treat lab as sole law.
4. For “how complete?” open [[common-case-coverage]] — do **not** treat zoo counts as majority done.
5. Do **not** invent task journeys or `and`-joined folders.
6. Prefer `canonical`; cite `id`. Treat `temp/` as harvest, not doctrine.
7. Domain facts → systems-knowledge-base or user. Methods → change-knowledge-base. Code-level engineering/test craft is out of scope.
8. Structural edits: [[methodology]] + [[changing-this-bible]]. Praxis: [[praxis-ingestion]].

## Related

- [[layout]] · [[methodology]] · [[changing-this-bible]] · [[catalog-maps]] · [[common-case-coverage]] · [[purpose]]
