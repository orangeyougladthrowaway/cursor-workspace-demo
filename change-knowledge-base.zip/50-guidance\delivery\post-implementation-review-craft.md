---
type: guidance
status: draft
id: change-knowledge-base-g-059
concern: delivery
description: How to produce post implementation review — what good looks like.
derived_from:
  - "[[post-implementation-review]]"
updated: 2026-07-18
---

# Post implementation review craft

House how-to for [[post-implementation-review]].

## House defaults

1. Schedule PIR after enough live use to judge benefit.
2. Compare to business case measures.
3. Lessons are method pressure — amend vault when repeated.
4. Can extend [[closure-confirmation]] or stand alone.

## What good looks like

Org learns; benefit tracking has an owner.

## Done test

Outcome check · lessons · benefit status · recommendations · owner.

## Related

- [[post-implementation-review]] · [[post-implementation-review-worked]] · [[write-post-implementation-review]] · skeleton `post-implementation-review/`
