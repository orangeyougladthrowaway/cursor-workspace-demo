---
type: workflow
status: draft
id: change-knowledge-base-wf-027
concern: verification
description: Sequence to assess intent coverage against change-knowledge-base-s-016 with explicit gaps.
derived_from:
  - "[[intent-coverage]]"
  - "[[coverage-dimensions]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Assess intent coverage

Agent-operable sequence for TA03.

## Steps

1. **Retrieve** — [[test-analysis-atlas]] → [[intent-coverage]] (`change-knowledge-base-s-016`) → [[coverage-dimensions]] → skeleton `lab/skeletons/intent-coverage/`.
2. **Map** — intents (requirements/acceptance/risks) to conditions.
3. **Classify** — covered / gap / untestable per dimension.
4. **Escalate untestable** — back to BA/acceptance.
5. **Report honestly** — no test counts as proof; gaps named.
6. **Cite** — `change-knowledge-base-s-016`. Code/line coverage is out of change-knowledge-base scope.

## Forbidden

- Test counts or line coverage presented as intent coverage
- Hiding uncovered intents
- Silently passing untestable intents
