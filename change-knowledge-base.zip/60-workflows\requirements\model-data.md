---
type: workflow
status: draft
id: change-knowledge-base-wf-067
concern: requirements
description: Sequence to produce data model artefact.
derived_from:
  - "[[data-model]]"
  - "[[data-model-craft]]"
  - "[[precision-over-vagueness]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-20
---

# Model data

Agent-operable sequence for [[data-model]].

## Steps

1. **Retrieve** — theme atlas → [[data-model]] → [[data-model-craft]] → [[precision-over-vagueness]] → [[data-model-worked]] → skeleton `lab/skeletons/data-model/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **If data load/historise/sync** — add source→target field map; link vendor/systems further-detail URLs for out-of-vault wire shape; escalate unwarranted fields as Gaps.
5. **Verify** — field tests on [[data-model]]; escalate Gaps; do not invent domain facts.
6. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Table-name-only models for store work marked Ready
- Leaving methods lane into eng automation / invented SoR
