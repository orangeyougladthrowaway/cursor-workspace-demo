---
type: workflow
status: draft
id: change-knowledge-base-wf-021
concern: delivery
description: Sequence to report status against change-knowledge-base-s-011 with evidence-backed RAG.
derived_from:
  - "[[status-reporting-honesty]]"
  - "[[status-rag-honesty]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Report status

Agent-operable sequence for PM04.

## Steps

1. **Retrieve** — [[project-management-atlas]] → [[status-reporting-honesty]] (`change-knowledge-base-s-011`) → [[status-reporting-craft]] → [[status-rag-honesty]] → skeleton `lab/skeletons/status-report/`.
2. **Gather evidence** — milestones hit, risk movement, spend/slip.
3. **Set RAG** — follow [[status-reporting-craft]]; colour follows thresholds and evidence, not comfort.
4. **State tradeoffs** — slips, descopes named ([[tradeoff-visible]]).
5. **Name asks** — decisions/unblocks needed.
6. **Cite** — `change-knowledge-base-s-011`. Escalate unconfirmed domain outcomes rather than reporting them green.

## Forbidden

- Green while material risks/slips are open (watermelon)
- Progress with no evidence
- Reporting domain results not yet verified
