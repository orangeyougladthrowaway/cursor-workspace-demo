# Data model skeleton

## Purpose

Copy-out starter for data model. Cite [[data-model]].

## Required canons

- [[data-model]]
- [[data-model-craft]]
- Workflow: [[model-data]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[data-model-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine. For load/historise/sync, field-map rows are required for Ready — eng DDL link alone fails ([[precision-over-vagueness]]).
