# Requirements prioritisation

- **Standard:** `change-knowledge-base-s-005` ([[requirements-prioritisation]])
- **Owner:**
- **Requirements pack ref:**
- **Framework:** MoSCoW / value×risk / Now-Next-Later / other:

| Rank / band | Req id | Rationale (outcome / risk) | Decision |
| --- | --- | --- | --- |
| | | | Now / Next / Later / Out |

## Deferred or rejected

| Req id | Why |
| --- | --- |
| | |

## Open questions

-
