# Process swimlane model

- **Standard:** [[process-swimlane]]
- **Owner:**
- **State:** as-is / to-be (circle one)
- **Notation:** UML activity / BPMN
- **Triggering event:**

## Actors / swimlanes

|

## Model (attach diagram or describe)

| Step | Swimlane | Task / decision | Next |
| --- | --- | --- | --- |
| | | | |

## Outcomes

## Links to catalogue / use cases

|
