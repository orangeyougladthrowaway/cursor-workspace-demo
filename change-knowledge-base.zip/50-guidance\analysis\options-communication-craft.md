---
type: guidance
status: draft
id: change-knowledge-base-g-021
concern: analysis
description: How to perform options communication — house craft for BA10.
derived_from:
  - "[[options-communication]]"
updated: 2026-07-18
---

# Options communication craft

House how-to for BA10. Field tests: [[options-communication]].

## House defaults

1. Lead with the decision ask.
2. Comparable options in a table — apples to apples.
3. Recommendation separate from options list.
4. Do-nothing/defer always considered.
5. Escalate missing value/risk facts — do not invent ROI.

## Done test

Ask · >=2 options · tradeoffs · recommendation · deadline.

## Related

- [[options-communication]] · [[options-communication-worked]] · [[common-case-coverage]]
