---
type: standard
status: draft
id: change-knowledge-base-s-047
concern: requirements
description: Data model — logical model plus forced physical mapping grain for data/integration work.
derived_from:
  - "[[enough-to-decide]]"
  - "[[claim-needs-warrant]]"
  - "[[bound-the-change]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Data model

## Normally require

A **logical data / information model** includes:

| Field | Test |
| --- | --- |
| Entities / groupings | Named business data groups |
| Relationships | Degree + optionality |
| Keys / identifiers | Business identifiers called out |
| Rules | Material data rules noted |
| Trace | Link to catalogue where relevant |

## Data / integration / store work (additional — forced precision)

When the change **loads, historises, or syncs** data into a store (or across APIs), also require a **source→target field map** (section or linked artefact):

| Column | Test |
| --- | --- |
| Source | System + module/endpoint/file; **link** vendor or systems-KB further-detail URL when wire shape is out of vault scope |
| Source field | API/file field name as warranted (or Gap) |
| Target | `database.schema.table.column` — may **also** cite eng DDL path as supporting SoT, but **map rows remain mandatory** for Ready |
| Transform | Pass-through / cast / hash input / derived rule |
| Historised? | Y/N — feeds SCD/hash scope |
| Notes | Nullability, PII, delete semantics |

Logical entities alone are **not Ready** for that class of work. Physical DDL authorship remains engineering — BA owns the **mapping contract** and Gaps. Citing DDL without filled map rows fails Ready.

## Refuse / escalate

- Physical DB design dumped as BA doctrine *without* logical model and warrants
- Invented entities or fields without warrant
- Data-store Must scope with table names only and no field map
- “See eng DDL” as substitute for the field-map section

## How to produce

[[data-model-craft]]. Worked: [[data-model-worked]]. Skeleton: `lab/skeletons/data-model/`.

## Related

- [[common-case-coverage]] · workflow [[model-data]] · [[requirements-catalogue]] · [[precision-over-vagueness]]
