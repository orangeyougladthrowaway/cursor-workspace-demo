---
type: guidance
status: draft
id: change-knowledge-base-g-026
concern: governance
description: How to perform decision log — house craft for PM09.
derived_from:
  - "[[decision-log]]"
updated: 2026-07-18
---

# Decision log craft

House how-to for PM09. Field tests: [[decision-log]].

## House defaults

1. Log material decisions same day.
2. Link change requests and prioritisation outcomes.
3. Reversal needs a new entry (delta control).
4. Keep portable — not meeting minutes dumps.

## Done test

Decision · decider/date · options · consequences · links.

## Related

- [[decision-log]] · [[decision-log-worked]] · [[common-case-coverage]]
