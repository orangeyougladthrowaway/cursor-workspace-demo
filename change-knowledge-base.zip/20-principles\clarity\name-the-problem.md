---
type: principle
status: draft
id: change-knowledge-base-p-001
category: clarity
description: State the problem as a decision-relevant question before listing solutions or features.
derived_from:
  - "[[clarity]]"
updated: 2026-07-16
---

# Name the problem

A change starts from a **named problem** (or opportunity) that stakeholders can recognise — not from a solution shopping list.

If two people can disagree about what “the problem” is after reading the brief, the brief is not clear enough to analyse.
