---
type: standard
status: draft
id: change-knowledge-base-s-051
concern: stakeholders
description: Raci matrix — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[name-who-matters]]"
  - "[[artefact-has-owner]]"
  - "[[enough-to-decide]]"
updated: 2026-07-18
---

# Raci matrix

## Normally require

A **RACI matrix** includes:

| Field | Test |
| --- | --- |
| Activities / decisions | Named rows |
| Parties | Named columns |
| Letters | R/A/C/I used consistently; one A per row |
| Scope | Matches current phase |

## Refuse / escalate

- Multiple Accountables without escalation path
- Org-chart dump with no activities

## How to produce

[[raci-matrix-craft]]. Worked: [[raci-matrix-worked]]. Skeleton: `lab/skeletons/raci-matrix/`.

## Related

- [[common-case-coverage]] · workflow [[write-raci-matrix]]
