---
type: standard
status: draft
id: change-knowledge-base-s-015
concern: verification
description: Test effort is focused by risk — depth follows likelihood and impact, not uniform coverage.
derived_from:
  - "[[risk-shapes-attention]]"
  - "[[tradeoff-visible]]"
  - "[[enough-to-decide]]"
  - "[[status-matches-evidence]]"
updated: 2026-07-16
---

# Risk based test focus

## Normally require

A **risk-based focus view** over the test conditions includes:

| Field | Test |
| --- | --- |
| Risk basis | Areas rated by likelihood × impact on the outcome ([[risk-shapes-attention]]) |
| Depth mapping | Higher risk → deeper/earlier testing; lower risk → lighter, stated |
| Tradeoffs | What is deliberately tested lightly or not at all ([[tradeoff-visible]]) |
| Trace | Focus links to conditions ([[test-conditions]]) and product risks |
| Honesty | "Everything tested equally" or "fully tested" without a risk basis fails ([[status-matches-evidence]]) |

## Framework posture

Risk-based testing and product-risk analysis are portable frameworks. Domain likelihoods needing expert input are escalated, not invented.

## How to produce

[[risk-based-test-focus-craft]]. Worked: [[risk-based-test-focus-worked]].

## Refuse / escalate

- Uniform effort with no risk rationale
- Claiming exhaustive testing (impossible) instead of risk-justified focus
- Inventing domain risk ratings → escalate

## Not this standard

Deriving the conditions ([[test-conditions]]); coverage measurement ([[intent-coverage]]); PM risk register ([[risk-cadence]]).
