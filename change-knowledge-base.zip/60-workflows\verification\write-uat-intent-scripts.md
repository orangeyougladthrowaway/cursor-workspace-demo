---
type: workflow
status: draft
id: change-knowledge-base-wf-053
concern: verification
description: Sequence to produce uat intent scripts for TA09.
derived_from:
  - "[[uat-intent-scripts]]"
  - "[[uat-intent-scripts-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write uat intent scripts

Agent-operable sequence for TA09.

## Steps

1. **Retrieve** — theme atlas → [[uat-intent-scripts]] → [[uat-intent-scripts-craft]] → [[uat-intent-scripts-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[uat-intent-scripts]]; escalate Gaps.
5. **Cite** — `uat-intent-scripts` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
