# Risk register skeleton

## Purpose

Copy-out starter for a scored risk register on a cadence. Cite [[risk-cadence]] (`change-knowledge-base-s-010`).

## Required canons

- [[risk-cadence]] · [[risk-register-shape]] · [[raid-log]]
- Workflow: [[run-risk-cadence]]

## Copy

1. Copy `register.md` into the host work area.
2. State cause→event→effect; score; assign owner and response; set review date.
3. Cite `change-knowledge-base-s-010`.

## Honesty

Skeleton ≠ doctrine. No write-once list; escalate unknown domain probabilities.
