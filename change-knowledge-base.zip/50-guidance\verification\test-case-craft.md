---
type: guidance
status: draft
id: change-knowledge-base-g-055
concern: verification
description: How to produce test case — what good looks like.
derived_from:
  - "[[test-case]]"
updated: 2026-07-18
---

# Test case craft

House how-to for [[test-case]].

## House defaults

1. Derive from conditions; do not freestyle.
2. One objective per case where practical.
3. Expected = AC/oracle, not hope.
4. Manual cases here; automation is engineering lane.
5. Negative/boundary cases explicit.

## What good looks like

Another tester can run and pass/fail without asking the author.

## Done test

Trace · preconditions · steps · expected · priority.

## Related

- [[test-case]] · [[test-case-worked]] · [[write-test-case]] · skeleton `test-case/`
