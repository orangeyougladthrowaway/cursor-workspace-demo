---
type: example
status: draft
id: change-knowledge-base-ex-051
description: Worked exemplar — coverage honesty narrative good vs bad.
derived_from:
  - "[[coverage-honesty-narrative]]"
  - "[[coverage-honesty-narrative-craft]]"
updated: 2026-07-18
---

# Coverage honesty narrative worked

## Bad

"QA complete — 100%."

## Good

Must R1/R2 covered with boundary+auth. R3 skipped. Residual: DEF-12 Med accepted. Recommend proceed to UAT for Must only.

## Related

- [[coverage-honesty-narrative-craft]] · skeleton if present under lab/skeletons/
