---
type: workflow
status: draft
id: change-knowledge-base-wf-014
concern: requirements
description: Sequence to prioritise requirements against change-knowledge-base-s-005 with outcome/risk rationale.
derived_from:
  - "[[requirements-prioritisation]]"
  - "[[requirements-quality]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Prioritise requirements

Agent-operable sequence for BA05.

## Steps

1. **Retrieve** — [[business-analysis-atlas]] → [[requirements-prioritisation]] (`change-knowledge-base-s-005`) → skeleton `lab/skeletons/requirements-prioritisation/`.
2. **Preconditions** — requirements pack meeting [[requirements-quality]] (or escalate).
3. **Choose framework** — MoSCoW ([[moscow-bands]]), value×risk ([[value-risk-matrix]]), or Now-Next-Later — name it on the artefact.
4. **Rank** — order or band items; write outcome/risk rationale per [[rank-by-outcome]].
5. **Honesty check** — name deferred/rejected ([[tradeoff-visible]]); refuse “all Must.”
6. **Cite** — `change-knowledge-base-s-005`; link requirement ids.
7. **Escalate** — unknown business value or priority basis → user / domain SoR.

## Forbidden

- Silent FIFO or loudest-voice ranking without rationale
- Inventing value scores
