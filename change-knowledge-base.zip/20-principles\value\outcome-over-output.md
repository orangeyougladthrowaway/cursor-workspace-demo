---
type: principle
status: draft
id: change-knowledge-base-p-005
category: value
description: Tie the change to a stakeholder outcome, not a feature checklist alone.
derived_from:
  - "[[value]]"
updated: 2026-07-16
---

# Outcome over output

Problem frames state **who is better off and how** if the change succeeds. Feature lists without outcomes are incomplete frames.
