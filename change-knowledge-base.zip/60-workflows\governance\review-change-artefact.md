---
type: workflow
status: draft
id: change-knowledge-base-wf-034
concern: governance
description: Independently review a change artefact for honesty, cited ids, lane walls, precision, and evidence.
domain: ["cursor"]
derived_from:
  - "[[staff-agent-projection]]"
  - "[[status-reporting-honesty]]"
  - "[[verify-change-artefact]]"
  - "[[precision-over-vagueness]]"
  - "[[change-artefact-policy]]"
updated: 2026-07-20
---

# Review change artefact

Use after [[verify-change-artefact]] or when asked for an independent methods review.

## Preconditions

- Artefact + stated acceptance for the change task
- Verification result, or explicit statement that verification is absent

## Retrieve

1. [[staff-agent-projection]] — functional staff-agent DoD and Forbidden.
2. The artefact’s standard and producing workflow.
3. [[precision-over-vagueness]] for catalogue / AC / data / NFR / plan / RAID / cases.
4. Related honesty standards ([[status-reporting-honesty]], [[status-matches-evidence]]) when status/RAG is involved.

## Steps

1. Findings first: defects vs improvements.
2. Check retrieve honesty and cited `id`s.
3. Check lane walls — no invented SoR; no engineering substitute for TA/PM/BA.
4. **Precision:** refuse approve on Ready/vague in-scope grain; data work without field-map rows; AC happy-path-only when change/delete in scope; plan exits without AC/evidence pointers.
5. Check evidence vs claims (watermelon green).
6. Rank by impact; state residual risk and required corrections.
7. Verdict: approve, request changes, or blocked.

## Output

- Ordered findings (location · problem · consequence · fix · `id`)
- Open questions / Gaps (include imprecise grain)
- Verdict

## Handoff

Corrections → [[produce-change-artefact]] → [[verify-change-artefact]] → review again.

## Forbidden

- Soft “looks fine” without field tests / precision bar
- Inventing domain acceptance to close Gaps
- Treating zoo/skeleton as sole law
- Approving eng-DDL-only substitutes for BA field maps
- Green-wash Ready on adjective-only packs
