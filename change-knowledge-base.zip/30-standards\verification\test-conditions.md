---
type: standard
status: draft
id: change-knowledge-base-s-014
concern: verification
description: Test conditions derive from requirements, acceptance, and risks — each traceable to intent.
derived_from:
  - "[[condition-derives-from-intent]]"
  - "[[intent-must-be-testable]]"
  - "[[claim-needs-warrant]]"
  - "[[enough-to-decide]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Test conditions

## Normally require

A **test-condition set** for a change includes:

| Field | Test |
| --- | --- |
| Condition | A thing to verify, phrased testably ([[intent-must-be-testable]]) at actionable grain ([[precision-over-vagueness]]) |
| Source | Trace to a requirement id, acceptance criterion, or named risk ([[condition-derives-from-intent]]) |
| Type | Positive / negative / boundary as relevant ([[boundary-equivalence-thinking]]) — **not** a single paraphrase of AC when change/delete/boundary are in scope |
| Priority | Relative importance, usually risk-informed ([[risk-based-test-focus]]) |
| Gaps | Intents with no condition flagged, not hidden |

## Framework posture

Condition derivation, equivalence partitioning, and boundary analysis are portable **analysis** techniques and in scope. Writing/automating the tests in code is out of change-knowledge-base scope.

## How to produce

[[test-conditions-craft]]. Worked: [[test-conditions-worked]].

## Refuse / escalate

- Conditions with no upstream intent ([[condition-derives-from-intent]])
- Inventing expected behaviour where the requirement/domain rule is unknown → escalate
- Producing scripts/automation as a substitute for analysis (out of change-knowledge-base scope)

## Not this standard

Acceptance wording ([[acceptance-criteria]]); coverage judgement ([[intent-coverage]]); defect reporting ([[defect-clarity]]).
