---
type: example
status: draft
id: change-knowledge-base-ex-028
description: Worked exemplar — engagement-matched stakeholder map vs org dump.
derived_from:
  - "[[stakeholder-clarity]]"
  - "[[stakeholder-clarity-craft]]"
updated: 2026-07-18
---

# Stakeholder clarity worked

## Bad

Org chart paste with no interest/influence/engagement.

## Good (excerpt)

| Party | Interest | Impact | Influence | Engagement | Warrant |
| --- | --- | --- | --- | --- | --- |
| Finance ops lead | Month-end speed | Primary user | H | Manage closely; elicit first | Interview 1 Jul |
| CFO | Audit exposure | Sponsor | H | Keep informed weekly; decisions | Mandate holder |
| IT security | Data access | Gate | M | Consult on roles | Policy owner — escalate SoR |
| Colour-theme fan club | Cosmetics | Low | L | Monitor only | Out of Must |

Owner: BA A. Example
