---
type: example
status: draft
id: change-knowledge-base-ex-049
description: Worked exemplar — kickoff honesty good vs bad.
derived_from:
  - "[[kickoff-honesty]]"
  - "[[kickoff-honesty-craft]]"
updated: 2026-07-18
---

# Kickoff honesty worked

## Bad

Kickoff slides; no charter; "we'll figure scope later."

## Good

Charter PF/PM brief read; roles named; opens: age-rule conflict, vendor API; mandate CFO ack recorded.

## Related

- [[kickoff-honesty-craft]] · skeleton if present under lab/skeletons/
