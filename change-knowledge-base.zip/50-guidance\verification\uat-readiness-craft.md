---
type: guidance
status: draft
id: change-knowledge-base-g-018
concern: verification
description: How to judge UAT readiness — entry/exit observable, residuals honest.
derived_from:
  - "[[uat-readiness]]"
  - "[[intent-coverage]]"
  - "[[intent-must-be-testable]]"
updated: 2026-07-18
---

# Uat readiness craft

House how-to for TA05. Field tests: [[uat-readiness]].

## House defaults

1. Scope = intents UAT will confirm (from coverage view).
2. Entry criteria concrete (build, data, access) — escalate unknown env facts.
3. Exit criteria observable pass/fail for sign-off.
4. Residual defects/gaps with severity — no hide.
5. Roles: who tests, who signs.
6. Refuse ready while material intents uncovered or exit vague.

## Done test

Scope · entry · exit · residuals · roles · honesty.

## Related

- [[uat-readiness]] · [[assess-uat-readiness]] · [[uat-readiness-worked]] · [[intent-coverage-craft]]
