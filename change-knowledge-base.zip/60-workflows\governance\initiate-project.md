---
type: workflow
status: draft
id: change-knowledge-base-wf-018
concern: governance
description: Sequence to produce an initiation brief/charter against change-knowledge-base-s-008 without self-authorising.
derived_from:
  - "[[initiation-mandate]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Initiate project

Agent-operable sequence for PM01.

## Steps

1. **Retrieve** — [[project-management-atlas]] → [[initiation-mandate]] (`change-knowledge-base-s-008`) → skeleton `lab/skeletons/project-initiation/`.
2. **Inputs** — sponsor/mandate, problem or opportunity, any BA problem frame. No authorising party → escalate; do not self-authorise.
3. **Draft charter** — mandate · outcome · scope bounds · key stakeholders · success measure · warrant · owner.
4. **Verify** — field tests in [[initiation-mandate]]; outcome stated as benefit not output.
5. **Cite** — `change-knowledge-base-s-008`.
6. **Hand off** — feed [[build-plan]]; do not jump to detailed planning before the mandate is agreed.

## Forbidden

- Self-authorising scope with no mandate
- Inventing business justification
- Restating the BA problem frame as a charter without mandate/success measure
