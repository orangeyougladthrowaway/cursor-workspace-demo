---
type: example
status: draft
id: change-knowledge-base-ex-035
description: Worked exemplar — risk-depth mapping vs uniform coverage claim.
derived_from:
  - "[[risk-based-test-focus]]"
  - "[[risk-based-test-focus-craft]]"
updated: 2026-07-18
---

# Risk based test focus worked

## Bad

Everything tested equally. Fully tested.

## Good

| Area | Risk | Depth | Tradeoff |
| --- | --- | --- | --- |
| Export authz | H | Deep — TC03 + extra role matrix | — |
| Age boundary 30d | H | Deep — boundary conditions | — |
| Colour theme | L | Skip this release | Explicit |
| Predictive ML | n/a | Out of scope | Won't |
