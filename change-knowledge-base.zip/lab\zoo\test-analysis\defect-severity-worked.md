---
type: example
status: draft
id: change-knowledge-base-ex-052
description: Worked exemplar — defect severity good vs bad.
derived_from:
  - "[[defect-severity]]"
  - "[[defect-severity-craft]]"
updated: 2026-07-18
---

# Defect severity worked

## Bad

Severity Critical — reporter annoyed.

## Good

High: wrong invoices in export breaks month-end trust (Must R2). Priority: fix before UAT sign-off.

## Related

- [[defect-severity-craft]] · skeleton if present under lab/skeletons/
