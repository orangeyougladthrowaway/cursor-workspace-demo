# TA analysis pass skeleton

## Purpose

Checklist for one supervised TA pass across cells. Cite [[ta-analysis-pass]] (`change-knowledge-base-wf-030`).

## Required canons

- [[ta-analysis-pass]]
- Cell standards `change-knowledge-base-s-014` … `change-knowledge-base-s-018`

## Copy

1. Copy `pass.md` into the host work area.
2. Walk steps; report defects as found; escalate ambiguous intent.
3. Do not implement executable tests here.

## Honesty

Order is a default dependency. Coverage is intent-based, never counts.
