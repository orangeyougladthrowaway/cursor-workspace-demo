---
name: change-knowledge-base-verify
description: Verifies a change artefact against change-knowledge-base standard field tests. Use when asked to check, validate, or quality-gate methods artefacts.
disable-model-invocation: true
---

Follow `60-workflows/verification/verify-change-artefact.md` (`change-knowledge-base-wf-033`).

Return field-test results and Gaps. Never soft-pass without evidence.
