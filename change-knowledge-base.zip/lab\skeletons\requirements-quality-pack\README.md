# Requirements quality pack skeleton

## Purpose

Copy-out starter for assessing or drafting a requirements pack. Cite [[requirements-quality]] (`change-knowledge-base-s-002`).

## Required canons

- [[requirements-quality]]
- Governing frame: [[problem-framing]]
- Workflow: [[assess-requirements-quality]]

## Copy

1. Copy `pack.md` into the host work area.
2. Link the problem frame. Run field tests per requirement.
3. Escalate missing domain facts — do not invent.

## Honesty

Skeleton ≠ doctrine. Standard wins on conflict.
