---
type: standard
status: draft
id: change-knowledge-base-s-025
concern: risk
description: Issue risk split — usable bar for PM07.
derived_from:
  - "[[risk-managed-continuously]]"
  - "[[status-matches-evidence]]"
  - "[[artefact-has-owner]]"
updated: 2026-07-18
---

# Issue risk split

## Normally require

Risk vs issue discipline:

| Field | Test |
| --- | --- |
| Risk | May happen — cause→event→effect; scored |
| Issue | Happening now — impact, date opened, resolution owner |
| Split honesty | Items not misfiled to hide RAG colour |
| Link | Related plan/status ids |

## Refuse / escalate

- Calling active blockers "risks" to keep Green
- Issues without owners/dates

## How to produce

[[issue-risk-split-craft]]. Worked: [[issue-risk-split-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
