---
type: category
status: draft
id: change-knowledge-base-cat-change
description: Spine for change — deltas are controlled, not absorbed silently.
updated: 2026-07-16
---

# Change

## Theme

Scope and requirement deltas need an explicit control path.

## Leaves

- [[control-the-delta]]
