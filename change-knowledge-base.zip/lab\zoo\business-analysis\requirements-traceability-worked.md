---
type: example
status: draft
id: change-knowledge-base-ex-029
description: Worked exemplar — honest trace with gap vs fake full coverage.
derived_from:
  - "[[requirements-traceability]]"
  - "[[requirements-traceability-craft]]"
updated: 2026-07-18
---

# Requirements traceability worked

## Bad

Claim "100% traced" while R4 has no AC.

## Good

| Req | AC | Notes |
| --- | --- | --- |
| R1 | AC-R1-happy, AC-R1-boundary | OK |
| R2 | AC-R2-unauth | OK |
| R3 | gap — escalate | Could; no AC yet — not "fully traced" |
| R4 | Won't this release | Explicit out |

Frame: problem-frame PF-12. Owner: BA A. Example
