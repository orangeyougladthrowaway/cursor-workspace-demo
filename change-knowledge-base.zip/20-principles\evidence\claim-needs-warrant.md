---
type: principle
status: draft
id: change-knowledge-base-p-002
category: evidence
description: Every material requirement or status claim must carry a warrant or an explicit unknown.
derived_from:
  - "[[evidence]]"
updated: 2026-07-16
---

# Claim needs warrant

Material statements (“users need X”, “this is ready”) need a **warrant**: observation, stakeholder statement, measured friction, or an explicit `unknown` / escalate.

Unwarranted claims are not house method — they are invention.
