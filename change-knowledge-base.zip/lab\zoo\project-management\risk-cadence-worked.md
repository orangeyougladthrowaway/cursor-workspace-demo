---
type: example
status: draft
id: change-knowledge-base-ex-024
description: Worked exemplar — cause-event-effect risk vs vague cloud risk.
derived_from:
  - "[[risk-cadence]]"
  - "[[risk-cadence-craft]]"
  - "[[risk-register-shape]]"
updated: 2026-07-18
---

# Risk cadence worked

Fictional grain. Quality bar for PM03 G4.

## Bad

| Risk | Score | Response | Why it fails |
| --- | --- | --- | --- |
| Cloud / vendor | Medium | Monitor | No cause→event→effect; no owner; wallpaper |

## Good

| Id | Statement | P | I | Response | Owner | Last review |
| --- | --- | --- | --- | --- | --- | --- |
| RISK-04 | **Cause:** Vendor invoice API SLA not contracted. **Event:** API unavailable >2 days in July. **Effect:** M2 slip; month-end export path blocked | H | H | Reduce — escalate CSM; spike mock; decision ask on descope | PM P. Example | 12 Jul |
| RISK-07 | **Cause:** Finance role model unconfirmed. **Event:** Wrong users see invoice ages. **Effect:** Confidentiality incident / rework | M | H | Avoid — hold prod until role matrix warranted (BA escalate) | BA A. Example | 12 Jul |

**Cadence:** weekly with status; next 19 Jul.

## Related

- [[risk-cadence-thin]] · [[risk-cadence-craft]] · skeleton `risk-register/`
