---
type: category
status: draft
id: change-knowledge-base-cat-evidence
description: Spine for evidence — claims about need and status require warrants.
updated: 2026-07-16
---

# Evidence

## Theme

Assertions about need, priority, and readiness without warrants become theatre.

## Leaves

- [[claim-needs-warrant]]
- [[elicit-before-invent]]
- [[defect-carries-evidence]]
