---
type: standard
status: draft
id: change-knowledge-base-s-020
concern: analysis
description: Workshop facilitation — usable bar for BA08.
derived_from:
  - "[[elicit-before-invent]]"
  - "[[influence-shapes-engagement]]"
  - "[[enough-to-decide]]"
updated: 2026-07-18
---

# Workshop facilitation

## Normally require

A **facilitated workshop** for material shared decisions includes:

| Field | Test |
| --- | --- |
| Decision question | Named up front — what must be decided today |
| Participants | Right influence in the room ([[influence-shapes-engagement]]) |
| Agenda / timebox | Published; parking lot for off-topic |
| Outputs | Decisions, open conflicts, owners — not only slides |
| Neutrality | Facilitator does not force fake consensus |

## Refuse / escalate

- Workshop used to invent domain facts without SME warrants
- Critical dissenters excluded without record

## How to produce

[[workshop-facilitation-craft]]. Worked: [[workshop-facilitation-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
