---
type: workflow
status: draft
id: change-knowledge-base-wf-050
concern: verification
description: Sequence to produce boundary applied for TA06.
derived_from:
  - "[[boundary-applied]]"
  - "[[boundary-applied-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Apply boundary

Agent-operable sequence for TA06.

## Steps

1. **Retrieve** — theme atlas → [[boundary-applied]] → [[boundary-applied-craft]] → [[boundary-applied-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[boundary-applied]]; escalate Gaps.
5. **Cite** — `boundary-applied` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
