---
type: workflow
status: draft
id: change-knowledge-base-wf-001
concern: knowledge
description: Lived harvest and remote research enter via claims → collide → amend-first; books/templates are pressure.
derived_from:
  - "[[navigation]]"
  - "[[changing-this-bible]]"
  - "[[methodology]]"
  - "[[scope]]"
updated: 2026-07-16
---

# Knowledge ingestion

How knowledge enters this bible. Sources are pressure; **claims** are the unit of work; **living notes** remain doctrine.

## Paths

```text
Lived:  delivery friction / temp harvest → distill claims → collide → amend
Remote: book / template / course / vendor docs → admit → claims → collide → amend
                                              └ pointer | defer | reject (often)
```

| Branch | Default altitude | Remote may overwrite lived canonical? |
| --- | --- | --- |
| Lived | guidance → pattern when portable | N/A |
| Remote | draft guidance / pressure on higher notes | **No** — see conflict protocol |

## Pipeline

```text
Admit → Claim cards → Locate/collide → Conflict resolve → Elevate → Cleanliness gate
```

### Stage A — Admit

| Admit | Meaning | May emit claims? |
| --- | --- | --- |
| `pressure` | Challenges doctrine you care about / on watchlist | Yes |
| `specialise` | Maps to an existing concern | Yes |
| `pointer` | Research aid only | **No** |
| `defer` | Wrong season | No |
| `reject` | Out of [[scope]], curriculum dump, noise | No |

**Books** are first-class remote sources — admit as `pressure` or `specialise`, never as a chapter-tree mirror.  
**Draft templates** pressure **artefact standards**; elevate field tests that matter; put copy-shapes in `lab/skeletons/` citing canons.  
**Cert syllabi** default `pointer` or selective `pressure` — **reject** wholesale syllabus trees.  
**Vendor tool docs** → guidance with `domain:` — never philosophy.

Ledger: [[ingest-coverage]] (outside doctrine bodies). Praxis zoo is **not** a curriculum — [[praxis-ingestion]].

### Stage B — Claim cards

Cap **≤20 claims per source** first pass. Prefer claims that change a decision.

Ban as claims: chapter outlines, glossary of widely known terms, tool clickpath encyclopaedias, entire template libraries pasted as guidance.

### Stage C — Locate and collide

1. Search by concern, atlas links, `id`, stem.
2. Open candidate living notes (`canonical` preferred; `draft` = non-law).
3. Classify: Reinforce · Specialise · Gap · Tension · Contradiction · Reject.
4. **Amend-first.** New note requires explicit “no merge target” check.

### Stage D — Conflict protocol

**Authority stack (highest wins):**

1. User explicit override (then amend living note)
2. Canonical change-knowledge-base note already decided
3. Lived delivery friction in *your* change practice
4. Invariant principles (clarity, evidence, risk, scope, value, verification, honesty, …)
5. Stronger primary/trusted method sources over blogs
6. Drafts / popular templates — advisory until collided

**Practiced asymmetry:** if a book contradicts canonical *lived* house method, allowed outcomes only: reject remote · aspirational `draft` · tradeoff with **default = lived**.

### Stage E — Elevate

| Become | Required |
| --- | --- |
| `draft` | Pass Stage C; one concern; one question; upward links |
| `canonical` | Human/user promotion; no open contradiction; short rationale |
| Higher altitude | Multiple independent pressures + fit — never “book said so” alone |
| New concern folder | Amend [[navigation]] **first** |

**Session budget:** ≤30 claim cards · ≤3 note amends · ≤1 new draft. Prefer `amends ≫ new notes`.

**Deep-dive (explicitly invoked only):** budget may rise; amend-first and cleanliness still bind.

### Coverage axes

| Axis | change-knowledge-base meaning |
| --- | --- |
| **W** | Theme atlases + concerns for PM/BA/TA spines |
| **D** | Deep harvest from chosen primary sources per theme |
| **P** | Praxis capacity — skills/zoo/skeletons cite canons |
| **F** | Majority **common cases** (G1–G4) on [[common-case-coverage]] |

**Anti-shrink:** seeded skill ≠ functional staff agent.

### Stage F — Cleanliness

Run [[changing-this-bible]] cleanliness accept. Update [[ingest-coverage]] and [[common-case-coverage]] when cells move. Hand-write notes — no bulk generators.

## Refuse modes

- `pointer-only` · `contradiction — needs human` · `out of scope` · `defer` · `merge targets missing`

## Forbidden

- Course mirrors, bookmark dumps, vendor encyclopaedias as doctrine
- Second taxonomy for sources (domain × textbook trees)
- Treating ledger / claim cards / `temp/` as doctrine
- Fat skills that restate this note

## Related

- [[staff-agent-projection]] · [[praxis-ingestion]] · [[common-case-coverage]] · [[scope]] · [[catalog-maps]]
