---
type: pattern
status: draft
id: change-knowledge-base-pt-007
concern: risk
description: Risk register shape — cause→event→effect statements scored by probability and impact.
derived_from:
  - "[[risk-shapes-attention]]"
  - "[[risk-cadence]]"
updated: 2026-07-16
---

# Risk register shape

## Shape

State each risk as **cause → event → effect**, then score:

| Field | Note |
| --- | --- |
| Statement | "Because <cause>, <event> may occur, leading to <effect>" |
| Probability | Low / Med / High (or scale) |
| Impact | Low / Med / High on outcome/plan |
| Score | Probability × impact for triage |
| Response | Avoid / reduce / transfer / accept |
| Owner | Accountable person |

Probability × impact read:

| | Low impact | High impact |
| --- | --- | --- |
| **High prob** | Reduce / monitor | Act now |
| **Low prob** | Accept / monitor | Contingency plan |

## When

Populating or reviewing the [[risk-cadence]] register.

## When not

As invented probabilities for domain events → escalate; as a write-once list ([[risk-managed-continuously]]).

## Related

- [[raid-log]] · [[run-risk-cadence]]
