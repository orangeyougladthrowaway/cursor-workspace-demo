---
type: guidance
status: draft
id: change-knowledge-base-g-047
concern: requirements
description: How to produce data model — what good looks like.
derived_from:
  - "[[data-model]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Data model craft

House how-to for [[data-model]].

## House defaults

1. Logical/business grain first; physical **authorship** is engineering — BA still owns the **mapping contract** when data moves.
2. ERD or equivalent: entities, relationships, optionality.
3. Define identifiers that users recognise (invoice id, not surrogate only).
4. Keep in sync with catalogue data NFRs and retention.
5. Escalate SoR ownership to systems-knowledge-base / user.
6. For load/historise/sync work: add source→target field map; **link** vendor/systems further-detail URLs where wire payloads are out of vault scope — do not paste encyclopaedias.

## What good looks like

Readers agree what "things" exist and how they relate; implementers can see each in-scope field’s target column/transform without a second elicitation.

## Done test

Entities · relationships · optionality · ids · owner · SoR Gaps named · field map when data-store work (or Gap).

## Related

- [[data-model]] · [[data-model-worked]] · [[model-data]] · skeleton `data-model/`
