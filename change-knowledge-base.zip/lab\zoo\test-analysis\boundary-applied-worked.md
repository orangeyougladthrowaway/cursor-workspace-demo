---
type: example
status: draft
id: change-knowledge-base-ex-050
description: Worked exemplar — boundary applied good vs bad.
derived_from:
  - "[[boundary-applied]]"
  - "[[boundary-applied-craft]]"
updated: 2026-07-18
---

# Boundary applied worked

## Bad

Only tested age=45 days for "30+" filter.

## Good

Classes: <30, =30, >30. Conditions at 29, 30, 31 days per agreed clock start.

## Related

- [[boundary-applied-craft]] · skeleton if present under lab/skeletons/
