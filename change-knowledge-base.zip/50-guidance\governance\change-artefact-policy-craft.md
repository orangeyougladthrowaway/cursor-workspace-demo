---
type: guidance
status: draft
id: change-knowledge-base-g-061
concern: governance
description: How to classify engagement and apply change-artefact-policy without silent skips.
derived_from:
  - "[[change-artefact-policy]]"
  - "[[small-change-control]]"
  - "[[project-artefact-pack]]"
  - "[[enough-to-decide]]"
  - "[[tradeoff-visible]]"
updated: 2026-07-20
---

# Change artefact policy craft

House how-to for [[change-artefact-policy]]. Process path detail for micro-fix / enhancement: [[small-change-control]].

## House defaults

1. **Classify first** — one class from the standard; write it on the plan and Task notes. Map colloquial **BAU** → micro-fix or enhancement ([[small-change-control]]) — never “no class.”
2. **List M then R** — copy the column into the plan; mark each M as Produce / Substitute→X / Exempt (decision id).
3. **Choose process path** — micro-fix → named cells covering M; enhancement → selected cells or thinned journey; project/regulatory → profile journey default. Write the choice on the plan.
4. **Prefer substitute over exempt** when one living artefact already carries the fields.
5. **Prefer delta on living product artefacts** (catalogue / AC / RAID / data model) over blank parallel packs for BAU/small change.
6. **Regulatory beats enhancement** when audit/compliance is in play — do not stay on enhancement to dodge docs.
7. **Programme** = project policy per child + programme RAID/status; do not invent a mega-pack in chat.
8. Open [[project-artefact-pack]] only for stems marked Produce — quality path is standard → craft → workflow → skeleton.

## What good looks like

A reader sees: class, process path (cells vs journey + which steps), M-set status (done / substitute / exempt+decision), next produce list. No silent gaps. Residual risk on exemptions is visible. Micro-fix still has AC + defect clarity (or logged exemption).

## Done test (planning)

Class named · process path named · every M accounted · R defaults include or explicit skip · cited `change-knowledge-base-s-060` · handoff to named produce workflows (cells or thinned journey).

## Related

- [[change-artefact-policy]] · [[small-change-control]] · [[plan-change-work]] · [[project-artefact-pack]] · [[log-decision]]
