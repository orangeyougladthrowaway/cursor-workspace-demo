---
type: workflow
status: draft
id: change-knowledge-base-wf-040
concern: analysis
description: Sequence to produce workshop facilitation for BA08.
derived_from:
  - "[[workshop-facilitation]]"
  - "[[workshop-facilitation-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Facilitate workshop

Agent-operable sequence for BA08.

## Steps

1. **Retrieve** — theme atlas → [[workshop-facilitation]] → [[workshop-facilitation-craft]] → [[workshop-facilitation-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[workshop-facilitation]]; escalate Gaps.
5. **Cite** — `workshop-facilitation` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
