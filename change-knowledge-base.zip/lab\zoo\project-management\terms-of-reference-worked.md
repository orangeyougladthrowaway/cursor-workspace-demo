---
type: example
status: draft
id: change-knowledge-base-ex-061
description: Worked exemplar — terms of reference good vs bad.
derived_from:
  - "[[terms-of-reference]]"
  - "[[terms-of-reference-craft]]"
updated: 2026-07-18
---

# Terms of reference worked

## Bad

"Do some BA on invoices." No scope, no deliverables.

## Good (excerpt)

**Objectives:** Reduce month-end unpaid join effort. **Scope in:** aged unpaid view+export. **Out:** collections. **Deliverables:** ToR, catalogue, use cases, swimlanes, RTM, UAT pack. **Reporting:** CFO weekly.

## Related

- [[terms-of-reference-craft]] · `lab/skeletons/terms-of-reference/`
