---
type: example
status: draft
id: change-knowledge-base-ex-075
description: Worked exemplar — test case good vs bad.
derived_from:
  - "[[test-case]]"
  - "[[test-case-craft]]"
updated: 2026-07-18
---

# Test case worked

## Good

TC-12 \| Export filter match \| TC01/AC-R1 \| Finance; filter 30+ \| Export \| CSV ids = UI ids.

## Related

- [[test-case-craft]] · `lab/skeletons/test-case/`
