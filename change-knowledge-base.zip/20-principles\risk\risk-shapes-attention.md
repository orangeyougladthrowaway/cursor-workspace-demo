---
type: principle
status: draft
id: change-knowledge-base-p-003
category: risk
description: Direct analysis and verification effort toward uncertainties that can fail the change.
derived_from:
  - "[[risk]]"
updated: 2026-07-16
---

# Risk shapes attention

When framing and accepting work, call out the uncertainties that could invalidate the outcome. Do not pretend every field is equally important.
