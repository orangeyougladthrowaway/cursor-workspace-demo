---
type: guidance
status: draft
id: change-knowledge-base-g-015
concern: delivery
description: How to close honestly — outcome vs mandate, residuals owned, handoff.
derived_from:
  - "[[closure-confirmation]]"
  - "[[close-confirms-benefit]]"
  - "[[tradeoff-visible]]"
updated: 2026-07-18
---

# Closure confirmation craft

House how-to for PM06. Field tests: [[closure-confirmation]].

## House defaults

1. Compare outcome to initiation success measure — activity stop is not success.
2. Name descopes vs planned.
3. Residuals with owners (defects, benefits not yet realised).
4. Handoff run/support/benefit owner named.
5. Lessons = portable method pressure — not a diary dump.
6. Refuse success theatre while material residuals hide.

## Done test

Outcome check · scope vs plan · residuals owned · handoff · honesty.

## Related

- [[closure-confirmation]] · [[close-delivery]] · [[initiation-mandate]] · [[closure-confirmation-worked]]
