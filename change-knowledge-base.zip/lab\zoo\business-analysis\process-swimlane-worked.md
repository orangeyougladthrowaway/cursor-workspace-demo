---
type: example
status: draft
id: change-knowledge-base-ex-066
description: Worked exemplar — process swimlane good vs bad.
derived_from:
  - "[[process-swimlane]]"
  - "[[process-swimlane-craft]]"
updated: 2026-07-18
---

# Process swimlane worked

## Bad

Boxes with no actors; mixed as-is/to-be.

## Good

As-is: Finance → join CSVs → chase. To-be: Finance → filter aged view → export CSV → chase. Swimlanes: Finance, System, Vendor.

## Related

- [[process-swimlane-craft]] · `lab/skeletons/process-swimlane/`
