---
type: guidance
status: draft
id: change-knowledge-base-g-005
concern: requirements
description: How to quality-check a requirements pack — clarity, warrants, honesty of ready.
derived_from:
  - "[[requirements-quality]]"
  - "[[claim-needs-warrant]]"
  - "[[elicit-before-invent]]"
updated: 2026-07-18
---

# Requirements quality craft

House how-to for BA02. Field tests: [[requirements-quality]].

## Applies when

Turning elicitation output into a pack that build/TA can trust.

## House defaults

1. **Actor–action–object** per requirement. If two readers disagree who does what to what, rewrite.
2. **Stable ids** before prioritisation or AC. Renaming ids later breaks trace.
3. **Warrant per material item** — elicitation mode + source, or `unknown — escalate`. No warrant → not ready.
4. **Link the governing frame.** Pack without [[problem-framing]] is orphan theatre.
5. **Open questions are first-class.** Hiding unknowns to mark “ready” fails honesty.
6. **Explicit non-requirements** (assumptions, design notes, out-of-scope) so they are not smuggled as Musts.
7. **Conflicts stay visible** until resolved with an owner — do not average opposing SMEs.

## Decision rules

| Situation | Do |
| --- | --- |
| Ambiguous NFR | Escalate for measure or keep as open question — do not invent thresholds |
| “Ready” but elicitation incomplete | Refuse ready status |
| Tool-imported backlog with no warrants | Treat as candidate list; run elicitation before quality pass |

## Done test

| Check | Pass means |
| --- | --- |
| Clear | Actor/action/object unambiguous |
| Warranted | Source or escalate tag on each material row |
| Bounded | Out-of-scope / non-requirements noted |
| Honest | Ready ⇒ no hidden conflicts/unknowns |
| Owned | Pack maintainer named |

## Related

- [[requirements-quality]] · [[assess-requirements-quality]] · [[elicitation-craft]] · [[acceptance-criteria-craft]]
