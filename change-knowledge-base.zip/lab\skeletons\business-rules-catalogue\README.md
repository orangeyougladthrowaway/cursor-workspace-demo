# Business rules catalogue skeleton

## Purpose

Copy-out starter for business rules catalogue. Cite [[business-rules-catalogue]].

## Required canons

- [[business-rules-catalogue]]
- [[business-rules-catalogue-craft]]
- Workflow: [[maintain-business-rules]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[business-rules-catalogue-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
