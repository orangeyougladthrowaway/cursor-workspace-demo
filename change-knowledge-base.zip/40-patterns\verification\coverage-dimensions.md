---
type: pattern
status: draft
id: change-knowledge-base-pt-011
concern: verification
description: Coverage dimensions — read coverage against intent, risk, and scenario, not test counts.
derived_from:
  - "[[coverage-measures-intent]]"
  - "[[intent-coverage]]"
updated: 2026-07-16
---

# Coverage dimensions

## Shape

Ask coverage along dimensions, not a single number:

| Dimension | Question |
| --- | --- |
| Requirement | Is each requirement exercised by ≥1 condition? |
| Acceptance | Is each acceptance criterion checked? |
| Risk | Is each material risk probed? |
| Scenario | Are key end-to-end paths covered? |

Report **covered / gap / untestable** per dimension. Counts are context, never the claim.

## When

Assessing [[intent-coverage]].

## When not

Reporting line/test counts as intent coverage; hiding gaps.

## Related

- [[test-condition-derivation]] · [[assess-intent-coverage]]
