---
type: workflow
status: draft
id: change-knowledge-base-wf-044
concern: requirements
description: Sequence to produce requirements conflict for BA12.
derived_from:
  - "[[requirements-conflict]]"
  - "[[requirements-conflict-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Resolve requirements conflict

Agent-operable sequence for BA12.

## Steps

1. **Retrieve** — theme atlas → [[requirements-conflict]] → [[requirements-conflict-craft]] → [[requirements-conflict-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[requirements-conflict]]; escalate Gaps.
5. **Cite** — `requirements-conflict` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
