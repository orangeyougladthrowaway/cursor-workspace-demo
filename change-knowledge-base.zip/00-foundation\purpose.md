---
type: foundation
status: draft
id: change-knowledge-base-fnd-purpose
description: Why change-knowledge-base exists — methods bible for functional PM/BA/TA staff agents with majority common-case ambition.
updated: 2026-07-16
---

# Purpose

## Why this repository exists

Change work becomes tribal memory: how we frame problems, quality of requirements, what “done” means for acceptance, how plans and risks stay honest. This vault makes the **current** methods reasoning explicit so humans and staff agents share the same grounds.

External books, templates, and lived delivery friction are inputs. This repository holds distilled **doctrine** — not a history of every amendment — and a controlled **praxis** plane (`lab/`) so law can be applied as exemplars and artefact skeletons.

## What it is

- A long-lived **current-state** **change-methods bible** (doctrine: `00`–`60` + `maps/`)
- Abstract → concrete layering (philosophy → … → guidance), placed by **concern**
- Coverage ambition: the **majority of common cases** for house PM/BA/TA work ([[scope]]), each rooted in **principle** and **trusted sources** ([[common-case-coverage]], [[knowledge-ingestion]])
- A subordinate **praxis plane** (`lab/`) — zoo / skeletons / stubs that **cite** canons and never redefine law
- Optimised for small notes, unique catalogs/maps, and AI navigation ([[navigation]])

## What it is not

- Domain process truth (that is systems-knowledge-base / the user)
- Engineering / pytest / CI / code-level test craft (out of scope)
- A course or BABOK/PMBOK/ISTQB chapter mirror
- A ticket archive or project history warehouse
- A persona prompt without standards (“you are a senior BA”)
- A curriculum path that replaces living canons

## Success

1. Staff agents retrieve change-knowledge-base before acting; artefacts cite living `id`s.
2. House PM/BA/TA tracks have **majority common-case** law (G1–G3) then praxis (G4) on [[common-case-coverage]].
3. Agents escalate when domain facts or doctrine are missing — they do not invent process lore.
4. Behaviour change amends living change-knowledge-base notes; skills stay thin pointers.
5. Session budgets stay tight; **program** ambition stays wide — agents must not quietly shrink the destination bar.
