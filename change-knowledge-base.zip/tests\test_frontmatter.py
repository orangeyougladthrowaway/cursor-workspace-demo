"""Tests for frontmatter rules."""

from __future__ import annotations

import pytest

from tests.vault import (
    iter_notes,
    map_family_folder,
    parse_frontmatter,
    read_text,
    rel_posix,
    responsibility_folder,
)


DOCTRINE_TYPES_REQUIRING_ID = {
    "principle",
    "standard",
    "pattern",
    "guidance",
    "workflow",
    "map",
    "catalog",
    "category",
    "philosophy",
}


def test_concern_matches_folder() -> None:
    mismatches: list[str] = []
    for path in iter_notes():
        fm, _ = parse_frontmatter(read_text(path))
        concern = fm.get("concern")
        if not concern:
            continue
        resp = responsibility_folder(path)
        fam = map_family_folder(path)
        if resp and concern != resp:
            mismatches.append(f"{rel_posix(path)} concern={concern} folder={resp}")
        if fam and concern != fam:
            mismatches.append(f"{rel_posix(path)} concern={concern} family={fam}")
    assert not mismatches, "\n".join(mismatches)


def test_principles_have_category() -> None:
    missing: list[str] = []
    for path in iter_notes():
        fm, _ = parse_frontmatter(read_text(path))
        if fm.get("type") != "principle":
            continue
        if path.stem.startswith("catalog-"):
            continue
        if not fm.get("category"):
            missing.append(rel_posix(path))
    assert not missing, "Principles missing category:\n" + "\n".join(missing)


def test_doctrine_notes_have_id() -> None:
    missing: list[str] = []
    for path in iter_notes():
        fm, _ = parse_frontmatter(read_text(path))
        ntype = fm.get("type")
        if ntype not in DOCTRINE_TYPES_REQUIRING_ID:
            continue
        if path.stem.startswith("catalog-"):
            continue
        if not fm.get("id"):
            missing.append(rel_posix(path))
    assert not missing, "Doctrine notes missing id:\n" + "\n".join(missing)


def test_no_deprecated_doctrine_status() -> None:
    deprecated: list[str] = []
    for path in iter_notes():
        if "templates" in path.parts:
            continue
        fm, _ = parse_frontmatter(read_text(path))
        if fm.get("status") == "deprecated":
            deprecated.append(rel_posix(path))
    assert not deprecated, "Deprecated doctrine residue:\n" + "\n".join(deprecated)


def test_guidance_pattern_standard_workflow_have_concern() -> None:
    missing: list[str] = []
    for path in iter_notes():
        fm, _ = parse_frontmatter(read_text(path))
        if fm.get("type") not in {"guidance", "pattern", "standard", "workflow", "map"}:
            continue
        if path.stem.startswith("catalog-"):
            continue
        if not fm.get("concern"):
            missing.append(rel_posix(path))
    assert not missing, "Missing concern:\n" + "\n".join(missing)
