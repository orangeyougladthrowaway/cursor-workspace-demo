---
type: guidance
status: draft
id: change-knowledge-base-g-014
concern: governance
description: How to control change — delta, impact, options, named decision.
derived_from:
  - "[[change-control]]"
  - "[[control-the-delta]]"
  - "[[bound-the-change]]"
updated: 2026-07-18
---

# Change control craft

House how-to for PM05. Field tests: [[change-control]].

## House defaults

1. Delta vs baseline in one sentence — what was agreed, what would change.
2. Reason warranted — not preference.
3. Impact on scope, plan, cost, risk — all four considered; N/A explicit.
4. Options including do-nothing.
5. Decision + named approver — no silent absorb.
6. Trace to affected reqs/plan items; update artefacts after approve.

## Done test

Delta · reason · impact · options · decision/approver · trace.

## Related

- [[change-control]] · [[control-change]] · [[plan-honesty]] · [[change-control-worked]]
