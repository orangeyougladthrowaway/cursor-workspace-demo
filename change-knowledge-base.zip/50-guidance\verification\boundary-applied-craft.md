---
type: guidance
status: draft
id: change-knowledge-base-g-029
concern: verification
description: How to perform boundary applied — house craft for TA06.
derived_from:
  - "[[boundary-applied]]"
updated: 2026-07-18
---

# Boundary applied craft

House how-to for TA06. Field tests: [[boundary-applied]].

## House defaults

1. For each range rule, condition at edge and just inside/outside as relevant.
2. Document class representatives.
3. Invalid/unexpected input as negative class when in scope.

## Done test

Classes · boundary conditions · trace · no mid-only coverage.

## Related

- [[boundary-applied]] · [[boundary-applied-worked]] · [[common-case-coverage]]
