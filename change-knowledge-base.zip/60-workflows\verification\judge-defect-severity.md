---
type: workflow
status: draft
id: change-knowledge-base-wf-052
concern: verification
description: Sequence to produce defect severity for TA08.
derived_from:
  - "[[defect-severity]]"
  - "[[defect-severity-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Judge defect severity

Agent-operable sequence for TA08.

## Steps

1. **Retrieve** — theme atlas → [[defect-severity]] → [[defect-severity-craft]] → [[defect-severity-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[defect-severity]]; escalate Gaps.
5. **Cite** — `defect-severity` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
