---
type: guidance
status: draft
id: change-knowledge-base-g-028
concern: governance
description: How to perform kickoff honesty — house craft for PM11.
derived_from:
  - "[[kickoff-honesty]]"
updated: 2026-07-18
---

# Kickoff honesty craft

House how-to for PM11. Field tests: [[kickoff-honesty]].

## House defaults

1. Kickoff is confirmation, not discovery theatre — unknowns listed.
2. Revisit charter live; log deltas.
3. End with named owners for first milestones.
4. No fake "all clear."

## Done test

Charter OK · roles · WoW · opens listed · mandate ack.

## Related

- [[kickoff-honesty]] · [[kickoff-honesty-worked]] · [[common-case-coverage]]
