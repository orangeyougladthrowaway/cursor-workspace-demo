---
type: workflow
status: draft
id: change-knowledge-base-wf-074
concern: verification
description: Sequence to produce test plan artefact.
derived_from:
  - "[[test-plan]]"
  - "[[test-plan-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write test plan

Agent-operable sequence for [[test-plan]].

## Steps

1. **Retrieve** — theme atlas → [[test-plan]] → [[test-plan-craft]] → [[test-plan-worked]] → skeleton `lab/skeletons/test-plan/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[test-plan]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
