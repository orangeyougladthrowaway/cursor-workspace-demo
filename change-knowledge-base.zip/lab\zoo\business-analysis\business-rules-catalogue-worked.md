---
type: example
status: draft
id: change-knowledge-base-ex-069
description: Worked exemplar — business rules catalogue good vs bad.
derived_from:
  - "[[business-rules-catalogue]]"
  - "[[business-rules-catalogue-craft]]"
updated: 2026-07-18
---

# Business rules catalogue worked

## Good

BR-12: Unpaid age clock starts at invoice date (ops warrant; conflict with controller — open).

## Related

- [[business-rules-catalogue-craft]] · `lab/skeletons/business-rules-catalogue/`
