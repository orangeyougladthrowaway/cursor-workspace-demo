---
type: guidance
status: draft
id: change-knowledge-base-g-012
concern: requirements
description: How to maintain trace — forward/back links, gaps honest, delta control.
derived_from:
  - "[[requirements-traceability]]"
  - "[[link-across-artefacts]]"
  - "[[control-the-delta]]"
updated: 2026-07-18
---

# Requirements traceability craft

House how-to for BA06. Field tests: [[requirements-traceability]].

## House defaults

1. Forward: each in-scope req to at least one AC (or explicit gap).
2. Backward: each AC to a req id (no orphans).
3. Frame link on the pack — orphans from problem fail.
4. Record broken links when ids change ([[control-the-delta]]).
5. Never claim fully traced while gaps hide.
6. Do not invent AC text to fill cells — escalate to write real criteria.

## Done test

Forward+back complete or gaps named · frame cited · owner · honesty of coverage claim.

## Related

- [[requirements-traceability]] · [[trace-requirements]] · [[acceptance-criteria-craft]] · [[requirements-traceability-worked]]
