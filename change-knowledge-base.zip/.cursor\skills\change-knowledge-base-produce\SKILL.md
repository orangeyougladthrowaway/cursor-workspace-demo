---
name: change-knowledge-base-produce
description: Produces a change-knowledge-base change artefact by following a named cell or journey workflow. Use when asked to draft frames, plans, requirements, status, conditions, or run a BA/PM/TA pass.
disable-model-invocation: true
---

Follow `60-workflows/delivery/produce-change-artefact.md` (`change-knowledge-base-wf-032`).

Require a named cell or journey workflow (e.g. `frame-problem`, `ba-change-pass`).
Do not invent domain facts or implement engineering as a methods substitute.
