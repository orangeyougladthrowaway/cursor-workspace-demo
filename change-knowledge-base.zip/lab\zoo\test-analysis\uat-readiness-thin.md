---
type: example
status: draft
id: change-knowledge-base-ex-021
description: Thin exemplar — refuse declaring UAT ready while material intents are uncovered.
derived_from:
  - "[[uat-readiness]]"
  - "[[assess-uat-readiness]]"
updated: 2026-07-16
---

# Uat readiness thin

## When

"Ready for UAT" while key requirements have no coverage and open high-severity defects hide.

## When not

Coverage confirmed; observable exit criteria; residual risk stated; roles named.

## Choice

Fail [[uat-readiness]] / [[status-matches-evidence]]. Run [[assess-uat-readiness]]; give an honest not-ready verdict with evidence.
