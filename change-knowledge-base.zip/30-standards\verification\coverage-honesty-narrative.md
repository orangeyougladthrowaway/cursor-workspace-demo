---
type: standard
status: draft
id: change-knowledge-base-s-031
concern: verification
description: Coverage honesty narrative — usable bar for TA07.
derived_from:
  - "[[coverage-measures-intent]]"
  - "[[status-matches-evidence]]"
  - "[[tradeoff-visible]]"
updated: 2026-07-18
---

# Coverage honesty narrative

## Normally require

A **coverage narrative** (prose or short brief) states:

| Field | Test |
| --- | --- |
| What is covered | Intent groups |
| What is not | Gaps/skips with rationale |
| Risk posture | Why this is enough to proceed or not |
| No count theatre | Avoids test counts as proof |

## Refuse / escalate

- "Fully covered" without gap list
- Line-coverage screenshots as intent proof

## How to produce

[[coverage-honesty-narrative-craft]]. Worked: [[coverage-honesty-narrative-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
