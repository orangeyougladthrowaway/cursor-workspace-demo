"""Tests that layer catalogs list all non-catalog notes."""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.vault import ROOT, extract_wikilinks, note_stems, read_text


CATALOGS = {
    "20-principles": ROOT / "20-principles" / "catalog-principles.md",
    "30-standards": ROOT / "30-standards" / "catalog-standards.md",
    "40-patterns": ROOT / "40-patterns" / "catalog-patterns.md",
    "50-guidance": ROOT / "50-guidance" / "catalog-guidance.md",
    "60-workflows": ROOT / "60-workflows" / "catalog-workflows.md",
}


def _layer_notes(layer: str) -> set[str]:
    base = ROOT / layer
    return {
        p.stem
        for p in base.rglob("*.md")
        if not p.stem.startswith("catalog-") and "templates" not in p.parts
    }


@pytest.mark.parametrize("layer,catalog_path", list(CATALOGS.items()))
def test_catalog_links_cover_layer_notes(layer: str, catalog_path: Path) -> None:
    linked = set(extract_wikilinks(read_text(catalog_path)))
    present = _layer_notes(layer)
    missing = sorted(present - linked)
    assert not missing, f"{layer} catalog missing: {', '.join(missing)}"


def test_maps_catalog_and_theme_atlases_resolve() -> None:
    stems = note_stems()
    required = {
        "catalog-maps",
        "business-analysis-atlas",
        "project-management-atlas",
        "test-analysis-atlas",
    }
    missing = sorted(required - stems)
    assert not missing, f"Missing atlases: {missing}"
