---
type: map
status: draft
id: change-knowledge-base-map-pm
concern: project-management
description: Theme atlas — project management methods body (indexes doctrine; not a PM curriculum).
updated: 2026-07-18
---

# Project management atlas

Index of PM methods knowledge in this vault. **Not** a task playbook.

## Living law

| Concern | Notes |
| --- | --- |
| initiation | [[initiation-mandate]] · [[initiate-project]] · [[terms-of-reference]] · [[business-case]] · [[kickoff-honesty]] |
| planning | [[plan-honesty]] · [[build-plan]] · [[quality-plan]] · [[communications-plan]] · patterns [[work-breakdown-structure]], [[estimate-range-method]] |
| risk | [[risk-cadence]] · [[run-risk-cadence]] · [[raid-pack]] · patterns [[risk-register-shape]], [[raid-log]] |
| status | [[status-reporting-honesty]] · [[status-reporting-craft]] · [[report-status]] · pattern [[status-rag-honesty]] |
| change | [[change-control]] · [[control-change]] · [[decision-log]] |
| stakeholders | [[raci-matrix]] · [[write-raci-matrix]] |
| closure | [[closure-confirmation]] · [[close-delivery]] · [[post-implementation-review]] |
| journey | end-to-end [[pm-delivery-pass]] |
| artefacts | [[change-artefact-policy]] (mandatory set) · [[small-change-control]] (micro/enhancement path) · [[project-artefact-pack]] (shapes) |

## Praxis (after canon)

| Cell | Skeleton | Zoo |
| --- | --- | --- |
| PM01 | `project-initiation/` | [[initiation-mandate-thin]] |
| PM02 | `delivery-plan/` | [[estimate-range-thin]] |
| PM03 | `risk-register/` · `raid-pack/` | [[risk-cadence-thin]] · [[raid-pack-worked]] |
| PM04 | `status-report/` | [[status-rag-thin]] |
| PM05 | `change-request/` | [[change-control-thin]] |
| PM06 | `closure-report/` · `post-implementation-review/` | [[closure-confirmation-thin]] |
| Journey | `pm-delivery-pass/` | — |
| Pack | see [[lab-atlas]] Artefact pack | AR matrix on [[common-case-coverage]] |

Index: [[lab-atlas]]

## Untapped (honest)

- Dry-runs (Axis U4) before `canonical` promotion — see [[roadmap]]
- Deep primary-source harvest — deferred ([[ingest-coverage]])
- Tool/system specialisations — out of scope while abstract

## Related

- [[catalog-maps]] · [[common-case-coverage]] · [[staff-agent-projection]] · [[project-artefact-pack]]
