# Quality plan skeleton

## Purpose

Copy-out starter for quality plan. Cite [[quality-plan]].

## Required canons

- [[quality-plan]]
- [[quality-plan-craft]]
- Workflow: [[write-quality-plan]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[quality-plan-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
