# Decision log

- **Standard:** [[decision-log]]
- **Owner:**

| Id | Date | Decision | Decider | Options considered | Consequences | Links |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |
