# Requirements traceability

- **Standard:** `change-knowledge-base-s-006` ([[requirements-traceability]])
- **Owner:**
- **Problem frame ref:**
- **Requirements pack ref:**
- **Acceptance set ref:**

## Forward (requirement → acceptance)

| Req id | Acceptance id(s) | Gap? |
| --- | --- | --- |
| | | |

## Backward (acceptance → requirement)

| Acceptance id | Req id | Gap? |
| --- | --- | --- |
| | | |

## Link deltas

| Date | Change | Who |
| --- | --- | --- |
| | | |

## Trace status

not ready / ready — evidence:
