---
type: workflow
status: draft
id: change-knowledge-base-wf-078
concern: verification
description: Sequence to produce uat sign off artefact.
derived_from:
  - "[[uat-sign-off]]"
  - "[[uat-sign-off-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Record uat sign off

Agent-operable sequence for [[uat-sign-off]].

## Steps

1. **Retrieve** — theme atlas → [[uat-sign-off]] → [[uat-sign-off-craft]] → [[uat-sign-off-worked]] → skeleton `lab/skeletons/uat-sign-off/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[uat-sign-off]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
