---
type: index
status: draft
id: change-knowledge-base-root
description: Entry point — Change Knowledge Base (PM/BA/TA methods bible + staff-agent praxis).
updated: 2026-07-17
---

# Change Knowledge Base (change-knowledge-base)

The methods bible — how change is analysed, planned, governed, and verified across Project Management (PM), Business Analysis (BA), and Test Analysis (TA). Not domain process truth; not engineering or test-implementation craft.

> **New here? Start from the [agent-harness](../agent-harness/README.md) hub.** It is the single entry point for the workspace: it classifies your task, retrieves the right knowledge, and runs one workflow at a time. Use it before editing this vault directly.

**Two planes:** **doctrine** (`00`–`60` + `maps/`) and **praxis** (`lab/` — examples and skeletons that cite the canon).

**Ambition:** cover the majority of common cases for house PM/BA/TA work, scored on [[common-case-coverage]]. Seeding a skill is not the same as a working staff agent.

## Authority lanes

| Lane | Path | Owns | From this repo |
| --- | --- | --- | --- |
| **change-knowledge-base** (this) | `.` | Change methods, workflows, staff-agent praxis | **Write** |
| **systems-knowledge-base** (optional) | sibling systems vault / `.systems-knowledge-base/` | Domain systems and process facts | **Read-only** |

change-knowledge-base is **standalone** for methods. Code-level test craft and engineering implementation are out of scope ([[scope]]).

## Organising questions

1. What **altitude** of knowledge?
2. What **responsibility folder**?
3. Which **theme atlas**? (`maps/themes/…`)
4. Which tool facets? (`domain` / `aliases`)
5. How **covered** is this track? → [[common-case-coverage]]
6. Need an **exemplar**? → [[lab-atlas]] after the canon

## Start here

| Note | Role |
| --- | --- |
| [[navigation]] | Navigation constitution |
| [[methodology]] | Note shape, naming, linking |
| [[changing-this-bible]] | Amend / retire / cleanliness |
| [[catalog-maps]] | Theme (and optional family) atlases |
| [[common-case-coverage]] | Majority coverage scoreboard (Axis F) |
| [[lab-atlas]] | Praxis index |
| [[purpose]] | Why this exists |
| [[scope]] | In/out |
| [[layout]] | Folders |
| [[staff-agent-projection]] | How PM/BA/TA agents bind to change-knowledge-base |
| [[plan-change-work]] | Plan change-task (skill `change-knowledge-base-plan`) |
| [[produce-change-artefact]] | Produce via named cell/journey (`change-knowledge-base-produce`) |
| [[verify-change-artefact]] | Verify artefact field tests (`change-knowledge-base-verify`) |
| [[review-change-artefact]] | Review honesty / lanes (`change-knowledge-base-review`) |
| [[vault-health-checks]] | How to run vault cleanliness tests |

## Agents

Follow `.cursor/rules/change-knowledge-base-authority.mdc` and root `AGENTS.md`. Prefer theme atlases + responsibility notes. Invoke `change-knowledge-base-plan` / `change-knowledge-base-produce` / `change-knowledge-base-verify` / `change-knowledge-base-review` as thin pointers. Open lab only after the canon. Full-coverage asks → [[common-case-coverage]], not quiet scope shrink.
