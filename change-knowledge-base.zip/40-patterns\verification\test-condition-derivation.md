---
type: pattern
status: draft
id: change-knowledge-base-pt-010
concern: verification
description: Derive test conditions from requirements, acceptance criteria, and risks — traceable analysis.
derived_from:
  - "[[condition-derives-from-intent]]"
  - "[[test-conditions]]"
updated: 2026-07-16
---

# Test condition derivation

## Shape

For each intent source, extract conditions:

| Source | Ask |
| --- | --- |
| Requirement | What must be true / must not happen? |
| Acceptance criterion | What is the observable pass/fail? |
| Risk | What failure are we guarding against? |

Each condition records its **source id**. Add positive, negative, and boundary variants where the rule has ranges ([[boundary-equivalence-thinking]]).

## When

Building a [[test-conditions]] set.

## When not

Inventing conditions with no source; writing executable tests (out of change-knowledge-base scope).

## Related

- [[coverage-dimensions]] · [[derive-test-conditions]]
