---
type: category
status: draft
id: change-knowledge-base-cat-authority
description: Spine for authority — change artefacts have clear ownership and SoT.
updated: 2026-07-16
---

# Authority

## Theme

Multiple competing docs for the same decision produce silent drift.

## Leaves

- [[artefact-has-owner]]
- [[link-across-artefacts]]
- [[work-needs-mandate]]
