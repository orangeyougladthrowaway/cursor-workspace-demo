---
type: standard
status: draft
id: change-knowledge-base-s-010
concern: risk
description: Risk work runs on a cadence — register with owners, scoring, responses, and review rhythm.
derived_from:
  - "[[risk-managed-continuously]]"
  - "[[risk-shapes-attention]]"
  - "[[status-matches-evidence]]"
  - "[[artefact-has-owner]]"
updated: 2026-07-16
---

# Risk cadence

## Normally require

A **risk discipline** for a change includes:

| Field | Test |
| --- | --- |
| Register | Risks (and issues) captured with clear statements — cause → event → effect ([[risk-register-shape]]) |
| Scoring | Probability × impact or equivalent, applied consistently |
| Response | Avoid / reduce / transfer / accept named per material risk |
| Owner | Each risk has an accountable owner ([[artefact-has-owner]]) |
| Cadence | A review rhythm; risks re-scored, closed, or escalated ([[risk-managed-continuously]]) |
| Honesty | Stale or all-green registers flagged, not hidden ([[status-matches-evidence]]) |

## Framework posture

Probability/impact matrices, RAID logs, and response taxonomies are portable frameworks in scope. Domain-specific risk catalogues belong to the user / systems SoR.

## How to produce

[[risk-cadence-craft]]. Worked: [[risk-cadence-worked]].

## Refuse / escalate

- Register logged once and never reviewed ([[risk-managed-continuously]])
- Risks with no owner or no response
- Domain likelihoods that need expert input → escalate; do not invent probabilities

## Not this standard

Plan sequencing ([[plan-honesty]]); status reporting ([[status-reporting-honesty]]); change control ([[change-control]]).
