---
type: example
status: draft
id: change-knowledge-base-ex-044
description: Worked exemplar — requirements conflict good vs bad.
derived_from:
  - "[[requirements-conflict]]"
  - "[[requirements-conflict-craft]]"
updated: 2026-07-18
---

# Requirements conflict worked

## Bad

Merged "invoice date or due date" into vague "age."

## Good

Conflict C1: Ops=invoice date vs Controller=due date. Blocks R1 AC. Owner CFO. Status Open — decision ask 20 Jul.

## Related

- [[requirements-conflict-craft]] · skeleton if present under lab/skeletons/
