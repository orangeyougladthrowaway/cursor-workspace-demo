---
type: standard
status: draft
id: change-knowledge-base-s-008
concern: governance
description: Initiation records mandate, outcome, scope bounds, key stakeholders, and success measure before mobilising.
derived_from:
  - "[[work-needs-mandate]]"
  - "[[outcome-over-output]]"
  - "[[bound-the-change]]"
  - "[[name-who-matters]]"
  - "[[claim-needs-warrant]]"
updated: 2026-07-16
---

# Initiation mandate

## Normally require

An **initiation brief / charter** for a change includes:

| Field | Test |
| --- | --- |
| Mandate | Who authorises the work and holds the budget/decision ([[work-needs-mandate]]) |
| Outcome | The benefit sought, stated as a change in the world ([[outcome-over-output]]) |
| Scope bounds | In / out / assumptions / constraints ([[bound-the-change]]) |
| Key stakeholders | Deciders and materially affected parties ([[name-who-matters]]) |
| Success measure | How success will be judged — measurable or observable |
| Warrant | Why this is worth doing now — or `unknown — escalate` ([[claim-needs-warrant]]) |
| Owner | Who maintains the charter |

## Framework posture

Portable charter shapes (PID-style headings, one-page brief) are allowed. Do not import a vendor gating template as doctrine.

## How to produce

[[initiation-mandate-craft]]. Worked: [[initiation-mandate-worked]].

## Refuse / escalate

- No authorising mandate → escalate; do not self-authorise scope
- Outcome stated only as output ("deliver system X") → push for the benefit
- Business justification unknown → escalate; do not invent value

## Not this standard

Detailed plan ([[plan-honesty]]); change control after baseline ([[change-control]]); BA problem frame ([[problem-framing]]).
