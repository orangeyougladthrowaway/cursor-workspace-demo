---
type: workflow
status: draft
id: change-knowledge-base-wf-016
concern: requirements
description: Sequence to plan or record elicitation against change-knowledge-base-s-007 without inventing answers.
derived_from:
  - "[[elicitation-discipline]]"
  - "[[elicitation-modes]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Elicit requirements

Agent-operable sequence for BA07.

## Steps

1. **Retrieve** — [[business-analysis-atlas]] → [[elicitation-discipline]] (`change-knowledge-base-s-007`) → [[elicitation-craft]] → [[elicitation-modes]] → skeleton `lab/skeletons/elicitation-record/`.
2. **Name unknowns** — from frame, stakeholder map, or pack gaps. No unknown → stop (nothing to elicit).
3. **Choose mode + target** — follow [[elicitation-craft]]; match influence/interest ([[influence-interest-grid]]); escalate if targets unknown.
4. **Write prompts** — discovery focus; forbid leading “confirm our solution” scripts unless validating a named option.
5. **Record results** — findings, conflicts, warrants earned; remaining unknowns explicit.
6. **Feed forward** — update [[requirements-quality]] pack warrants; do not invent missing answers.

## Forbidden

- Filling requirements to avoid elicitation
- Inventing stakeholder answers
- Tool/system encyclopaedia as “elicitation”
