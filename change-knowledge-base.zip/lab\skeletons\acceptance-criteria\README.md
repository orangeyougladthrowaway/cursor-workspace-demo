# Acceptance criteria skeleton

## Purpose

Copy-out starter for acceptance criteria tied to requirements. Cite [[acceptance-criteria]] (`change-knowledge-base-s-003`).

## Required canons

- [[acceptance-criteria]]
- Requirements pack meeting [[requirements-quality]]
- Workflow: [[write-acceptance-criteria]]

## Copy

1. Copy `criteria.md` into the host work area.
2. One observable pass/fail set per requirement (or scenario group).
3. Escalate domain gaps; do not design code-level tests here.

## Honesty

Skeleton ≠ doctrine. No vague adjective-only criteria. Data/historisation intents need insert/change/noop/tombstone (or Gap) ([[precision-over-vagueness]]).
