---
type: standard
status: draft
id: change-knowledge-base-s-013
concern: delivery
description: Closure confirms outcome vs mandate, records residuals and lessons, and hands off ownership.
derived_from:
  - "[[close-confirms-benefit]]"
  - "[[status-matches-evidence]]"
  - "[[tradeoff-visible]]"
  - "[[artefact-has-owner]]"
updated: 2026-07-16
---

# Closure confirmation

## Normally require

A **closure record** for a change includes:

| Field | Test |
| --- | --- |
| Outcome check | Achieved vs the initiation mandate/success measure ([[close-confirms-benefit]], [[initiation-mandate]]) |
| Delivered scope | What shipped vs planned, with descopes named ([[tradeoff-visible]]) |
| Residuals | Open items, defects, or benefits not yet realised — with owners |
| Handoff | Who owns run/support/benefit realisation next ([[artefact-has-owner]]) |
| Lessons | Portable learnings (kept as method pressure, not a diary) |
| Honesty | No "success" claim while material residuals hide ([[status-matches-evidence]]) |

## Framework posture

Closure report and lessons-log shapes are portable. Benefit-realisation tracking beyond handoff is a governance concern, not this artefact.

## How to produce

[[closure-confirmation-craft]]. Worked: [[closure-confirmation-worked]].

## Refuse / escalate

- Declaring done because activity stopped, not because outcome was met ([[close-confirms-benefit]])
- Benefit realisation unknown → escalate to the accountable owner
- Residuals with no owner

## Not this standard

Initiation ([[initiation-mandate]]); status reporting ([[status-reporting-honesty]]); UAT readiness ([[uat-readiness]]).
