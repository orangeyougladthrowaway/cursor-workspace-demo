---
type: example
status: draft
id: change-knowledge-base-ex-062
description: Worked exemplar — business case good vs bad.
derived_from:
  - "[[business-case]]"
  - "[[business-case-craft]]"
updated: 2026-07-18
---

# Business case worked

## Bad

"Build dashboard — ROI huge." No options, no measures.

## Good (excerpt)

Options: (A) aged view+export (B) defer (C) do nothing. Rec: A. Benefit: cut ~4h/month join (ops warrant). Cost: eng estimate range. Risk: vendor API. Ask: CFO approve A by 20 Jul.

## Related

- [[business-case-craft]] · `lab/skeletons/business-case/`
