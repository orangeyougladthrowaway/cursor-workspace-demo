---
type: glossary
status: draft
id: change-knowledge-base-fnd-glossary
description: Local definitions as used in this methods bible.
updated: 2026-07-16
---

# Glossary

| Term | Meaning |
| --- | --- |
| Aliases | Frontmatter search tokens only — never old basenames or rename substitutes |
| Atlas | Knowledge index under `maps/themes/` or `maps/families/` — not a task playbook |
| Axis F | Majority common-case program for PM/BA/TA tracks ([[common-case-coverage]]) |
| systems-knowledge-base | Systems Knowledge Base — domain process/system facts (optional read-only sibling) |
| change-knowledge-base | This vault — Change Knowledge Base (standalone methods bible) |
| Common case | Recurring ship/break methods question for house PM/BA/TA work |
| Concern | Folder name in frontmatter (must match parent; maps use theme/family leaf) |
| G1–G4 | Coverage gates: law · rooted · depth · praxis |
| Lab / praxis | Subordinate plane under `lab/` — zoo, skeletons, stubs that cite doctrine |
| Skeleton | Copy-out artefact starter under `lab/skeletons/` — not note templates |
| Staff agent | PM/BA/TA agent bound to change-knowledge-base via [[staff-agent-projection]] |
| Micro-fix | Engagement class — bounded defect/tweak; thinner M-set; cell-first path ([[change-artefact-policy]] · [[small-change-control]]) |
| Enhancement | Engagement class — increment on a live mandate; thinned journey or selected cells |
| BAU (colloquial) | Maps to **micro-fix** or **enhancement** — not a sixth class |
| Theme atlas | Primary browse body (`maps/themes/{theme}/`) |
| Zoo | Thin `type: example` notes under `lab/zoo/{facet}/` |
| Deprecated | Brief migration status only — then delete |
| Domain (facet) | Tool tags in frontmatter — never L1 folders |
| Quarantine | Habits that must not become doctrine |
| Stem ↔ H1 | Basename kebab and note title must agree |
| Wikilink basename | Globally unique vault note handle used as `[[navigation]]` |
