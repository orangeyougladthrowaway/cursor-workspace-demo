---
name: change-knowledge-base-review
description: Independently reviews a change artefact for honesty, cited ids, and lane walls. Use when asked to review BA/PM/TA outputs or status evidence.
disable-model-invocation: true
---

Follow `60-workflows/governance/review-change-artefact.md` (`change-knowledge-base-wf-034`).

Findings first. No green-wash. Do not rewrite the artefact unless asked.
