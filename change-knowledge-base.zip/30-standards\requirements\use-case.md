---
type: standard
status: draft
id: change-knowledge-base-s-045
concern: requirements
description: Use case — flows plus named system I/O when data crosses boundaries.
derived_from:
  - "[[intent-must-be-testable]]"
  - "[[name-who-matters]]"
  - "[[enough-to-decide]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Use case

## Normally require

**Use cases** include:

| Field | Test |
| --- | --- |
| Diagram or index | Actors, use cases, system boundary |
| Description | Goal, primary actor, preconditions, main flow, alternatives/exceptions, postconditions |
| Trace | Link to catalogue ids |
| Testability | Flows support AC/conditions |
| I/O (when data moves) | Named inputs/outputs (systems, files, stores); link catalogue / field map ([[precision-over-vagueness]]) |

## Refuse / escalate

- UI click-scripts with no goal
- Invented actor behaviour — escalate
- Data-crossing flows with unnamed artefacts

## How to produce

[[use-case-craft]]. Worked: [[use-case-worked]]. Skeleton: `lab/skeletons/use-case/`.

## Related

- [[common-case-coverage]] · workflow [[write-use-case]] · [[data-model]]
