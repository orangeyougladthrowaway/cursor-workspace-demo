---
type: standard
status: draft
id: change-knowledge-base-s-030
concern: verification
description: Boundary applied — usable bar for TA06.
derived_from:
  - "[[condition-derives-from-intent]]"
  - "[[intent-must-be-testable]]"
updated: 2026-07-18
---

# Boundary applied

## Normally require

When intents imply ranges/partitions, the condition set applies [[boundary-equivalence-thinking]]:

| Field | Test |
| --- | --- |
| Classes | Equivalence classes named |
| Boundaries | Edge values have conditions |
| Trace | Back to AC/req |
| Honesty | Not only happy mid-range examples |

## Refuse / escalate

- Boundary ignored when numeric/date rules exist
- Invented edges when rule unknown — escalate

## How to produce

[[boundary-applied-craft]]. Worked: [[boundary-applied-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
