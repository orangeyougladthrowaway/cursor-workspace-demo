---
type: example
status: draft
id: change-knowledge-base-ex-042
description: Worked exemplar — options communication good vs bad.
derived_from:
  - "[[options-communication]]"
  - "[[options-communication-craft]]"
updated: 2026-07-18
---

# Options communication worked

## Bad

"We should build ML." No alternatives.

## Good

Ask: Include R4 this release? Options: (A) include +15d (B) defer new frame (C) do nothing. Rec: B. Decide: CFO by 15 Jul.

## Related

- [[options-communication-craft]] · skeleton if present under lab/skeletons/
