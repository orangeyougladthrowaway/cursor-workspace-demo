---
type: guidance
status: draft
id: change-knowledge-base-g-023
concern: requirements
description: How to perform requirements conflict — house craft for BA12.
derived_from:
  - "[[requirements-conflict]]"
updated: 2026-07-18
---

# Requirements conflict craft

House how-to for BA12. Field tests: [[requirements-conflict]].

## House defaults

1. Capture both (all) positions with warrants.
2. Block dependent AC/priority until resolved or explicitly deferred.
3. Decision owner named (often sponsor).
4. Resolved conflict updates req pack + trace.

## Done test

Positions · impact · decision owner · status honest.

## Related

- [[requirements-conflict]] · [[requirements-conflict-worked]] · [[common-case-coverage]]
