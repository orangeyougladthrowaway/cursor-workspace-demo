---
type: principle
status: draft
id: change-knowledge-base-p-023
category: evidence
description: A defect report carries reproduction, expected vs actual, and impact — not a bare complaint.
derived_from:
  - "[[evidence]]"
updated: 2026-07-16
---

# Defect carries evidence

A defect states **what was expected, what happened, how to reproduce, and why it matters**. "It's broken" without evidence is noise, not a defect.
