# Gap analysis skeleton

## Purpose

Copy-out starter for gap analysis. Cite [[gap-analysis]].

## Required canons

- [[gap-analysis]]
- [[gap-analysis-craft]]
- Workflow: [[write-gap-analysis]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[gap-analysis-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
