# Intent coverage skeleton

## Purpose

Copy-out starter for an intent-coverage assessment. Cite [[intent-coverage]] (`change-knowledge-base-s-016`).

## Required canons

- [[intent-coverage]] · [[coverage-dimensions]]
- Workflow: [[assess-intent-coverage]]

## Copy

1. Copy `coverage.md` into the host work area.
2. Map intents to conditions; classify covered/gap/untestable per dimension.
3. Cite `change-knowledge-base-s-016`. Line/code coverage is out of change-knowledge-base scope.

## Honesty

Skeleton ≠ doctrine. No test counts as proof; name gaps.
