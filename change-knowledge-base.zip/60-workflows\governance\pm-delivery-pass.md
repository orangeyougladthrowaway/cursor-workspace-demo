---
type: workflow
status: draft
id: change-knowledge-base-wf-024
concern: governance
description: End-to-end PM delivery pass — sequence PM cells without skipping mandate or honesty.
derived_from:
  - "[[initiation-mandate]]"
  - "[[plan-honesty]]"
  - "[[risk-cadence]]"
  - "[[status-reporting-honesty]]"
  - "[[change-control]]"
  - "[[closure-confirmation]]"
  - "[[project-artefact-pack]]"
  - "[[change-artefact-policy]]"
  - "[[small-change-control]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-20
---

# Pm delivery pass

One supervised pass across the PM cell set. **Not** a curriculum — a dependency order with running cadences.

## Sequence

1. **Initiate** — [[initiate-project]] (`change-knowledge-base-s-008`). Stop if no mandate. Produce only policy-selected start docs (ToR / business case / RACI / kickoff) per [[change-artefact-policy]].
2. **Plan** — [[build-plan]] (`change-knowledge-base-s-009`) with WBS + estimate ranges. Produce selected quality/comms/RAID items from the plan’s M/R account.
3. **Run cadences** (recurring) — [[run-risk-cadence]] (`change-knowledge-base-s-010`) and [[report-status]] (`change-knowledge-base-s-011`) on a rhythm; keep RAID / decision log current when mandatory or selected.
4. **Control changes** (as they arise) — [[control-change]] (`change-knowledge-base-s-012`) against the baseline.
5. **Close** — [[close-delivery]] (`change-knowledge-base-s-013`) confirming outcome vs mandate; PIR when policy/plan marks Produce.
6. **Verify pass** — each artefact cites its `id`; M-set accounted; open escalations listed; no green-wash.

## Branching

- **Class path** ([[change-artefact-policy]] §7 · [[small-change-control]]): **micro-fix** — cells covering M (often defect clarity + closure lite); living mandate check, not a new initiation pack by default. **Enhancement** — thinned pass (plan slice + RAID/decision/status/change-control as M); name skips. **Project / regulatory** — this sequence is the default.
- Cadences (risk, status) repeat throughout when selected — not once.
- Any step may **escalate** and pause the pass.
- Skip a step only with an explicit because tied to scope — not convenience or “it’s BAU.”

## Skeleton

`lab/skeletons/pm-delivery-pass/` — checklist citing this workflow.

## Forbidden

- Planning or reporting with no mandate baseline
- Running risk/status as one-offs
- Inventing domain facts to keep the pass green
