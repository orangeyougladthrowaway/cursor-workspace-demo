---
type: example
status: draft
id: change-knowledge-base-ex-041
description: Worked exemplar — assumption log good vs bad.
derived_from:
  - "[[assumption-log]]"
  - "[[assumption-log-craft]]"
updated: 2026-07-18
---

# Assumption log worked

## Bad

"API will be ready" buried in chat.

## Good

| Id | Statement | If false | Owner | Status |
| --- | --- | --- | --- | --- |
| A1 | Vendor status field matches docs | Export wrong | PM | Open — spike |
| A2 | IdP groups exist for Finance | Auth blocked | BA | Invalidate → escalate IT |

## Related

- [[assumption-log-craft]] · skeleton if present under lab/skeletons/
