---
type: guidance
status: draft
id: change-knowledge-base-g-001
concern: verification
description: How to write usable acceptance criteria — observables, ties, refuse patterns, done tests.
derived_from:
  - "[[acceptance-criteria]]"
  - "[[intent-must-be-testable]]"
  - "[[status-matches-evidence]]"
  - "[[enough-to-decide]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Acceptance criteria craft

House how-to for BA03. Field tests live on [[acceptance-criteria]]; this note is how to *produce* criteria a stranger can verify.

## Applies when

Turning in-scope requirements (stable ids) into observable pass/fail criteria for BA ↔ build ↔ TA handoff.

## Does not apply when

- Designing pytest/fixtures/automation (engineering lane)
- Inventing domain rules missing from systems-knowledge-base / user — escalate instead

## House defaults

1. **One requirement → one or more scenarios**, each with an observable outcome. Prefer Given / When / Then or equivalent; shape is secondary to observability.
2. **Tie every row to a requirement id.** Orphan criteria are noise.
3. **Prefer behaviour over adjectives.** “User-friendly”, “fast”, “secure” fail unless an agreed measure or check is named — or escalate for the measure.
4. **Name the actor and the system surface** when it matters (who does what where). Vague “the system should allow…” hides scope.
5. **Negative / refusal paths** for material risk: what must *not* happen, or how the system refuses.
6. **Data and state** called out when the outcome depends on them (preconditions in Given) — keys, hashes, target tables when historisation is in scope.
7. **Stop when domain facts are missing.** Write the Gap; do not invent process lore to keep the pack “green.”
8. **Precision:** happy-path-only fails when change/delete/noop are in the requirement ([[precision-over-vagueness]]).

## Decision rules

| Situation | Do |
| --- | --- |
| Measure unknown (perf, UX) | Escalate for threshold; or mark criterion blocked — do not fake numbers |
| Multi-step journey | Split scenarios; keep each Then independently checkable |
| Shared setup | Factor Given; do not copy-paste conflicting preconditions |
| NFR without owner | Frame as open question to sponsor ([[enough-to-decide]]) — not silent skip |

## Done test

| Check | Pass means |
| --- | --- |
| Observable | A stranger can say pass/fail without re-interpreting adjectives |
| Tied | Every scenario cites a requirement / intent id |
| Honest | No “done” claim on vague rows ([[status-matches-evidence]]) |
| Domain-safe | No invented process/system facts |
| Precise | Grain matches requirement (keys/states/measures); not happy-path-only when change/delete in scope |

## Refuse / escalate

- Adjective-only packs
- Criteria that encode unconfirmed domain SoR
- Substituting automation design for analysis

## Related

- [[acceptance-criteria]] · [[write-acceptance-criteria]] · [[requirements-quality]] · [[acceptance-criteria-worked]] · [[intent-must-be-testable]]
