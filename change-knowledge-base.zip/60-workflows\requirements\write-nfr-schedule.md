---
type: workflow
status: draft
id: change-knowledge-base-wf-068
concern: requirements
description: Sequence to produce nfr schedule artefact.
derived_from:
  - "[[nfr-schedule]]"
  - "[[nfr-schedule-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write nfr schedule

Agent-operable sequence for [[nfr-schedule]].

## Steps

1. **Retrieve** — theme atlas → [[nfr-schedule]] → [[nfr-schedule-craft]] → [[nfr-schedule-worked]] → skeleton `lab/skeletons/nfr-schedule/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[nfr-schedule]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
