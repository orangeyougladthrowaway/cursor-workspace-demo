---
type: example
status: draft
id: change-knowledge-base-ex-010
description: Thin exemplar — refuse skipping frame and elicit to jump to acceptance criteria.
derived_from:
  - "[[ba-change-pass]]"
  - "[[frame-problem]]"
updated: 2026-07-16
---

# Ba change pass thin

## When

Ask is “write acceptance criteria” with no problem frame and no warrants.

## When not

Upstream frame + elicited warrants exist (or gaps explicitly escalated).

## Choice

Enter [[ba-change-pass]] at step 1; do not green-wash step 6. Escalate missing inputs.
