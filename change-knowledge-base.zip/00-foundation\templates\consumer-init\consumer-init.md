---
type: template
status: draft
id: change-knowledge-base-tpl-consumer-init
description: Copy-pack for staff-agent host repos — AGENTS + change-knowledge-base-readonly rule; fill fields; do not commit the pack folder.
domain: [cursor]
updated: 2026-07-17
---

# Consumer init

Copy the **listed sibling files** into a **host repo root** (where PM/BA/TA agents work tickets), then fill brackets. Do **not** copy the change-knowledge-base vault into the host tree as committed doctrine.

**Hard cleanup:** after copying, the host must **not** keep a `consumer-init/` folder. Commit only root `AGENTS.md`, `.cursor/rules/change-knowledge-base-readonly.mdc`, and gitignore lines.

## Agent binding

Host control files must encode:

- change-knowledge-base as **primary** methods source
- systems-knowledge-base (optional) for domain facts
- **Retrieve before act** (theme atlas → canons → workflow → artefact)
- Never invent domain lore; escalate when facts are missing
- Code-level test craft is out of change-knowledge-base scope

Wording SoT: [[staff-agent-projection]].

## Copy checklist (host repo)

1. Copy **only** `AGENTS.md` → host root; fill fields (BA profile defaults below).
2. Copy **only** `change-knowledge-base-readonly.mdc` → `.cursor/rules/change-knowledge-base-readonly.mdc`.
3. Append lines from `gitignore-snippet.txt` into the host `.gitignore`.
4. Mount change-knowledge-base locally (pick one):
   - **Preferred:** sibling `../change-knowledge-base` and set path in `AGENTS.md`.
   - **Junction:** `mklink /J .change-knowledge-base X:\repos\change-knowledge-base` (gitignored).
5. Confirm mounts are ignored and **not** staged.
6. **Delete** any accidental `consumer-init/` pack folder from the host tree.
7. Start work; agents read change-knowledge-base via path in `AGENTS.md` / `.change-knowledge-base`.

## Files in this folder

| File | Role |
| --- | --- |
| `AGENTS.md` | Host agent entry — methods primary source + operating law |
| `change-knowledge-base-readonly.mdc` | Always-on: change-knowledge-base primary for methods; read-only vault |
| `gitignore-snippet.txt` | Ignore `.change-knowledge-base/`, optional `.systems-knowledge-base/` |

## Related

- [[staff-agent-projection]] · [[common-case-coverage]] · [[business-analysis-atlas]]
