---
type: standard
status: draft
id: change-knowledge-base-s-005
concern: requirements
description: Prioritisation names a framework, ranks with outcome/risk rationale, and shows tradeoffs.
derived_from:
  - "[[rank-by-outcome]]"
  - "[[outcome-over-output]]"
  - "[[risk-shapes-attention]]"
  - "[[tradeoff-visible]]"
  - "[[status-matches-evidence]]"
  - "[[enough-to-decide]]"
updated: 2026-07-16
---

# Requirements prioritisation

## Normally require

A **prioritisation view** over in-scope requirements (or slices) includes:

| Field | Test |
| --- | --- |
| Framework | Named portable method (e.g. MoSCoW bands, Now-Next-Later, value×risk matrix, cost-of-delay style) — see [[moscow-bands]], [[value-risk-matrix]] |
| Ordered set | Explicit rank or bands — not an unordered dump |
| Rationale | Why this before that via outcome and/or material risk ([[rank-by-outcome]]) |
| Trace | Each ranked item links to a requirement id from a pack meeting [[requirements-quality]] |
| Tradeoffs | Deferred/rejected/reduced items named ([[tradeoff-visible]]) |
| Honesty | “All Must” / all P1 without tradeoff fails ([[status-matches-evidence]]) |
| Owner | Who maintains the ranking |

## Framework posture

Choose **one** primary framework per view and apply it consistently. Mixing labels without mapping (Must vs P1 vs Now) fails clarity.

## How to produce

[[requirements-prioritisation-craft]]. Worked: [[requirements-prioritisation-worked]].

## Refuse / escalate

- Ranking items whose meaning or value basis is unknown → escalate; do not invent business value
- Tool backlog order presented as analysis without rationale
- Pretending everything is top priority

## Not this standard

Requirements quality ([[requirements-quality]]); acceptance wording ([[acceptance-criteria]]); elicitation ([[elicitation-discipline]]).
