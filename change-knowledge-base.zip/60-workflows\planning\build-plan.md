---
type: workflow
status: draft
id: change-knowledge-base-wf-019
concern: planning
description: Sequence to build a plan against change-knowledge-base-s-009 with WBS and honest estimate ranges.
derived_from:
  - "[[plan-honesty]]"
  - "[[work-breakdown-structure]]"
  - "[[estimate-range-method]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Build plan

Agent-operable sequence for PM02.

## Steps

1. **Retrieve** — [[project-management-atlas]] → [[plan-honesty]] (`change-knowledge-base-s-009`) → [[work-breakdown-structure]] · [[estimate-range-method]] → skeleton `lab/skeletons/delivery-plan/`.
2. **Preconditions** — agreed initiation mandate ([[initiate-project]]) or escalate.
3. **Decompose** — WBS to ownable/estimable items.
4. **Sequence** — dependencies, milestones tied to outcome.
5. **Estimate** — ranges with assumptions; no single-point certainty.
6. **Link risks** — cross-reference [[risk-cadence]].
7. **Cite** — `change-knowledge-base-s-009`. Escalate effort that hinges on unknown domain facts.

## Forbidden

- Single-point estimates as certainty
- Flat task list with no dependencies
- Inventing durations for unknown domain work
