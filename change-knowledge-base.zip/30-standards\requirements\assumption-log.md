---
type: standard
status: draft
id: change-knowledge-base-s-021
concern: requirements
description: Assumption log — usable bar for BA09.
derived_from:
  - "[[claim-needs-warrant]]"
  - "[[bound-the-change]]"
  - "[[status-matches-evidence]]"
updated: 2026-07-18
---

# Assumption log

## Normally require

An **assumption / dependency log** includes:

| Field | Test |
| --- | --- |
| Statement | Clear assumption or external dependency |
| Impact if false | What breaks |
| Owner | Who validates / watches |
| Status | Open / validated / invalidated |
| Link | Related req/plan/risk ids |

## Refuse / escalate

- Silent assumptions treated as facts
- Invented validation — escalate to SME/SoR

## How to produce

[[assumption-log-craft]]. Worked: [[assumption-log-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
