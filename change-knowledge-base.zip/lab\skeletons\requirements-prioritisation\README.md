# Requirements prioritisation skeleton

## Purpose

Copy-out starter for ranking requirements. Cite [[requirements-prioritisation]] (`change-knowledge-base-s-005`).

## Required canons

- [[requirements-prioritisation]]
- Pack meeting [[requirements-quality]]
- Workflow: [[prioritise-requirements]]

## Copy

1. Copy `priority.md` into the host work area.
2. Rank or band each requirement id; write outcome/risk rationale.
3. Name deferred/rejected. Cite `change-knowledge-base-s-005`.

## Honesty

No “all Must.” Skeleton ≠ doctrine.
