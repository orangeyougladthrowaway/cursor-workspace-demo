---
type: workflow
status: draft
id: change-knowledge-base-wf-045
concern: risk
description: Sequence to produce issue risk split for PM07.
derived_from:
  - "[[issue-risk-split]]"
  - "[[issue-risk-split-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Split issue risk

Agent-operable sequence for PM07.

## Steps

1. **Retrieve** — theme atlas → [[issue-risk-split]] → [[issue-risk-split-craft]] → [[issue-risk-split-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[issue-risk-split]]; escalate Gaps.
5. **Cite** — `issue-risk-split` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
