# Raid pack skeleton

## Purpose

Copy-out starter for raid pack. Cite [[raid-pack]].

## Required canons

- [[raid-pack]]
- [[raid-pack-craft]]
- Workflow: [[maintain-raid-log]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[raid-pack-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
