---
type: workflow
status: draft
id: change-knowledge-base-wf-046
concern: planning
description: Sequence to produce delivery dependencies for PM08.
derived_from:
  - "[[delivery-dependencies]]"
  - "[[delivery-dependencies-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Manage delivery dependencies

Agent-operable sequence for PM08.

## Steps

1. **Retrieve** — theme atlas → [[delivery-dependencies]] → [[delivery-dependencies-craft]] → [[delivery-dependencies-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[delivery-dependencies]]; escalate Gaps.
5. **Cite** — `delivery-dependencies` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
