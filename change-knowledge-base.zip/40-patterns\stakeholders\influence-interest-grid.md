---
type: pattern
status: draft
id: change-knowledge-base-pt-001
concern: stakeholders
description: Influence × interest grid — portable engagement shape (Mendelow-style), not org lore.
derived_from:
  - "[[influence-shapes-engagement]]"
  - "[[stakeholder-clarity]]"
updated: 2026-07-16
---

# Influence interest grid

## Shape

Place each party on two axes:

| | Low interest | High interest |
| --- | --- | --- |
| **High influence** | Keep satisfied — concise updates; protect critical decisions | Manage closely — co-design / agree path |
| **Low influence** | Monitor — minimal noise | Keep informed — pull channels; invite when scoped |

Axes may be labelled power/interest; the **question** is the same: who can block, who cares, what engagement fits.

## When

Stakeholder map needs engagement strategy beyond a flat list ([[stakeholder-clarity]]).

## When not

As a substitute for naming interest/impact; as a dump of every employee; as invented politics.

## Related

- Workflow [[map-stakeholders]] · standard [[stakeholder-clarity]]
