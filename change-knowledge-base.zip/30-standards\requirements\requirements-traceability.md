---
type: standard
status: draft
id: change-knowledge-base-s-006
concern: requirements
description: Traceability keeps frame, requirement, and acceptance intent linked; orphans and silent breaks fail.
derived_from:
  - "[[link-across-artefacts]]"
  - "[[artefact-has-owner]]"
  - "[[intent-must-be-testable]]"
  - "[[control-the-delta]]"
  - "[[status-matches-evidence]]"
updated: 2026-07-16
---

# Requirements traceability

## Normally require

A **trace view** for the change includes:

| Field | Test |
| --- | --- |
| Forward | Each in-scope requirement id links to ≥1 acceptance criterion (or explicit `gap — escalate`) |
| Backward | Each acceptance criterion links to a requirement id |
| Frame link | Requirements pack cites the governing [[problem-framing]] |
| Delta | Broken or changed links record who/when ([[control-the-delta]], [[link-across-artefacts]]) |
| Honesty | “Fully traced” only when gaps are zero or explicitly accepted ([[status-matches-evidence]]) |
| Owner | Who maintains the trace |

## How to produce

[[requirements-traceability-craft]]. Worked: [[requirements-traceability-worked]].

## Refuse / escalate

- Filling trace cells with invented domain rules → systems-knowledge-base / user
- Claiming coverage when acceptance criteria are missing or untestable ([[acceptance-criteria]])

## Not this standard

Writing the criteria themselves ([[acceptance-criteria]]); code-level test matrix (out of change-knowledge-base scope).
