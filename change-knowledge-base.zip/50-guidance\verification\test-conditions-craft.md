---
type: guidance
status: draft
id: change-knowledge-base-g-009
concern: verification
description: How to derive test conditions from intent — trace, types, gaps, no invented expected behaviour.
derived_from:
  - "[[test-conditions]]"
  - "[[condition-derives-from-intent]]"
  - "[[boundary-equivalence-thinking]]"
updated: 2026-07-18
---

# Test conditions craft

House how-to for TA01. Field tests: [[test-conditions]]. Analysis grain only — no automation craft.

## Applies when

Requirements/AC/risks exist and need a condition set for coverage and design handoff.

## House defaults

1. **Start from intent ids** (requirement, AC scenario, named risk) — never from a free-floating “test idea” list.
2. **One condition = one verifiable claim.** Bundle less; split more when Then clauses diverge.
3. **Cover positive, negative, and boundary** where the intent implies them ([[boundary-equivalence-thinking]]).
4. **Priority follows risk/focus**, not author convenience ([[risk-based-test-focus]]).
5. **Flag intents with no condition** as Gaps — silence is false coverage.
6. **Escalate when expected behaviour is unknown.** Do not invent domain rules to finish the set.
7. **Stop at analysis.** Scripts, fixtures, and CI belong to the engineering lane.

## Decision rules

| Situation | Do |
| --- | --- |
| AC adjective-only | Reject upstream to BA; do not derive fake conditions |
| High-risk path | Extra negative/boundary conditions; cite risk id |
| Equivalence classes | One condition per class + note representatives |
| Overlap with AC | Prefer AC as source; condition may refine observation focus |

## Done test

| Check | Pass means |
| --- | --- |
| Trace | Every condition cites intent/AC/risk |
| Testable | Pass/fail imaginable without code |
| Types | Pos/neg/boundary considered where relevant |
| Gaps | Uncovered intents listed |
| Lane | No pytest/automation substitute |

## Related

- [[test-conditions]] · [[derive-test-conditions]] · [[boundary-equivalence-thinking]] · [[test-conditions-worked]] · [[intent-coverage]]
