---
type: guidance
status: draft
id: change-knowledge-base-g-030
concern: verification
description: How to perform coverage honesty narrative — house craft for TA07.
derived_from:
  - "[[coverage-honesty-narrative]]"
updated: 2026-07-18
---

# Coverage honesty narrative craft

House how-to for TA07. Field tests: [[coverage-honesty-narrative]].

## House defaults

1. Write for decision makers: enough or not.
2. Pair with [[intent-coverage]] table.
3. State residual risk explicitly.
4. Recommend proceed / hold / narrow scope.

## Done test

Covered · not covered · risk posture · decision ask.

## Related

- [[coverage-honesty-narrative]] · [[coverage-honesty-narrative-worked]] · [[common-case-coverage]]
