---
type: standard
status: draft
id: change-knowledge-base-s-018
concern: verification
description: UAT readiness confirms intent coverage, entry/exit criteria, and honest residual risk before sign-off.
derived_from:
  - "[[status-matches-evidence]]"
  - "[[intent-must-be-testable]]"
  - "[[tradeoff-visible]]"
  - "[[artefact-has-owner]]"
updated: 2026-07-16
---

# Uat readiness

## Normally require

A **UAT readiness view** includes:

| Field | Test |
| --- | --- |
| Scope | Which intents UAT will confirm ([[intent-coverage]]) |
| Entry criteria | What must be true to start UAT (build, data, access — access facts from user/SoR) |
| Exit criteria | Observable pass/fail for sign-off ([[intent-must-be-testable]]) |
| Residual risk | Known open defects/gaps with severity ([[defect-clarity]], [[tradeoff-visible]]) |
| Roles | Who tests, who signs off ([[artefact-has-owner]]) |
| Honesty | "Ready" while material gaps/defects hide fails ([[status-matches-evidence]]) |

## Framework posture

Entry/exit criteria and readiness checklists are portable. Test environment/tool specifics are user/SoR domain, not this vault.

## How to produce

[[uat-readiness-craft]]. Worked: [[uat-readiness-worked]].

## Refuse / escalate

- Declaring ready while material intents are uncovered ([[intent-coverage]])
- Exit criteria that are not observable
- Environment/data facts unknown → escalate; do not assume

## Not this standard

Deriving conditions ([[test-conditions]]); acceptance wording ([[acceptance-criteria]]); PM closure ([[closure-confirmation]]).
