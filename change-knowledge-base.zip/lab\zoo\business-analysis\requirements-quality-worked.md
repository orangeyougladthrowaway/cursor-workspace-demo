---
type: example
status: draft
id: change-knowledge-base-ex-030
description: Worked exemplar — clear warranted requirement vs ambiguous ready theatre.
derived_from:
  - "[[requirements-quality]]"
  - "[[requirements-quality-craft]]"
updated: 2026-07-18
---

# Requirements quality worked

## Bad

R1: System should be fast and user-friendly. Status: Ready. Warrant: none.

## Good

| Id | Requirement | Warrant | Status |
| --- | --- | --- | --- |
| R1 | Finance user can view unpaid invoices aged >= 30 days filtered by age band | Ops interview 1 Jul | Draft — open: age rule SoR |
| R2 | Finance user with export permission can download filtered set as CSV | Same + AC pack | Ready for prioritise |

Non-requirements: colour themes (R3) not Must. Owner: BA A. Example. Frame: PF-12.
