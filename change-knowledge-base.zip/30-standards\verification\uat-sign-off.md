---
type: standard
status: draft
id: change-knowledge-base-s-058
concern: verification
description: Uat sign off — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[uat-readiness]]"
  - "[[status-matches-evidence]]"
  - "[[artefact-has-owner]]"
updated: 2026-07-18
---

# Uat sign off

## Normally require

A **UAT sign-off** record includes:

| Field | Test |
| --- | --- |
| Scope signed | Intents/AC covered |
| Evidence | Results / completion report ref |
| Residuals accepted | Named with owners |
| Signatories | Named roles + date |
| Decision | Accept / accept with conditions / reject |

## Refuse / escalate

- Sign-off while Must gaps hide

## How to produce

[[uat-sign-off-craft]]. Worked: [[uat-sign-off-worked]]. Skeleton: `lab/skeletons/uat-sign-off/`.

## Related

- [[common-case-coverage]] · workflow [[record-uat-sign-off]]
