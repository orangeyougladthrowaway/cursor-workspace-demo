# Gap analysis

- **Standard:** [[gap-analysis]]
- **Owner:**
- **Linked frame:**

## As-is (warranted)

## To-be (outcome-linked)

## Gaps

| Gap | Evidence | Impact |
| --- | --- | --- |
| | | |

## Actions / options

| Action | Addresses gap | Notes |
| --- | --- | --- |
| | | |
