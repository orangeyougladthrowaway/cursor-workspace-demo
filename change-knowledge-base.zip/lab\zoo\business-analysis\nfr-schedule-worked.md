---
type: example
status: draft
id: change-knowledge-base-ex-068
description: Worked exemplar — nfr schedule good vs bad.
derived_from:
  - "[[nfr-schedule]]"
  - "[[nfr-schedule-craft]]"
updated: 2026-07-18
---

# Nfr schedule worked

## Good

NFR-1 Perf: aged list <3s p95 for 10k rows, Finance role. Priority Must. Open: confirm 3s with sponsor.

## Related

- [[nfr-schedule-craft]] · `lab/skeletons/nfr-schedule/`
