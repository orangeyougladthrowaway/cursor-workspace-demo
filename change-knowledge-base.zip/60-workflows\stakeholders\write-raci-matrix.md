---
type: workflow
status: draft
id: change-knowledge-base-wf-071
concern: stakeholders
description: Sequence to produce raci matrix artefact.
derived_from:
  - "[[raci-matrix]]"
  - "[[raci-matrix-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write raci matrix

Agent-operable sequence for [[raci-matrix]].

## Steps

1. **Retrieve** — theme atlas → [[raci-matrix]] → [[raci-matrix-craft]] → [[raci-matrix-worked]] → skeleton `lab/skeletons/raci-matrix/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[raci-matrix]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
