# Use case skeleton

## Purpose

Copy-out starter for use case. Cite [[use-case]].

## Required canons

- [[use-case]]
- [[use-case-craft]]
- Workflow: [[write-use-case]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[use-case-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
