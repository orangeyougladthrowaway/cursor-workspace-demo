# Business case

- **Standard:** [[business-case]]
- **Owner:**
- **Decision maker:**

## Background / warrant

## Options

| Option | Description | Cost class | Benefit | Risk | Time |
| --- | --- | --- | --- | --- | --- |
| Do nothing / defer | | | | | |
| Option A | | | | | |
| Option B | | | | | |

## Costs (detail)

## Benefits (detail + measures)

## Recommendation

## Material risks to benefits

## Decision ask

| Approver | Decide by | Decision |
| --- | --- | --- |
| | | |
