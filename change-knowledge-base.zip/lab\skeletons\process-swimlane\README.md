# Process swimlane skeleton

## Purpose

Copy-out starter for process swimlane. Cite [[process-swimlane]].

## Required canons

- [[process-swimlane]]
- [[process-swimlane-craft]]
- Workflow: [[model-process-swimlane]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[process-swimlane-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
