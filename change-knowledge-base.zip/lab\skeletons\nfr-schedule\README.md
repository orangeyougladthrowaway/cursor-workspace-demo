# Nfr schedule skeleton

## Purpose

Copy-out starter for nfr schedule. Cite [[nfr-schedule]].

## Required canons

- [[nfr-schedule]]
- [[nfr-schedule-craft]]
- Workflow: [[write-nfr-schedule]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[nfr-schedule-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
