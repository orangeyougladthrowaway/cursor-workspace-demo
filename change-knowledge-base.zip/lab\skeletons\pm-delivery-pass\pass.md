# PM delivery pass

- **Workflow:** `change-knowledge-base-wf-024` ([[pm-delivery-pass]])
- **Owner:**
- **Change ref:**

| Step | Workflow | Standard | Status | Artefact ref | Escalations |
| --- | --- | --- | --- | --- | --- |
| 1 Initiate | [[initiate-project]] | `change-knowledge-base-s-008` | | | |
| 2 Plan | [[build-plan]] | `change-knowledge-base-s-009` | | | |
| 3 Risk (cadence) | [[run-risk-cadence]] | `change-knowledge-base-s-010` | | | |
| 3 Status (cadence) | [[report-status]] | `change-knowledge-base-s-011` | | | |
| 4 Change control | [[control-change]] | `change-knowledge-base-s-012` | | | |
| 5 Close | [[close-delivery]] | `change-knowledge-base-s-013` | | | |

## Pass verdict

not ready / ready — evidence:
