---
type: workflow
status: draft
id: change-knowledge-base-wf-025
concern: verification
description: Sequence to derive test conditions against change-knowledge-base-s-014 with full traceability.
derived_from:
  - "[[test-conditions]]"
  - "[[test-condition-derivation]]"
  - "[[boundary-equivalence-thinking]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Derive test conditions

Agent-operable sequence for TA01.

## Steps

1. **Retrieve** — [[test-analysis-atlas]] → [[test-conditions]] (`change-knowledge-base-s-014`) → [[test-condition-derivation]] · [[boundary-equivalence-thinking]] → skeleton `lab/skeletons/test-conditions/`.
2. **Inputs** — requirements pack + acceptance set + risks. Missing/untestable intent → escalate to BA.
3. **Derive** — conditions per source; add positive/negative/boundary variants.
4. **Trace** — every condition cites a source id.
5. **Flag gaps** — intents with no condition named.
6. **Cite** — `change-knowledge-base-s-014`. Do not write executable tests (out of change-knowledge-base scope).

## Forbidden

- Conditions with no upstream intent
- Inventing expected behaviour
- Producing automation as a substitute for analysis
