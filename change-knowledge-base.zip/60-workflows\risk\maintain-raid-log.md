---
type: workflow
status: draft
id: change-knowledge-base-wf-070
concern: risk
description: Sequence to produce raid pack artefact.
derived_from:
  - "[[raid-pack]]"
  - "[[raid-pack-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Maintain raid log

Agent-operable sequence for [[raid-pack]].

## Steps

1. **Retrieve** — theme atlas → [[raid-pack]] → [[raid-pack-craft]] → [[raid-pack-worked]] → skeleton `lab/skeletons/raid-pack/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[raid-pack]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
