---
type: example
status: draft
id: change-knowledge-base-ex-013
description: Thin exemplar — refuse a write-once risk register that never changes.
derived_from:
  - "[[risk-cadence]]"
  - "[[run-risk-cadence]]"
updated: 2026-07-16
---

# Risk cadence thin

## When

Risk register was written at kickoff and never reviewed; every risk still "open, medium."

## When not

Risks re-scored, closed, or escalated on a rhythm with owners.

## Choice

Fail [[risk-managed-continuously]]. Re-run the cadence; flag staleness. Do not present a frozen list as risk management.
