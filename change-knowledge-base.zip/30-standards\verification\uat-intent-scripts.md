---
type: standard
status: draft
id: change-knowledge-base-s-033
concern: verification
description: Uat intent scripts — usable bar for TA09.
derived_from:
  - "[[intent-must-be-testable]]"
  - "[[condition-derives-from-intent]]"
  - "[[artefact-has-owner]]"
updated: 2026-07-18
---

# Uat intent scripts

## Normally require

**UAT intent scripts** (analysis grain) include:

| Field | Test |
| --- | --- |
| Intent link | Req/AC/condition id |
| Business steps | What the UAT user does |
| Observe | What pass looks like |
| Data / role | Preconditions (facts from user/SoR) |
| Not automation | Not pytest/CI scripts |

## Refuse / escalate

- Scripts without intent trace
- Invented business data rules
- Engineering test code as substitute

## How to produce

[[uat-intent-scripts-craft]]. Worked: [[uat-intent-scripts-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
