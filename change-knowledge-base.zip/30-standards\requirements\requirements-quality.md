---
type: standard
status: draft
id: change-knowledge-base-s-002
concern: requirements
description: Requirements packs must be clear, warranted, bounded, honest — warrants come from elicitation, not invention.
derived_from:
  - "[[claim-needs-warrant]]"
  - "[[elicit-before-invent]]"
  - "[[bound-the-change]]"
  - "[[status-matches-evidence]]"
  - "[[artefact-has-owner]]"
  - "[[enough-to-decide]]"
updated: 2026-07-16
---

# Requirements quality

## Normally require

Each material requirement (or requirement group) passes:

| Test | Fail if |
| --- | --- |
| Clear | Ambiguous actor, action, or object — two readers disagree |
| Warranted | No elicitation/source warrant or escalate tag ([[claim-needs-warrant]], [[elicit-before-invent]]) |
| Bounded | Silent scope creep or missing out-of-scope notes ([[bound-the-change]]) |
| Honest | Marked “ready” while open conflicts or unknowns remain ([[status-matches-evidence]]) |
| Owned | No named maintainer for the pack ([[artefact-has-owner]]) |

## Pack minimum

- Link to governing [[problem-framing]] (or escalate if absent)
- List of requirements with ids or stable labels
- Warrant per material item (mode + source ref, or `unknown — escalate`) — see [[elicitation-discipline]]
- Open questions / unknowns called out
- Explicit “not requirements” / out-of-scope notes when relevant

## How to produce

[[requirements-quality-craft]]. Worked: [[requirements-quality-worked]].

## Refuse / escalate

- Inventing business rules or process steps to fill gaps → user / domain SoR
- Template or syllabus dump without field tests
- “Ready” pack with no elicitation warrants

## Not this standard

How to run elicitation ([[elicitation-discipline]]); prioritisation ([[requirements-prioritisation]]); acceptance ([[acceptance-criteria]]).
