# Test procedure / manual script

- **Standard:** [[test-procedure]] (`change-knowledge-base-s-056`)
- **Owner:**
- **Cases covered:**
- **Precision:** runnable steps with named observe points — not “click around”

## Preconditions (data / role / env)

## Steps

| # | Action | Expected (observable) | Actual / notes |
| --- | --- | --- | --- |
| 1 | | | |

## Result summary

| Case id | Pass/fail | Notes |
| --- | --- | --- |
| | | |
