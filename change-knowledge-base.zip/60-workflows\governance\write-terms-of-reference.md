---
type: workflow
status: draft
id: change-knowledge-base-wf-061
concern: governance
description: Sequence to produce terms of reference artefact.
derived_from:
  - "[[terms-of-reference]]"
  - "[[terms-of-reference-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write terms of reference

Agent-operable sequence for [[terms-of-reference]].

## Steps

1. **Retrieve** — theme atlas → [[terms-of-reference]] → [[terms-of-reference-craft]] → [[terms-of-reference-worked]] → skeleton `lab/skeletons/terms-of-reference/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[terms-of-reference]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
