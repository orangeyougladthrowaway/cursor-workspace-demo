---
type: standard
status: draft
id: change-knowledge-base-s-042
concern: governance
description: Business case — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[outcome-over-output]]"
  - "[[tradeoff-visible]]"
  - "[[enough-to-decide]]"
  - "[[claim-needs-warrant]]"
updated: 2026-07-18
---

# Business case

## Normally require

A **business case** includes:

| Field | Test |
| --- | --- |
| Background | Problem/opportunity with warrant |
| Options | ≥2 real options including do-nothing/defer |
| Costs | Tangible/intangible called out; unknowns escalated |
| Benefits | Areas of benefit; how measured |
| Recommendation | Named option + rationale |
| Risks | Material risks to benefits |
| Decision ask | Who approves by when |

## Refuse / escalate

- Single option as fait accompli
- Invented ROI numbers — escalate finance/ops

## How to produce

[[business-case-craft]]. Worked: [[business-case-worked]]. Skeleton: `lab/skeletons/business-case/`.

## Related

- [[common-case-coverage]] · workflow [[write-business-case]]
