---
type: standard
status: draft
id: change-knowledge-base-s-044
concern: requirements
description: Requirements catalogue — project artefact field tests (BCS-aligned house pack) with actionable grain.
derived_from:
  - "[[claim-needs-warrant]]"
  - "[[bound-the-change]]"
  - "[[intent-must-be-testable]]"
  - "[[artefact-has-owner]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Requirements catalogue

## Normally require

A **requirements catalogue** (BCS-style) holds each material requirement with:

| Field | Test |
| --- | --- |
| Id / name / description | Clear actor–action–object |
| Type | Business / functional / non-functional / constraint… |
| Source / owner | Warranted |
| Priority | Band or rank |
| Rationale | Why needed |
| Cross-refs | Related reqs / documents |
| Acceptance criteria | Link or embedded observable |
| Status / version | Honest lifecycle |
| Precision (in-scope grain) | Description names the **actionable grain** for its type — not adjective fog ([[precision-over-vagueness]]) |

### Data / integration / store requirements (additional)

When the requirement moves, stores, or historises data (API, file, DB, queue), the description **or** a linked mapping row must name:

| Element | Test |
| --- | --- |
| Source | System / module / endpoint or file class (link vendor or systems-KB note) |
| Target | Store grain: database/schema/table (or explicit eng DDL path) |
| Business key | Stable identifier(s) |
| Attributes | Fields in scope — **list here or cite field-map row ids** that exist on the [[data-model]] artefact (eng DDL path alone is insufficient) |
| Transform / rule | Material mapping, hash, SCD, delete/absence rule — or link to field-map / [[business-rules-catalogue]] rows |
| Completeness | Snapshot vs delta; when absence may mean delete |

Refuse “historise customers” / “load to ODS” without those elements (or an explicit Gap blocking Ready). **Do not** mark Ready by pointing only at future eng DDL.

## Refuse / escalate

- Ready catalogue with missing warrants or adjective-only NFRs
- Invented domain rules
- Data/store Must rows without source/target/key grain (Gap or deepen)

## How to produce

[[requirements-catalogue-craft]]. Worked: [[requirements-catalogue-worked]]. Skeleton: `lab/skeletons/requirements-catalogue/`.

## Related

- [[common-case-coverage]] · workflow [[maintain-requirements-catalogue]] · [[data-model]] · [[acceptance-criteria]]
