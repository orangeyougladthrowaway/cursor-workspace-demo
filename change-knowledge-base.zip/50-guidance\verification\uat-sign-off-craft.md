---
type: guidance
status: draft
id: change-knowledge-base-g-058
concern: verification
description: How to produce uat sign off — what good looks like.
derived_from:
  - "[[uat-sign-off]]"
updated: 2026-07-18
---

# Uat sign off craft

House how-to for [[uat-sign-off]].

## House defaults

1. Sign only after [[uat-readiness]] exit met or residuals explicitly accepted.
2. Conditions of acceptance written.
3. One page; link evidence.

## What good looks like

Clear accountability for go-live from business owner.

## Done test

Scope · evidence · residuals · signatures · decision.

## Related

- [[uat-sign-off]] · [[uat-sign-off-worked]] · [[record-uat-sign-off]] · skeleton `uat-sign-off/`
