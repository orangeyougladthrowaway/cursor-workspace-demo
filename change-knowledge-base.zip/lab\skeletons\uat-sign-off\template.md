# UAT sign-off

- **Standard:** [[uat-sign-off]]
- **Build / env:**

## Scope accepted

|

## Evidence references

|

## Residuals / conditions

| Item | Sev | Condition / owner |
| --- | --- | --- |
| | | |

## Decision

- [ ] Accept
- [ ] Accept with conditions
- [ ] Reject

| Role | Name | Date | Signature / ack |
| --- | --- | --- | --- |
| | | | |
