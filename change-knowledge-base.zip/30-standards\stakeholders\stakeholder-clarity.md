---
type: standard
status: draft
id: change-knowledge-base-s-004
concern: stakeholders
description: Stakeholder maps use interest, impact, influence, and engagement strategy — frameworks OK; org lore not.
derived_from:
  - "[[name-who-matters]]"
  - "[[influence-shapes-engagement]]"
  - "[[claim-needs-warrant]]"
  - "[[enough-to-decide]]"
  - "[[artefact-has-owner]]"
updated: 2026-07-16
---

# Stakeholder clarity

## Normally require

A **stakeholder map** for the change includes:

| Field | Test |
| --- | --- |
| Party | Named person, role, or group that matters ([[name-who-matters]]) |
| Interest | What they care about for *this* change — or `unknown — escalate` |
| Impact | How the change affects them (or they affect it) |
| Influence | Relative ability to enable or block — high/med/low or equivalent |
| Engagement | Strategy matched to influence × interest ([[influence-shapes-engagement]]; see [[influence-interest-grid]]) |
| Warrant | Why they are on the list ([[claim-needs-warrant]]) |
| Owner | Who maintains the map ([[artefact-has-owner]]) |

Decision rights (RACI or equivalent) may appear as **clarity of who decides**, not HR structure.

## Framework posture

Portable grids (influence/interest, power/interest) are **allowed shapes**. Filling cells with invented org politics or system ownership is **forbidden** — escalate.

## How to produce

[[stakeholder-clarity-craft]]. Worked: [[stakeholder-clarity-worked]].

## Refuse / escalate

- Inventing who owns a process or system → user / domain SoR (not change-knowledge-base’s job)
- Directory or org-chart dump with no interest/influence/engagement
- Same engagement plan for every party when influence clearly differs

## Not this standard

Problem framing ([[problem-framing]]); elicitation modes ([[elicitation-discipline]]); prioritisation ([[requirements-prioritisation]]).
