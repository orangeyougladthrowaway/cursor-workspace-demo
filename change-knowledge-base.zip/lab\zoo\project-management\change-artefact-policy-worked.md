---
type: example
status: draft
id: change-knowledge-base-ex-080
concern: project-management
description: Worked — applying change-artefact-policy (micro-fix, enhancement, project).
derived_from:
  - "[[change-artefact-policy]]"
  - "[[change-artefact-policy-craft]]"
  - "[[small-change-control]]"
updated: 2026-07-20
---

# Change artefact policy worked

## Bad

“Full BCS pack for a one-line label fix.” No class. Twenty blank skeletons. Or: “agile — no docs” / “BAU — skip AC” with no class, M-account, or exemption. Or: auto-running [[ba-change-pass]] for a micro-fix.

## Good (micro-fix excerpt)

**Class:** micro-fix. **Mandate:** living product charter P-12 (no new ToR).  
**Process path:** named cells — [[write-acceptance-criteria]] + [[report-defect]]; not a full BA/PM/TA journey.  
**M produce:** AC (observable pass/fail for the tweak); defect clarity (repro / expected / actual).  
**R include:** one RTM/quality lite note linking AC→change-task; assumption “copy already in UAT” owned on RAID A.  
**R skip:** separate status cadence — “hours-scale; residual: sponsor not watching RAG” (stated on plan).  
**Substitute:** —  
**Cite:** `change-knowledge-base-s-060` · `change-knowledge-base-g-062`.

## Good (enhancement excerpt)

**Class:** enhancement. **Mandate:** existing product charter P-12.  
**Process path:** thinned [[ba-change-pass]] (frame delta → AC → trace) + PM plan slice; skip full kickoff/ToR.  
**M produce:** problem frame (delta), stakeholders, catalogue delta, AC, RTM row, assumption/RAID, plan slice, change control if baseline moves, conditions, status.  
**Substitute:** assumption log → RAID A. ToR → not required (—).  
**R skip:** separate quality plan — “covered in team DoD; residual: process audit low” (stated on plan).  
**Cite:** `change-knowledge-base-s-060` · `change-knowledge-base-g-062`.

## Related

- [[change-artefact-policy-craft]] · [[small-change-control]] · [[plan-change-work]]
