---
type: example
status: draft
id: change-knowledge-base-ex-031
description: Worked exemplar — elicitation record with conflict vs invented answers.
derived_from:
  - "[[elicitation-discipline]]"
  - "[[elicitation-craft]]"
updated: 2026-07-18
---

# Elicitation worked

## Bad

Filled requirements without a session: "Finance wants predictive ML."

## Good

| Field | Content |
| --- | --- |
| Unknown | Age band definition for unpaid (30 days from invoice date vs due date?) |
| Mode | Interview |
| Target | Finance ops lead (H influence) |
| Prompts | When does the clock start? What breaks if wrong? |
| Warrant bound | Session may support age-rule requirement wording only |
| Result | Ops: invoice date. Finance controller: due date. **Conflict open** — owner CFO decide by 20 Jul. No invention. |
