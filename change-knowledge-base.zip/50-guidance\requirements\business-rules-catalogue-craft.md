---
type: guidance
status: draft
id: change-knowledge-base-g-049
concern: requirements
description: How to produce business rules catalogue — what good looks like.
derived_from:
  - "[[business-rules-catalogue]]"
updated: 2026-07-18
---

# Business rules catalogue craft

House how-to for [[business-rules-catalogue]].

## House defaults

1. Separate rules from UI requirements.
2. Atomic statements; one rule one id.
3. Link to swimlanes and data model.
4. Legal/regulatory constraints flagged.

## What good looks like

Change to a rule has an obvious impact map.

## Done test

Atomic · typed · sourced · linked · owned.

## Related

- [[business-rules-catalogue]] · [[business-rules-catalogue-worked]] · [[maintain-business-rules]] · skeleton `business-rules-catalogue/`
