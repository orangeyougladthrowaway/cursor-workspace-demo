---
type: example
status: draft
id: change-knowledge-base-ex-032
description: Worked exemplar — outcome-led charter vs output-only kickoff.
derived_from:
  - "[[initiation-mandate]]"
  - "[[initiation-mandate-craft]]"
updated: 2026-07-18
---

# Initiation mandate worked

## Bad

Mandate: Build invoice dashboard. Success: Dashboard live.

## Good

| Field | Content |
| --- | --- |
| Mandate | CFO authorises; budget code FIN-26 |
| Outcome | Finance ops cut month-end spreadsheet join time for aged unpaid |
| In | Aged list, filter, CSV export |
| Out | Collections workflow; ML cashflow |
| Success | Ops confirms aged unpaid actionable in one view within month-end window (observable) |
| Stakeholders | CFO, Finance ops lead, IT security |
| Warrant | Ops time-study ~4h/month joining CSVs |
| Owner | PM P. Example |
