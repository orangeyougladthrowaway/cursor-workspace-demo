---
type: workflow
status: draft
id: change-knowledge-base-wf-051
concern: verification
description: Sequence to produce coverage honesty narrative for TA07.
derived_from:
  - "[[coverage-honesty-narrative]]"
  - "[[coverage-honesty-narrative-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Narrate coverage honesty

Agent-operable sequence for TA07.

## Steps

1. **Retrieve** — theme atlas → [[coverage-honesty-narrative]] → [[coverage-honesty-narrative-craft]] → [[coverage-honesty-narrative-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[coverage-honesty-narrative]]; escalate Gaps.
5. **Cite** — `coverage-honesty-narrative` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
