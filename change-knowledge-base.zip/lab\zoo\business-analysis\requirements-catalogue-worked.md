---
type: example
status: draft
id: change-knowledge-base-ex-064
description: Worked exemplar — requirements catalogue good vs bad including data grain.
derived_from:
  - "[[requirements-catalogue]]"
  - "[[requirements-catalogue-craft]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Requirements catalogue worked

Fictional initiative grain (not domain SoR).

## Bad

| Id | Description | Why fails |
| --- | --- | --- |
| R4 | System shall historise customers in ODS | No source/target/key/attrs/delete rule; Ready theatre |

Spreadsheet of wishes, no ids, no AC, status Ready.

## Good (functional row)

R1 | Finance views unpaid ≥30d by band | Functional | Ops interview | Must | AC-R1-* | Draft pending age-rule SoR.

## Good (data / store row + map link)

| Id | Description grain | Type | Priority | AC | Status |
| --- | --- | --- | --- | --- | --- |
| R20 | Ingest CRM Contacts list into staging then SCD2 ODS; key=`contact_id`; historise email, first_name, last_name, customer_ref; absence≡delete only after complete list; field map FM-Contacts | Functional | Must | AC-R20-* | Draft until SoR fields warranted |

| Req id | Source | Target | Business key | Attributes / map | Transform / delete | Completeness |
| --- | --- | --- | --- | --- | --- | --- |
| R20 | CRM Contacts GET (vendor link on map) | `dwh.ods.contact_history` (+ staging table on map) | contact_id | FM-Contacts | Hash attrs; close+insert on change; tombstone after complete snapshot | Full list snapshot |

## Related

- [[requirements-catalogue-craft]] · [[precision-over-vagueness]] · `lab/skeletons/requirements-catalogue/`
