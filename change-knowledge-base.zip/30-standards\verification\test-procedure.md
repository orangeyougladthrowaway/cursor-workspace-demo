---
type: standard
status: draft
id: change-knowledge-base-s-056
concern: verification
description: Test procedure — runnable steps with named observe points.
derived_from:
  - "[[test-case]]"
  - "[[uat-intent-scripts]]"
  - "[[artefact-has-owner]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Test procedure

## Normally require

A **test procedure / manual script** includes:

| Field | Test |
| --- | --- |
| Ordered steps | Runnable sequence |
| Cases covered | Which test case ids |
| Data / environment | Preconditions |
| Observe / record | Named expected per step ([[precision-over-vagueness]]) |
| Not automation code | Analysis/UAT grain |

## Refuse / escalate

- "Click around" scripts
- Domain data invented
- Steps with no observable expected

## How to produce

[[test-procedure-craft]]. Worked: [[test-procedure-worked]]. Skeleton: `lab/skeletons/test-procedure/`.

## Related

- [[common-case-coverage]] · workflow [[write-test-procedure]]
