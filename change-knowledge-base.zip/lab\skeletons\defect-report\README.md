# Defect report skeleton

## Purpose

Copy-out starter for a clear defect report. Cite [[defect-clarity]] (`change-knowledge-base-s-017`).

## Required canons

- [[defect-clarity]] · [[defect-report-shape]]
- Workflow: [[report-defect]]

## Copy

1. Copy `defect.md` into the host work area.
2. Fill expected/actual, reproduction, evidence, impact, trace.
3. Cite `change-knowledge-base-s-017`.

## Honesty

Skeleton ≠ doctrine. No bare "broken"; escalate ambiguous expected behaviour.
