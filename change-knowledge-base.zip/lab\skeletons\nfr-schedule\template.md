# NFR schedule

- **Standard:** [[nfr-schedule]] (`change-knowledge-base-s-048`)
- **Owner:**
- **Precision:** measure/check required — adjective-only rows are not Ready ([[precision-over-vagueness]])

| Id | Attribute | Measure / check (observable or escalate) | Context (load/role/env) | Priority | Catalogue ref | Status |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |

## Gaps (threshold unknown)

-
