# Test procedure skeleton

## Purpose

Copy-out starter for test procedure. Cite [[test-procedure]].

## Required canons

- [[test-procedure]]
- [[test-procedure-craft]]
- Workflow: [[write-test-procedure]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[test-procedure-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
