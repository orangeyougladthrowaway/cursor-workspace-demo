# Post implementation review skeleton

## Purpose

Copy-out starter for post implementation review. Cite [[post-implementation-review]].

## Required canons

- [[post-implementation-review]]
- [[post-implementation-review-craft]]
- Workflow: [[write-post-implementation-review]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[post-implementation-review-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
