---
type: example
status: draft
id: change-knowledge-base-ex-074
description: Worked exemplar — test plan good vs bad.
derived_from:
  - "[[test-plan]]"
  - "[[test-plan-craft]]"
updated: 2026-07-18
---

# Test plan worked

## Good

Scope: Must R1/R2. Approach: risk-based; boundary+auth deep. Exit: TC Must pass; no Sev High. Out: themes.

## Related

- [[test-plan-craft]] · `lab/skeletons/test-plan/`
