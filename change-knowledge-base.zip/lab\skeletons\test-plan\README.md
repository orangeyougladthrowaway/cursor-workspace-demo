# Test plan skeleton

## Purpose

Copy-out starter for test plan. Cite [[test-plan]].

## Required canons

- [[test-plan]]
- [[test-plan-craft]]
- Workflow: [[write-test-plan]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[test-plan-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
