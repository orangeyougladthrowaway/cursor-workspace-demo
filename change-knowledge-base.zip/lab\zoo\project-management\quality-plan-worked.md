---
type: example
status: draft
id: change-knowledge-base-ex-073
description: Worked exemplar — quality plan good vs bad.
derived_from:
  - "[[quality-plan]]"
  - "[[quality-plan-craft]]"
updated: 2026-07-18
---

# Quality plan worked

## Good

Gate M2: RTM Must covered; test cases reviewed; no Sev High open.

## Related

- [[quality-plan-craft]] · `lab/skeletons/quality-plan/`
