---
type: guidance
status: draft
id: change-knowledge-base-g-041
concern: governance
description: How to produce terms of reference — what good looks like.
derived_from:
  - "[[terms-of-reference]]"
updated: 2026-07-18
---

# Terms of reference craft

House how-to for [[terms-of-reference]].

## House defaults

1. Prefer BOSCARD: Background, Objectives, Scope, Constraints, Assumptions, Reporting, Deliverables.
2. Objectives tie to benefit, not only tasks.
3. Scope bounds prevent BA/PM wander.
4. Deliverables list the artefact pack expected (catalogue, models, plan…).
5. Keep short; link [[business-case]] and [[initiation-mandate]] when they exist.

## What good looks like

Reader can start work without asking "what are we allowed to do?" Sponsor can sign without rewriting.

## Done test

BOSCARD complete · objectives decidable · deliverables named · owner.

## Related

- [[terms-of-reference]] · [[terms-of-reference-worked]] · [[write-terms-of-reference]] · skeleton `terms-of-reference/`
