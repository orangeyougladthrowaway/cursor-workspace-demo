---
type: standard
status: draft
id: change-knowledge-base-s-012
concern: governance
description: Change control records the delta, impact on scope/plan/risk, decision, and approver.
derived_from:
  - "[[control-the-delta]]"
  - "[[bound-the-change]]"
  - "[[status-matches-evidence]]"
  - "[[artefact-has-owner]]"
updated: 2026-07-16
---

# Change control

## Normally require

A **change request / control record** includes:

| Field | Test |
| --- | --- |
| Delta | What is changing vs the agreed baseline ([[control-the-delta]]) |
| Reason | Why the change is needed — warranted, not preference |
| Impact | Effect on scope, plan, cost, risk ([[bound-the-change]], [[risk-cadence]]) |
| Options | Alternatives considered, including do-nothing |
| Decision | Approve / reject / defer, with approver named ([[artefact-has-owner]]) |
| Trace | Links to affected requirements/plan items |

## Framework posture

Change-request forms and impact-assessment shapes are portable. Do not encode a specific tool's workflow states as doctrine.

## How to produce

[[change-control-craft]]. Worked: [[change-control-worked]].

## Refuse / escalate

- Silent scope absorption without a control record ([[control-the-delta]])
- Impact assessment needing domain facts that are unknown → escalate
- Approval claimed without a named approver

## Not this standard

Initiation baseline ([[initiation-mandate]]); status reporting ([[status-reporting-honesty]]); BA traceability mechanics ([[requirements-traceability]]).
