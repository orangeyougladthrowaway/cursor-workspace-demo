---
type: guidance
status: draft
id: change-knowledge-base-g-020
concern: requirements
description: How to perform assumption log — house craft for BA09.
derived_from:
  - "[[assumption-log]]"
updated: 2026-07-18
---

# Assumption log craft

House how-to for BA09. Field tests: [[assumption-log]].

## House defaults

1. Log assumptions when writing frame/reqs/plan — not after failure.
2. Impact-if-false forces seriousness.
3. Invalidated assumption → change control or replan.
4. Dependencies on other teams are first-class rows.

## Done test

Statement · impact · owner · status · links.

## Related

- [[assumption-log]] · [[assumption-log-worked]] · [[common-case-coverage]]
