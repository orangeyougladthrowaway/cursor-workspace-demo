---
type: example
status: draft
id: change-knowledge-base-ex-036
description: Worked exemplar — intent map with gaps vs test-count 100%.
derived_from:
  - "[[intent-coverage]]"
  - "[[intent-coverage-craft]]"
updated: 2026-07-18
---

# Intent coverage worked

## Bad

87 tests run = 100% coverage.

## Good

| Intent | Conditions | Status |
| --- | --- | --- |
| R1 / AC-R1-happy | TC01, TC02 | Covered |
| R2 / AC-R2-unauth | TC03 | Covered |
| R3 themes | — | Gap — accepted skip (Could) |
| R4 ML | — | Out of release |

Honesty: Must intents covered; not 100% of backlog.
