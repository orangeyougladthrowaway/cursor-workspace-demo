---
type: workflow
status: draft
id: change-knowledge-base-wf-073
concern: planning
description: Sequence to produce quality plan artefact.
derived_from:
  - "[[quality-plan]]"
  - "[[quality-plan-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write quality plan

Agent-operable sequence for [[quality-plan]].

## Steps

1. **Retrieve** — theme atlas → [[quality-plan]] → [[quality-plan-craft]] → [[quality-plan-worked]] → skeleton `lab/skeletons/quality-plan/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[quality-plan]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
