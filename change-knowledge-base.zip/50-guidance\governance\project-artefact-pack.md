---
type: guidance
status: draft
id: change-knowledge-base-g-060
concern: governance
description: House project artefact pack — when to use each Tier-1 template, craft, and workflow.
derived_from:
  - "[[common-case-coverage]]"
  - "[[staff-agent-projection]]"
  - "[[change-artefact-policy]]"
  - "[[small-change-control]]"
  - "[[produce-change-artefact]]"
  - "[[precision-over-vagueness]]"
  - "[[lab-atlas]]"
updated: 2026-07-20
---

# Project artefact pack

**Menu and quality path** for in-scope project documents: pick the named artefact → open its **standard** (field tests) → **craft** (what good looks like) → **workflow** → copy the **skeleton** into the consumer workspace. Do not invent parallel templates.

**Whether** a document is mandatory is **not** decided here — open [[change-artefact-policy]] first (class → M/R/O). Process path for micro-fix / enhancement: [[small-change-control]]. This pack supplies shapes once an item is Produce (or recommended and kept). There is **no** separate BAU template suite.

Blank skeleton ≠ done. G4 needs craft + worked exemplar ([[common-case-coverage]] Artefact track). In-scope grain must meet [[precision-over-vagueness]] — adjective-only / table-name-only Ready fails.

## How to use (lifecycle)

1. [[plan-change-work]] — classify via [[change-artefact-policy]]; name Produce / Substitute / Exempt; name process path (cells vs journey).
2. [[produce-change-artefact]] — named artefact workflow (or journey that calls them). For small change prefer **deltas** on living artefacts.
3. [[verify-change-artefact]] — standard field tests; confirm M-set still accounted.
4. [[review-change-artefact]] — honesty; no green-wash.

Journeys ([[ba-change-pass]] · [[pm-delivery-pass]] · [[ta-analysis-pass]]) sequence cells when the plan selects them; micro-fix usually skips full journeys. This pack supplies the **document shapes** those cells and gates expect when selected.

## Pack index

| Artefact | Standard | Craft | Workflow | Skeleton |
| --- | --- | --- | --- | --- |
| Terms of reference | [[terms-of-reference]] | [[terms-of-reference-craft]] | [[write-terms-of-reference]] | `terms-of-reference/` |
| Business case | [[business-case]] | [[business-case-craft]] | [[write-business-case]] | `business-case/` |
| Gap analysis | [[gap-analysis]] | [[gap-analysis-craft]] | [[write-gap-analysis]] | `gap-analysis/` |
| Requirements catalogue | [[requirements-catalogue]] | [[requirements-catalogue-craft]] | [[maintain-requirements-catalogue]] | `requirements-catalogue/` |
| Use case | [[use-case]] | [[use-case-craft]] | [[write-use-case]] | `use-case/` |
| Process swimlane | [[process-swimlane]] | [[process-swimlane-craft]] | [[model-process-swimlane]] | `process-swimlane/` |
| Data model | [[data-model]] | [[data-model-craft]] | [[model-data]] | `data-model/` |
| NFR schedule | [[nfr-schedule]] | [[nfr-schedule-craft]] | [[write-nfr-schedule]] | `nfr-schedule/` |
| Business rules catalogue | [[business-rules-catalogue]] | [[business-rules-catalogue-craft]] | [[maintain-business-rules]] | `business-rules-catalogue/` |
| RAID pack | [[raid-pack]] | [[raid-pack-craft]] | [[maintain-raid-log]] | `raid-pack/` (+ shape [[raid-log]]) |
| RACI matrix | [[raci-matrix]] | [[raci-matrix-craft]] | [[write-raci-matrix]] | `raci-matrix/` |
| Communications plan | [[communications-plan]] | [[communications-plan-craft]] | [[write-communications-plan]] | `communications-plan/` |
| Quality plan | [[quality-plan]] | [[quality-plan-craft]] | [[write-quality-plan]] | `quality-plan/` |
| Test plan | [[test-plan]] | [[test-plan-craft]] | [[write-test-plan]] | `test-plan/` |
| Test case | [[test-case]] | [[test-case-craft]] | [[write-test-case]] | `test-case/` |
| Test procedure | [[test-procedure]] | [[test-procedure-craft]] | [[write-test-procedure]] | `test-procedure/` |
| Test completion report | [[test-completion-report]] | [[test-completion-report-craft]] | [[write-test-completion-report]] | `test-completion-report/` |
| UAT sign-off | [[uat-sign-off]] | [[uat-sign-off-craft]] | [[record-uat-sign-off]] | `uat-sign-off/` |
| Post-implementation review | [[post-implementation-review]] | [[post-implementation-review-craft]] | [[write-post-implementation-review]] | `post-implementation-review/` |
| Decision log | [[decision-log]] | [[decision-log-craft]] | [[log-decision]] | `decision-log/` |
| Assumption log | [[assumption-log]] | [[assumption-log-craft]] | [[maintain-assumption-log]] | `assumption-log/` |

Cell-home artefacts (problem frame, AC, status, risk register, etc.) remain on the BA/PM/TA matrices — this pack is the **BCS-aligned document suite** layered on top.

## When in the approach (typical)

Prefer [[change-artefact-policy]] class column over this hint table. Hints only:

| Phase | Often Produce when class warrants |
| --- | --- |
| Mandate / start | ToR · business case · initiation · RACI · kickoff |
| Discover / analyse | Gap · catalogue · use case · swimlane · data model · NFR · rules · assumption log |
| Plan / govern | Delivery plan · quality plan · RAID · communications · decision log |
| Build / verify | Test plan · cases · procedures · conditions · coverage · defects |
| Accept / close | UAT sign-off · completion report · closure · PIR |

**M** skips only via logged exemption ([[change-artefact-policy]]). **R** skips need explicit “not needed because…” on the plan.

## Forbidden

- Parallel house templates outside these stems
- Treating blank skeleton as G4
- Treating this pack as the mandatory set (use [[change-artefact-policy]])
- Inventing domain facts to fill fields
- TA implementing automation as a substitute for [[test-case]] / [[test-procedure]] analysis grain

## Related

- [[change-artefact-policy]] · [[change-artefact-policy-craft]] · [[small-change-control]] · [[common-case-coverage]] · [[lab-atlas]] · [[ba-change-pass]] · [[pm-delivery-pass]] · [[ta-analysis-pass]]
