---
type: principle
status: draft
id: change-knowledge-base-p-020
category: value
description: Closing a change confirms the intended benefit and outstanding items — not just that tasks stopped.
derived_from:
  - "[[value]]"
updated: 2026-07-16
---

# Close confirms benefit

Closure checks whether the **named outcome** was achieved, records what was not, and hands off residuals. Declaring done because work stopped is not closure.
