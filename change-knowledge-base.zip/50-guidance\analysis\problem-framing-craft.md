---
type: guidance
status: draft
id: change-knowledge-base-g-004
concern: analysis
description: How to frame a problem — outcome, bounds, warrants, refuse solution-only asks.
derived_from:
  - "[[problem-framing]]"
  - "[[name-the-problem]]"
  - "[[outcome-over-output]]"
  - "[[bound-the-change]]"
updated: 2026-07-18
---

# Problem framing craft

House how-to for BA01. Field tests: [[problem-framing]].

## Applies when

A change is requested as a feature list, ticket dump, or “build X” without a shared problem statement.

## House defaults

1. **Start from pain or missing capability**, not from a preferred design. If only solutions arrive, ask “what fails today?” until two readers would name the same problem.
2. **Outcome = who is better off and how** — measurable or at least observable. Outputs (screens, APIs) are means.
3. **Draw three buckets early:** in scope / out / later. Silence is scope creep.
4. **Warrants before commitment.** Stakeholder quote, incident, metric, or `unknown — escalate`. Invented need fails.
5. **List material risks that would invalidate the outcome** (wrong user, wrong SoR, dependency). Not a full risk register — a frame-level alert list.
6. **One owner** for the living frame; freeze language when prioritisation starts unless change control says otherwise.

## Decision rules

| Situation | Do |
| --- | --- |
| Sponsor insists on a solution | Capture as *option*; still write the problem; note forced solution as constraint |
| Domain process unclear | Escalate systems-knowledge-base / user — do not invent as-is |
| Multiple problems bundled | Split frames or explicit multi-problem with separate outcomes |
| “Strategic” with no user | Push for beneficiary; else mark outcome Gap |

## Done test

| Check | Pass means |
| --- | --- |
| Named problem | Two readers agree what is wrong/missing |
| Outcome | Beneficiary + better-off-how stated |
| Bounds | In/out/later present |
| Warrants | Need sourced or explicitly unknown |
| Owner | Named maintainer |

## Related

- [[problem-framing]] · [[frame-problem]] · [[problem-frame-worked]] · [[requirements-quality]]
