"""Tests that note folders appear in navigation enum."""

from __future__ import annotations

from tests.vault import ROOT, navigation_responsibility_folders, rel_posix


def test_guidance_folders_in_navigation() -> None:
    nav = navigation_responsibility_folders()
    missing: list[str] = []
    base = ROOT / "50-guidance"
    if not base.is_dir():
        return
    for folder in sorted(p.name for p in base.iterdir() if p.is_dir()):
        if folder not in nav:
            missing.append(folder)
    assert not missing, f"Guidance folders not in navigation: {missing}"


def test_standards_folders_in_navigation() -> None:
    nav = navigation_responsibility_folders()
    missing: list[str] = []
    base = ROOT / "30-standards"
    for folder in sorted(p.name for p in base.iterdir() if p.is_dir()):
        if folder not in nav:
            missing.append(folder)
    assert not missing, f"Standards folders not in navigation: {missing}"


def test_no_empty_responsibility_folders() -> None:
    empty: list[str] = []
    for layer in ("30-standards", "40-patterns", "50-guidance", "60-workflows"):
        base = ROOT / layer
        if not base.is_dir():
            continue
        for folder in base.iterdir():
            if not folder.is_dir() or folder.name == "templates":
                continue
            md_files = [p for p in folder.glob("*.md") if not p.stem.startswith("catalog-")]
            if not md_files:
                empty.append(rel_posix(folder))
    assert not empty, f"Empty responsibility folders: {empty}"
