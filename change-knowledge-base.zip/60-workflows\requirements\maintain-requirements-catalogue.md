---
type: workflow
status: draft
id: change-knowledge-base-wf-064
concern: requirements
description: Sequence to produce requirements catalogue artefact.
derived_from:
  - "[[requirements-catalogue]]"
  - "[[requirements-catalogue-craft]]"
  - "[[precision-over-vagueness]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-20
---

# Maintain requirements catalogue

Agent-operable sequence for [[requirements-catalogue]].

## Steps

1. **Retrieve** — theme atlas → [[requirements-catalogue]] → [[requirements-catalogue-craft]] → [[precision-over-vagueness]] → [[requirements-catalogue-worked]] → skeleton `lab/skeletons/requirements-catalogue/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Precision** — for data/store rows, fill source/target/key/attributes/transform (or link field map); else Gap, not Ready.
5. **Verify** — field tests on [[requirements-catalogue]]; escalate Gaps; do not invent domain facts.
6. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Vague data intents marked Ready
- Leaving methods lane into eng automation / invented SoR
