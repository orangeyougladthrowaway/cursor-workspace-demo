---
type: guidance
status: draft
id: change-knowledge-base-g-019
concern: analysis
description: How to perform workshop facilitation — house craft for BA08.
derived_from:
  - "[[workshop-facilitation]]"
updated: 2026-07-18
---

# Workshop facilitation craft

House how-to for BA08. Field tests: [[workshop-facilitation]].

## House defaults

1. Open with the decision question and timebox.
2. Separate diverge (ideas) from converge (decide).
3. Capture conflicts; assign owners — do not average silently.
4. End with written decisions + next actions.
5. Wrong people in room → reschedule or escalate.

## Done test

Decision question · right people · outputs owned · conflicts visible.

## Related

- [[workshop-facilitation]] · [[workshop-facilitation-worked]] · [[common-case-coverage]]
