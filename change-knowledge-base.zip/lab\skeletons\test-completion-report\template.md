# Test completion report

- **Standard:** [[test-completion-report]]
- **Owner:**
- **Period / build:**

## Scope planned vs executed

## Results summary

| Priority | Pass | Fail | Blocked | Not run |
| --- | --- | --- | --- | --- |
| | | | | |

## Coverage honesty

## Residual defects

| Id | Sev | Status | Owner |
| --- | --- | --- | --- |
| | | | |

## Recommendation / ask

|
