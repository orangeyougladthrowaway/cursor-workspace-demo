---
type: workflow
status: draft
id: change-knowledge-base-wf-010
concern: analysis
description: Sequence to produce a problem frame against change-knowledge-base-s-001 without inventing domain lore.
derived_from:
  - "[[problem-framing]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Frame problem

Agent-operable sequence for BA01.

## Steps

1. **Retrieve** — [[business-analysis-atlas]] → [[problem-framing]] (`change-knowledge-base-s-001`) → optional skeleton `lab/skeletons/problem-frame/`.
2. **Inputs** — change brief; any systems-knowledge-base paths the user names. If domain facts are required and missing → **stop and escalate**.
3. **Draft frame** — fill fields required by [[problem-framing]]: problem, outcome, in/out/later, risks, warrants, owner.
4. **Verify** — run the field tests in the standard. Mark unknowns explicitly.
5. **Cite** — reference `change-knowledge-base-s-001` on the artefact.
6. **Hand off** — do not silently expand into a full requirements pack (use [[assess-requirements-quality]] next).

## Forbidden

- Inventing process/system facts
- Solution shopping list with no problem
- Treating the skeleton as law without the standard
