---
type: workflow
status: draft
id: change-knowledge-base-wf-011
concern: requirements
description: Sequence to assess or produce a requirements pack against change-knowledge-base-s-002.
derived_from:
  - "[[requirements-quality]]"
  - "[[problem-framing]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-16
---

# Assess requirements quality

Agent-operable sequence for BA02.

## Steps

1. **Retrieve** — [[business-analysis-atlas]] → [[requirements-quality]] (`change-knowledge-base-s-002`) → skeleton `lab/skeletons/requirements-quality-pack/`.
2. **Preconditions** — governing problem frame exists or is produced via [[frame-problem]]. Else escalate.
3. **Gather** — candidate requirements only with elicitation warrants or escalate ([[elicitation-discipline]]). Process/system facts missing → user / domain SoR.
4. **Apply field tests** — clear · warranted · bounded · honest · owned (see standard).
5. **Record gaps** — open questions list; do not invent answers.
6. **Cite** — `change-knowledge-base-s-002` on the pack; link frame artefact.
7. **Next** — prioritise ([[prioritise-requirements]]) and/or acceptance ([[write-acceptance-criteria]]) when ready.

## Forbidden

- Filling gaps with invented business rules
- Declaring “ready” while unknowns remain ([[status-matches-evidence]])
