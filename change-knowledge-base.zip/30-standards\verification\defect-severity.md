---
type: standard
status: draft
id: change-knowledge-base-s-032
concern: verification
description: Defect severity — usable bar for TA08.
derived_from:
  - "[[risk-shapes-attention]]"
  - "[[defect-carries-evidence]]"
  - "[[status-matches-evidence]]"
updated: 2026-07-18
---

# Defect severity

## Normally require

Severity assignment includes:

| Field | Test |
| --- | --- |
| Impact | Who/what harmed relative to outcome |
| Scale | Agreed bands (e.g. Blocker/High/Med/Low) applied consistently |
| Rationale | Why this band — not emotion |
| Separate priority | Severity != fix order (priority may differ) |

## Refuse / escalate

- Critical!!! with no impact
- Severity used to bully without evidence

## How to produce

[[defect-severity-craft]]. Worked: [[defect-severity-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
