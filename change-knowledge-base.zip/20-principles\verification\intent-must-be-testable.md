---
type: principle
status: draft
id: change-knowledge-base-p-006
category: verification
description: Acceptance language must allow a clear pass/fail against stated intent.
derived_from:
  - "[[verification]]"
updated: 2026-07-16
---

# Intent must be testable

Acceptance criteria describe observable outcomes or behaviours that can pass or fail. Vague adjectives (“user-friendly”, “fast enough”) without measures or examples are not house acceptance language.
