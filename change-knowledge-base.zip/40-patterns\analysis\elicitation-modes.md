---
type: pattern
status: draft
id: change-knowledge-base-pt-004
concern: analysis
description: Portable elicitation modes — interview, workshop, observation, document study, prototype review.
derived_from:
  - "[[elicit-before-invent]]"
  - "[[elicitation-discipline]]"
updated: 2026-07-16
---

# Elicitation modes

## Modes (choose deliberately)

| Mode | Best for | Weak when |
| --- | --- | --- |
| Interview | Deep individual knowledge, sensitive topics | Need shared agreement fast |
| Workshop | Conflict surfacing, shared prioritisation, scope bounds | Politics unready for a room |
| Observation | As-is behaviour vs stated process | Access denied / unsafe to invent “what I saw” |
| Document study | Rules already written; baselines | Docs are stale — mark warrant weak |
| Prototype / example review | Make abstract intent concrete | Treated as final design without criteria |

## When

Planning elicitation under [[elicitation-discipline]].

## When not

Defaulting to one mode for every gap; using mode names as decoration without prompts/warrants.

## Related

- [[elicit-requirements]] · [[influence-interest-grid]]
