"""Shared helpers for vault health tests."""

from __future__ import annotations

import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
SKIP_PARTS = {
    ".git",
    "temp",
    "node_modules",
    ".cursor",
    ".obsidian",
    "lab",
    ".systems-knowledge-base",
    ".change-knowledge-base",
    "__pycache__",
    ".pytest_cache",
    ".venv",
    "venv",
}


def _iter_md(root: Path, *, extra_skip: set[str] | None = None) -> list[Path]:
    """Walk markdown files without descending into skipped / junction dirs."""
    skip = SKIP_PARTS | (extra_skip or set())
    notes: list[Path] = []
    for dirpath, dirnames, filenames in os_walk_pruned(root, skip):
        for name in filenames:
            if name.endswith(".md"):
                notes.append(Path(dirpath) / name)
    return notes


def os_walk_pruned(root: Path, skip: set[str]):
    import os

    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        # Prune skipped directory names in-place
        dirnames[:] = [
            d
            for d in dirnames
            if d not in skip and not d.startswith(".")
        ]
        yield dirpath, dirnames, filenames


def iter_notes() -> list[Path]:
    return _iter_md(ROOT)


def iter_lab_notes() -> list[Path]:
    lab = ROOT / "lab"
    if not lab.is_dir():
        return []
    # Lab walk: do not apply doctrine SKIP that excludes lab itself
    skip = SKIP_PARTS - {"lab"}
    notes: list[Path] = []
    for dirpath, dirnames, filenames in os_walk_pruned(lab, skip):
        for name in filenames:
            if name.endswith(".md"):
                notes.append(Path(dirpath) / name)
    return notes


def note_stems() -> set[str]:
    return {p.stem for p in iter_notes()}


def all_linkable_stems() -> set[str]:
    return note_stems() | {p.stem for p in iter_lab_notes()}


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def parse_frontmatter(text: str) -> tuple[dict, str]:
    if not text.startswith("---"):
        return {}, text
    end = text.find("---", 3)
    if end < 0:
        return {}, text
    block = text[3:end]
    body = text[end + 3 :]
    try:
        data = yaml.safe_load(block) or {}
    except yaml.YAMLError:
        data = {}
    if not isinstance(data, dict):
        data = {}
    return data, body


def rel_posix(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def extract_wikilinks(text: str) -> list[str]:
    return [m.group(1).strip().split("|")[0].strip() for m in re.finditer(r"\[\[([^\]|#]+)", text)]


def norm_slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def responsibility_folder(path: Path) -> str | None:
    rel = rel_posix(path)
    parts = Path(rel).parts
    if len(parts) >= 3 and re.match(r"^(30|40|50|60)-", parts[0]):
        return parts[1]
    return None


def principle_concept_folder(path: Path) -> str | None:
    rel = rel_posix(path)
    parts = Path(rel).parts
    if len(parts) >= 3 and parts[0] == "20-principles" and parts[1] != "templates":
        if path.stem.startswith("catalog-"):
            return None
        return parts[1]
    return None


def map_leaf_folder(path: Path) -> str | None:
    rel = rel_posix(path)
    parts = Path(rel).parts
    if (
        len(parts) >= 4
        and parts[0] == "maps"
        and parts[1] in ("families", "themes")
        and not path.stem.startswith("catalog-")
    ):
        return parts[2]
    return None


def map_family_folder(path: Path) -> str | None:
    return map_leaf_folder(path)


def h1_title(body: str) -> str | None:
    for line in body.splitlines():
        if line.startswith("# "):
            return line[2:].strip()
    return None


def navigation_responsibility_folders() -> set[str]:
    text = read_text(ROOT / "00-foundation" / "navigation.md")
    folders: set[str] = set()
    in_table = False
    for line in text.splitlines():
        if line.startswith("| `") and "|" in line[3:]:
            m = re.match(r"\|\s*`([^`]+)`\s*\|", line)
            if m:
                folders.add(m.group(1))
        if "### Principle concepts" in line:
            in_table = True
        if in_table and line.startswith("`") and "·" in line:
            for token in re.findall(r"`([^`]+)`", line):
                folders.add(token)
    principles = ROOT / "20-principles"
    if principles.is_dir():
        for p in principles.iterdir():
            if p.is_dir() and p.name != "templates":
                folders.add(p.name)
    return folders
