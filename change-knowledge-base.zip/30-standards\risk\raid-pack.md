---
type: standard
status: draft
id: change-knowledge-base-s-050
concern: risk
description: RAID pack — owned moving rows with named impact on artefacts/AC.
derived_from:
  - "[[risk-cadence]]"
  - "[[issue-risk-split]]"
  - "[[assumption-log]]"
  - "[[delivery-dependencies]]"
  - "[[raid-log]]"
  - "[[status-matches-evidence]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Raid pack

## Normally require

A **RAID log** tracks:

| Band | Test |
| --- | --- |
| Risks | Cause→event→effect; score; response; owner; **impacts** named (req/AC/map/milestone) when material |
| Assumptions | Impact if false; validation owner |
| Issues | Happening now; date; resolution owner; **blocks** named when material |
| Dependencies | Need-by; status; impact if late on named deliverable/AC |

## Refuse / escalate

- Wallpaper lists with no owners/movement
- Misfiling issues as risks to keep Green
- “Delivery at risk” with no artefact/AC pointer when impact is claimed

## How to produce

[[raid-pack-craft]]. Worked: [[raid-pack-worked]]. Skeleton: `lab/skeletons/raid-pack/`.

## Related

- [[common-case-coverage]] · workflow [[maintain-raid-log]] · [[precision-over-vagueness]]
