# Test conditions

- **Standard:** `change-knowledge-base-s-014` ([[test-conditions]])
- **Owner:**
- **Requirements / acceptance refs:**
- **Precision:** distinct pos/neg/boundary where intent implies them — not AC paraphrase only ([[precision-over-vagueness]])

| Cond id | Condition (testable claim) | Source id | Type (pos/neg/boundary) | Priority |
| --- | --- | --- | --- | --- |
| | | | | |

## Data / historisation (when in scope)

| Cond id | Type (insert/change/noop/tombstone/refuse) | Source AC | Priority |
| --- | --- | --- | --- |
| | | | |

## Gaps (intent with no condition)

-

## Escalations (untestable intent)

-
