---
type: standard
status: draft
id: change-knowledge-base-s-048
concern: requirements
description: NFR schedule — measure/check precision for non-functional intents.
derived_from:
  - "[[intent-must-be-testable]]"
  - "[[nonfunctional-framing]]"
  - "[[enough-to-decide]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Nfr schedule

## Normally require

An **NFR schedule** lists non-functional intents with:

| Field | Test |
| --- | --- |
| Attribute | Perf, security, availability… |
| Measure / check | Observable number/check **or** Gap/escalate — never adjective alone ([[precision-over-vagueness]]) |
| Context | Load, role, environment class |
| Catalogue id | Trace |
| Priority | Band |

## Refuse / escalate

- Adjective-only rows (“secure”, “scalable”, “fast”)
- Invented thresholds without warrant — escalate sponsor/domain

## How to produce

[[nfr-schedule-craft]]. Worked: [[nfr-schedule-worked]]. Skeleton: `lab/skeletons/nfr-schedule/`.

## Related

- [[common-case-coverage]] · workflow [[write-nfr-schedule]] · [[precision-over-vagueness]]
