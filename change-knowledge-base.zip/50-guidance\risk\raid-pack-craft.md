---
type: guidance
status: draft
id: change-knowledge-base-g-050
concern: risk
description: How to produce raid pack — what good looks like.
derived_from:
  - "[[raid-pack]]"
updated: 2026-07-18
---

# Raid pack craft

House how-to for [[raid-pack]].

## House defaults

1. One RAID SoT; do not scatter four silent lists.
2. Review on status cadence.
3. Promote risk→issue when triggered.
4. Feed [[status-reporting-honesty]] asks.

## What good looks like

Steering sees real blockers and assumptions, not a risk museum.

## Done test

All four bands · owners · dates · movement · honesty.

## Related

- [[raid-pack]] · [[raid-pack-worked]] · [[maintain-raid-log]] · skeleton `raid-pack/`
