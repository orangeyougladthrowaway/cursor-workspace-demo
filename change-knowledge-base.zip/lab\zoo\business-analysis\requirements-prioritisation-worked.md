---
type: example
status: draft
id: change-knowledge-base-ex-022
description: Worked exemplar — MoSCoW with tradeoffs vs all-Must theatre.
derived_from:
  - "[[requirements-prioritisation]]"
  - "[[requirements-prioritisation-craft]]"
  - "[[moscow-bands]]"
updated: 2026-07-18
---

# Requirements prioritisation worked

Fictional grain. Quality bar for BA05 G4.

## Shared items

| Id | Intent |
| --- | --- |
| R1 | View aged unpaid invoices |
| R2 | Export filtered CSV |
| R3 | Colour themes for dashboard |
| R4 | Predictive cashflow ML |

## Bad

| Id | Band | Why it fails |
| --- | --- | --- |
| R1–R4 | Must | All Must; no tradeoff; R3/R4 not release-critical |

## Good (MoSCoW)

| Id | Band | Rationale |
| --- | --- | --- |
| R1 | Must | Outcome fails without visibility of aged unpaid |
| R2 | Must | Month-end action today depends on export (warranted) |
| R3 | Could | Cosmetic; no outcome dependency |
| R4 | Won't (this release) | Out of frame “Later”; needs separate problem frame |

**Tradeoffs named:** R3 deferred unless spare capacity; R4 rejected for this release — new frame required.

## Related

- [[moscow-bands-thin]] · [[requirements-prioritisation-craft]] · skeleton `requirements-prioritisation/`
