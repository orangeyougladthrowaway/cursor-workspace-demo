---
type: standard
status: draft
id: change-knowledge-base-s-055
concern: verification
description: Test case — observable expected results at AC grain.
derived_from:
  - "[[test-conditions]]"
  - "[[intent-must-be-testable]]"
  - "[[condition-derives-from-intent]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Test case

## Normally require

A **test case specification** includes:

| Field | Test |
| --- | --- |
| Id | Stable |
| Objective | What is verified |
| Trace | Condition / AC / req |
| Preconditions | Data/role/state (keys/hashes when historisation) |
| Inputs / steps | Enough to execute |
| Expected results | Observable at AC grain — not “works” ([[precision-over-vagueness]]) |
| Priority | Risk-informed |

When AC covers insert/change/noop/tombstone, cases should cover those types (or Gap named).

## Refuse / escalate

- Cases with no trace
- Expected results invented when AC missing — escalate BA
- Automation code as substitute for analysis cases
- Paraphrase-only expected results

## How to produce

[[test-case-craft]]. Worked: [[test-case-worked]]. Skeleton: `lab/skeletons/test-case/`.

## Related

- [[common-case-coverage]] · workflow [[write-test-case]] · [[acceptance-criteria]]
