# Stakeholder map

- **Standard:** `change-knowledge-base-s-004` ([[stakeholder-clarity]])
- **Owner:**
- **Problem frame ref:**

| Party | Interest | Impact | Influence | Engagement | Warrant |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

## Influence × interest (optional grid)

See [[influence-interest-grid]]. Note quadrant / strategy per party above.

## Decision rights (optional RACI-as-clarity)

| Decision | Responsible | Accountable | Consulted | Informed |
| --- | --- | --- | --- | --- |
| | | | | |

## Open questions

-
