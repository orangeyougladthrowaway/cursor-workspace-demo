---
type: standard
status: draft
id: change-knowledge-base-s-057
concern: verification
description: Test completion report — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[intent-coverage]]"
  - "[[status-matches-evidence]]"
  - "[[tradeoff-visible]]"
updated: 2026-07-18
---

# Test completion report

## Normally require

A **test completion / summary report** includes:

| Field | Test |
| --- | --- |
| Scope executed | What was planned vs done |
| Results | Pass/fail summary by priority |
| Coverage | Intent/risk coverage honesty |
| Residuals | Open defects + severity |
| Recommendation | Ship / hold / narrow |
| Evidence | Links to logs/cases |

## Refuse / escalate

- "100% tested" without coverage basis

## How to produce

[[test-completion-report-craft]]. Worked: [[test-completion-report-worked]]. Skeleton: `lab/skeletons/test-completion-report/`.

## Related

- [[common-case-coverage]] · workflow [[write-test-completion-report]]
