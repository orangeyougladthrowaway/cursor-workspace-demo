---
type: standard
status: draft
id: change-knowledge-base-s-052
concern: delivery
description: Communications plan — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[delivery-comms]]"
  - "[[name-who-matters]]"
  - "[[status-matches-evidence]]"
updated: 2026-07-18
---

# Communications plan

## Normally require

A **communications plan** includes:

| Field | Test |
| --- | --- |
| Audience | Who |
| Purpose / content bar | What grain |
| Channel / rhythm | How often |
| Owner | Who sends |
| Feedback path | How replies escalate |

## Refuse / escalate

- Plan that green-washes

## How to produce

[[communications-plan-craft]]. Worked: [[communications-plan-worked]]. Skeleton: `lab/skeletons/communications-plan/`.

## Related

- [[common-case-coverage]] · workflow [[write-communications-plan]]
