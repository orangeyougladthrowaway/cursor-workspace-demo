---
type: guidance
status: draft
id: change-knowledge-base-g-056
concern: verification
description: How to produce test procedure — what good looks like.
derived_from:
  - "[[test-procedure]]"
updated: 2026-07-18
---

# Test procedure craft

House how-to for [[test-procedure]].

## House defaults

1. Procedures order cases for efficient runs.
2. Language for business UAT where needed.
3. Record actual vs expected briefly.
4. Keep secrets out.

## What good looks like

UAT user completes a path without BA sitting beside them.

## Done test

Order · case refs · data · observe · owner.

## Related

- [[test-procedure]] · [[test-procedure-worked]] · [[write-test-procedure]] · skeleton `test-procedure/`
