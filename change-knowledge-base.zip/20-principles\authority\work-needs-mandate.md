---
type: principle
status: draft
id: change-knowledge-base-p-017
category: authority
description: Work needs an explicit mandate — who authorised it, toward what outcome, within what bounds.
derived_from:
  - "[[authority]]"
updated: 2026-07-16
---

# Work needs mandate

Before mobilising a change, name the **mandate**: who authorises it, the outcome it serves, and the bounds it accepts. Activity without a traceable mandate is motion, not delivery.
