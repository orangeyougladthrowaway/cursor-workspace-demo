---
type: standard
status: draft
id: change-knowledge-base-s-043
concern: analysis
description: Gap analysis — project artefact field tests (BCS-aligned house pack).
derived_from:
  - "[[bound-the-change]]"
  - "[[enough-to-decide]]"
  - "[[claim-needs-warrant]]"
updated: 2026-07-18
---

# Gap analysis

## Normally require

A **gap analysis** includes:

| Field | Test |
| --- | --- |
| As-is | Current situation summarised with warrant |
| To-be | Desired situation tied to outcome |
| Gaps | Explicit differences |
| Actions / options | Change actions mapped to gaps |
| Owner | Who maintains |

## Refuse / escalate

- To-be invented without stakeholder warrant
- Gaps that are solution lists only

## How to produce

[[gap-analysis-craft]]. Worked: [[gap-analysis-worked]]. Skeleton: `lab/skeletons/gap-analysis/`.

## Related

- [[common-case-coverage]] · workflow [[write-gap-analysis]]
