---
type: workflow
status: draft
id: change-knowledge-base-wf-065
concern: requirements
description: Sequence to produce use case artefact.
derived_from:
  - "[[use-case]]"
  - "[[use-case-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write use case

Agent-operable sequence for [[use-case]].

## Steps

1. **Retrieve** — theme atlas → [[use-case]] → [[use-case-craft]] → [[use-case-worked]] → skeleton `lab/skeletons/use-case/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[use-case]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
