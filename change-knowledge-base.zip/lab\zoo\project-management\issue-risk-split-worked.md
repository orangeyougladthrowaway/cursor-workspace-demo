---
type: example
status: draft
id: change-knowledge-base-ex-045
description: Worked exemplar — issue risk split good vs bad.
derived_from:
  - "[[issue-risk-split]]"
  - "[[issue-risk-split-craft]]"
updated: 2026-07-18
---

# Issue risk split worked

## Bad

Vendor down 10 days still listed as "risk — monitor."

## Good

ISS-02: Vendor API down since 2 Jul — owner PM; escalate CSM daily. RISK-04 closed/superseded by issue.

## Related

- [[issue-risk-split-craft]] · skeleton if present under lab/skeletons/
