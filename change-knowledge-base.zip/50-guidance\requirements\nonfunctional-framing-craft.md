---
type: guidance
status: draft
id: change-knowledge-base-g-022
concern: requirements
description: How to perform nonfunctional framing — house craft for BA11.
derived_from:
  - "[[nonfunctional-framing]]"
updated: 2026-07-18
---

# Nonfunctional framing craft

House how-to for BA11. Field tests: [[nonfunctional-framing]].

## House defaults

1. Convert adjectives to measures or explicit open questions.
2. Security NFRs need control intent, not "be secure."
3. Perf needs workload context.
4. Untestable NFR blocks Ready — escalate.

## Done test

Attribute · measure/check or Gap · context · owner.

## Related

- [[nonfunctional-framing]] · [[nonfunctional-framing-worked]] · [[common-case-coverage]]
