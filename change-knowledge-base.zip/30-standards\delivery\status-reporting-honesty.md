---
type: standard
status: draft
id: change-knowledge-base-s-011
concern: delivery
description: Status reports state RAG with evidence, progress vs plan, risks, and asks — no green-washing.
derived_from:
  - "[[status-matches-evidence]]"
  - "[[tradeoff-visible]]"
  - "[[claim-needs-warrant]]"
  - "[[artefact-has-owner]]"
updated: 2026-07-16
---

# Status reporting honesty

## Normally require

A **status report** for a change includes:

| Field | Test |
| --- | --- |
| Overall state | RAG (or equivalent) backed by evidence, not mood ([[status-rag-honesty]]) |
| Progress vs plan | Against milestones/baseline ([[plan-honesty]]) |
| Risks / issues | Material items and movement since last report ([[risk-cadence]]) |
| Tradeoffs | Slips, descopes, or overspend named ([[tradeoff-visible]]) |
| Asks / decisions | What the reader must decide or unblock |
| Owner / date | Who reported and when |

## Framework posture

RAG status, RAID summaries, and highlight-report shapes are portable. The bar is evidence, not format.

**How to produce:** [[status-reporting-craft]]. Worked: [[status-reporting-worked]].

## Refuse / escalate

- Green status while material risks or slips are open ([[status-matches-evidence]])
- Progress claimed without evidence ([[claim-needs-warrant]])
- Reporting domain outcomes not yet confirmed → escalate

## Not this standard

Plan itself ([[plan-honesty]]); closure ([[closure-confirmation]]); BA status of requirements packs ([[requirements-quality]]).
