---
type: workflow
status: draft
id: change-knowledge-base-wf-069
concern: requirements
description: Sequence to produce business rules catalogue artefact.
derived_from:
  - "[[business-rules-catalogue]]"
  - "[[business-rules-catalogue-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Maintain business rules

Agent-operable sequence for [[business-rules-catalogue]].

## Steps

1. **Retrieve** — theme atlas → [[business-rules-catalogue]] → [[business-rules-catalogue-craft]] → [[business-rules-catalogue-worked]] → skeleton `lab/skeletons/business-rules-catalogue/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[business-rules-catalogue]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
