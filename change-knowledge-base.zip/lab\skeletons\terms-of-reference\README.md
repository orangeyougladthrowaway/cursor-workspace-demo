# Terms of reference skeleton

## Purpose

Copy-out starter for terms of reference. Cite [[terms-of-reference]].

## Required canons

- [[terms-of-reference]]
- [[terms-of-reference-craft]]
- Workflow: [[write-terms-of-reference]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[terms-of-reference-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
