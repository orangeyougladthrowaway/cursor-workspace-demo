# Communications plan

- **Standard:** [[communications-plan]]
- **Owner:**

| Audience | Purpose | Channel | Rhythm | Content bar | Sender |
| --- | --- | --- | --- | --- | --- |
| | | | | | |
