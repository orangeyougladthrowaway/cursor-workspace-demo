# RAID pack (log)

- **Standard:** [[raid-pack]] (`change-knowledge-base-s-050`)
- **Pattern shape:** [[raid-log]]
- **Owner:**
- **Last review:**
- **Precision:** owned, moving rows; name artefact/AC/map impact when risk hits delivery ([[precision-over-vagueness]])

## Risks

| Id | Cause → event → effect | P | I | Response | Owner | Status | Impacts (req/AC/map/milestone ids) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | |

## Assumptions

| Id | Statement | If false (impact on grain/AC) | Owner | Status | Validation by |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

## Issues

| Id | Description | Opened | Owner | Next action | Status | Blocks (artefact / AC) |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |

## Dependencies

| Id | Dependency | Need-by | Counterparty | Impact if late (named deliverable/AC) | Status |
| --- | --- | --- | --- | --- | --- |
| | | | | | |
