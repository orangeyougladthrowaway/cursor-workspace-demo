---
type: guidance
status: draft
id: change-knowledge-base-g-013
concern: governance
description: How to initiate — mandate, outcome, bounds, success measure before mobilising.
derived_from:
  - "[[initiation-mandate]]"
  - "[[work-needs-mandate]]"
  - "[[outcome-over-output]]"
updated: 2026-07-18
---

# Initiation mandate craft

House how-to for PM01. Field tests: [[initiation-mandate]].

## House defaults

1. Name the authoriser (mandate) before building a team plan.
2. Outcome before output — benefit in the world, not deliver-system-X alone.
3. Bounds: in / out / assumptions / constraints on day one.
4. Success measure observable or measurable.
5. Key stakeholders = deciders + materially affected (link BA map when exists).
6. Warrant why now — or escalate; do not invent business case.

## Done test

Mandate · outcome · bounds · success measure · stakeholders · warrant · owner.

## Related

- [[initiation-mandate]] · [[initiate-project]] · [[problem-framing-craft]] · [[initiation-mandate-worked]]
