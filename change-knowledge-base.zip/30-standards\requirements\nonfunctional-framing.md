---
type: standard
status: draft
id: change-knowledge-base-s-023
concern: requirements
description: Nonfunctional framing — usable bar for BA11.
derived_from:
  - "[[intent-must-be-testable]]"
  - "[[enough-to-decide]]"
  - "[[claim-needs-warrant]]"
updated: 2026-07-18
---

# Nonfunctional framing

## Normally require

**Non-functional intents** (perf, security, usability, reliability) include:

| Field | Test |
| --- | --- |
| Quality attribute | Named (perf, security, …) |
| Measure or check | Observable threshold or testable rule — or escalate |
| Context | Load/role/environment class |
| Owner | Who sets the bar |

## Refuse / escalate

- Adjective-only NFRs ("fast", "secure") without measure
- Invented thresholds — escalate sponsor/ops

## How to produce

[[nonfunctional-framing-craft]]. Worked: [[nonfunctional-framing-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
