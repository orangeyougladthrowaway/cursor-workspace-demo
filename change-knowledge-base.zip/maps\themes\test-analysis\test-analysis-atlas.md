---
type: map
status: draft
id: change-knowledge-base-map-ta
concern: test-analysis
description: Theme atlas — test analysis methods body (intent/coverage grain; not code-level test craft).
updated: 2026-07-18
---

# Test analysis atlas

Index of TA methods knowledge at **analysis** grain (conditions, intent coverage, UAT readiness). Code-level test craft is out of change-knowledge-base scope. **Not** a task playbook.

## Living law

| Concern | Notes |
| --- | --- |
| conditions | [[test-conditions]] · [[derive-test-conditions]] · patterns [[test-condition-derivation]], [[boundary-equivalence-thinking]] |
| focus | [[risk-based-test-focus]] · [[focus-by-risk]] |
| coverage | [[intent-coverage]] · [[assess-intent-coverage]] · pattern [[coverage-dimensions]] |
| defects | [[defect-clarity]] · [[report-defect]] · pattern [[defect-report-shape]] |
| readiness | [[uat-readiness]] · [[assess-uat-readiness]] · [[uat-sign-off]] |
| testware | [[test-plan]] · [[test-case]] · [[test-procedure]] · [[test-completion-report]] (manual/analysis grain) |
| journey | end-to-end [[ta-analysis-pass]] |
| handoff | BA [[acceptance-criteria]] (shared surface) |
| artefacts | [[change-artefact-policy]] · [[small-change-control]] · [[project-artefact-pack]] |

## Praxis (after canon)

| Cell | Skeleton | Zoo |
| --- | --- | --- |
| TA01 | `test-conditions/` | [[test-conditions-thin]] |
| TA02 | `risk-focus/` | [[risk-focus-thin]] |
| TA03 | `intent-coverage/` | [[intent-coverage-thin]] |
| TA04 | `defect-report/` | [[defect-clarity-thin]] |
| TA05 | `uat-readiness/` | [[uat-readiness-thin]] |
| Journey | `ta-analysis-pass/` | [[ta-boundary-thin]] |
| Pack | `test-plan/` · `test-case/` · `test-procedure/` · `test-completion-report/` · `uat-sign-off/` | AR14–AR18 on [[common-case-coverage]] |

Index: [[lab-atlas]]

## Untapped (honest)

- Dry-runs (Axis U4) before `canonical` promotion — see [[roadmap]]
- Deep primary-source harvest — deferred ([[ingest-coverage]])
- Tool/system/environment specialisations — out of scope while abstract

## Related

- [[catalog-maps]] · [[common-case-coverage]] · [[staff-agent-projection]] · [[scope]] · [[project-artefact-pack]]
