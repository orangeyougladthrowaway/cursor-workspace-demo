---
type: catalog
status: draft
id: change-knowledge-base-cat-lab
description: Lab inventory -- zoo and skeletons.
updated: 2026-07-18
---

# Catalog -- Lab

## Skeletons

- acceptance-criteria
- assumption-log
- ba-change-pass
- business-case
- business-rules-catalogue
- change-request
- closure-report
- communications-plan
- data-model
- decision-log
- defect-report
- delivery-plan
- elicitation-record
- gap-analysis
- intent-coverage
- nfr-schedule
- pm-delivery-pass
- post-implementation-review
- problem-frame
- process-swimlane
- project-initiation
- quality-plan
- raci-matrix
- raid-pack
- requirements-catalogue
- requirements-prioritisation
- requirements-quality-pack
- requirements-traceability
- risk-focus
- risk-register
- stakeholder-map
- status-report
- ta-analysis-pass
- terms-of-reference
- test-case
- test-completion-report
- test-conditions
- test-plan
- test-procedure
- uat-readiness
- uat-sign-off
- use-case

## Zoo

### business-analysis

- [[acceptance-criteria-thin]]
- [[acceptance-criteria-worked]]
- [[assumption-log-worked]]
- [[ba-change-pass-thin]]
- [[business-rules-catalogue-worked]]
- [[data-model-worked]]
- [[elicitation-record-thin]]
- [[elicitation-worked]]
- [[gap-analysis-worked]]
- [[influence-interest-thin]]
- [[moscow-bands-thin]]
- [[nfr-schedule-worked]]
- [[nonfunctional-framing-worked]]
- [[options-communication-worked]]
- [[problem-frame-thin]]
- [[problem-frame-worked]]
- [[process-swimlane-worked]]
- [[requirements-catalogue-worked]]
- [[requirements-conflict-worked]]
- [[requirements-prioritisation-thin]]
- [[requirements-prioritisation-worked]]
- [[requirements-quality-thin]]
- [[requirements-quality-worked]]
- [[requirements-traceability-thin]]
- [[requirements-traceability-worked]]
- [[stakeholder-clarity-worked]]
- [[stakeholder-map-thin]]
- [[use-case-worked]]
- [[workshop-facilitation-worked]]

### project-management

- [[business-case-worked]]
- [[change-artefact-policy-worked]]
- [[change-control-thin]]
- [[change-control-worked]]
- [[closure-confirmation-thin]]
- [[closure-confirmation-worked]]
- [[communications-plan-worked]]
- [[decision-log-worked]]
- [[delivery-comms-worked]]
- [[delivery-dependencies-worked]]
- [[estimate-range-thin]]
- [[initiation-mandate-thin]]
- [[initiation-mandate-worked]]
- [[issue-risk-split-worked]]
- [[kickoff-honesty-worked]]
- [[plan-honesty-worked]]
- [[post-implementation-review-worked]]
- [[quality-plan-worked]]
- [[raci-matrix-worked]]
- [[raid-pack-worked]]
- [[risk-cadence-thin]]
- [[risk-cadence-worked]]
- [[status-rag-thin]]
- [[status-reporting-worked]]
- [[terms-of-reference-worked]]

### test-analysis

- [[boundary-applied-worked]]
- [[coverage-honesty-narrative-worked]]
- [[defect-clarity-thin]]
- [[defect-clarity-worked]]
- [[defect-severity-worked]]
- [[intent-coverage-thin]]
- [[intent-coverage-worked]]
- [[risk-based-test-focus-worked]]
- [[risk-focus-thin]]
- [[ta-boundary-thin]]
- [[test-case-worked]]
- [[test-completion-report-worked]]
- [[test-conditions-thin]]
- [[test-conditions-worked]]
- [[test-plan-worked]]
- [[test-procedure-worked]]
- [[uat-intent-scripts-worked]]
- [[uat-readiness-thin]]
- [[uat-readiness-worked]]
- [[uat-sign-off-worked]]

## Indexes

- [[lab-atlas]]
