---
type: example
status: draft
id: change-knowledge-base-ex-070
description: Worked exemplar — raid pack good vs bad.
derived_from:
  - "[[raid-pack]]"
  - "[[raid-pack-craft]]"
updated: 2026-07-18
---

# Raid pack worked

## Good

R: vendor API. A: IdP groups exist. I: API down since 2 Jul. D: vendor field by M2 — broken.

## Related

- [[raid-pack-craft]] · `lab/skeletons/raid-pack/`
