---
type: example
status: draft
id: change-knowledge-base-ex-037
description: Worked exemplar — ready with observable exit vs ready with open Must gaps.
derived_from:
  - "[[uat-readiness]]"
  - "[[uat-readiness-craft]]"
updated: 2026-07-18
---

# Uat readiness worked

## Bad

Ready. Exit: users happy. Open: R2 uncovered.

## Good

| Field | Content |
| --- | --- |
| Scope | R1, R2 Must intents |
| Entry | Build rc3; finance test users; seed unpaid set (ops provided) |
| Exit | Ops confirms TC01–TC03 pass on rc3; no Sev High open |
| Residuals | DEF-12 Med accepted for UAT with workaround documented |
| Roles | Testers: Finance ops; Sign-off: CFO delegate |
| Ready? | **Yes** for Must scope |
