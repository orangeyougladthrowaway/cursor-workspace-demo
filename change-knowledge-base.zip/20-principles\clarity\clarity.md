---
type: category
status: draft
id: change-knowledge-base-cat-clarity
description: Spine for clarity — name what is being decided or changed without fog.
updated: 2026-07-16
---

# Clarity

## Theme

Ambiguous problem and requirement language hides decisions. Prefer names that a stranger can act on.

## Belongs here

Principles about naming problems, stakeholders' asks, and decision questions clearly.

## Does not belong here

Whether evidence warrants a claim ([[evidence]]); invent-vs-escalate ([[restraint]]); actionable grain depth ([[precision]]).

## Leaves

- [[name-the-problem]]
- [[name-who-matters]]
- [[influence-shapes-engagement]]
