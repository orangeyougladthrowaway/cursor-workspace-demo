# Terms of reference (BOSCARD)

- **Standard:** [[terms-of-reference]]
- **Owner:**
- **Sponsor:**

## Background

## Objectives

## Scope

| In | Out |
| --- | --- |
| | |

## Constraints

## Assumptions

| Assumption | Impact if false | Owner |
| --- | --- | --- |
| | | |

## Reporting / stakeholders

| Party | Role |
| --- | --- |
| | |

## Deliverables

| Artefact | Due / gate |
| --- | --- |
| | |

## Open questions

-
