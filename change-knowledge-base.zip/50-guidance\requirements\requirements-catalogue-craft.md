---
type: guidance
status: draft
id: change-knowledge-base-g-044
concern: requirements
description: How to produce requirements catalogue — what good looks like.
derived_from:
  - "[[requirements-catalogue]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Requirements catalogue craft

House how-to for [[requirements-catalogue]].

## House defaults

1. Catalogue is the SoT list; BRD/package may wrap it with models.
2. One id forever; version the row, do not recycle ids.
3. AC linked via [[acceptance-criteria]] / RTM.
4. Types explicit; NFRs need measures ([[nfr-schedule]] may extract them).
5. Status Ready only when quality tests pass ([[requirements-quality]]) **and** [[precision-over-vagueness]].
6. Data/store rows: name source, target grain, key, attributes/transform (or link field map) — see standard.

## What good looks like

Build and TA can implement/verify without re-eliciting meaning; every Must has AC link; data intents name grain a stranger can map to DDL/API fields.

## Done test

Metadata complete · warrants · AC links · honest status · owner · precision grain (or Gap).

## Related

- [[requirements-catalogue]] · [[requirements-catalogue-worked]] · [[maintain-requirements-catalogue]] · skeleton `requirements-catalogue/`
