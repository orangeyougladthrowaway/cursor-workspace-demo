---
type: example
status: draft
id: change-knowledge-base-ex-077
description: Worked exemplar — test completion report good vs bad.
derived_from:
  - "[[test-completion-report]]"
  - "[[test-completion-report-craft]]"
updated: 2026-07-18
---

# Test completion report worked

## Good

Must cases 12/12 pass; DEF-12 Med accepted; recommend UAT sign-off for Must scope.

## Related

- [[test-completion-report-craft]] · `lab/skeletons/test-completion-report/`
