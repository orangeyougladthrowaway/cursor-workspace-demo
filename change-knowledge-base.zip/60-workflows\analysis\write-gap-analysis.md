---
type: workflow
status: draft
id: change-knowledge-base-wf-063
concern: analysis
description: Sequence to produce gap analysis artefact.
derived_from:
  - "[[gap-analysis]]"
  - "[[gap-analysis-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Write gap analysis

Agent-operable sequence for [[gap-analysis]].

## Steps

1. **Retrieve** — theme atlas → [[gap-analysis]] → [[gap-analysis-craft]] → [[gap-analysis-worked]] → skeleton `lab/skeletons/gap-analysis/`.
2. **Preconditions** — governing ToR/frame/catalogue/plan as relevant (or escalate).
3. **Copy skeleton** into consumer workspace; fill using craft "what good looks like".
4. **Verify** — field tests on [[gap-analysis]]; escalate Gaps; do not invent domain facts.
5. **Cite** — standard id; link related artefacts (RTM, RAID, test plan…).

## Forbidden

- Skipping retrieve
- Blank theatre marked Ready
- Leaving methods lane into eng automation / invented SoR
