---
type: guidance
status: draft
id: change-knowledge-base-g-051
concern: stakeholders
description: How to produce raci matrix — what good looks like.
derived_from:
  - "[[raci-matrix]]"
updated: 2026-07-18
---

# Raci matrix craft

House how-to for [[raci-matrix]].

## House defaults

1. Rows = decisions/artefacts/activities that matter now.
2. Exactly one A per row.
3. R does the work; C consulted before decision; I informed after.
4. Refresh at phase changes.
5. Align with [[stakeholder-clarity]].

## What good looks like

No "who decides?" ambiguity on Must artefacts.

## Done test

Rows · parties · single A · consistent letters · owner.

## Related

- [[raci-matrix]] · [[raci-matrix-worked]] · [[write-raci-matrix]] · skeleton `raci-matrix/`
