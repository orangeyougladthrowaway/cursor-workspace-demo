"""Praxis (lab/) contract tests — structural; not per-snippet unit tests."""

from __future__ import annotations

from pathlib import Path

from tests.vault import (
    ROOT,
    all_linkable_stems,
    extract_wikilinks,
    iter_lab_notes,
    iter_notes,
    parse_frontmatter,
    read_text,
    rel_posix,
)

FACET_ALLOWLIST = {
    "business-analysis",
    "project-management",
    "test-analysis",
}

REQUIRED_SKELETONS = {
    "problem-frame",
    "requirements-quality-pack",
    "acceptance-criteria",
    "stakeholder-map",
    "requirements-prioritisation",
    "requirements-traceability",
    "elicitation-record",
    "ba-change-pass",
    "project-initiation",
    "delivery-plan",
    "risk-register",
    "status-report",
    "change-request",
    "closure-report",
    "pm-delivery-pass",
    "test-conditions",
    "risk-focus",
    "intent-coverage",
    "defect-report",
    "uat-readiness",
    "ta-analysis-pass",
}

ZOO_MAX_BODY_LINES = 40


def _zoo_files() -> list[Path]:
    zoo = ROOT / "lab" / "zoo"
    if not zoo.is_dir():
        return []
    return sorted(p for p in zoo.rglob("*.md") if p.is_file())


def test_lab_plane_index_files_exist() -> None:
    required = [
        ROOT / "lab" / "praxis-plane.md",
        ROOT / "lab" / "catalog-lab.md",
        ROOT / "lab" / "maps" / "lab-atlas.md",
    ]
    missing = [rel_posix(p) for p in required if not p.is_file()]
    assert not missing, f"Missing lab indexes: {missing}"


def test_zoo_entries_are_examples_with_doctrine_cites() -> None:
    stems = all_linkable_stems()
    doctrine = {p.stem for p in iter_notes()}
    offenders: list[str] = []
    for path in _zoo_files():
        fm, body = parse_frontmatter(read_text(path))
        rel = rel_posix(path)
        if fm.get("type") != "example":
            offenders.append(f"{rel}: type must be example")
        facet = path.parent.name
        if path.parent.parent.name == "zoo" and facet not in FACET_ALLOWLIST:
            offenders.append(f"{rel}: facet {facet!r} not allowlisted")
        derived = fm.get("derived_from") or []
        if not isinstance(derived, list):
            derived = [derived]
        targets = []
        for item in derived:
            if isinstance(item, str):
                targets.extend(extract_wikilinks(item))
        body_links = extract_wikilinks(body)
        cites = set(targets) | set(body_links)
        doctrine_cites = cites & doctrine
        if not doctrine_cites:
            offenders.append(f"{rel}: need derived_from or Related doctrine stem")
        for t in cites:
            if t not in stems:
                offenders.append(f"{rel}: broken [[{t}]]")
    assert not offenders, "\n".join(offenders[:40])


def test_lab_index_wikilinks_resolve() -> None:
    stems = all_linkable_stems()
    broken: list[str] = []
    for path in iter_lab_notes():
        if "zoo" in path.parts:
            continue
        for target in extract_wikilinks(read_text(path)):
            if target not in stems:
                broken.append(f"{rel_posix(path)} -> missing [[{target}]]")
    assert not broken, "\n".join(broken[:40])


def test_skeleton_readme_contract() -> None:
    root = ROOT / "lab" / "skeletons"
    assert root.is_dir(), "lab/skeletons missing"
    required = ("Purpose", "Required canons", "Copy", "Honesty")
    offenders: list[str] = []
    found = {child.name for child in root.iterdir() if child.is_dir()}
    missing = sorted(REQUIRED_SKELETONS - found)
    if missing:
        offenders.append(f"missing skeletons: {missing}")
    for child in sorted(root.iterdir()):
        if not child.is_dir():
            continue
        readme = child / "README.md"
        if not readme.is_file():
            offenders.append(f"{child.name}: missing README.md")
            continue
        text = read_text(readme)
        for needle in required:
            if needle.lower() not in text.lower():
                offenders.append(f"{child.name}: README missing {needle!r}")
    assert not offenders, "\n".join(offenders)


def test_allowlisted_facets_have_at_least_one_zoo() -> None:
    zoo = ROOT / "lab" / "zoo"
    present = (
        {
            p.name
            for p in zoo.iterdir()
            if p.is_dir() and any(p.glob("*.md"))
        }
        if zoo.is_dir()
        else set()
    )
    missing = sorted(FACET_ALLOWLIST - present)
    assert not missing, f"Allowlisted facets with no zoo entries: {missing}"


def test_zoo_bodies_stay_thin() -> None:
    offenders: list[str] = []
    for path in _zoo_files():
        _, body = parse_frontmatter(read_text(path))
        lines = [ln for ln in body.splitlines() if ln.strip()]
        if len(lines) > ZOO_MAX_BODY_LINES:
            offenders.append(f"{rel_posix(path)}: {len(lines)} non-empty lines > {ZOO_MAX_BODY_LINES}")
    assert not offenders, "\n".join(offenders[:20])
