# Test completion report skeleton

## Purpose

Copy-out starter for test completion report. Cite [[test-completion-report]].

## Required canons

- [[test-completion-report]]
- [[test-completion-report-craft]]
- Workflow: [[write-test-completion-report]]

## Copy

1. Copy template file(s) into the host work area.
2. Fill using craft guidance; compare to [[test-completion-report-worked]].
3. Escalate domain Gaps; do not invent.

## Honesty

Skeleton ≠ doctrine.
