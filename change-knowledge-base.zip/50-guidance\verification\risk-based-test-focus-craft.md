---
type: guidance
status: draft
id: change-knowledge-base-g-016
concern: verification
description: How to focus test depth by risk — tradeoffs explicit, no uniform theatre.
derived_from:
  - "[[risk-based-test-focus]]"
  - "[[risk-shapes-attention]]"
  - "[[test-conditions]]"
updated: 2026-07-18
---

# Risk based test focus craft

House how-to for TA02. Field tests: [[risk-based-test-focus]].

## House defaults

1. Rate areas by likelihood x impact on outcome — escalate domain likelihoods.
2. Map depth: high to earlier/deeper conditions; low to lighter, stated.
3. Name what is lightly tested or skipped ([[tradeoff-visible]]).
4. Link to conditions and product risks — not a vibes heatmap.
5. Refuse everything-equally / fully-tested claims.

## Done test

Risk basis · depth mapping · tradeoffs · trace · honesty.

## Related

- [[risk-based-test-focus]] · [[focus-by-risk]] · [[test-conditions-craft]] · [[risk-based-test-focus-worked]]
