---
type: pattern
status: draft
id: change-knowledge-base-pt-002
concern: requirements
description: MoSCoW-style bands — Must/Should/Could/Won’t with visible Won’t/Could tradeoffs.
derived_from:
  - "[[rank-by-outcome]]"
  - "[[tradeoff-visible]]"
  - "[[requirements-prioritisation]]"
updated: 2026-07-16
---

# Moscow bands

## Shape

Assign each in-scope item to exactly one band:

| Band | Meaning |
| --- | --- |
| Must | Change fails its outcome without this |
| Should | Important; outcome weakened if deferred |
| Could | Nice; only after Must/Should capacity |
| Won’t (this time) | Explicitly out of *this* pass — not forgotten |

**Must** without any Won’t/Could candidates usually fails [[tradeoff-visible]].

## When

Need a shared band language for a release/pass ([[requirements-prioritisation]]).

## When not

As fake consensus (“everything Must”); as a substitute for outcome/risk rationale.

## Related

- [[value-risk-matrix]] · [[prioritise-requirements]]
