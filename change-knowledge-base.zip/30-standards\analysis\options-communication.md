---
type: standard
status: draft
id: change-knowledge-base-s-022
concern: analysis
description: Options communication — usable bar for BA10.
derived_from:
  - "[[enough-to-decide]]"
  - "[[tradeoff-visible]]"
  - "[[outcome-over-output]]"
updated: 2026-07-18
---

# Options communication

## Normally require

An **options brief** to sponsors includes:

| Field | Test |
| --- | --- |
| Decision needed | Explicit ask |
| Options | At least two real alternatives including do-nothing/defer |
| Tradeoffs | Outcome, cost, risk, time per option |
| Recommendation | Named with rationale — not hidden |
| Ask | Who decides by when |

## Refuse / escalate

- Single option presented as fait accompli
- Domain facts invented to favour one option

## How to produce

[[options-communication-craft]]. Worked: [[options-communication-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
