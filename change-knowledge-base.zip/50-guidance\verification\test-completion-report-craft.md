---
type: guidance
status: draft
id: change-knowledge-base-g-057
concern: verification
description: How to produce test completion report — what good looks like.
derived_from:
  - "[[test-completion-report]]"
updated: 2026-07-18
---

# Test completion report craft

House how-to for [[test-completion-report]].

## House defaults

1. Pair with [[intent-coverage]] / [[coverage-honesty-narrative]].
2. Residuals owned.
3. Recommendation is a decision ask.
4. No count theatre as proof.

## What good looks like

Sponsor can decide release risk with eyes open.

## Done test

Scope · results · coverage · residuals · recommendation.

## Related

- [[test-completion-report]] · [[test-completion-report-worked]] · [[write-test-completion-report]] · skeleton `test-completion-report/`
