---
type: standard
status: draft
id: change-knowledge-base-s-028
concern: delivery
description: Delivery comms — usable bar for PM10.
derived_from:
  - "[[status-matches-evidence]]"
  - "[[enough-to-decide]]"
  - "[[name-who-matters]]"
updated: 2026-07-18
---

# Delivery comms

## Normally require

A **comms cadence** for delivery includes:

| Field | Test |
| --- | --- |
| Audience | Who gets what grain |
| Channel / rhythm | Named (e.g. weekly status, Slack unblock) |
| Content bar | Evidence-backed; asks clear |
| Owner | Who sends |

## Refuse / escalate

- Same wall-of-text to every audience without purpose
- Green-wash in any channel

## How to produce

[[delivery-comms-craft]]. Worked: [[delivery-comms-worked]].

## Not this standard

See related cells on [[common-case-coverage]].
