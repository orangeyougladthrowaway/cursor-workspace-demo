# Agent notes — Change Knowledge Base (change-knowledge-base)

## Authority

| Source | Owns | Write? |
| --- | --- | --- |
| This repo (`change-knowledge-base`) | PM/BA/TA methods, workflows, staff-agent praxis | **Write here** |
| systems-knowledge-base (optional sibling) | Domain systems/process facts | **Read-only — never write** |
| User | Domain facts when systems-knowledge-base is silent | Ask / escalate |

change-knowledge-base is **standalone** for methods. Code-level test craft, CI, and engineering implementation are out of scope — do not retrieve an engineering bible for methods authority.

## Operating law (always)

1. **Retrieve before act** — `README` → [[navigation]] → theme atlas → canonical notes → workflow; lab only after canon.
2. Prefer `status: canonical`; treat `draft` as unfinished.
3. Cite `id`s for load-bearing method choices.
4. Books/templates are pressure via [[knowledge-ingestion]] — not curriculum mirrors.
5. Skills point at canons; never reprint standard bodies.
6. Never invent domain facts — escalate to systems-knowledge-base or the user.
7. Test analysis owns intent/coverage analysis; do not implement tests/CI as a TA substitute.
8. Full-coverage asks → [[common-case-coverage]]; no quiet shrink to seeding.
9. Hand-write doctrine; no bulk generators.
10. Follow `.cursor/rules/change-knowledge-base-authority.mdc`.

## Start here

- Navigation: `00-foundation/navigation.md`
- BA theme: `maps/themes/business-analysis/business-analysis-atlas.md`
- Staff agents: `60-workflows/knowledge/staff-agent-projection.md`
- Coverage: `60-workflows/knowledge/common-case-coverage.md`
- Artefact pack: `50-guidance/governance/project-artefact-pack.md`
- Artefact policy: `30-standards/governance/change-artefact-policy.md`
- Small change / BAU path: `50-guidance/governance/small-change-control.md`
- Ingestion: `60-workflows/knowledge/knowledge-ingestion.md`
- Praxis: `60-workflows/knowledge/praxis-ingestion.md`
- Vault health: `60-workflows/knowledge/vault-health-checks.md`
- Branching / PRs: root `CONTRIBUTING.md` (house detail: sibling `agent-harness` → `docs/source-control.md`)

## Profiles (usable G4 — dry-runs pending canonical)

**BA** BA01–BA12 · **PM** PM01–PM11 · **TA** TA01–TA09 at **G4** on [[common-case-coverage]] under the usable craft bar (guidance + worked exemplar). Notes remain `draft` until human dry-runs / canonical promotion ([[roadmap]] U4–U6). Frameworks in; tools/systems out. TA is analysis grain.


Lifecycle skills: `change-knowledge-base-plan` · `change-knowledge-base-produce` · `change-knowledge-base-verify` · `change-knowledge-base-review` → [[plan-change-work]] · [[produce-change-artefact]] · [[verify-change-artefact]] · [[review-change-artefact]].

- PM theme: `maps/themes/project-management/project-management-atlas.md`
- TA theme: `maps/themes/test-analysis/test-analysis-atlas.md`

## Quarantine

Syllabus trees · fat skills · persona-only agents · invented domain lore · code-level test craft as TA substitute · systems-knowledge-base lore copy · soft status theatre · `_index.md` / `and`-names
