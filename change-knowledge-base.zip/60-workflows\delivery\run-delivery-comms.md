---
type: workflow
status: draft
id: change-knowledge-base-wf-048
concern: delivery
description: Sequence to produce delivery comms for PM10.
derived_from:
  - "[[delivery-comms]]"
  - "[[delivery-comms-craft]]"
  - "[[staff-agent-projection]]"
updated: 2026-07-18
---

# Run delivery comms

Agent-operable sequence for PM10.

## Steps

1. **Retrieve** — theme atlas → [[delivery-comms]] → [[delivery-comms-craft]] → [[delivery-comms-worked]].
2. **Preconditions** — governing frame/pack/plan as relevant (or escalate).
3. **Draft** — follow craft defaults; use worked quality bar.
4. **Verify** — field tests on [[delivery-comms]]; escalate Gaps.
5. **Cite** — `delivery-comms` id; do not invent domain facts.

## Forbidden

- Skipping retrieve
- Silent consensus / green-wash
- Leaving the methods lane into eng/domain invention
