---
type: standard
status: draft
id: change-knowledge-base-s-003
concern: verification
description: Acceptance criteria must be testable at actionable grain; escalate missing domain facts.
derived_from:
  - "[[intent-must-be-testable]]"
  - "[[status-matches-evidence]]"
  - "[[claim-needs-warrant]]"
  - "[[enough-to-decide]]"
  - "[[precision-over-vagueness]]"
updated: 2026-07-20
---

# Acceptance criteria

## Normally require

For each in-scope requirement (or scenario group):

| Test | Fail if |
| --- | --- |
| Testable | No observable pass/fail ([[intent-must-be-testable]]) |
| Tied | No link to a requirement / intent id |
| Honest | “Done” claimed without criteria or with only vague adjectives ([[status-matches-evidence]]) |
| Domain-safe | Criteria invent process facts not supplied by systems-knowledge-base/user |
| Precise | Outcome grain matches the requirement — named keys, states, measures, or refuse paths ([[precision-over-vagueness]]) |

### Data / historisation / API scenarios (additional)

When the requirement is data movement or history, scenarios must make **observable** at least the material behaviours in scope, for example:

- Insert / change (hash or field delta) / noop on unchanged
- Delete or tombstone rule (and completeness precondition)
- Target location identifiable (table or artefact path)

Happy-path-only packs fail when change/delete/noop are in scope for the requirement.

## Preferred shape (not law by itself)

Given / When / Then or equivalent **observable** form is fine. The skeleton under `lab/skeletons/acceptance-criteria/` is copy-shape citing this standard — not a second SoT.

**How to produce:** [[acceptance-criteria-craft]]. **Worked quality bar:** [[acceptance-criteria-worked]].

## Refuse / escalate

- Missing domain rules needed to make criteria concrete → systems-knowledge-base / user
- Code-level test design (fixtures, pytest) — out of change-knowledge-base scope
- “It works” / “SCD2 works” without named observables

## Not this standard

Full TA intent-coverage method; requirements quality ([[requirements-quality]]).
