# Gap analysis

- **Standard:** [[gap-analysis]]
- **Owner:** BA
- **Updated:** 2026-07-22

| Gap | Impact | Disposition |
| --- | --- | --- |
| Public equity quote SoR absent from systems-KB | Cannot claim house feed doctrine | Eng chooses provider; document in DEC + domain-gaps |
| Zoho draft (unsent) mail API on sandbox | REQ-005 blocked until proven | Sponsor sandbox spike; DEC-004 |
| Zoho Contact vs Lead for “customer” | Field map risk | Default Contact; DEC-001 |
| Cloudflare DNS / cert details | Edge reachability | Operator runbook; eng outputs IPs |
| Trade attribution model (per customer vs house book) | Dash semantics | DEC-002 |
| Accounting / GL | Explicitly deferred | Slice H later |

## Not gaps

Gateway/bridges pattern, Spaces S3 API, managed Postgres VPC-private — covered by vault / eng patterns.
