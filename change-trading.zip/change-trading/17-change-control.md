# Change control

- **Standard:** [[change-control]]
- **Owner:** PM
- **Updated:** 2026-07-22

## Policy (demo-thin)

1. Scope changes that add symbols, real brokerage, or accounting before W4 → require sponsor A on RAID + catalogue delta.
2. Eng may refine craft (chart lib, PDF vs HTML receipt) without catalogue change if AC unchanged.
3. Secret values never committed; rotate via `.env` only.

## Log

| Date | Change | Disposition |
| --- | --- | --- |
| 2026-07-22 | Greenfield pair-trade mandate opened | Accepted |
