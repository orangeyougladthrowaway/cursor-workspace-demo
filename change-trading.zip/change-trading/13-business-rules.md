# Business rules

- **Standard:** [[business-rules-catalogue]]
- **Owner:** BA
- **Updated:** 2026-07-22

| Id | Rule | Refs |
| --- | --- | --- |
| BR-001 | Signup requires non-empty name, valid DOB (date), and amount > 0 | REQ-002 |
| BR-002 | Zoho customer upsert is idempotent on configured external key / email; no duplicate Contacts for same signup retry | REQ-003 |
| BR-003 | Exactly one receipt per successful signup; Spaces object key includes `receipt_id` | REQ-004 |
| BR-004 | Zoho mail created as **draft only**; send APIs must not be invoked on this path | REQ-005 |
| BR-005 | Each poll cycle must attempt both KO and PEP; partial success records what was obtained and marks run metadata | REQ-006 |
| BR-006 | Pair-trade signal: compare last two ticks per symbol; **KO up & PEP down** → SELL KO + BUY PEP; **KO down & PEP up** → BUY KO + SELL PEP; else no trade | REQ-007 |
| BR-007 | Demo notional: fixed quantity per leg from config (`PAIR_TRADE_QTY`) | REQ-007 |
| BR-008 | P&L uses latest quote per symbol × open position; formula documented in dash | REQ-008 |
| BR-009 | When Zoho enabled and credentials missing → fail-closed on zoho-bridge only | REQ-015 · `pat-002` |
| BR-010 | When Zoho disabled → skip-closed with structured reason; signup may still persist local customer (DEC-003) | REQ-003 |

## Out of rules

Accounting recognition, tax, real best-execution.
