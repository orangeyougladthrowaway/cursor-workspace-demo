# Delivery plan

- **Standard:** [[plan-honesty]]
- **Owner:** PM
- **Updated:** 2026-07-22

## Waves

| Wave | Content | Exit |
| --- | --- | --- |
| W0 | Pack `00`–`25` + `example.env` | This planning pass |
| W1 | Eng slices A–B (spine + DWH DDL) | pytest + compose health |
| W2 | Slices C–E (market, signup, pair-trade) | AC-003..007 evidence |
| W3 | Slice F (Caddy + dashes) | AC-001/008..011 |
| W4 | Slice G (cloud + DNS) | AC-016/017 |
| W5 | Slice H accounting | Separate go |

## Dependencies

Methods AC Ready (sponsor agree) before treating W2 Zoho paths as done. Quote provider DEC before W2 market slice closes.

## Cadence

Status in `18-status.md` after each wave.
