# UAT readiness

- **Owner:** PM/TA
- **Updated:** 2026-07-22

## Checklist (pre-UAT)

- [ ] Slices A–F complete; G optional for cloud UAT
- [ ] AC-001..011 evidence attached or demonstrated
- [ ] Zoho sandbox + Spaces + basic-auth creds in `.env`
- [ ] Cloudflare DNS pointed (cloud UAT)
- [ ] Known Gaps accepted by sponsor

## Not ready until

DEC-001/004 confirmed for CRM paths marked Must.
