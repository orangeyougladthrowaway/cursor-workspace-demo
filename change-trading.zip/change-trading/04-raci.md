# RACI

- **Standard:** [[raci-matrix]]
- **Owner:** PM
- **Updated:** 2026-07-22

| Activity | Sponsor | PM | BA | TA | Eng |
| --- | --- | --- | --- | --- | --- |
| Mandate / scope change | A | R | C | C | C |
| Requirements / AC / data model | A | C | R | C | C |
| Delivery plan / RAID / status | A | R | C | C | C |
| Test conditions / cases | A | C | C | R | C |
| Implementation slices A–G | A | C | C | C | R |
| Secrets / DNS / deploy | R/A | I | I | I | C |
| UAT sign-off | A | C | C | C | C |
| Accounting slice H | A | R | C | C | R |

R = Responsible · A = Accountable · C = Consulted · I = Informed
