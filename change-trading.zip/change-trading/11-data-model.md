# Data model

- **Standard:** [[data-model]] (`change-knowledge-base-s-047`)
- **Owner:** BA
- **Updated:** 2026-07-22

## Logical systems

| System | Role | SoR? |
| --- | --- | --- |
| Zoho CRM | Customer party | Yes (CRM) |
| DigitalOcean Spaces | Receipt objects | Yes (blob) |
| `dwh` Postgres | App warehouse (customers, quotes, trades, receipts) | Yes (analytics/app) |
| `platform` Postgres | Gateway WAL | Yes (control-plane audit) |
| Public quote feed | KO/PEP prices | External — Gap |

## Entities (app warehouse `dwh`)

| Entity | Grain | Notes |
| --- | --- | --- |
| customer | one row per signup | Links Zoho id + dash identity |
| receipt | one per signup amount | Spaces key + amount |
| quote_tick | one per symbol per poll timestamp | KO and PEP |
| trade | one per executed fake leg | side, symbol, qty, price, customer_id |
| etl_run_log | one per pipeline run | etlcontrol |

## Field maps

### Customer (`dwh.customer`) — MAP-C-*

| Id | Attribute | Type | Source | Notes |
| --- | --- | --- | --- | --- |
| MAP-C-01 | customer_id | UUID PK | generated | |
| MAP-C-02 | full_name | text | signup | |
| MAP-C-03 | date_of_birth | date | signup | |
| MAP-C-04 | signup_amount | numeric | signup | receipt amount |
| MAP-C-05 | zoho_contact_id | text | Zoho | nullable until linked |
| MAP-C-06 | created_at | timestamptz | system | |

### Receipt (`dwh.receipt`) — MAP-R-*

| Id | Attribute | Type | Source | Notes |
| --- | --- | --- | --- | --- |
| MAP-R-01 | receipt_id | UUID PK | generated | |
| MAP-R-02 | customer_id | UUID FK | customer | |
| MAP-R-03 | amount | numeric | signup | |
| MAP-R-04 | spaces_object_key | text | storage put | |
| MAP-R-05 | zoho_draft_mail_id | text | Zoho | nullable Gap |
| MAP-R-06 | created_at | timestamptz | system | |

### Quote tick (`dwh.quote_tick`) — MAP-Q-*

| Id | Attribute | Type | Source | Notes |
| --- | --- | --- | --- | --- |
| MAP-Q-01 | quote_id | UUID/bigserial | generated | |
| MAP-Q-02 | symbol | text | feed | `KO` \| `PEP` |
| MAP-Q-03 | price | numeric | feed | |
| MAP-Q-04 | as_of | timestamptz | feed/system | |
| MAP-Q-05 | source | text | eng | provider name |

### Trade (`dwh.trade`) — MAP-T-*

| Id | Attribute | Type | Source | Notes |
| --- | --- | --- | --- | --- |
| MAP-T-01 | trade_id | UUID PK | generated | |
| MAP-T-02 | customer_id | UUID FK | engine | demo may fan-out or use house book — DEC-002 |
| MAP-T-03 | symbol | text | engine | KO/PEP |
| MAP-T-04 | side | text | engine | BUY/SELL |
| MAP-T-05 | quantity | numeric | engine | demo notional rule |
| MAP-T-06 | price | numeric | quote | |
| MAP-T-07 | signal_as_of | timestamptz | engine | |
| MAP-T-08 | created_at | timestamptz | system | |

### Zoho Contact mapping — MAP-Z-*

| Id | Zoho field | ← | Local |
| --- | --- | --- | --- |
| MAP-Z-01 | Last_Name / Full name fields | ← | MAP-C-02 |
| MAP-Z-02 | Date_of_Birth (custom if needed) | ← | MAP-C-03 |
| MAP-Z-03 | Description / custom amount | ← | MAP-C-04 |
| MAP-Z-04 | id | → | MAP-C-05 |

### Platform WAL — MAP-P-*

As-built `deploy/sql/platform_schema.sql`: jobs, task_executions, execution_logs (gateway observer).

### etlcontrol — MAP-E-*

| Id | Attribute | Notes |
| --- | --- | --- |
| MAP-E-01 | run_id | |
| MAP-E-02 | pipeline_name | e.g. `market_poll`, `pair_trade` |
| MAP-E-03 | started_at / finished_at / status | |
| MAP-E-04 | metadata | jsonb |

## Relationships

```text
customer 1──* receipt
customer 1──* trade
quote_tick (* KO/PEP series)
trade *──) quote_tick (price as_of)
```

## Open model decisions

- DEC-002: trades attributed per customer vs single house book mirrored to all dashes.
- Receipt document format (PDF vs HTML) — eng craft.
