# Status

- **Standard:** [[status-reporting-honesty]]
- **Owner:** PM
- **Updated:** 2026-07-22

## Summary

**Build ready for CI image push + deploy.sh** (no live deploy run this pass). Unit tests **14** green (domain + compose isolation).

| Area | State | Evidence |
| --- | --- | --- |
| Methods pack | Produced | `docs/change-trading/` |
| Eng slices A–F | Implemented | services + SQL + Caddy + CI matrix |
| Edge firewall | Enabled via `.env` | `ENABLE_PUBLIC_EDGE=true` + `DROPLET_RESERVED_IPV6` (quarantine lifted) |
| Slice G cloud prove | Operator | fill `example.env` → `.env`; CI push; `./deploy.sh create` |
| Accounting | Deferred | REQ-019 |

## Next

1. Fill `.env` from `example.env` (incl. `CADDY_BASIC_AUTH_HASH`, Spaces, `SITE_DOMAIN`, `DROPLET_RESERVED_IPV6`; optional Zoho).
2. Merge/push `main` so CI builds DOCR images (gateway, audit-db, storage, dwh-db, zoho, market-data, trade-workflow, web).
3. Run `deploy/terraform/deploy.sh create` when ready — enter SSH key passphrase at `ssh-add` prompt only.
4. Point Cloudflare A/AAAA at droplet outputs.
