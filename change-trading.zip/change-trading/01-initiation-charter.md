# Project initiation charter

- **Standard:** `change-knowledge-base-s-008` ([[initiation-mandate]])
- **Owner:** PM · **Sponsor:** User
- **Class:** project
- **Updated:** 2026-07-22

## Outcome (benefit sought)

Deliver a **pair-trade demonstration platform** that proves controlled delivery (methods + engineering + live DigitalOcean) with a vivid product story: customers sign up, Zoho holds the CRM record, receipts land in object storage, Coke and Pepsi prices drive a transparent fake trading rule, and four Caddy-fronted surfaces show signup, customer P&L, business aggregates, and gateway traffic — with a full greenfield project pack.

## Scope

| In | Out | Assumptions | Constraints |
| --- | --- | --- | --- |
| Signup → Zoho + receipt + draft mail + Spaces | Real broker / exchange APIs | Sponsor provides Zoho sandbox + DO + Cloudflare | Write wall: this repo |
| Fake KO/PEP pair-trade + live charts | Full accounting/GL (deferred) | Public quote feed reachable | Single operator `.env` from `example.env` |
| Gateway/bridges, DWH, Caddy edge, DO deploy | DOKS / multi-region DR | Existing Spaces buckets for app + TF state | Gateway is sole call path to bridges |
| Project artefact pack `docs/change-trading/` | Programme-level BCS theatre | Dummy Zoho org available | Accounting last |

## Key stakeholders

| Party | Role |
| --- | --- |
| User / Sponsor | Mandate, secrets, DNS, UAT, deploy |
| PM / BA / TA | Pack honesty + precision |
| Eng | Implement per `25-engineering-build-plan.md` |

## Success measure

Polished pack M-set accounted; unit tests green for domain rules; local compose healthy; CI→DOCR + OpenTofu/`deploy.sh` path documented; live droplet reachable via Cloudflare with basic-auth; signup→Zoho→receipt→trades visible on dashes. Accounting not required for first UAT.

## Warrant

Sponsored capability / storytelling demo — not a production brokerage.

## Open questions

- Zoho module for customer; draft-mail API behaviour on sandbox.
- Quote provider selection (Gap).
- Basic-auth credential values (operator `.env` only).
