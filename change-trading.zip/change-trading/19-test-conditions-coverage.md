# Test conditions & coverage

- **Owner:** TA
- **Updated:** 2026-07-22

| Condition id | Intent | Covers | Priority |
| --- | --- | --- | --- |
| TC-AUTH-01 | Unauthenticated site access denied | REQ-001 | Must |
| TC-SU-01 | Valid signup accepted | REQ-002 | Must |
| TC-SU-02 | Invalid signup rejected | REQ-002 | Must |
| TC-ZO-01 | Zoho Contact linked | REQ-003 | Must |
| TC-ZO-02 | Draft mail unsent | REQ-005 | Must |
| TC-RC-01 | Receipt in DWH + Spaces | REQ-004 | Must |
| TC-MD-01 | KO+PEP quotes stored | REQ-006 | Must |
| TC-PT-01 | Opposite-move signal trades | REQ-007 | Must |
| TC-PT-02 | Same-direction → no trade | REQ-007 | Must |
| TC-UI-01 | Customer P&L visible | REQ-008 | Must |
| TC-UI-02 | Charts render | REQ-009 | Must |
| TC-UI-03 | Business aggregates | REQ-010 | Must |
| TC-UI-04 | Gateway WAL visible | REQ-011 | Must |
| TC-ARCH-01 | Gateway-only privileged I/O | REQ-012 | Must |
| TC-SEC-01 | Secret isolation | REQ-015 | Must |
| TC-DW-01 | Warehouse entities present | REQ-014 | Must |
| TC-OPS-01 | example.env contract | REQ-016 | Must |
| TC-OPS-02 | DNS/IP path | REQ-017 | Should |
| TC-UT-01 | Domain unit suite | REQ-018 | Must |
| TC-SCOPE-01 | No accounting service | REQ-019 | Must |

## Coverage notes

Pair-trade rule must have pure unit coverage independent of Zoho/feed.
