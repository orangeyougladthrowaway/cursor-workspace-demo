# Change plan — pair-trade demo (greenfield)

- **Workflow:** `change-knowledge-base-wf-031` ([[plan-change-work]])
- **Policy:** `change-knowledge-base-s-060` ([[change-artefact-policy]])
- **Precision:** `change-knowledge-base-p-014` ([[precision-over-vagueness]])
- **Eng plan:** `25-engineering-build-plan.md` (`engineering-knowledge-base-wf-009`)
- **Active Task:** `task-demo-trading-greenfield` (harness `store/` only)
- **Engagement class:** **project**
- **Data/integration override:** **Yes** — Zoho CRM, Spaces receipts, market quotes, trades, dual Postgres → [[data-model]] **M**; field maps required for Ready
- **Process path:** **full journey** (BA → PM → TA), demo-thin craft, polished content
- **Owner:** PM · **Sponsor:** User
- **Pack root:** `docs/change-trading/`
- **Updated:** 2026-07-22

## Outcome (this change-task acceptance)

1. A **greenfield** project pack under `docs/change-trading/` describes a Coke/Pepsi **pair-trade demo** end-to-end — mandate through UAT/closure — with **no migration language** and no reference to any prior product mandate.
2. Observable product intent is locked: customer signup (name, DOB, amount) → Zoho customer + receipt + **draft** Zoho mail (unsent) + receipt object in Spaces; poll public Coke/Pepsi prices; apply a transparent fake pair-trade rule; show live trades/P&L and real price charts on customer and business dashes; gateway dash over platform WAL; Caddy basic-auth edge; Cloudflare DNS → DigitalOcean droplet (+ reserved IPv6).
3. Data model + catalogue + AC + rules + NFR + TA conditions/cases meet the precision bar (named grains / MAP-* refs).
4. Engineering build plan (`25`) sequences vertical slices with verification; **accounting is last**.
5. Domain Gaps are named (not invented): equity quote source, Zoho draft-mail realisation, Cloudflare operator DNS, org Zoho DC/OAuth.

## Scope

| In | Out | Later |
| --- | --- | --- |
| Signup → Zoho Contact (or agreed module) + receipt + draft mail + Spaces put | Real broker execution / exchange connectivity | Multi-symbol universe beyond KO/PEP |
| Market poll for Coke + Pepsi; fake pair-trade; customer P&L | Real PnL accounting ledger (full GL) | **Accounting system (deferred — last)** |
| DWH for customers, quotes, trades, receipts (app DB `dwh`) | Multi-tenant BI / warehouse mesh | Historical analytics beyond demo panels |
| Gateway → bridges only; platform WAL | Peer-to-peer service calls | — |
| Caddy edge: landing/signup, customer dash, business dash, gateway dash + site basic-auth | Public unauthenticated internet surface | WAF / rate-limit hardening |
| OpenTofu Droplet + managed Postgres + DOCR + compose | DOKS / App Platform | Multi-region DR |
| Full project M-set pack (this folder) | Deep BCS programme theatre | — |

## Domain authority (honest)

| Topic | Authority |
| --- | --- |
| Zoho CRM modules / REST v7 / OAuth | systems-knowledge-base Zoho family (`g-sys-007`, `g-proc-004`); org DC + OAuth app = operator |
| DigitalOcean Spaces / managed Postgres | `g-sys-003`, `g-sys-006` |
| Equity quote SoR | **Gap** — no house SoR; eng chooses a public poll source; document as demo scaffold |
| Zoho **draft** mail (create unsent) | **Gap** — confirm API/workflow surface with sponsor sandbox; DEC if needed |
| Cloudflare DNS → droplet / reserved IPv6 | Operator DNS; eng exposes droplet IP outputs |

## M/R account (project + data override)

| Artefact | Code | Action |
| --- | --- | --- |
| Initiation / charter | M | Produce `01` |
| Problem frame / stakeholders / RACI / kickoff / elicitation | M | Produce `02`–`06` |
| Requirements catalogue + quality/RTM | M | Produce `07`–`08` |
| Acceptance criteria | M | Produce `09` |
| Gap analysis | R | Produce `10` |
| Data model (+ field maps) | **M (override)** | Produce `11` |
| NFR schedule | M | Produce `12` |
| Business rules | R→include | Produce `13` |
| Delivery plan / RAID / decisions / change control / status | M | Produce `14`–`18` |
| Test conditions / plan / cases | M / R | Produce `19`–`21` |
| UAT readiness / sign-off / closure | M | Produce `22`–`24` (skeletons Ready for sponsor) |
| Use case / swimlane / business case / ToR / comms / quality plan | R/O | **Skip with reason:** use case+swimlane substituted by catalogue+AC+process in `02`/`07`; business case/ToR warranted by sponsor demo mandate; comms/quality folded into delivery plan + status |
| Engineering build plan | — | Produce `25` (host eng lane artefact, co-located for demo) |

## Ordered produces (this pass)

1. This plan (`00`) + eng build plan (`25`)
2. Mandate frame: `01`–`06`
3. Analyse: `11` → `07` → `13` → `09` → `12` → `10` → `08`
4. Govern: `14`–`18`
5. TA: `19`–`21`; UAT/close shells `22`–`24`
6. Operator contract: repo-root `example.env` (single `.env`)

## Escalations

- Confirm Zoho module for “customer” (Contact vs Lead) and draft-mail API behaviour on dummy org.
- Confirm public quote feed choice (Gap).
- Confirm Caddy basic-auth username/password storage (env only; not vault).
- Accounting explicitly **out until last** — do not start GL work in early slices.

## Cited ids

`harness-wf-start-work`, `change-knowledge-base-wf-031`, `change-knowledge-base-wf-032`, `change-knowledge-base-s-060`, `change-knowledge-base-s-044`, `change-knowledge-base-s-047`, `change-knowledge-base-s-003`, `change-knowledge-base-p-014`, `engineering-knowledge-base-wf-009`, `engineering-knowledge-base-pat-002`, `engineering-knowledge-base-pat-006`, `systems-knowledge-base-g-sys-003`, `systems-knowledge-base-g-sys-006`, `systems-knowledge-base-g-sys-007`, `systems-knowledge-base-g-proc-004`
