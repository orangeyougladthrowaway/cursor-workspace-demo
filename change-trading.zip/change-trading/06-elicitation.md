# Elicitation record

- **Standard:** [[elicitation-discipline]]
- **Owner:** BA
- **Updated:** 2026-07-22

## Sources

| Id | Source | Type | Notes |
| --- | --- | --- | --- |
| E1 | Sponsor brief (pair-trade demo) | Interview / mandate | Primary product story |
| E2 | systems-knowledge-base Zoho / DO notes | Vault | CRM + Spaces + managed PG facts |
| E3 | House eng patterns (gateway/bridges) | Eng bible | `pat-002` credential ownership |
| E4 | Dummy Zoho org | Sandbox | Operator-configured |

## Key statements captured

1. Document as **greenfield**; do not narrate prior products in the pack.
2. Signup fields: **name, DOB, amount**.
3. Zoho: customer record + receipt + **draft mail do not send**.
4. Receipt stored in S3/Spaces.
5. Poll Coke and Pepsi; fake pair-trade when one rises and the other falls.
6. Customer dash: live trades + real stock graphs; business dash: aggregates; gateway dash: backend calls.
7. Warehouse all of: customers, prices, trades, receipts.
8. Caddy site-wide user/password; Cloudflare → DO (+ reserved IPv6).
9. Accounting last.
10. Single `.env` / complete `example.env`.

## Unresolved (escalations)

- Exact Zoho draft-mail API behaviour on sandbox (E4).
- Quote feed vendor (Gap).
