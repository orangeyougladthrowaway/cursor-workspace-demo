# Requirements catalogue

- **Standard:** [[requirements-catalogue]] (`change-knowledge-base-s-044`)
- **Owner:** BA · **Frame:** `01` · `02`
- **Precision:** `change-knowledge-base-p-014`
- **Field map:** `11-data-model.md`
- **Updated:** 2026-07-22

| Id | Name | Description (actor–action–object + grain) | Type | Source | Owner | Priority | Rationale | Cross-refs | AC refs | Status | Ver |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| REQ-001 | Site basic-auth | Caddy shall require HTTP basic-auth credentials from `example.env` for **all** site routes before any page is served | Constraint | E1 | BA | Must | Gate the demo | NFR-001 | AC-001 | Draft | 1 |
| REQ-002 | Landing signup | Unauthenticated-after-edge user shall submit **name**, **date of birth**, **amount** on the landing page and receive a customer session/id for the customer dash | Functional | E1 | BA | Must | Journey origin | BR-001 · MAP-C-* | AC-002 | Draft | 1 |
| REQ-003 | Zoho customer | On signup, system shall create/upsert one Zoho CRM **Contact** (pending DEC module) with mapped name + DOB via zoho-bridge REST v7 + OAuth | Functional | E1 · E2 | BA | Must | CRM SoR | BR-002 · MAP-Z-* · `g-sys-007` | AC-003 | Draft | 1 |
| REQ-004 | Receipt create | On signup, system shall create one receipt for the customer amounting to submitted **amount**, persist warehouse row MAP-R-*, and put a receipt object to Spaces via storage-bridge | Functional | E1 | BA | Must | Evidence artefact | BR-003 · MAP-R-* · `g-sys-003` | AC-004 | Draft | 1 |
| REQ-005 | Draft Zoho mail | On signup, system shall create a **draft** (unsent) Zoho mail to the customer referencing the receipt; must not send | Functional | E1 | BA | Must | Visible CRM theatre without spam | BR-004 · Gap draft-mail | AC-005 | Draft | 1 |
| REQ-006 | Quote poll | System shall poll public prices for symbols **KO** and **PEP** on a configured interval and append quote rows MAP-Q-* | Functional | E1 | BA | Must | Drive strategy | BR-005 · MAP-Q-* | AC-006 | Draft | 1 |
| REQ-007 | Pair-trade rule | When KO return (vs prior poll) is **up** and PEP is **down**, system shall record sell KO + buy PEP (fixed demo notional); inverse when KO down and PEP up; no trade if same direction or flat | Functional | E1 | BA | Must | Transparent fake strategy | BR-006 · MAP-T-* | AC-007 | Draft | 1 |
| REQ-008 | Customer P&L | Customer dash shall show the customer’s trades and mark-to-market P&L using latest quotes | Functional | E1 | BA | Must | Hero visual | MAP-T-* · MAP-Q-* | AC-008 | Draft | 1 |
| REQ-009 | Price charts | Customer and business dashes shall render time-series charts from stored KO/PEP quotes (real polled prices) | Functional | E1 | BA | Must | Credibility | MAP-Q-* · NFR-004 | AC-009 | Draft | 1 |
| REQ-010 | Business dash | Business dash shall show customer count, trade count, notional totals, and aggregate P&L graphs | Functional | E1 | BA | Must | Sponsor view | MAP-RV-B-* | AC-010 | Draft | 1 |
| REQ-011 | Gateway dash | Gateway dash shall list recent platform WAL call/job activity from `platform` DB | Functional | E1 | BA | Must | Show control plane | MAP-P-* | AC-011 | Draft | 1 |
| REQ-012 | Gateway-only I/O | Application code shall invoke storage, Zoho, DWH, and market_data **only** via gateway envelopes; bridges own credentials | Constraint | E3 | BA | Must | House pattern | NFR-002 · `pat-002` | AC-012 | Draft | 1 |
| REQ-013 | Dual database | Distinct `platform` (WAL) and `dwh` (app warehouse) databases/URLs | Constraint | E3 | BA | Must | Separation | NFR-003 · `g-sys-006` | AC-013 | Draft | 1 |
| REQ-014 | Warehouse coverage | `dwh` shall store customers, quotes, trades, and receipts at grains in `11` | Functional | E1 | BA | Must | Demo warehouse | MAP-* | AC-014 | Draft | 1 |
| REQ-015 | Secret isolation | `SPACES_*` only on storage-bridge; `ZOHO_*` only on zoho-bridge; DB URLs only on owning DB services; Caddy auth only on edge — sourced from single `.env` | Constraint | E3 · E1 | BA | Must | Least privilege | NFR-002 · `pat-002` | AC-015 | Draft | 1 |
| REQ-016 | Deploy path | Repo provides CI→DOCR, OpenTofu + `deploy.sh`, cloud compose, and `example.env` | Constraint | E1 | BA | Must | Operator path | AC-016 | Draft | 1 |
| REQ-017 | DNS / IP | Operator can point Cloudflare domain at droplet public IPv4 and optional reserved IPv6 from OpenTofu outputs | Constraint | E1 | BA | Must | Public edge | AC-017 | Draft | 1 |
| REQ-018 | Unit gate | Domain unit tests cover pair-trade rule and critical mappers without Docker | Constraint | quality | BA | Must | Fast proof | AC-018 | Draft | 1 |
| REQ-019 | Accounting deferred | No general-ledger / accounting service in slices A–G | Constraint | E1 | BA | Must | Focus | `00` later | AC-019 | Draft | 1 |

## Data / store / API requirements

| Req id | Source | Target | Business key | Map | Transform | Completeness |
| --- | --- | --- | --- | --- | --- | --- |
| REQ-003 | Signup form | Zoho Contact | Zoho record id | MAP-Z-* | Upsert on email/external key | One CRM party per customer |
| REQ-004 | Signup amount | Spaces object + `dwh.receipt` | `receipt_id` | MAP-R-* | Generate + put | One receipt per signup |
| REQ-006 | Quote feed | `dwh.quote_tick` | (`symbol`,`as_of`) | MAP-Q-* | Append | Both KO and PEP each interval |
| REQ-007 | Quotes | `dwh.trade` | `trade_id` | MAP-T-* | Rule engine | 0–2 legs per signal |
| REQ-011 | Gateway calls | `platform` WAL tables | job/task ids | MAP-P-* | Append | Per call |
| REQ-014 | All above | `dwh` schemas | per entity | MAP-* | As mapped | Demo-complete set |

## Notes / Gaps

- Quote provider not a house SoR — eng DEC + Gap.
- Zoho draft-mail surface — Gap until sandbox proven.
- Customer Zoho module default Contact — confirm DEC-001.
