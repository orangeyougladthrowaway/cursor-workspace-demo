# RAID

- **Standard:** [[raid-pack]]
- **Owner:** PM
- **Updated:** 2026-07-22

## Risks

| Id | Risk | Impact | Mitigation | Owner |
| --- | --- | --- | --- | --- |
| R-001 | Quote feed unstable | Empty charts/trades | Cache + visible error; DEC provider | Eng |
| R-002 | Zoho sandbox limits | Signup path fails | Draft-only; dedupe; fail-closed messaging | Eng/Sponsor |
| R-003 | Secret bleed in compose | Credential theatre | `pat-002` review; AC-015 | Eng |
| R-004 | Scope creep to accounting | Delay hero demo | REQ-019 hard gate | PM |

## Assumptions

| Id | Assumption | Status |
| --- | --- | --- |
| A-001 | Sponsor Zoho dummy org supports Contact + draft mail | Unvalidated |
| A-002 | Cloudflare DNS under sponsor control | Stated |
| A-003 | Spaces buckets exist for app + TF state | Stated |

## Issues

| Id | Issue | Status |
| --- | --- | --- |
| I-001 | Placeholder OCR warehouse DDL still in repo until slice B | Open (builder-only) |

## Dependencies

| Id | Dependency | Status |
| --- | --- | --- |
| D-001 | Quote provider choice | Open |
| D-002 | Draft-mail sandbox proof | Open |
