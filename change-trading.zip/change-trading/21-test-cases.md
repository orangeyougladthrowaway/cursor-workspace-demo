# Test cases

- **Standard:** [[test-case]]
- **Owner:** TA
- **Updated:** 2026-07-22

| Case | Condition | Steps (summary) | Expected |
| --- | --- | --- | --- |
| UT-001 | TC-PT-01 | Feed ticks KO↑ PEP↓ into rule | SELL KO + BUY PEP |
| UT-002 | TC-PT-02 | Feed ticks both ↑ | No trades |
| UT-003 | TC-SU-02 | amount=0 validator | Reject |
| E2E-001 | TC-AUTH-01 | GET / without auth | 401 |
| E2E-002 | TC-SU-01 | POST signup valid | customer_id |
| E2E-003 | TC-ZO-01 | Signup with Zoho on | Contact id stored |
| E2E-004 | TC-RC-01 | Signup | Spaces head/get OK |
| E2E-005 | TC-ZO-02 | Inspect Zoho mail | draft/unsent |
| E2E-006 | TC-MD-01 | Trigger poll | KO+PEP rows |
| E2E-007 | TC-UI-01 | Open customer dash | P&L + trades |
| E2E-008 | TC-UI-02 | Open charts | series drawn |
| E2E-009 | TC-UI-03 | Business dash | counts |
| E2E-010 | TC-UI-04 | Gateway dash | WAL rows |
| E2E-011 | TC-DW-01 | SQL count entities | ≥1 where seeded |
| RV-001 | TC-ARCH-01 | Code/compose review | no peer SDK |
| RV-003 | TC-SEC-01 | Compose env audit | isolation OK |
| RV-004 | TC-OPS-01 | Diff example.env vs docs | complete |
| RV-006 | TC-SCOPE-01 | Service list | no accounting |

Detailed procedures deferred to UAT scripts when slices land.
