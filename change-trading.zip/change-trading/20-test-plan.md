# Test plan

- **Standard:** [[test-plan]]
- **Owner:** TA
- **Updated:** 2026-07-22

## Levels

| Level | Scope | Env |
| --- | --- | --- |
| Unit | Pair-trade, mappers, validators | Local pytest |
| Contract | Bridge method envelopes | Local |
| End-to-end | Signup→Zoho→receipt→dash | Compose + sandbox |
| Review | Secret isolation, gateway-only | Static + compose inspect |
| UAT | Sponsor script | Cloud droplet |

## Entry

AC Draft reviewed; `example.env` complete; Zoho sandbox available for E2E Musts.

## Exit

Must conditions have passing cases or logged waiver; UAT sign-off for live demo.
