# Acceptance criteria

- **Standard:** [[acceptance-criteria]]
- **Owner:** BA
- **Updated:** 2026-07-22

| Req | AC | Given | When | Then |
| --- | --- | --- | --- | --- |
| REQ-001 | AC-001 | Caddy up; creds in `.env` | User hits any site route without auth | 401; with valid basic-auth → page |
| REQ-002 | AC-002 | Landing available | Submit valid name, DOB, amount | Customer id returned; redirect/open customer dash |
| REQ-002 | AC-002b | Landing available | Submit amount ≤ 0 or missing name | Validation error; no Zoho/DWH writes |
| REQ-003 | AC-003 | Zoho enabled + sandbox creds | Signup succeeds | Zoho Contact exists; `customer.zoho_contact_id` set |
| REQ-004 | AC-004 | Spaces creds present | Signup succeeds | Receipt row + Spaces object GET-able by key |
| REQ-005 | AC-005 | Zoho enabled | Signup succeeds | Draft mail exists; not sent (sandbox evidence) |
| REQ-006 | AC-006 | Feed reachable | Poll runs | New KO and PEP `quote_tick` rows with `as_of` |
| REQ-007 | AC-007 | Two ticks with KO↑ PEP↓ | Engine runs | One SELL KO + one BUY PEP trade (or documented attribution) |
| REQ-007 | AC-007b | Two ticks same direction | Engine runs | Zero trades |
| REQ-008 | AC-008 | Customer has trades + quotes | Open customer dash | Trades listed; P&L number visible |
| REQ-009 | AC-009 | ≥2 quote points | Open dash charts | KO and PEP series render |
| REQ-010 | AC-010 | ≥1 customer | Open business dash | Counts/totals non-zero where expected |
| REQ-011 | AC-011 | Traffic through gateway | Open gateway dash | Recent WAL/job rows visible |
| REQ-012 | AC-012 | Code review / architecture test | Inspect call paths | No direct SDK use outside bridges |
| REQ-013 | AC-013 | Local or cloud | Inspect env/compose | Distinct platform vs dwh URLs |
| REQ-015 | AC-015 | Compose config | Inspect service env | Spaces keys absent from non-storage; Zoho absent from non-zoho |
| REQ-016 | AC-016 | Repo | Operator follows README | `example.env` → `.env`; deploy docs accurate |
| REQ-017 | AC-017 | Droplet up | DNS configured | Domain resolves to droplet; TLS via Caddy (or documented lab mode) |
| REQ-018 | AC-018 | CI/local | `pytest` | Pair-trade + mapper tests pass |
| REQ-019 | AC-019 | Slices A–G | Inventory services | No accounting service deployed |

## Ready bar

AC Draft until sponsor agrees Zoho module + draft-mail proof path; then promote Agreed.
