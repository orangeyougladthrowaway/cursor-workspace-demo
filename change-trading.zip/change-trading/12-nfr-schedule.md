# NFR schedule

- **Standard:** [[nfr-schedule]]
- **Owner:** BA
- **Updated:** 2026-07-22

| Id | Category | Requirement | Measure | Priority |
| --- | --- | --- | --- | --- |
| NFR-001 | Security | Site-wide basic-auth at Caddy | Unauthenticated requests denied | Must |
| NFR-002 | Security | Credential-owning bridges; no secret broadcast | Compose review checklist | Must |
| NFR-003 | Architecture | Dual DB planes platform vs dwh | Deploy evidence | Must |
| NFR-004 | UX | Chart refresh ≤ configured poll interval + 5s skew | Stopwatch on dash | Should |
| NFR-005 | Reliability | Quote poll failure surfaces on dash (not silent) | Fault injection | Must |
| NFR-006 | Operability | Single `example.env` / `.env` contract | Operator dry-run | Must |
| NFR-007 | Performance | Signup path < 10s under demo load (excl. Zoho SLA) | Manual timing | Should |
| NFR-008 | Audit | Gateway WAL retains demo-session call history | Gateway dash | Must |

## Out of NFR

Production HA/DR RPO/RTO; penetration test programme.
