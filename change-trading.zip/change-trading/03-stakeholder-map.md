# Stakeholder map

- **Standard:** [[stakeholder-clarity]]
- **Owner:** BA/PM
- **Updated:** 2026-07-22

| Stakeholder | Interest | Influence | Engagement |
| --- | --- | --- | --- |
| Sponsor (User) | Demo success, honesty, live VM | High | Decide / UAT / secrets |
| Demo audience | Credible story + visuals | Medium | Observe |
| PM (agent) | Pack / RAID / status honesty | Medium | Produce / gate |
| BA (agent) | REQ/AC/data precision | Medium | Produce |
| TA (agent) | Conditions / cases / coverage | Medium | Produce |
| Eng (agent) | Build slices A–H | High | Implement |
| Zoho sandbox tenant | API quotas / module config | Low | Constraint |
| DigitalOcean / Cloudflare | Infra / DNS | Low | Operator |

## RACI link

See `04-raci.md`.
