# Requirements quality / RTM

- **Owner:** BA/TA
- **Updated:** 2026-07-22

## Quality checklist

| Check | Result |
| --- | --- |
| Atomic ids REQ-001..019 | Yes |
| Grain / map refs on data REQs | Yes (`11`) |
| AC coverage | See matrix |
| Ambiguous adjectives | Avoided; Gaps named |

## RTM

| Req | AC | Rule | Test condition | Case |
| --- | --- | --- | --- | --- |
| REQ-001 | AC-001 | — | TC-AUTH-01 | UT/E2E-001 |
| REQ-002 | AC-002/b | BR-001 | TC-SU-01 | E2E-002 |
| REQ-003 | AC-003 | BR-002/009/010 | TC-ZO-01 | E2E-003 |
| REQ-004 | AC-004 | BR-003 | TC-RC-01 | E2E-004 |
| REQ-005 | AC-005 | BR-004 | TC-ZO-02 | E2E-005 |
| REQ-006 | AC-006 | BR-005 | TC-MD-01 | E2E-006 |
| REQ-007 | AC-007/b | BR-006/007 | TC-PT-01/02 | UT-001 |
| REQ-008 | AC-008 | BR-008 | TC-UI-01 | E2E-007 |
| REQ-009 | AC-009 | — | TC-UI-02 | E2E-008 |
| REQ-010 | AC-010 | — | TC-UI-03 | E2E-009 |
| REQ-011 | AC-011 | — | TC-UI-04 | E2E-010 |
| REQ-012 | AC-012 | — | TC-ARCH-01 | RV-001 |
| REQ-013 | AC-013 | — | TC-ARCH-02 | RV-002 |
| REQ-014 | AC-014 | — | TC-DW-01 | E2E-011 |
| REQ-015 | AC-015 | BR-009 | TC-SEC-01 | RV-003 |
| REQ-016 | AC-016 | — | TC-OPS-01 | RV-004 |
| REQ-017 | AC-017 | — | TC-OPS-02 | RV-005 |
| REQ-018 | AC-018 | — | TC-UT-01 | UT-001.. |
| REQ-019 | AC-019 | — | TC-SCOPE-01 | RV-006 |
