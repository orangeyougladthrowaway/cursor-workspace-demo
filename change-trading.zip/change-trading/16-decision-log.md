# Decision log

- **Standard:** [[decision-log]]
- **Owner:** PM
- **Updated:** 2026-07-22

| Id | Decision | Status | Notes |
| --- | --- | --- | --- |
| DEC-001 | Zoho module for customer = **Contact** | Proposed | Confirm on sandbox |
| DEC-002 | Trade attribution = **per customer** (signup customer receives mirrored house signal trades) | Proposed | Simplifies dash story |
| DEC-003 | If Zoho disabled, persist local customer/receipt only; skip Zoho steps skip-closed | Proposed | Local demo without CRM |
| DEC-004 | Draft mail via Zoho API/workflow surface proven on sandbox before AC-005 Agreed | Proposed | Gap |
| DEC-005 | Operator contract = single `.env` from `example.env`; selective compose inject | Accepted | `pat-002` |
| DEC-006 | Accounting explicitly last (slice H) | Accepted | Charter |
| DEC-007 | Pack root `docs/change-trading/`; prior `docs/change/` frozen unused for this mandate | Accepted | Greenfield narrative |
| DEC-008 | Symbols in scope: **KO** and **PEP** only | Accepted | Brief |
