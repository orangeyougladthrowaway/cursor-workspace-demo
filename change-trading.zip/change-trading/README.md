# Change pack — pair-trade demo (greenfield)

**SoT for this mandate.** Do not use `docs/change/` for this product story.

| Doc | Purpose |
| --- | --- |
| [00-change-plan](./00-change-plan.md) | Class, M/R, process path |
| [01–06](./01-initiation-charter.md) | Mandate / frame / stakeholders |
| [07–13](./07-requirements-catalogue.md) | Catalogue, AC, data, rules, NFR, gaps, RTM |
| [14–18](./14-delivery-plan.md) | Delivery / RAID / decisions / status |
| [19–24](./19-test-conditions-coverage.md) | TA + UAT + closure |
| [25-engineering-build-plan](./25-engineering-build-plan.md) | Implementation slices A–H |

Operator env: repo-root [`example.env`](../../example.env) → `.env`.
