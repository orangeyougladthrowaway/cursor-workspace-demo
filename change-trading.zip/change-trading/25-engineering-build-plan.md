# Engineering build plan — pair-trade demo

- **Workflow:** `engineering-knowledge-base-wf-009` ([[plan-engineering-change]])
- **Pattern:** `engineering-knowledge-base-pat-002` (credential-owning bridge) · dual-plane pressure `pat-006`
- **Methods SoT:** `00-change-plan.md` · AC `09` · data `11`
- **Write wall:** this repo only
- **Updated:** 2026-07-22

## Outcome

Ship a runnable pair-trade demo on DigitalOcean: Caddy edge (basic-auth) → web surfaces + gateway; all backend calls via gateway → bridges; warehouse facts for customers/quotes/trades/receipts; Zoho CRM + Spaces receipts; live KO/PEP charts and fake trades.

## Acceptance (build gates)

1. All service calls to privileged capabilities go **only** through the gateway; bridges own secrets (`pat-002`).
2. Operator uses **one** repo-root `.env` copied from `example.env`; compose/`deploy.sh` inject **selected** keys per service (never whole-file broadcast).
3. Signup path creates Zoho customer, receipt object in Spaces, draft Zoho mail (unsent), and DWH customer/receipt rows.
4. Market poll stores KO/PEP quotes; pair-trade rule produces trade rows; customer dash shows trades + charts; business dash aggregates; gateway dash shows WAL calls.
5. Unit tests cover domain rules (pair-trade, hashing/maps as applicable); compose stack healthy locally; cloud path documented.
6. Accounting service **not** started until slices A–G green and sponsor says go.

## Scope

| In | Out | Later |
| --- | --- | --- |
| Gateway, audit_db, storage, zoho, dwh_db, market_data bridge, trade_workflow, web UI, Caddy | Real brokerage APIs | Accounting / GL |
| SQL schemas for trading DWH (replace placeholder object-OCR facts) | Multi-region | Advanced charting productisation |
| CI → DOCR matrix for all runtime images | DOKS | — |

## Architecture (target)

```text
                    Cloudflare DNS ──► Droplet (reserved IPv6 optional)
                                         │
                                      Caddy (:443)
                         basic-auth for all site routes
                    ┌────────┼────────┬────────────┐
                    ▼        ▼        ▼            ▼
               landing   customer  business    gateway-dash
               /signup     dash      dash      (platform WAL UI)
                    │        │        │            │
                    └────────┴────┬───┴────────────┘
                                  ▼
                              gateway ──► audit_db (platform WAL)
                                  │
              ┌───────────────────┼───────────────────┐
              ▼                   ▼                   ▼
         storage_api          zoho_api            dwh_db
         (Spaces)             (CRM+draft mail)    (app warehouse)
              ▲                   ▲                   ▲
              └──────── trade_workflow / market_data ─┘
                        (orchestrators; no vendor secrets)
```

## Binding constraints

- **Single `.env`:** `example.env` is the complete operator contract; runtime is `.env` only.
- **Secret injection:** per-service `environment:` keys only — Zoho vars only on `zoho-bridge`; Spaces only on `storage-bridge`; DB URLs only on owning DB services; Caddy auth only on edge.
- **Optional Zoho:** if disabled via flag owned by orchestrator, skip-closed with structured reason; credential fail-closed **only** on zoho-bridge when enabled (`pat-002`).
- **Happy path only:** no silent fallbacks for missing quote feed or Zoho when enabled.

## Implementation slices (dependency order)

| Slice | Deliverable | Verify |
| --- | --- | --- |
| **A — Platform spine** | Gateway + audit_db + storage + zoho + dwh_db healthy; manifests clean; `example.env` + compose selective inject | `pytest`; compose health |
| **B — Trading DWH DDL** | Replace placeholder OCR facts with customers / quotes / trades / receipts / etlcontrol; dwh_db methods | SQL init on fresh volume; unit tests for mappers |
| **C — Market data** | `market_data` bridge polls KO/PEP; writes quotes via gateway→dwh_db | Mocked poll unit test; one live poll optional |
| **D — Signup journey** | Web signup → trade_workflow: Zoho upsert customer, create receipt, Spaces put, draft mail, DWH rows | Contract tests + Zoho sandbox |
| **E — Pair-trade engine** | Rule: KO↑ & PEP↓ → sell KO / buy PEP (and inverse); persist trades; P&L view model | Pure domain unit tests + integration |
| **F — Dashboards + Caddy** | Four routes; charts from quote history; basic-auth; gateway-dash over platform | Browser UAT checklist |
| **G — Cloud prove** | CI images; `deploy.sh`; Cloudflare A/AAAA → droplet; reserved IPv6 as configured | Sponsor tunnel + health |
| **H — Accounting (last)** | GL / boring ledger — **blocked until A–G accepted** | Separate change-task |

## Service catalogue (planned)

| Service | Role | Owns secrets |
| --- | --- | --- |
| `gateway` | Route + WAL observer | JWT keys only |
| `audit_db` / `db_api` | Platform WAL API | `DATABASE_URL` |
| `storage_api` | Spaces list/get/put | `SPACES_*` |
| `zoho_api` | Contacts/receipts/draft mail | `ZOHO_*` |
| `dwh_db` | Trading warehouse API | `DWH_DATABASE_URL` |
| `market_data` | Quote poll adapter | `MARKET_DATA_API_KEY` (Finnhub) |
| `trade_workflow` | Signup + trade orchestration | **none** (flags only) |
| `web` | Static/SSR UI for four pages | none |
| `caddy` | TLS + basic-auth + reverse proxy | `CADDY_BASIC_AUTH_*` |

## Data planes

| DB | Logical name | Content |
| --- | --- | --- |
| Platform | `platform` | jobs / task_executions / execution_logs |
| App warehouse | `dwh` | customer, quote, trade, receipt, etlcontrol (+ dims/facts as in `11`) |

## Open eng questions (do not invent)

1. Public quote provider + rate limits (Gap).
2. Zoho draft-mail API shape on dummy org (Gap / DEC).
3. Chart library choice (eng craft; not methods).
4. Whether receipt PDF is generated in-process or templated HTML→PDF (eng craft).

## Risks

| Risk | Mitigation |
| --- | --- |
| Quote feed flaky | Cache last good quote; fail-closed on empty with visible dash state |
| Zoho sandbox limits | Dedupe keys; draft-only mail; document quotas |
| Secret bleed via compose | Review every service `environment:` against `example.env` sections |
| Scope creep into accounting | Slice H hard-gated |

## Handoff

Accepted plan → `engineering-knowledge-base-build` slice A first. Methods pack remains SoT for REQ/AC; eng does not invent acceptance.
