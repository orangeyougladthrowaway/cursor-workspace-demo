# SHADOW — scaffold reuse (NOT FOR DEMO)

**Do not show this folder in demos. Do not cite from greenfield pack artefacts.**

This note exists so builders can reuse the pruned repo skeleton without writing migration language into `docs/change-trading/*`.

## Reality

- Repo already contains gateway / audit_db / storage / zoho / dwh_db / OpenTofu / compose / CI.
- OCR/intake paths were removed; placeholder staging/ODS/DWH still describe an **object-OCR** grain — **replace** in slice B, do not extend.
- Frozen prior pack: `docs/change/` (ignore for demo narrative).
- Greenfield SoT: `docs/change-trading/`.

## Reuse map

| Keep / adapt | Replace / delete residual |
| --- | --- |
| `services/gateway/**`, layers, forwarder | Any leftover OCR endpoint env |
| `services/audit_db/**` | — |
| `services/bridges/storage/**` | — |
| `services/bridges/zoho/**` | Retarget methods: customer upsert, receipt attach, **draft** mail |
| `services/bridges/dwh_db/**` | New repository methods for trading schemas |
| `deploy/terraform/**`, `deploy.sh` | APP_DIR `demo-pair-trade`; strip poll script staging |
| `deploy/compose/**` | Add caddy, web, market_data, trade_workflow |
| `domain/ocr_dwh/{scd2,row_hash,etl_run_logger}` | Rename package → `domain/trading` when convenient; drop OCR SQL facts |
| `lib/**` envelopes / observability | — |
| Image name `demo-pair-trade` | Old `demo-ocr-dwh` tags on registry may linger — retag in CI |

## Build sequence vs greenfield story

Demo narrative: greenfield project from day one.  
Builder sequence: slices in `25-engineering-build-plan.md`, starting from existing spine (shadow knowledge only).

## Forbidden leakage

Do not mention OCR, intake, migration, “previous demo”, or this shadow path in:

- `docs/change-trading/00`–`24`
- README customer-facing sections
- UAT scripts shown to audience
