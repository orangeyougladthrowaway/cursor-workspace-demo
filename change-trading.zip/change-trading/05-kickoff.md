# Kickoff

- **Standard:** [[kickoff-honesty]]
- **Owner:** PM
- **Updated:** 2026-07-22

## Purpose

Align on greenfield pair-trade demo mandate, pack location (`docs/change-trading/`), single-`.env` operator model, and **accounting deferred**.

## Agenda (done / standing)

1. Outcome and non-goals (charter)
2. Architecture sketch (gateway-only, four Caddy surfaces)
3. Domain Gaps (quotes, draft mail, DNS)
4. Slice plan A→G then H
5. UAT evidence expectations

## Decisions sought at kickoff

- Confirm customer Zoho module (default **Contacts** pending sponsor).
- Confirm draft-mail approach on sandbox.
- Confirm quote provider once eng proposes options.

## Risks called early

See `15-raid.md` (quote feed, Zoho limits, secret isolation).
