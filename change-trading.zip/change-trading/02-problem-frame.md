# Problem frame

- **Standard:** [[problem-framing]]
- **Owner:** BA · **Charter:** `01-initiation-charter.md`
- **Updated:** 2026-07-22

## Problem statement

We need a single demonstrable product that makes **governance, microservices discipline, warehouse honesty, and CRM integration** visible in one story — without relying on a boring back-office narrative as the hero.

## Current state

No live pair-trade demo product exists for this mandate. Platform building blocks (gateway, bridges, Postgres, deploy) are to be assembled into the product described here.

## Target state

A customer can sign up behind Caddy basic-auth; the system creates a Zoho customer, a receipt (object in Spaces + warehouse row), and a **draft** (unsent) Zoho email; the system continuously reflects KO/PEP prices and applies a published fake pair-trade rule; customer and business dashes show P&L and charts; a gateway dash shows backend call traffic; all privileged I/O is via gateway→bridges.

## Actors

| Actor | Need |
| --- | --- |
| Demo customer | Sign up; see “their” trades and charts |
| Business viewer | See counts, totals, aggregate P&L |
| Operator / sponsor | Deploy, secrets, DNS, UAT |
| Platform observer | See gateway WAL / call history |

## Process (happy path)

1. Operator deploys stack; Cloudflare points at droplet; Caddy enforces basic-auth.
2. Customer opens landing, submits name + DOB + amount.
3. `trade_workflow` (via gateway): upsert Zoho customer → create receipt → put receipt object to Spaces → create draft Zoho mail → write DWH customer/receipt.
4. `market_data` polls KO/PEP → DWH quotes.
5. Pair-trade engine evaluates rule → writes trade(s) → updates P&L views.
6. Customer dash streams/refreshes trades + charts; business dash aggregates; gateway dash reads platform WAL.

## Non-goals

Real order routing; production mail send; full GL/accounting (later); inventing Zoho/DO doctrine beyond vault + sponsor facts.

## Risks to framing

- Quote feed or Zoho sandbox instability → demo theatre fails → mitigate with visible fail states and draft-only mail.
- Scope creep into accounting → blocked by charter.
