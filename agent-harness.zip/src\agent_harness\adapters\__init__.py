"""Cursor adapters — deferred until unattended orchestration is required."""

from __future__ import annotations


class CursorSdkAdapter:
    """Placeholder for @cursor/sdk / cursor-sdk integration."""

    def __init__(self) -> None:
        raise NotImplementedError(
            "Cursor SDK adapter deferred — use IDE skills first (see AGENTS.md)"
        )


class CursorCliAdapter:
    """Placeholder for headless `agent` CLI integration."""

    def __init__(self) -> None:
        raise NotImplementedError(
            "Cursor CLI adapter deferred — use IDE skills first (see AGENTS.md)"
        )
