---
name: harness-create-knowledge-base
description: >-
  Creates and links a new sibling *-knowledge-base under the agent-harness hub.
  Use when asked to add a new knowledge base, vault, or bible for a domain/BU.
disable-model-invocation: true
---

# harness-create-knowledge-base

Follow `docs/workflows/create-knowledge-base.md` (`harness-wf-create-knowledge-base`).

## Rules

1. Token must be `{domain}-knowledge-base` — full kebab, **no new acronyms**.
2. Scaffold structure from an existing vault; never paste foreign doctrine into harness or the new vault as a bulk dump.
3. Update the hub catalogue / workspace / AGENTS only as the workflow lists.
4. Stop when verify steps are done; escalate Gaps to the user.
