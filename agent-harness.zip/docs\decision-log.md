# Decision log — agent-harness

Product-local decisions. Do **not** copy into vault doctrine. Elevate reusable law into engineering-knowledge-base/change-knowledge-base when stable.

| Date | Decision | Why | Elevate? |
| --- | --- | --- | --- |
| 2026-07-17 | Bootstrap in Python with JSON Schema contracts | Matches house Python tooling; schemas are language-agnostic | Later: engineering-knowledge-base agent-engineering if portable |
| 2026-07-17 | IDE-first; SDK adapters stubbed | Avoid API spend until skills/workflows prove | — |
| 2026-07-17 | Single entry = `harness-start` + `start-work` workflow | Task-agnostic classify → one atomic; cascade by pointer not doctrine paste | Later: engineering-knowledge-base agent-engineering if portable |
| 2026-07-18 | Keep separate repos (no monorepo); optional sibling vaults | Authority + ownership per remote; harness works with Gaps if a vault is missing | — |
| 2026-07-18 | Branch model = `main` + `feature/` (`bug/`/`chore/` optional); no Dev/UAT/Prod | Fits doc/vault repos; simpler for non-technical owners | — |
| 2026-07-18 | Require `pytest` on PRs to `main` (all four house repos) | Hard gate without soft CI theatre | — |
| 2026-07-18 | Hub docs: setup + source-control + `harness-create-knowledge-base` | Onboarding and new-vault procedure live in harness; vaults keep thin CONTRIBUTING | — |
| 2026-07-18 | Ephemeral Tasks in gitignored `store/`; no committed `artefacts/` or audit WAL | Resume mid-work without chat; purge on complete with user consent | — |
| 2026-07-18 | Remove write-ahead audit-as-law / `harness-audit-query` | Not valuable in-repo; product audit doctrine stays in engineering-knowledge-base | — |
