"""Deterministic task lifecycle — create, allocate, gate, cancel (in-memory).

For cross-session resume use `agent_harness.task_store.EphemeralTaskStore` (gitignored store/).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _id(prefix: str) -> str:
    return f"{prefix}-{uuid4().hex[:12]}"


@dataclass
class TaskRecord:
    task_id: str
    created_at: str
    goal: str
    profile: str
    status: str = "draft"
    acceptance: list[str] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    parent_task_id: str | None = None
    allowed_vaults: list[str] = field(default_factory=lambda: ["harness"])
    write_mode: str = "read_only"
    cited_ids: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class ControlPlane:
    """In-memory control plane for local/dev and tests."""

    def __init__(self) -> None:
        self.tasks: dict[str, TaskRecord] = {}
        self.allocations: dict[str, dict[str, Any]] = {}

    def create_task(
        self,
        goal: str,
        profile: str,
        *,
        acceptance: list[str] | None = None,
        write_mode: str = "read_only",
        allowed_vaults: list[str] | None = None,
    ) -> TaskRecord:
        task = TaskRecord(
            task_id=_id("task"),
            created_at=_now(),
            goal=goal,
            profile=profile,
            acceptance=acceptance or [],
            write_mode=write_mode,
            allowed_vaults=allowed_vaults or ["harness"],
            status="ready",
        )
        self.tasks[task.task_id] = task
        return task

    def propose_allocation(
        self,
        task_id: str,
        profile: str,
        *,
        proposed_by: str = "human",
        skill_hint: str | None = None,
        workflow_hint: str | None = None,
        cwd_hint: str | None = None,
    ) -> dict[str, Any]:
        if task_id not in self.tasks:
            raise KeyError(f"unknown task_id: {task_id}")
        alloc = {
            "allocation_id": _id("alloc"),
            "task_id": task_id,
            "profile": profile,
            "proposed_by": proposed_by,
            "status": "proposed",
            "skill_hint": skill_hint,
            "workflow_hint": workflow_hint,
            "cwd_hint": cwd_hint,
            "reason": "",
        }
        self.allocations[alloc["allocation_id"]] = alloc
        return alloc

    def accept_allocation(self, allocation_id: str) -> dict[str, Any]:
        alloc = self.allocations[allocation_id]
        alloc["status"] = "accepted"
        return alloc

    def cancel_task(self, task_id: str) -> TaskRecord:
        task = self.tasks[task_id]
        task.status = "cancelled"
        return task
