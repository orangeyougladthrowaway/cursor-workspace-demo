---
name: harness-complete-task
description: >-
  Marks a harness Task done or cancelled and asks whether to purge its ephemeral
  local store record. Use when closing work or cleaning completed leftovers in store/.
disable-model-invocation: true
---

# harness-complete-task

Follow `docs/workflows/complete-task.md` (`harness-wf-complete-task`).

## Rules

1. Set status to `done` or `cancelled` in gitignored `store/` first (if not already).
2. **Ask the user** before deleting local records — do not silently purge.
3. Default offer: purge after close (or after elevating lasting content to product/vault).
4. Never commit `store/`. Never write to `artefacts/`.
