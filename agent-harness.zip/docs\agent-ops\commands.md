# Agent ops — commands

Shell, git, and Task-store rules for **agent-harness** sessions. Not vault doctrine.

On command failure: re-read this page. If the case is **new**, propose a patch here before inventing a workaround.

## Hard rules

| Rule | Do | Do not |
| --- | --- | --- |
| Dependencies | Use the environment the user already has | Local `pip install` / `npm install` / similar unless the user asks |
| Read files | Cursor **Read** / **Grep** / **Glob** | Shell `type` / `Get-Content` / `cat` / `head` |
| Edit files | Cursor **Write** / **StrReplace** | Shell bulk edit unless the user explicitly approves |
| Git | Only when the user explicitly allows | Own-initiative `status` / `commit` / `push` |
| Shell shape | Short commands; PowerShell `;` between steps | Mega one-liners; PowerShell `&&` |
| Task store | File path `store/tasks.json` | Directory `store/` to `EphemeralTaskStore` |

## Prefer tools over shell

| Intent | Prefer |
| --- | --- |
| Open / skim a file | Read |
| Find a symbol | Grep |
| Find a file by name | Glob |
| Change code/docs | Write / StrReplace |
| Run tests (when asked) | Short `pytest` in the target repo cwd |

## PowerShell

```powershell
# Good
Set-Location X:\repos\demo-cloud-data-warehouse; python -m pytest -q

# Bad — && often breaks in Windows PowerShell
cd X:\repos\demo-cloud-data-warehouse && python -m pytest -q
```

One concern per shell call. Prefer multiple short tool calls over one giant script block.

## Git publish (when user asks)

```powershell
Set-Location X:\repos\<repo>
git add -A
git commit -m "short why-focused message"
git push
```

| Rule | Detail |
| --- | --- |
| Allow | Only when the user asks to add / commit / push |
| `git add -A` | Default stage for these repos |
| Message | One `-m` string; prefer why |
| `git push` | Current branch upstream (`-u` on first push of a new branch only) |
| Never | Commit `store/`; force-push `main`; `--no-verify` unless asked |
| Multi-repo | One cwd + sequence per repo |

Branch / PR rules: [`docs/source-control.md`](../source-control.md).

## Task store

```powershell
Set-Location X:\repos\agent-harness
$env:PYTHONPATH = "src"
python -c "from pathlib import Path; from agent_harness.task_store import EphemeralTaskStore, default_store_path; s=EphemeralTaskStore(default_store_path(Path('.'))); rows=s.list_open(); print(len(rows), 'open');
[print(t.get('task_id'), t.get('status'), (t.get('goal') or '')[:80]) for t in rows]"
```

- `list_open()` returns **dicts** — keys `task_id` / `goal` / `status` (not `t.id`).
- Constructor: `default_store_path(Path('.'))` → `store/tasks.json` (file, not directory).
- Never commit `store/`. On `done` / `cancelled`: ask before purge (`harness-complete-task`).
- Do not combine multi-repo git sweeps with Task Python in one command.

## Patterns

| Pattern | Why |
| --- | --- |
| `EphemeralTaskStore(default_store_path(repo_root))` | Correct JSON path |
| Cursor Read / Grep / Glob / patches | Correct I/O surface |
| PowerShell `;` on short steps | Reliable on Windows |
| User-approved `pytest` in repo cwd | Small honest gate |
| User-asked `git add -A` → `commit -m` → `push` (per repo) | House publish sequence |
| Cite vault ids; write only in the allowed wall | Authority split |

## Anti-patterns

| Anti-pattern | Symptom / risk |
| --- | --- |
| `EphemeralTaskStore(Path("…/store"))` | Often `PermissionError` on Windows — wrong path |
| Task row as object (`t.id`) | `AttributeError: 'dict' object has no attribute 'id'` |
| PowerShell `&&` | Parser error on many hosts |
| Multi-repo / huge pasted blocks | Timeouts, quoting breakage |
| Dep installs without ask | Pollutes machine |
| Shell file-read / bulk rewrite | Bypasses tools |
| Git without user allow | History / push surprises |
| Alternate publish ritual when standard was asked | Drift |
| Commit `store/` or write `artefacts/` | Forbidden |

## Related

- `AGENTS.md` · skill `harness-task`
- `docs/workflows/start-work.md` · `docs/workflows/complete-task.md`
