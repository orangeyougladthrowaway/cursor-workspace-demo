# Agent harness

**Start here.** Agent harness is the hub for this workspace — the control plane and runtime for task-triggered staff and coding agents, and the single entry point for all work.

**Not** a fourth knowledge base. Doctrine lives in the sibling knowledge bases below (each optional per role); those vaults point back here as the place to start:

| Vault | Mount (preferred) | Owns |
| --- | --- | --- |
| engineering-knowledge-base | `.engineering-knowledge-base/` or `../engineering-knowledge-base` | Engineering craft, coding-agent rails |
| change-knowledge-base | `.change-knowledge-base/` or `../change-knowledge-base` | PM/BA/TA methods |
| systems-knowledge-base | `.systems-knowledge-base/` or `../systems-knowledge-base` | Domain systems / SoR / process facts |

This repo owns: task/allocation/gate/escalation **schemas**, thin control-plane helpers, Cursor adapters (deferred), and harness-local Cursor config.

**Ephemeral Tasks** may live in gitignored `store/` so you can resume mid-work in a new agent without chat history. Never commit `store/`. On completion, agents ask before purge.

## Start here

- **New user setup:** [`docs/setup.md`](docs/setup.md) (minimum = harness only; vaults optional)
- **Source control:** [`docs/source-control.md`](docs/source-control.md) · [`CONTRIBUTING.md`](CONTRIBUTING.md)
- **Entry skill:** `harness-start` → [`docs/workflows/start-work.md`](docs/workflows/start-work.md)
- **Close Task:** `harness-complete-task` → [`docs/workflows/complete-task.md`](docs/workflows/complete-task.md)
- **New knowledge base:** `harness-create-knowledge-base` → [`docs/workflows/create-knowledge-base.md`](docs/workflows/create-knowledge-base.md)
- Agent notes: [`AGENTS.md`](AGENTS.md)
- Product charter: [`docs/charter.md`](docs/charter.md)
- Schemas: [`schemas/`](schemas/)

## Mode

- **Now:** IDE-first. Prefer **`harness-start`**; it classifies lanes and points at one vault atomic skill at a time.
- **Later:** optional SDK/CLI unattended runs — see `src/adapters/`.

## Layout

```text
schemas/          task / allocation / gate / escalation contracts
src/agent_harness/
  control_plane/  in-memory helpers
  task_store/     ephemeral store/ IO (gitignored path)
  harness/        profile → cwd / write walls
  adapters/       cursor_sdk / cursor_cli (deferred)
docs/             setup, source-control, charter, workflows
.cursor/skills/   harness-start, harness-task, harness-complete-task, harness-create-knowledge-base
store/            gitignored — local resume only (never commit)
```

## Develop

```bash
python -m pip install -e ".[dev]"
pytest tests/ -v
```

CI runs **`pytest`** on pull requests to `main` (required check once branch protection is enabled).
