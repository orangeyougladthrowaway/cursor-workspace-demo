# Source control — house rules

Applies to **agent-harness** and every `*-knowledge-base` repo. Keep local copies thin (`CONTRIBUTING.md` in each repo); this note is the hub summary.

## Publish (agent-ops)

When the user asks to commit/push current work, use the sequence in [`docs/agent-ops/commands.md`](agent-ops/commands.md): `git add -A` → `git commit -m "…"` → `git push` (one repo cwd at a time). Do not invent a different default ritual.

## Branches

| Branch | Use |
| --- | --- |
| `main` | Protected integration line — **PR required** |
| `feature/<short-name>` | Default work |
| `bug/<short-name>` | Fixes (optional prefix) |
| `chore/<short-name>` | Tooling / meta (optional prefix) |

No long-lived `dev` / `uat` / `prod` on these repos. Merge to `main` is the release line for docs and vault health.

**Carve-out:** SQL Server **product** repos with persistent DEV/UAT/PROD instances may use long-lived env branches and release assembly. Doctrine lives in sibling **engineering-knowledge-base** (`sql-env-release-assembly`, `sql-server-env-branches`) — not in this hub table.

## Pull requests

- One concern per PR; prefer small PRs.
- Target `main`.
- **Required check:** the repo’s `pytest` GitHub Actions job must pass before merge (see below).
- Vault content amends still follow that vault’s ingestion / changing-this-bible — branching ≠ doctrine process.
- Ownership is **per remote**: reviewers/CODEOWNERS on that repo; harness does not merge foreign vault PRs.

## CI — pytest on PR

Each house repo runs **pytest** on pull requests to `main` (and on pushes to `main`).

| Repo | Workflow | Job name (require this) |
| --- | --- | --- |
| agent-harness | `.github/workflows/harness-tests.yml` | `pytest` |
| engineering-knowledge-base | `.github/workflows/vault-health.yml` | `pytest` |
| change-knowledge-base | `.github/workflows/vault-health.yml` | `pytest` |
| systems-knowledge-base | `.github/workflows/vault-health.yml` | `pytest` |

### Enable branch protection (human / `gh`)

For **each** remote, after the workflow has run at least once on a PR:

1. Settings → Branches → Add rule for `main`
2. Require a pull request before merging
3. Require status checks to pass → select **`pytest`**
4. (Optional) Require conversation resolution; CODEOWNERS

Example with GitHub CLI (adjust owner/repo):

```bash
gh api repos/<github-org>/agent-harness/branches/main/protection \
  --method PUT \
  --input - <<'EOF'
{
  "required_status_checks": {
    "strict": true,
    "contexts": ["pytest"]
  },
  "enforce_admins": true,
  "required_pull_request_reviews": {
    "required_approving_review_count": 0
  },
  "restrictions": null,
  "allow_force_pushes": false,
  "allow_deletions": false
}
EOF
```

Repeat for `engineering-knowledge-base`, `change-knowledge-base`, and `systems-knowledge-base`. Tune review count and admin enforcement to taste.

## New knowledge bases

New remotes use the **same** branch table and a `pytest` workflow before `main` is protected. See [`docs/workflows/create-knowledge-base.md`](workflows/create-knowledge-base.md).
