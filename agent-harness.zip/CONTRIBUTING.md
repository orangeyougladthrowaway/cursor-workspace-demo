# Contributing — agent-harness

## Branches

| Branch | Use |
| --- | --- |
| `main` | Protected — PR required; **`pytest`** must pass |
| `feature/<short-name>` | Default work |
| `bug/<short-name>` | Fixes (optional) |
| `chore/<short-name>` | Tooling / meta (optional) |

No long-lived `dev` / `uat` / `prod`.

## Pull requests

1. Branch from latest `main` (or your team’s agreed integration branch).
2. Keep the PR focused.
3. Ensure CI job **`pytest`** is green.
4. Merge only via PR into `main`.

House detail: [`docs/source-control.md`](docs/source-control.md).  
New user setup: [`docs/setup.md`](docs/setup.md).  
New vault: skill `harness-create-knowledge-base`.

## Local checks

```bash
python -m pip install -e ".[dev]"
pytest tests/ -v
```
