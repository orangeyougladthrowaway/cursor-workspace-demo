---
name: harness-start
description: >-
  Task-agnostic single entry for work across agent-harness, change-knowledge-base, systems-knowledge-base, and engineering-knowledge-base.
  Use when the user wants to start a project, initiative, investigation, build,
  domain question, or vague “do X” without specifying lane — or asks for a
  programme entry point / cascade across knowledge bases.
disable-model-invocation: true
---

# harness-start

Follow `docs/workflows/start-work.md` (`harness-wf-start-work`).

## Rules

1. Step 0 first: resume open Tasks from gitignored `store/`; ask about completed leftovers (purge vs keep).
2. Classify before acting. Do not assume methods, domain, or engineering.
3. Create or update an ephemeral Task via `harness-task` (local `store/` only — never commit).
4. Propose **one** next atomic skill/workflow only; wait for gate pass before the next lane.
5. Point into vault workflows — never paste change-knowledge-base/systems-knowledge-base/engineering-knowledge-base note bodies.
6. Stop on Gaps; escalate to the user. Do not invent facts or acceptance.
7. If the request is already a single clear atomic (e.g. “run systems-knowledge-base-lookup on X”), classify, record Task lightly, and hand straight to that atomic.
8. If a classified lane’s vault is missing, Gap — do not invent; see `docs/setup.md` and start-work step 4b.
9. Creating a new vault → `harness-create-knowledge-base` (not this skill).
10. Closing work → `harness-complete-task` (ask before purge). No audit-log theatre; no `artefacts/` dumps.
11. Shell / Task-store ops → `docs/agent-ops/commands.md`. On new command failures, check that doc and propose a patch if the case is missing.
