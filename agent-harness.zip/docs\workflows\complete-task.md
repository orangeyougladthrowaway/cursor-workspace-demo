---
id: harness-wf-complete-task
status: draft
description: Close a Task and ask the user whether to purge ephemeral local store records.
updated: 2026-07-18
---

# Complete task

Close in-flight harness work and decide what happens to the **local** resume record under gitignored `store/`.

## Purpose

Tasks exist so a **new agent session** can resume without chat history. Once work is finished, that local record is optional clutter — **ask** before deleting.

## Preconditions

- A `task_id` (from `store/tasks.json` or the user)
- Goal met, cancelled, or user wants to sweep completed leftovers

## Steps

1. **Load** the task via `harness-task` / `EphemeralTaskStore`.
2. If status is not already terminal, set `status` to `done` or `cancelled` (and note why).
3. **Ask the user** (required — do not skip):

   | Option | Meaning |
   | --- | --- |
   | **A — Purge** (default offer) | Delete this task from `store/` now |
   | **B — Keep locally** | Leave in `store/` (still gitignored); will ask again on later start-work sweeps |
   | **C — Elevate then purge** | First copy lasting content to product repo / PR / vault ingestion; then purge |

4. Execute the chosen option. For **A** or **C** after elevate: `EphemeralTaskStore.purge([task_id])`.
5. If sweeping **all** completed leftovers: list `list_completed()`, ask once for batch purge vs keep.

## Output

- Task id + final status
- User choice (A/B/C)
- Whether `store/` still contains this task

## Forbidden

- Silent delete without asking
- Committing `store/`
- Writing closure novels under `artefacts/`
- Treating local store as a compliance audit trail

## Related

- Skills: `harness-complete-task`, `harness-task`, `harness-start`
- Resume entry: `docs/workflows/start-work.md` (step 0)
