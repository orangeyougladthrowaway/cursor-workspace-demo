from __future__ import annotations

import json
from pathlib import Path

import jsonschema
import pytest

ROOT = Path(__file__).resolve().parents[1]
SCHEMAS = ROOT / "schemas"


def _load(name: str) -> dict:
    return json.loads((SCHEMAS / name).read_text(encoding="utf-8"))


@pytest.mark.parametrize(
    "schema_file,instance",
    [
        (
            "task.schema.json",
            {
                "task_id": "task-1",
                "created_at": "2026-07-17T00:00:00Z",
                "goal": "Plan a change",
                "profile": "pm",
                "status": "ready",
            },
        ),
        (
            "allocation.schema.json",
            {
                "allocation_id": "alloc-1",
                "task_id": "task-1",
                "profile": "ba",
                "proposed_by": "human",
                "status": "proposed",
            },
        ),
        (
            "gate-result.schema.json",
            {
                "gate_id": "gate-1",
                "task_id": "task-1",
                "kind": "verification",
                "verdict": "pass",
            },
        ),
        (
            "escalation.schema.json",
            {
                "escalation_id": "esc-1",
                "task_id": "task-1",
                "gap_type": "domain",
                "blocker": "SoR unknown",
                "status": "open",
            },
        ),
    ],
)
def test_schema_accepts_minimal_instance(schema_file: str, instance: dict) -> None:
    schema = _load(schema_file)
    jsonschema.validate(instance=instance, schema=schema)


def test_control_plane_create_and_allocate() -> None:
    from agent_harness.control_plane import ControlPlane

    cp = ControlPlane()
    task = cp.create_task("Frame the problem", "ba", acceptance=["Frame cites change-knowledge-base-s-001"])
    alloc = cp.propose_allocation(
        task.task_id,
        "ba",
        skill_hint="change-knowledge-base-produce",
        workflow_hint="produce-change-artefact",
    )
    cp.accept_allocation(alloc["allocation_id"])
    assert task.status == "ready"
    assert alloc["status"] == "accepted"


def test_profile_bindings_known() -> None:
    from agent_harness.harness import PROFILES, get_profile

    assert set(PROFILES) >= {"eng", "pm", "ba", "ta", "domain", "harness"}
    assert get_profile("eng").default_skill == "engineering-knowledge-base-plan"
    assert get_profile("harness").default_skill == "harness-start"
    assert get_profile("harness").default_workflow == "start-work"


def test_start_work_workflow_exists() -> None:
    path = ROOT / "docs" / "workflows" / "start-work.md"
    assert path.is_file()
    text = path.read_text(encoding="utf-8")
    assert "harness-wf-start-work" in text
    assert "store/" in text
    assert "complete-task" in text
    assert "Do not** write `artefacts/`" in text or "not** write `artefacts/`" in text or "Writing `artefacts/`" in text


def test_complete_task_workflow_exists() -> None:
    path = ROOT / "docs" / "workflows" / "complete-task.md"
    assert path.is_file()
    text = path.read_text(encoding="utf-8")
    assert "harness-wf-complete-task" in text
    assert "Purge" in text


def test_harness_start_skill_exists() -> None:
    path = ROOT / ".cursor" / "skills" / "harness-start" / "SKILL.md"
    assert path.is_file()
    text = path.read_text(encoding="utf-8")
    assert "name: harness-start" in text
    assert "docs/workflows/start-work.md" in text
    assert "harness-complete-task" in text


def test_ephemeral_task_store_round_trip(tmp_path: Path) -> None:
    from agent_harness.task_store import EphemeralTaskStore

    store = EphemeralTaskStore(tmp_path / "tasks.json")
    task = store.create("Resume me", "harness", acceptance=["A1"])
    tid = task["task_id"]
    assert store.get(tid)["goal"] == "Resume me"
    store.update(tid, status="done")
    assert store.list_completed()[0]["task_id"] == tid
    removed = store.purge([tid])
    assert removed == [tid]
    assert store.get(tid) is None


def test_no_artefacts_dir_in_repo() -> None:
    assert not (ROOT / "artefacts").exists()


def test_audit_module_removed() -> None:
    assert not (ROOT / "src" / "agent_harness" / "audit").exists()
    assert not (SCHEMAS / "audit-event.schema.json").exists()
    assert not (ROOT / ".cursor" / "skills" / "harness-audit-query").exists()
