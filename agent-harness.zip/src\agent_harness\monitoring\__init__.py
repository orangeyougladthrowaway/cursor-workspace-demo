"""Platform health signals — stub for stuck runs / queue depth later."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class HealthSnapshot:
    task_count: int
    open_escalations: int
    stuck_runs: int = 0

    @property
    def ok(self) -> bool:
        return self.stuck_runs == 0
