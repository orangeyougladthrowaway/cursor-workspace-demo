"""Agent harness package — control plane, profiles, ephemeral task store, adapters."""

__version__ = "0.1.0"
