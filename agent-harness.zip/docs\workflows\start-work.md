---
id: harness-wf-start-work
status: draft
description: Task-agnostic single entry — classify lanes, ephemeral Task in store/, one next atomic skill/workflow.
updated: 2026-07-18
---

# Start work

Single entry for task-agnostic work across **agent-harness** and the knowledge bases that are present. This workflow **orchestrates**; it does not replace change-knowledge-base / systems-knowledge-base / engineering-knowledge-base procedures.

Known vaults are a **catalogue**, not a mandatory install — see [`docs/setup.md`](../setup.md).

Ephemeral Tasks live only in gitignored `store/` for **resume across agent sessions**. They are never committed. On completion, ask before purge — [`complete-task`](complete-task.md).

## Purpose

Turn a vague or concrete request into a Task, a lane plan, and the next atomic skill/workflow — with gates so work does not skip authority.

## Preconditions

- A user request (goal may be incomplete)
- Access to the vaults needed for the classified lanes **or** willingness to record Gaps if a vault is unavailable

## Do not assume

- That work is a delivery programme
- That BA, PM, or TA must run
- That code must be written
- That domain facts exist in systems-knowledge-base
- That the answer lives in only one vault

## Retrieve (always)

1. `AGENTS.md` (harness) — authority split and write walls
2. `docs/charter.md` — product scope
3. `schemas/task.schema.json` — Task shape (ephemeral store)
4. Only after classification: the **primary** vault’s projection
   - change-knowledge-base → `60-workflows/knowledge/staff-agent-projection.md`
   - systems-knowledge-base → `60-workflows/knowledge/agent-projection.md`
   - engineering-knowledge-base → `60-workflows/knowledge/coding-agent-projection.md`

## Steps

### 0. Resume and stale completed

Using `harness-task` / `EphemeralTaskStore` (`store/tasks.json`):

1. If any tasks with status `done` or `cancelled` remain → **ask the user**: purge completed trail(s) now, or keep locally? (Default offer: purge.) Use [`complete-task`](complete-task.md) / `harness-complete-task`.
2. List **open** tasks (`ready` | `running` | `blocked` | `draft`). If the user is continuing one, load it and skip to step 5 with that context.
3. If the user starts fresh work, continue below.

### 1. Capture request

- Restate the user’s goal in one sentence
- List stated constraints, deadlines, and non-goals
- Mark unknowns explicitly

### 2. Classify (deterministic questions)

Answer each; record on the Task (ephemeral `store/` via `harness-task` — **not** committed dumps):

| Question | Outcome |
| --- | --- |
| Is this primarily **domain truth** (SoR, system, process)? | lane+=`domain` |
| Is this primarily **change methods** (frame, reqs, plan, status, test analysis)? | lane+=`methods` |
| Is this primarily **engineering implementation** (code, tests, CI, packaging)? | lane+=`eng` |
| Is this primarily **harness/platform** (schemas, control plane, docs)? | lane+=`harness` |
| Does eng depend on missing acceptance / intent? | `needs_acceptance=true` |
| Does methods/eng depend on missing domain facts? | `needs_domain=true` |

A request may set **multiple** lanes. Default order:

1. `domain` (if `needs_domain`)
2. `methods` (if methods lane or `needs_acceptance`)
3. `eng` or `harness` (implementation)
4. methods cadence/close only if methods lane remains active

Override order only with an explicit user reason.

### 3. Create or update Task (ephemeral)

Upsert a Task conforming to `schemas/task.schema.json` via `harness-task` → `store/tasks.json`:

- `goal`, `profile` (best-fit primary: `pm` | `ba` | `ta` | `domain` | `eng` | `harness`)
- `acceptance` — may be empty provisional; must be filled before eng **implement**
- `allowed_vaults`, `write_mode`
- `status`: `ready` or `blocked`
- `cited_ids`: [] until steps cite vault ids

Also state the Task fields in the reply so the user can see them. **Do not** write `artefacts/`. **Do not** append audit event logs.

### 4. Gate A — classifiable?

- If classification is impossible → **stop**, ask clarifying questions, Task=`blocked`
- Do not invent domain facts or mandate

### 4b. Detect vault presence

For each lane that will run, check that the owning vault is available (sibling folder, workspace root, or mount `.engineering-knowledge-base` / `.change-knowledge-base` / `.systems-knowledge-base`).

| Lane needs | Vault token |
| --- | --- |
| `domain` / `needs_domain` | `systems-knowledge-base` |
| `methods` / `needs_acceptance` (methods produce) | `change-knowledge-base` |
| `eng` | `engineering-knowledge-base` |
| `harness` | this repo only |

If a needed vault is **missing**:

1. Record an explicit **Gap** (name the vault token).
2. Do **not** invent doctrine, SoR, or acceptance to unblock.
3. Set Task=`blocked` **or** skip that lane after user confirmation (clone the vault, or drop the lane).

Harness-only work proceeds without any knowledge-base sibling.

### 5. Select next atomic action

Pick **one** next action only:

| Condition | Next atomic |
| --- | --- |
| `needs_domain` and no answer yet | systems-knowledge-base skill `systems-knowledge-base-lookup` → workflow `lookup-domain-truth` |
| Domain amend requested in a systems-knowledge-base workspace | `systems-knowledge-base-plan` → later `systems-knowledge-base-amend` |
| Methods lane and no change-task plan yet | `change-knowledge-base-plan` → `plan-change-work` (loads `change-artefact-policy` then pack) |
| Methods produce with named cell/journey | `change-knowledge-base-produce` + **required** workflow name |
| Methods verify/review due | `change-knowledge-base-verify` / `change-knowledge-base-review` |
| Eng and `needs_acceptance` and acceptance empty | Stay in methods **or** ask user for AC — **do not** `engineering-knowledge-base-build` |
| Eng and acceptance present | `engineering-knowledge-base-plan` then later `engineering-knowledge-base-build` / `engineering-knowledge-base-test` / `engineering-knowledge-base-review` |
| Harness lane | Local harness design/implement against schemas/docs; cite charter |
| User asked only a question | Answer via the matching lookup/plan skill; may end after one atomic |

### 6. Execute atomic (pointer only)

- Follow the named vault/harness workflow; do **not** paste its body into harness docs or chat-as-law
- Collect: outputs, cited ids, Gaps/escalations, verdict
- Update the ephemeral Task (`status`, `cited_ids`, next hint) in `store/` as needed

### 7. Gate B — before leaving the lane

Apply what fits:

- Domain: Gaps listed or facts cited — no silent invention
- Methods: change-task acceptance present before eng implement
- Eng: verification evidence before claiming done
- Never soften vault Forbidden lists

If gate fails → Task=`blocked` or return to the owning lane; escalate.

### 8. Loop or stop

- If more lanes/actions remain → return to step 5 with **one** next atomic
- If goal met → set Task=`done`, then **[`complete-task`](complete-task.md)** (ask purge vs keep)
- If user stops mid-flight → leave Task `running`/`blocked` in `store/` for resume; or `cancelled` + complete-task ask
- Optional methods close (`report-status` / `close-delivery`) **only if** methods lane was in scope — deliverables in **consumer/product**, not harness dumps

## Output (every run)

- Task id + status (and that it lives in local `store/` only)
- Classification (lanes, `needs_domain`, `needs_acceptance`)
- Ordered remaining actions
- **Single next atomic** (skill name + workflow stem)
- Open Gaps / questions
- Cited ids so far

## Handoff

Human (or later control plane) invokes the named next skill, then returns here for the following gate — or continues in-session by repeating steps 5–8 without skipping gates.

## Forbidden

- Jumping to `engineering-knowledge-base-build` / code edits with empty acceptance when `needs_acceptance`
- Inventing SoR or mandate to unblock
- Running a full BA/PM/TA pass by default “just in case”
- Reprinting vault doctrine in harness notes
- Declaring work complete because code exists
- Writing `artefacts/` or committing `store/`
- Silent purge of completed tasks without asking
- Append-only audit log theatre as operating law

## Related

- Skills: `harness-start`, `harness-task`, `harness-complete-task`, `harness-create-knowledge-base`
- Vault skills: `change-knowledge-base-*`, `systems-knowledge-base-*`, `engineering-knowledge-base-*` (in owning repos)
- Setup: [`docs/setup.md`](../setup.md) · Source control: [`docs/source-control.md`](../source-control.md)
- Close: [`complete-task`](complete-task.md)
