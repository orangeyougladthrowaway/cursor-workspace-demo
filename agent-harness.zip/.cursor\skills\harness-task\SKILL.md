---
name: harness-task
description: >-
  Creates, updates, lists, or resumes ephemeral harness Tasks in gitignored store/.
  Use for mid-work resume across agent sessions without chat history — never commit store/.
disable-model-invocation: true
---

# harness-task

1. Read `AGENTS.md` and `docs/charter.md`.
2. Shape tasks against `schemas/task.schema.json`.
3. Persist **only** via `agent_harness.task_store.EphemeralTaskStore` → gitignored `store/tasks.json`.
4. Never write programme dumps under `artefacts/`. Never commit `store/`.
5. Do not invent vault doctrine; cite vault ids when the task depends on them.
6. On `done` / `cancelled` → follow `docs/workflows/complete-task.md` (`harness-complete-task`) and **ask** before purge.

## Invoke (ops)

- Commands: `docs/agent-ops/commands.md`
- Path: always `default_store_path(repo_root)` or `…/store/tasks.json` — **never** the `store/` directory.
- Shell: short commands; PowerShell use `;` not `&&`. No local dep installs, no git, no shell file-read/bulk-edit unless the user explicitly allows.
- On a new command failure: check `commands.md`; if missing, propose a patch there.
