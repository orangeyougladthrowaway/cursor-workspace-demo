# Setup — agent-harness house

How to join the house: clone the hub, add only the knowledge bases you need, open a workspace, contribute via PR.

Doctrine stays in the vaults. This repo is the **control plane / hub**.

## Minimum install

1. Clone **agent-harness** next to where you keep repos (example parent: `X:\repos`).
2. Open `agent-harness.minimal.code-workspace` **or** open the `agent-harness` folder alone.
3. Read [`AGENTS.md`](../AGENTS.md) and [`docs/charter.md`](charter.md).
4. For work: invoke skill **`harness-start`** → [`docs/workflows/start-work.md`](workflows/start-work.md).
5. Optional: ephemeral Tasks appear under local gitignored `store/` for resume — **never commit**; on close, agents ask before purge (`harness-complete-task`).
6. Agent shell / git / Task-store: [`docs/agent-ops/commands.md`](agent-ops/commands.md).

Harness-lane work (schemas, control plane, this docs tree) does **not** require any knowledge-base sibling.

## Full house (optional)

Clone vaults as **siblings** of `agent-harness` (same parent directory), then open [`agent-harness.code-workspace`](../agent-harness.code-workspace).

| Vault token | Typical remotes (example) | Typical lanes | Required? |
| --- | --- | --- | --- |
| `engineering-knowledge-base` | `https://github.com/<github-org>/engineering-knowledge-base.git` | eng | Only if you do engineering craft / product coding under house rails |
| `change-knowledge-base` | `https://github.com/<github-org>/change-knowledge-base.git` | methods (PM/BA/TA) | Only if you do change methods |
| `systems-knowledge-base` | `https://github.com/<github-org>/systems-knowledge-base.git` | domain | Only if you need SoR / system / process facts |

**Known vaults are a catalogue, not a mandatory install set.** Marketing-style owners may only need harness + their own future `*-knowledge-base`.

Example layout:

```text
repos/
  agent-harness/
  engineering-knowledge-base/   # optional
  change-knowledge-base/        # optional
  systems-knowledge-base/       # optional
```

```bash
cd X:\repos
git clone https://github.com/<github-org>/agent-harness.git
git clone https://github.com/<github-org>/engineering-knowledge-base.git   # if needed
git clone https://github.com/<github-org>/change-knowledge-base.git        # if needed
git clone https://github.com/<github-org>/systems-knowledge-base.git       # if needed
```

Prefer cloning the branch your team uses for integration (often `feature/init` until `main` is protected and current).

## Mounts (optional)

For single-folder Cursor sessions, junction/symlink a vault into harness:

| Mount | Target |
| --- | --- |
| `.engineering-knowledge-base` | sibling `engineering-knowledge-base` |
| `.change-knowledge-base` | sibling `change-knowledge-base` |
| `.systems-knowledge-base` | sibling `systems-knowledge-base` |

Windows (elevated or developer mode as required):

```bat
mklink /J .engineering-knowledge-base X:\repos\engineering-knowledge-base
mklink /J .change-knowledge-base X:\repos\change-knowledge-base
mklink /J .systems-knowledge-base X:\repos\systems-knowledge-base
```

Mounts are gitignored. Multi-root workspace alone is enough for most people.

## Missing vault → Gap

If `harness-start` / `start-work` classifies a lane whose vault is not present:

1. Record a **Gap** (do not invent doctrine or SoR).
2. Set Task `blocked` or skip that lane with user confirmation.
3. Clone the vault, or drop the lane.

See [`docs/workflows/start-work.md`](workflows/start-work.md) step “Detect vault presence”.

## Contribute

- Branching and PRs: [`docs/source-control.md`](source-control.md) and root [`CONTRIBUTING.md`](../CONTRIBUTING.md).
- PR into the **owning** repo only (do not amend a vault from a harness session).
- New vault: skill **`harness-create-knowledge-base`** → [`docs/workflows/create-knowledge-base.md`](workflows/create-knowledge-base.md).

## Develop harness

```bash
cd agent-harness
python -m pip install -e ".[dev]"
pytest tests/ -v
```
